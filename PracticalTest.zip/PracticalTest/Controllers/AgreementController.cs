﻿using MvcWebApiTest.Models;
using System.Linq;
using System.Web.Http;

namespace MvcWebApiTest.Controllers
{
    public class AgreementController : ApiController
    {
        #region Variables

        static readonly IAgreementRepository agreementRepository = new AgreementRepository();

        #endregion

        #region Constructor

        public AgreementController() { }

        #endregion

        #region Agreement API Methods

        #region Get all Agreements
        // GET api/agreement
        /// <summary>
        /// Get list of all Agreements
        /// </summary>
        [HttpGet]
        public IHttpActionResult GetAllAgreements()
        {
            var agreementList = agreementRepository.GetAll().ToList();
            if (agreementList.Count == 0)
            {
                return NotFound();
            }
            return Ok(agreementList);
        }
        #endregion

        #region Get an Agreement by ID
        // GET api/agreement/{id}
        /// <summary>
        /// Get an Agreement by ID
        /// </summary>
        [HttpGet]
        public IHttpActionResult GetAgreementById([FromUri]int id)
        {
            var agreement = agreementRepository.GetAgreementById(id);
            if (agreement == null)
            {
                return NotFound();
            }
            return Ok(agreement);
        }
        #endregion

        #region Add an Agreement
        // POST api/agreement
        /// <summary>
        /// Add an Agreement
        /// </summary>
        [HttpPost]
        public IHttpActionResult AddAgreement([FromBody]Agreement agreement)
        {
            var objAgreement = agreementRepository.Add(agreement);
            return Ok(objAgreement);
        }
        #endregion

        #region Edit an Agreement by Id
        // PUT api/agreement/{id}
        /// <summary>
        /// Edit an Agreement by id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="agreement"></param>
        /// <returns></returns>
        [HttpPut]
        public IHttpActionResult UpdateAgreement([FromUri]int id, [FromBody]Agreement agreement)
        {
            agreement.Id = id;
            var objAgreement = agreementRepository.Update(agreement);
            return Ok(objAgreement);
        }
        #endregion

        #region Delete an Agreement by Id
        // DELETE api/agreement/{id}
        /// <summary>
        /// Delete an Agreement by Id
        /// </summary>
        [HttpDelete()]
        public IHttpActionResult DeleteAgreement([FromUri]int id)
        {
            var deletedAgreement = agreementRepository.DeleteAgreementById(id);
            if (deletedAgreement == 0)
                return NotFound();
            return Ok(true);
        }
        #endregion

        #region Delete all Agreements
        // DELETE api/agreement
        /// <summary>
        /// Delete all Agreements
        /// </summary>
        /// <returns></returns>
        [HttpDelete()]
        public IHttpActionResult DeleteAllAgreements()
        {
            agreementRepository.DeleteAll();
            return Ok(true);
        }
        #endregion

        #endregion
    }
}
