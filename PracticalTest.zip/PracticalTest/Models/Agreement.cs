﻿using System;
using System.ComponentModel.DataAnnotations;

namespace MvcWebApiTest.Models
{
    public class Agreement
    {
        [Required]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }
        public string Description { get; set; }
        
        [Required]
        public decimal TotalValue { get; set; }

        [Required]
        public DateTime StartDate { get; set; }

        [Required]
        public DateTime EndDate { get; set; }
        
        public int PaymentTerms { get; set; }
    }
}