﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcWebApiTest.Models
{
    public class AgreementRepository : IAgreementRepository
    {
        #region Private Variables
        private List<Agreement> agreements = null;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public AgreementRepository()
        {
            agreements = new List<Agreement>()
            {          
                new Agreement() { Id = 1, Name = "Agreement1", Description="Agreement desc 1", TotalValue = 200.19M, StartDate = new DateTime(2008, 6, 21), EndDate = new DateTime(2009, 11, 2), PaymentTerms = 10 },
                new Agreement() { Id = 2, Name = "Agreement2", Description="Agreement desc 2", TotalValue = 109.20M, StartDate = new DateTime(2009, 3, 28), EndDate = new DateTime(2010, 4, 17), PaymentTerms = 4 },
                new Agreement() { Id = 3, Name = "Agreement3", Description="Agreement desc 3", TotalValue = 532.53M, StartDate = new DateTime(2010, 5, 13), EndDate = new DateTime(2011, 7, 25), PaymentTerms = 8 },
                new Agreement() { Id = 4, Name = "Agreement4", Description="Agreement desc 4", TotalValue = 758.82M, StartDate = new DateTime(2012, 10, 5), EndDate = new DateTime(2013, 1, 7), PaymentTerms = 2 },
                new Agreement() { Id = 5, Name = "Agreement5", Description="Agreement desc 5", TotalValue = 342.75M, StartDate = new DateTime(2004, 1, 11), EndDate = new DateTime(2005, 2, 21), PaymentTerms = 7 },
                new Agreement() { Id = 6, Name = "Agreement6", Description="Agreement desc 6", TotalValue = 862.38M, StartDate = new DateTime(2003, 4, 29), EndDate = new DateTime(2004, 6, 30), PaymentTerms = 9 },
                new Agreement() { Id = 7, Name = "Agreement7", Description="Agreement desc 7", TotalValue = 637.69M, StartDate = new DateTime(2001, 2, 3), EndDate = new DateTime(2002, 9, 11), PaymentTerms = 1 },
                new Agreement() { Id = 8, Name = "Agreement8", Description="Agreement desc 8", TotalValue = 145.15M, StartDate = new DateTime(2006, 8, 7), EndDate = new DateTime(2007, 3, 9), PaymentTerms = 3 },
                new Agreement() { Id = 9, Name = "Agreement9", Description="Agreement desc 9", TotalValue = 451.94M, StartDate = new DateTime(2000, 9, 18), EndDate = new DateTime(2001, 5, 16), PaymentTerms = 6 },
                new Agreement() { Id = 10, Name = "Agreement10", Description="Agreement desc 10", TotalValue = 901.42M, StartDate = new DateTime(2002, 7, 15), EndDate = new DateTime(2003, 12, 16), PaymentTerms = 5 }                
            };
        }
        #endregion

        #region Public Method
        
        #region Get all Agreements
        /// <summary>
        /// Get all Agreements
        /// </summary>
        public IEnumerable<Agreement> GetAll()
        {
            return agreements;
        }
        #endregion

        #region Get an Agreement by id
        /// <summary>
        /// Get an Agreement by id
        /// </summary>
        public Agreement GetAgreementById(int id)
        {
            return agreements.FirstOrDefault(item => item.Id == id);
        }
        #endregion

        #region Add an Agreement
        /// <summary>
        /// Add an Agreement
        /// </summary>
        public Agreement Add(Agreement agreement)
        {
            if (agreement == null)
            {
                throw new ArgumentNullException("Agreement");
            }
            agreement.Id = (agreements.LastOrDefault() != null ? agreements.LastOrDefault().Id : 0) + 1;
            agreements.Add(agreement);
            return agreement;
        }
        #endregion

        #region Update an Agreement
        /// <summary>
        /// Update an Agreement
        /// </summary>
        public Agreement Update(Agreement agreement)
        {
            if (agreement == null)
            {
                throw new ArgumentNullException("Agreement");
            }
            int index = agreements.FindIndex(element => element.Id == agreement.Id);
            agreements.RemoveAt(index);
            agreements.Insert(index, agreement);
            return agreement;
        }
        #endregion

        #region Delete an Agreement
        /// <summary>
        /// Delete an Agreement by id
        /// </summary>
        public int DeleteAgreementById(int id)
        {
            return agreements.RemoveAll(s => s.Id == id);
        }
        #endregion

        #region Delete all Agreements
        /// <summary>
        /// Delete all Agreements
        /// </summary>
        public void DeleteAll()
        {
            agreements.Clear();
        }
        #endregion

        #endregion
    }
}