﻿using System.Collections.Generic;

namespace MvcWebApiTest.Models
{
    interface IAgreementRepository
    {
        IEnumerable<Agreement> GetAll();
        Agreement GetAgreementById(int id);
        Agreement Add(Agreement agreement);
        Agreement Update(Agreement agreement);
        int DeleteAgreementById(int id);
        void DeleteAll();
    }
}
