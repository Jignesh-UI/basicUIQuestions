import { animate, keyframes, state, style, transition, trigger,group } from '@angular/animations';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-ang-animate',
  templateUrl: './ang-animate.component.html',
  styleUrls: ['./ang-animate.component.scss'],
  animations:[
    trigger('divState',[
      state('normal',style({
        'background-color':'red',
        transform:'translateX(0)'
      })),
      state('highlighted',style({
        'background-color':'blue',
        transform:'translateX(100%)'
      })),
      transition('normal <=> highlighted', animate(500)), // Back end forth same animation timing.
      // transition('normal => highlighted', animate(500)),
      // transition('highlighted => normal', animate(1000))
    ]),
    trigger('wildState',[
      state('normal',style({
        'background-color':'red',
        transform:'translateX(0) scale(1)'
      })),
      state('highlighted',style({
        'background-color':'blue',
        transform:'translateX(100px) scale(1)'
      })),
      state('shrunked',style({
        'background-color':'green',
        transform:'translateX(0) scale(0.5)'
      })),
      // transition('normal <=> highlighted', animate(500)), // Back end forth same animation timing.
      transition('normal => highlighted', animate(300)),
      transition('highlighted => normal', animate(800)),
      transition('shrunked <=> *', [
        style({
          'background-color':'orange'
        }),
        animate(1000,style({
          borderRadius:'50px'
        })),
        animate(500)
      ])
    ]),
    trigger('list1',[
      state('in',style({
        opacity:1,
        transform:'translateX(0)'
      })),
      transition('void => *', [
        style({
          opacity:0,
          transform:'translateX(-100px)'
        }),
        animate(500)
      ]),
      transition('* => void', [
        animate(500,
          style({
            opacity:0,
            transform:'translateX(100px)'
          }))
      ]),
    ]),
    trigger('list2',[
      state('in',style({
        opacity:1,
        transform:'translateX(0)'
      })),
      transition('void => *', [ animate(1000, keyframes([
        style({
          transform:'translateX(-100px)',
          opacity:0,
          offset:0
        }),
        style({
          transform:'translateX(-50px)',
          opacity:0.5,
          offset:0.3
        }),
        style({
          transform:'translateX(-20px)',
          opacity:1,
          offset:0.8
        }),
        style({
          transform:'translateX(0px)',
          opacity:1,
          offset:1
        })
      ]) )]),
      transition('* => void', [
        group([
          animate(300,
            style({
              color:'red'
            })),
          animate(800,
            style({
              opacity:0,
              transform:'translateX(100px)'
            }))
        ])

      ]),
    ])
  ]
})
export class AngAnimateComponent implements OnInit {

  state: string = 'normal';
  wildState: string = 'normal';
  list = ['Milk','Sugar','Bread'];
  listItem = '';
  @ViewChild('lstItem') lstItem: ElementRef | undefined;
  constructor() { }

  ngOnInit(): void {
  }

  animate(){
    this.state == 'normal' ? this.state = 'highlighted' : this.state = 'normal';
    this.wildState == 'normal' ? this.wildState = 'highlighted' : this.wildState = 'normal';
  }

  shrunk(){
    this.wildState = 'shrunked';
  }

  addItem(){
    const ne = this.lstItem?.nativeElement
    this.list.push(ne.value);
    ne.value = '';
    ne.focus();
  }

  removeItem(delItem:any){
    this.list.splice(this.list.indexOf(delItem), 1);
  }

  animateStarted(event:any){
    console.log(event)
  }

  animateEnded(event:any){
    console.log(event)
  }

}
