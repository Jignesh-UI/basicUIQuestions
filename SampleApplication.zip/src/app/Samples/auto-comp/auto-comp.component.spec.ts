import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatAutocomplete, MatAutocompleteModule } from '@angular/material/autocomplete';

import { AutoCompComponent } from './auto-comp.component';

describe('AutoCompComponent', () => {
  let component: AutoCompComponent;
  let fixture: ComponentFixture<AutoCompComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AutoCompComponent, MatAutocomplete ],
      imports:[],
      providers:[MatAutocompleteModule]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoCompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
