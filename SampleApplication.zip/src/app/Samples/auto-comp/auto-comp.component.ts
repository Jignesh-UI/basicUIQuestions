import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-auto-comp',
  templateUrl: './auto-comp.component.html',
  styleUrls: ['./auto-comp.component.scss']
})
export class AutoCompComponent implements OnInit {

  myControl = new FormControl();
  options: string[] = ["adeet","adelaide","adelie","adeliae","adele","adenocarcinoma","ade","adenine","aden","adenosine","bathrooms","battle","battles","bathing","bathroom","bat","bath","bats","baths","battlefields","cats","cat","cathedrals","cattle","cathedral","catholicism","catching","catholic","catalogue","catus","date","data","dating","dates","dated","database","dataset","datacraft","datebook","datacenter"];
  filteredOptions: Observable<string[]> | undefined;


  constructor() { }

  ngOnInit(): void {
    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => value.length >1 ? this._filter(value): [])
    );
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();
    console.log(filterValue.length);
      return this.options.filter(option => option.toLowerCase().indexOf(filterValue) === 0);
  }


}
