import { Component, OnInit } from '@angular/core';
import {ThemePalette} from '@angular/material/core';

export interface Task {
  name: string;
  completed: boolean;
  color: ThemePalette;
  subtasks?: Task[];
}

@Component({
  selector: 'app-chk-cmp',
  templateUrl: './chk-cmp.component.html',
  styleUrls: ['./chk-cmp.component.scss']
})
export class ChkCmpComponent implements OnInit {

  myLists = [
    { listTitle: 'Link 1', disabled:false, checked: false },
    { listTitle: 'Link 2', disabled:false, checked: false },
    { listTitle: 'Link 3', disabled:false, checked: false },
    { listTitle: 'None',   disabled:false, checked: false },
    { listTitle: 'Other',  disabled:false, checked: false }
  ];

  constructor() { }

  ngOnInit(): void {
  }

  updateAllComplete1(event:any) {
    if(event.source.value=="None" && event.checked){
      this.myLists.forEach(v => v.disabled = !v.disabled);
      this.myLists.filter(v => v.listTitle=="None")[0].disabled=false;
    }else{
      this.myLists.forEach(v => v.disabled = false);
    }
  }

}
