import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CdataBindingComponent } from './cdata-binding.component';

describe('CdataBindingComponent', () => {
  let component: CdataBindingComponent;
  let fixture: ComponentFixture<CdataBindingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CdataBindingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CdataBindingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
