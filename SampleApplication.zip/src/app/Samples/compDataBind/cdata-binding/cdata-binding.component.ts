import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cdata-binding',
  templateUrl: './cdata-binding.component.html',
  styleUrls: ['./cdata-binding.component.scss']
})
export class CdataBindingComponent implements OnInit {
  serverElements = [{type:'server', name:'First Server', content:'this is the server content'}];

  constructor() { }

  ngOnInit(): void {
  }

  onServerAdded(serverData: {serverName: string, serverContent: string }| any) {
    this.serverElements.push({
      type: 'server',
      name: serverData.serverName,
      content: serverData.serverContent
    });
  }

  onBlueprintAdded(blueprintData: {serverName: string, serverContent: string }| any) {
    this.serverElements.push({
      type: 'blueprint',
      name: blueprintData.serverName,
      content: blueprintData.serverContent
    });
  }

  onChangeFirst(){
    this.serverElements[0].name='Jignesh'
  }
 

}
