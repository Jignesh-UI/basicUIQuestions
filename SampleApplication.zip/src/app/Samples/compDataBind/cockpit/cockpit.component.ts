import { Component, OnInit, EventEmitter, Output, ViewChild, ElementRef } from '@angular/core';

@Component({
  selector: 'app-cockpit',
  templateUrl: './cockpit.component.html',
  styleUrls: ['./cockpit.component.scss']
})
export class CockpitComponent implements OnInit {

 @Output('sCreated') servercreated:any = new EventEmitter<{serverName: string, serverContent: string }>(); // Using this share the values to parent component
 @Output('bpCreated') blueprintcreated:any = new EventEmitter<{serverName: string, serverContent: string }>();// Using this share the values to parent component

 @ViewChild('serverContentInput',{static: true}) serverContentInput!: ElementRef;

  // newServerName = '';
  // newServerContent = '';
  constructor() { }

  ngOnInit(): void {
  }

  onAddServer(serverNameInput: HTMLInputElement) {
    this.servercreated.emit({
      serverName: serverNameInput.value, 
      serverContent: this.serverContentInput.nativeElement.value
    });
    this.resetField(serverNameInput);
  }

  onAddBlueprint(serverNameInput: HTMLInputElement) {
    this.blueprintcreated.emit({
      serverName: serverNameInput.value, 
      serverContent: this.serverContentInput.nativeElement.value
    });
    this.resetField(serverNameInput);
  }

  private resetField(serverInput:HTMLInputElement){
    // this.newServerName='';
    serverInput.value='';
    this.serverContentInput.nativeElement.value='';
    // this.newServerContent='';
  }

}
