import { AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, DoCheck, Input, OnChanges, OnDestroy, OnInit, SimpleChange, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-serverelement',
  templateUrl: './serverelement.component.html',
  styleUrls: ['./serverelement.component.scss'],
  // encapsulation: ViewEncapsulation.Emulated
})
export class ServerelementComponent implements OnInit, OnChanges, DoCheck, AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked, OnDestroy {
  @Input('srvElement')
  element!: { type: string; name: string; content: string; };

  @Input('name') name: string = '';

  constructor() { 
    console.log('Constructor');
  }

  ngOnInit(): void {
    console.log('ngOnInit');
  }

  ngOnChanges(changes: SimpleChange | any){
    console.log('ngOnChanges');
    console.log(changes);
  }

  ngDoCheck(){
    console.log('ngDoCheck');
  }

  ngAfterContentInit(){
    console.log('AfterContentInit');
  }

  ngAfterContentChecked(){
    console.log('AfterContentChecked');
  }
  ngAfterViewInit(){
    console.log('AfterViewInit');
  } 
  ngAfterViewChecked(){
    console.log('AfterViewChecked');
  }
  ngOnDestroy(){
    console.log('ngOnDestroy');
  }



}
