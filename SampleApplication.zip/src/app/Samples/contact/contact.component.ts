import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss']
})
export class ContactComponent implements OnInit {

  username: String = "";
  language = '';
  languages = ['Language 1', 'Language 2']
  constructor() { }

  ngOnInit(): void {
  }

  resetusername(){
    this.username='';
  }

  getColor(){
    return this.username === '' ? 'red' : '#cccccc';
  }

  addLanguage(){
    this.languages.push(this.language)
  }

}
