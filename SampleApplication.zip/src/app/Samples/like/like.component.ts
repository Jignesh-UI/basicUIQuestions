import { Component, OnInit } from '@angular/core';
import { likeComponentScript } from './likeComponent'; 

@Component({
  selector: 'app-like',
  templateUrl: './like.component.html',
  styleUrls: ['./like.component.scss']
})
export class LikeComponent implements OnInit {
 
 likeStatus:any;

  constructor() { }

  ngOnInit(): void {
  }

  btnClick(){
    let c2 = new likeComponentScript(10,true);
    c2.onClick();
    this.likeStatus = 'likesCount: ' + c2.likesCount + ', ' + 'isSelected: ' + c2.isSelected;
  }

  
}
