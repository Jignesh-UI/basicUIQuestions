import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ChildComponent } from "./child/child.component";
import { LangComponent } from "./lang/lang.component";
import { AllmatcompModule } from "../shared/allmatcomp.module";
import { SharedModule } from "../shared/shared-module";
import { CdataBindingComponent } from "./compDataBind/cdata-binding/cdata-binding.component";
import { CockpitComponent } from "./compDataBind/cockpit/cockpit.component";
import { ServerelementComponent } from "./compDataBind/serverelement/serverelement.component";
import { ContactComponent } from "./contact/contact.component";
import { LikeComponent } from "./like/like.component";
import { ParentComponent } from "./parent/parent.component";
import { TbldesignComponent } from "./tbldesign/tbldesign.component";
import { AngAnimateComponent } from "./ang-animate/ang-animate.component";
import { AutoCompComponent } from "./auto-comp/auto-comp.component";
import { ChkCmpComponent } from "./chk-cmp/chk-cmp.component";
import { InputDirectiveComponent } from "../input-directive/input-directive.component";


@NgModule({
    declarations:[
        ParentComponent,
        CdataBindingComponent,
        LikeComponent,
        ContactComponent,
        TbldesignComponent,
        ChildComponent,
        LangComponent,
        ServerelementComponent,
        CockpitComponent,
        AngAnimateComponent,
        AutoCompComponent,
        ChkCmpComponent,
        InputDirectiveComponent
    ],
    exports:[
        ParentComponent,
        CdataBindingComponent,
        LikeComponent,
        ContactComponent,
        TbldesignComponent,
        ChildComponent,
        LangComponent,
        ServerelementComponent,
        CockpitComponent,
        AutoCompComponent,
        ChkCmpComponent,
        InputDirectiveComponent
    ],
    imports:[
        CommonModule,
        FormsModule,
        SharedModule,
        ReactiveFormsModule,
        AllmatcompModule,
    ]
})

export class SamplesModule{}
