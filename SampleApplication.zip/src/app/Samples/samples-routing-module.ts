import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { InputDirectiveComponent } from "../input-directive/input-directive.component";
import { AngAnimateComponent } from "./ang-animate/ang-animate.component";
import { AutoCompComponent } from "./auto-comp/auto-comp.component";
import { ChkCmpComponent } from "./chk-cmp/chk-cmp.component";
import { CdataBindingComponent } from "./compDataBind/cdata-binding/cdata-binding.component";
import { ContactComponent } from "./contact/contact.component";
import { LikeComponent } from "./like/like.component";
import { ParentComponent } from "./parent/parent.component";
import { TbldesignComponent } from "./tbldesign/tbldesign.component";

const samplesRoutes: Routes = [
    { path:'parent', component:ParentComponent},
    { path:'cdatabinding', component:CdataBindingComponent},
    { path:'like', component:LikeComponent},
    { path:'contact', component:ContactComponent},
    { path:'tbldesign', component:TbldesignComponent},
    { path:'animation', component:AngAnimateComponent },
    { path:'autoComp', component:AutoCompComponent},
    { path:'matCheckbox', component:ChkCmpComponent},
    { path:'cDirInput', component:InputDirectiveComponent}

];

@NgModule({
    imports:[RouterModule.forChild(samplesRoutes)],
    exports:[RouterModule]
})

export class SamplesRoutingModule{}
