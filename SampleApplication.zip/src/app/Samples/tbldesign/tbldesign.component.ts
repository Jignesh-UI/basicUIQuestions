import { Component, Input, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import {map, startWith} from 'rxjs/operators';


@Component({
  selector: 'app-tbldesign',
  templateUrl: './tbldesign.component.html',
  styleUrls: ['./tbldesign.component.scss']
})
export class TbldesignComponent implements OnInit {
  @Input() comp: any;
  selectedAction='';
  myControl = new FormControl();
  options: string[] = ['One', 'Two', 'Three'];
  filteredOptions: Observable<string[]> | undefined;
  selected = 'option2';


  task: Task = {
    name: 'Indeterminate',
    completed: false,
    subtasks: [
      {name: 'Primary', completed: false},
      {name: 'Accent', completed: false},
      {name: 'Warn', completed: false}
    ]
  };

  constructor() { }


  ngOnInit(): void {
    console.log(this.constructor.name);
    this.loadStates();
    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value))
    )
  }

  private _filter(value: string): string[]{
    const filterVlaue = value.toLowerCase();
    if(value.length <=1){
      return [];
    }
    return this.options.filter(option => option.toLowerCase().includes(filterVlaue))
  }


  private loadStates() {
    var allStates = 'Alabama, Alaska, Arizona, Arkansas, California, Colorado, Connecticut, Delaware,\
       Florida, Georgia, Hawaii, Idaho, Illinois, Indiana, Iowa, Kansas, Kentucky, Louisiana,\
       Maine, Maryland, Massachusetts, Michigan, Minnesota, Mississippi, Missouri, Montana,\
       Nebraska, Nevada, New Hampshire, New Jersey, New Mexico, New York, North Carolina,\
       North Dakota, Ohio, Oklahoma, Oregon, Pennsylvania, Rhode Island, South Carolina,\
       South Dakota, Tennessee, Texas, Utah, Vermont, Virginia, Washington, West Virginia,\
       Wisconsin, Wyoming';
       
    this.options = allStates.split(',');
 }



  jdata={
    "succeeded": true,
    "data": {
      "assets": [{
        "fields": [{
          "name": "ARTESIA.FIELD.VIDEO.FRAME WIDTH",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.BITMAP WIDTH",
          "value": "5369"
        }, {
          "name": "ARTESIA.FIELD.CONTENT TYPE",
          "value": "BITMAP"
        }, {
          "name": "DAL.FIELD.LICENSING_LIMITATIONS",
          "value": "Licensees Yes;Only minor editing allowed"
        }, {
          "name": "DAL.FIELD.FILE SIZE",
          "value": "12.918"
        }, {
          "name": "DAL.FIELD.ASSET SOURCE",
          "value": "Shutterstock"
        }, {
          "name": "DAL.FIELD.VIDEO SOUND",
          "value": null
        }, {
          "name": "DAL.FIELD.VIDEO DIMENSION",
          "value": null
        }, {
          "name": "DAL.FIELD.ASSET TYPE",
          "value": "Photograph"
        }, {
          "name": "DAL.FIELD.DURATION",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.BITMAP HEIGHT",
          "value": "3232"
        }, {
          "name": "DAL.FIELD.DISTRIBUTION RIGHTS",
          "value": "World"
        }, {
          "name": "DAL.FIELD.BUSINESS UNIT RIGHTS",
          "value": "MHE World"
        }, {
          "name": "ARTESIA.FIELD.VIDEO.FRAME HEIGHT",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.VIDEO.LOW RES LOCATION",
          "value": null
        }, {
          "name": "DAL.FIELD.ADAPTATION RIGHTS",
          "value": "Y"
        }, {
          "name": "DAL.FIELD.MARKETING USE",
          "value": "Broad marketing allowed"
        }, {
          "name": "DAL.FIELD.PROVIDER BU",
          "value": "India"
        }, {
          "name": "DAL.FIELD.VIDEO_ASPECT_RATIO",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.ASSET ID",
          "value": "4ca7deded13f593b523a709f5fd31e86fac237d4"
        }, {
          "name": "DAL.FIELD.CREDIT TEXT",
          "value": "takepicsforfun/Shutterstock"
        }, {
          "name": "DAL.FIELD.DISPLAYED CREDIT REQUIRED",
          "value": "N"
        }, {
          "name": "DAL.FIELD.USAGE RESTRICTIONS",
          "value": ""
        }, {
          "name": "DAL.FIELD.GPS UOIID",
          "value": "ASSET_0002497845"
        }, {
          "name": "DAL.FIELD.ASSET STATUS",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.DATE IMPORTED",
          "value": "2021-03-04 12:50:46.0"
        }, {
          "name": "ARTESIA.FIELD.ASSET NAME",
          "value": "120049636.jpg"
        }, {
          "name": "ARTESIA.FIELD.MODEL",
          "value": "Image"
        }, {
          "name": "DAL.FIELD.TITLE",
          "value": "jahangiri mahal palace in agra fort, india"
        }, {
          "name": "DAL.FIELD.RIGHTS CATEGORY",
          "value": "Royalty Free"
        }],
        "thumbnailUrl": "/mediaportal/services/api/asset/rendition?assetId=4ca7deded13f593b523a709f5fd31e86fac237d4&contentKind=thumbnail",
        "mediumResolutionUrl": "/mediaportal/services/api/asset/rendition?assetId=4ca7deded13f593b523a709f5fd31e86fac237d4&contentKind=screen_res",
        "originalAssetUrl": null,
        "assetId": "4ca7deded13f593b523a709f5fd31e86fac237d4",
        "contentType": "BITMAP",
        "title": "jahangiri mahal palace in agra fort, india",
        "mediaType": "Image",
        "fileName": "120049636.jpg",
        "summaryViewPermission": false,
        "previewViewPermission": false,
        "projectViewPermission": false,
        "exportPermission": true,
        "subscribePermission": false,
        "commentsPermission": false,
        "editMetadataPermission": true,
        "editContentPermission": true,
        "editMembershipPermission": false,
        "deleteAssetPermission": true,
        "editParentsPermission": false,
        "assetView": true
      }, {
        "fields": [{
          "name": "ARTESIA.FIELD.VIDEO.FRAME WIDTH",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.BITMAP WIDTH",
          "value": "2049"
        }, {
          "name": "ARTESIA.FIELD.CONTENT TYPE",
          "value": "BITMAP"
        }, {
          "name": "DAL.FIELD.LICENSING_LIMITATIONS",
          "value": "Licensees Yes;Only minor editing allowed"
        }, {
          "name": "DAL.FIELD.FILE SIZE",
          "value": "7.703"
        }, {
          "name": "DAL.FIELD.ASSET SOURCE",
          "value": "Shutterstock"
        }, {
          "name": "DAL.FIELD.VIDEO SOUND",
          "value": null
        }, {
          "name": "DAL.FIELD.VIDEO DIMENSION",
          "value": null
        }, {
          "name": "DAL.FIELD.ASSET TYPE",
          "value": "Photograph"
        }, {
          "name": "DAL.FIELD.DURATION",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.BITMAP HEIGHT",
          "value": "3071"
        }, {
          "name": "DAL.FIELD.DISTRIBUTION RIGHTS",
          "value": "World"
        }, {
          "name": "DAL.FIELD.BUSINESS UNIT RIGHTS",
          "value": "MHE World"
        }, {
          "name": "ARTESIA.FIELD.VIDEO.FRAME HEIGHT",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.VIDEO.LOW RES LOCATION",
          "value": null
        }, {
          "name": "DAL.FIELD.ADAPTATION RIGHTS",
          "value": "Y"
        }, {
          "name": "DAL.FIELD.MARKETING USE",
          "value": "Broad marketing allowed"
        }, {
          "name": "DAL.FIELD.PROVIDER BU",
          "value": "SEG - ALL"
        }, {
          "name": "DAL.FIELD.VIDEO_ASPECT_RATIO",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.ASSET ID",
          "value": "0f518fc254dd01715b1db6383667afca325fd320"
        }, {
          "name": "DAL.FIELD.CREDIT TEXT",
          "value": "Sarunyu L"
        }, {
          "name": "DAL.FIELD.DISPLAYED CREDIT REQUIRED",
          "value": "Y"
        }, {
          "name": "DAL.FIELD.USAGE RESTRICTIONS",
          "value": ""
        }, {
          "name": "DAL.FIELD.GPS UOIID",
          "value": "ASSET_0000646663"
        }, {
          "name": "DAL.FIELD.ASSET STATUS",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.DATE IMPORTED",
          "value": "2018-12-17 09:32:32.0"
        }, {
          "name": "ARTESIA.FIELD.ASSET NAME",
          "value": "369572519.jpg"
        }, {
          "name": "ARTESIA.FIELD.MODEL",
          "value": "Image"
        }, {
          "name": "DAL.FIELD.TITLE",
          "value": "Beautiful flowers gemstone inlay on white marble at Agra Fort India"
        }, {
          "name": "DAL.FIELD.RIGHTS CATEGORY",
          "value": "Royalty Free"
        }],
        "thumbnailUrl": "/mediaportal/services/api/asset/rendition?assetId=0f518fc254dd01715b1db6383667afca325fd320&contentKind=thumbnail",
        "mediumResolutionUrl": "/mediaportal/services/api/asset/rendition?assetId=0f518fc254dd01715b1db6383667afca325fd320&contentKind=screen_res",
        "originalAssetUrl": null,
        "assetId": "0f518fc254dd01715b1db6383667afca325fd320",
        "contentType": "BITMAP",
        "title": "Beautiful flowers gemstone inlay on white marble at Agra Fort India",
        "mediaType": "Image",
        "fileName": "369572519.jpg",
        "summaryViewPermission": false,
        "previewViewPermission": false,
        "projectViewPermission": false,
        "exportPermission": true,
        "subscribePermission": false,
        "commentsPermission": false,
        "editMetadataPermission": true,
        "editContentPermission": true,
        "editMembershipPermission": false,
        "deleteAssetPermission": true,
        "editParentsPermission": false,
        "assetView": true
      }, {
        "fields": [{
          "name": "ARTESIA.FIELD.VIDEO.FRAME WIDTH",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.BITMAP WIDTH",
          "value": "4000"
        }, {
          "name": "ARTESIA.FIELD.CONTENT TYPE",
          "value": "BITMAP"
        }, {
          "name": "DAL.FIELD.LICENSING_LIMITATIONS",
          "value": "Licensees Yes"
        }, {
          "name": "DAL.FIELD.FILE SIZE",
          "value": "5.882"
        }, {
          "name": "DAL.FIELD.ASSET SOURCE",
          "value": "Shutterstock"
        }, {
          "name": "DAL.FIELD.VIDEO SOUND",
          "value": null
        }, {
          "name": "DAL.FIELD.VIDEO DIMENSION",
          "value": null
        }, {
          "name": "DAL.FIELD.ASSET TYPE",
          "value": "Photograph"
        }, {
          "name": "DAL.FIELD.DURATION",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.BITMAP HEIGHT",
          "value": "2667"
        }, {
          "name": "DAL.FIELD.DISTRIBUTION RIGHTS",
          "value": "World"
        }, {
          "name": "DAL.FIELD.BUSINESS UNIT RIGHTS",
          "value": "MHE World"
        }, {
          "name": "ARTESIA.FIELD.VIDEO.FRAME HEIGHT",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.VIDEO.LOW RES LOCATION",
          "value": null
        }, {
          "name": "DAL.FIELD.ADAPTATION RIGHTS",
          "value": "Y"
        }, {
          "name": "DAL.FIELD.MARKETING USE",
          "value": "Broad marketing allowed"
        }, {
          "name": "DAL.FIELD.PROVIDER BU",
          "value": "McGraw-Hill Education"
        }, {
          "name": "DAL.FIELD.VIDEO_ASPECT_RATIO",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.ASSET ID",
          "value": "b1e1a023d4d4ff29f2a563ff0c2849fd27f419e8"
        }, {
          "name": "DAL.FIELD.CREDIT TEXT",
          "value": "KKulikov/Shutterstock\n"
        }, {
          "name": "DAL.FIELD.DISPLAYED CREDIT REQUIRED",
          "value": "N"
        }, {
          "name": "DAL.FIELD.USAGE RESTRICTIONS",
          "value": ""
        }, {
          "name": "DAL.FIELD.GPS UOIID",
          "value": "ASSET_0001833658"
        }, {
          "name": "DAL.FIELD.ASSET STATUS",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.DATE IMPORTED",
          "value": "2016-08-03 09:08:41.0"
        }, {
          "name": "ARTESIA.FIELD.ASSET NAME",
          "value": "277683689.jpg"
        }, {
          "name": "ARTESIA.FIELD.MODEL",
          "value": "Image"
        }, {
          "name": "DAL.FIELD.TITLE",
          "value": "India. The thrown city of Fatehpur Sikri."
        }, {
          "name": "DAL.FIELD.RIGHTS CATEGORY",
          "value": "Royalty Free"
        }],
        "thumbnailUrl": "/mediaportal/services/api/asset/rendition?assetId=b1e1a023d4d4ff29f2a563ff0c2849fd27f419e8&contentKind=thumbnail",
        "mediumResolutionUrl": "/mediaportal/services/api/asset/rendition?assetId=b1e1a023d4d4ff29f2a563ff0c2849fd27f419e8&contentKind=screen_res",
        "originalAssetUrl": null,
        "assetId": "b1e1a023d4d4ff29f2a563ff0c2849fd27f419e8",
        "contentType": "BITMAP",
        "title": "India. The thrown city of Fatehpur Sikri.",
        "mediaType": "Image",
        "fileName": "277683689.jpg",
        "summaryViewPermission": false,
        "previewViewPermission": false,
        "projectViewPermission": false,
        "exportPermission": true,
        "subscribePermission": false,
        "commentsPermission": false,
        "editMetadataPermission": true,
        "editContentPermission": true,
        "editMembershipPermission": false,
        "deleteAssetPermission": true,
        "editParentsPermission": false,
        "assetView": true
      }, {
        "fields": [{
          "name": "ARTESIA.FIELD.VIDEO.FRAME WIDTH",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.BITMAP WIDTH",
          "value": "4000"
        }, {
          "name": "ARTESIA.FIELD.CONTENT TYPE",
          "value": "BITMAP"
        }, {
          "name": "DAL.FIELD.LICENSING_LIMITATIONS",
          "value": "Licensees Yes"
        }, {
          "name": "DAL.FIELD.FILE SIZE",
          "value": "6.419"
        }, {
          "name": "DAL.FIELD.ASSET SOURCE",
          "value": "Steve Waldron"
        }, {
          "name": "DAL.FIELD.VIDEO SOUND",
          "value": null
        }, {
          "name": "DAL.FIELD.VIDEO DIMENSION",
          "value": null
        }, {
          "name": "DAL.FIELD.ASSET TYPE",
          "value": "Photograph"
        }, {
          "name": "DAL.FIELD.DURATION",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.BITMAP HEIGHT",
          "value": "3000"
        }, {
          "name": "DAL.FIELD.DISTRIBUTION RIGHTS",
          "value": "World"
        }, {
          "name": "DAL.FIELD.BUSINESS UNIT RIGHTS",
          "value": "MHE World"
        }, {
          "name": "ARTESIA.FIELD.VIDEO.FRAME HEIGHT",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.VIDEO.LOW RES LOCATION",
          "value": null
        }, {
          "name": "DAL.FIELD.ADAPTATION RIGHTS",
          "value": "Y"
        }, {
          "name": "DAL.FIELD.MARKETING USE",
          "value": "Broad marketing allowed"
        }, {
          "name": "DAL.FIELD.PROVIDER BU",
          "value": "SEG - ALL"
        }, {
          "name": "DAL.FIELD.VIDEO_ASPECT_RATIO",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.ASSET ID",
          "value": "5b6ddb0e1578bad5dc2b8ed9a77c1ce913e396c9"
        }, {
          "name": "DAL.FIELD.CREDIT TEXT",
          "value": "Stephen Waldron"
        }, {
          "name": "DAL.FIELD.DISPLAYED CREDIT REQUIRED",
          "value": "N"
        }, {
          "name": "DAL.FIELD.USAGE RESTRICTIONS",
          "value": ""
        }, {
          "name": "DAL.FIELD.GPS UOIID",
          "value": "ASSET_0002049377"
        }, {
          "name": "DAL.FIELD.ASSET STATUS",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.DATE IMPORTED",
          "value": "2012-07-06 11:05:19.0"
        }, {
          "name": "ARTESIA.FIELD.ASSET NAME",
          "value": "SEG008954.jpg"
        }, {
          "name": "ARTESIA.FIELD.MODEL",
          "value": "Image"
        }, {
          "name": "DAL.FIELD.TITLE",
          "value": "Agra Fort"
        }, {
          "name": "DAL.FIELD.RIGHTS CATEGORY",
          "value": "Royalty Free"
        }],
        "thumbnailUrl": "/mediaportal/services/api/asset/rendition?assetId=5b6ddb0e1578bad5dc2b8ed9a77c1ce913e396c9&contentKind=thumbnail",
        "mediumResolutionUrl": "/mediaportal/services/api/asset/rendition?assetId=5b6ddb0e1578bad5dc2b8ed9a77c1ce913e396c9&contentKind=screen_res",
        "originalAssetUrl": null,
        "assetId": "5b6ddb0e1578bad5dc2b8ed9a77c1ce913e396c9",
        "contentType": "BITMAP",
        "title": "Agra Fort",
        "mediaType": "Image",
        "fileName": "SEG008954.jpg",
        "summaryViewPermission": false,
        "previewViewPermission": false,
        "projectViewPermission": false,
        "exportPermission": true,
        "subscribePermission": false,
        "commentsPermission": false,
        "editMetadataPermission": true,
        "editContentPermission": true,
        "editMembershipPermission": false,
        "deleteAssetPermission": true,
        "editParentsPermission": false,
        "assetView": true
      }, {
        "fields": [{
          "name": "ARTESIA.FIELD.VIDEO.FRAME WIDTH",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.BITMAP WIDTH",
          "value": "4000"
        }, {
          "name": "ARTESIA.FIELD.CONTENT TYPE",
          "value": "BITMAP"
        }, {
          "name": "DAL.FIELD.LICENSING_LIMITATIONS",
          "value": "Licensees Yes"
        }, {
          "name": "DAL.FIELD.FILE SIZE",
          "value": "5.442"
        }, {
          "name": "DAL.FIELD.ASSET SOURCE",
          "value": "Steve Waldron"
        }, {
          "name": "DAL.FIELD.VIDEO SOUND",
          "value": null
        }, {
          "name": "DAL.FIELD.VIDEO DIMENSION",
          "value": null
        }, {
          "name": "DAL.FIELD.ASSET TYPE",
          "value": "Photograph"
        }, {
          "name": "DAL.FIELD.DURATION",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.BITMAP HEIGHT",
          "value": "3000"
        }, {
          "name": "DAL.FIELD.DISTRIBUTION RIGHTS",
          "value": "World"
        }, {
          "name": "DAL.FIELD.BUSINESS UNIT RIGHTS",
          "value": "MHE World"
        }, {
          "name": "ARTESIA.FIELD.VIDEO.FRAME HEIGHT",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.VIDEO.LOW RES LOCATION",
          "value": null
        }, {
          "name": "DAL.FIELD.ADAPTATION RIGHTS",
          "value": "Y"
        }, {
          "name": "DAL.FIELD.MARKETING USE",
          "value": "Broad marketing allowed"
        }, {
          "name": "DAL.FIELD.PROVIDER BU",
          "value": "SEG - ALL"
        }, {
          "name": "DAL.FIELD.VIDEO_ASPECT_RATIO",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.ASSET ID",
          "value": "7ecdecf40d77c8f32b49884bf87d5d2006a57b48"
        }, {
          "name": "DAL.FIELD.CREDIT TEXT",
          "value": "Stephen Waldron"
        }, {
          "name": "DAL.FIELD.DISPLAYED CREDIT REQUIRED",
          "value": "N"
        }, {
          "name": "DAL.FIELD.USAGE RESTRICTIONS",
          "value": ""
        }, {
          "name": "DAL.FIELD.GPS UOIID",
          "value": "ASSET_0001847813"
        }, {
          "name": "DAL.FIELD.ASSET STATUS",
          "value": null
        }, {
          "name": "ARTESIA.FIELD.DATE IMPORTED",
          "value": "2012-07-06 11:05:19.0"
        }, {
          "name": "ARTESIA.FIELD.ASSET NAME",
          "value": "SEG008953.jpg"
        }, {
          "name": "ARTESIA.FIELD.MODEL",
          "value": "Image"
        }, {
          "name": "DAL.FIELD.TITLE",
          "value": "Agra Fort"
        }, {
          "name": "DAL.FIELD.RIGHTS CATEGORY",
          "value": "Royalty Free"
        }],
        "thumbnailUrl": "/mediaportal/services/api/asset/rendition?assetId=7ecdecf40d77c8f32b49884bf87d5d2006a57b48&contentKind=thumbnail",
        "mediumResolutionUrl": "/mediaportal/services/api/asset/rendition?assetId=7ecdecf40d77c8f32b49884bf87d5d2006a57b48&contentKind=screen_res",
        "originalAssetUrl": null,
        "assetId": "7ecdecf40d77c8f32b49884bf87d5d2006a57b48",
        "contentType": "BITMAP",
        "title": "Agra Fort",
        "mediaType": "Image",
        "fileName": "SEG008953.jpg",
        "summaryViewPermission": false,
        "previewViewPermission": false,
        "projectViewPermission": false,
        "exportPermission": true,
        "subscribePermission": false,
        "commentsPermission": false,
        "editMetadataPermission": true,
        "editContentPermission": true,
        "editMembershipPermission": false,
        "deleteAssetPermission": true,
        "editParentsPermission": false,
        "assetView": true
      }],
      "facets": [{
        "fieldId": "ARTESIA.FIELD.MODEL",
        "fieldPrompt": "Model",
        "valueList": [{
          "value": "Images",
          "count": 5
        }]
      }, {
        "fieldId": "DAL.FIELD.ASSET TYPE",
        "fieldPrompt": "Asset Type",
        "valueList": [{
          "value": "Photograph",
          "count": 5
        }]
      }, {
        "fieldId": "DAL.FIELD.BUSINESS UNIT RIGHTS",
        "fieldPrompt": "Business Unit Rights",
        "valueList": [{
          "value": "MHE World",
          "count": 5
        }]
      }, {
        "fieldId": "DAL.FIELD.ADAPTATION RIGHTS",
        "fieldPrompt": "Adaptation Rights",
        "valueList": [{
          "value": "Yes",
          "count": 5
        }]
      }, {
        "fieldId": "DAL.FIELD.RIGHTS CATEGORY",
        "fieldPrompt": "Rights Category",
        "valueList": [{
          "value": "Royalty Free",
          "count": 5
        }]
      }, {
        "fieldId": "DAL.FIELD.USAGE RESTRICTIONS",
        "fieldPrompt": "Usage Restrictions",
        "valueList": []
      }, {
        "fieldId": "DAL.FIELD.DISTRIBUTION RIGHTS",
        "fieldPrompt": "Distribution Rights",
        "valueList": [{
          "value": "World",
          "count": 5
        }]
      }, {
        "fieldId": "DAL.FIELD.ORIENTATION",
        "fieldPrompt": "Orientation",
        "valueList": [{
          "value": "Horizontal",
          "count": 4
        }, {
          "value": "Vertical",
          "count": 1
        }]
      }, {
        "fieldId": "DAL.FIELD.GENDER",
        "fieldPrompt": "Gender",
        "valueList": []
      }, {
        "fieldId": "DAL.FIELD.AGE GROUP",
        "fieldPrompt": "Age Group",
        "valueList": []
      }, {
        "fieldId": "DAL.FIELD.NUMBER OF PEOPLE",
        "fieldPrompt": "Number of People",
        "valueList": [{
          "value": "Nobody",
          "count": 4
        }, {
          "value": "Three People",
          "count": 1
        }]
      }, {
        "fieldId": "DAL.FIELD.ETHNICITY",
        "fieldPrompt": "Ethnicity",
        "valueList": [{
          "value": "Mixed group",
          "count": 1
        }]
      }, {
        "fieldId": "DAL.FIELD.SPECIAL NEEDS",
        "fieldPrompt": "Special Needs",
        "valueList": [{
          "value": "No",
          "count": 4
        }]
      }, {
        "fieldId": "DAL.FIELD.GENRE",
        "fieldPrompt": "Genre",
        "valueList": [{
          "value": "Architecture",
          "count": 2
        }, {
          "value": "Historical & Archival",
          "count": 2
        }, {
          "value": "Travel & Geography",
          "count": 2
        }, {
          "value": "Religion & Spirituality",
          "count": 1
        }]
      }, {
        "fieldId": "DAL.FIELD.CHARACTERISTICS",
        "fieldPrompt": "Characteristics",
        "valueList": []
      }, {
        "fieldId": "DAL.FIELD.LANGUAGE",
        "fieldPrompt": "Language",
        "valueList": []
      }, {
        "fieldId": "DAL.FIELD.ASSET SOURCE",
        "fieldPrompt": "Asset Source",
        "valueList": [{
          "value": "Shutterstock",
          "count": 3
        }, {
          "value": "Steve Waldron",
          "count": 2
        }]
      }, {
        "fieldId": "DAL.FIELD.PROVIDER BU",
        "fieldPrompt": "Provider BU",
        "valueList": [{
          "value": "SEG - ALL",
          "count": 3
        }, {
          "value": "India",
          "count": 1
        }, {
          "value": "McGraw-Hill Education",
          "count": 1
        }]
      }, {
        "fieldId": "DAL.FIELD.RETAIL COLLECTION",
        "fieldPrompt": "Retail Collection",
        "valueList": [{
          "value": "Shutterstock RF",
          "count": 2
        }, {
          "value": "Stephen Waldron RF",
          "count": 2
        }]
      }, {
        "fieldId": "DAL.FIELD.ASSET FORMAT",
        "fieldPrompt": "Asset Format",
        "valueList": [{
          "value": "Raster",
          "count": 5
        }]
      }, {
        "fieldId": "DAL.FIELD.FINALIZED FLAG",
        "fieldPrompt": "Finalized Flag",
        "valueList": [{
          "value": "Yes",
          "count": 5
        }]
      }, {
        "fieldId": "DAL.FIELD.LICENSING_LIMITATIONS",
        "fieldPrompt": "Licensing Limitations",
        "valueList": [{
          "value": "Licensees Yes",
          "count": 5
        }, {
          "value": "Only minor editing allowed",
          "count": 2
        }]
      }, {
        "fieldId": "DAL.FIELD.ASSET STATUS",
        "fieldPrompt": "Asset Status",
        "valueList": []
      }, {
        "fieldId": "DAL.FIELD.VIDEO SOUND",
        "fieldPrompt": "Video Sound",
        "valueList": []
      }, {
        "fieldId": "DAL.FIELD.COLORBW FACET",
        "fieldPrompt": "Color B&W",
        "valueList": [{
          "value": "Color",
          "count": 5
        }]
      }, {
        "fieldId": "DAL.FIELD.MARKETING USE",
        "fieldPrompt": "Marketing Use",
        "valueList": [{
          "value": "Broad marketing allowed",
          "count": 5
        }]
      }, {
        "fieldId": "DAL.FIELD.VIDEO DIMENSION",
        "fieldPrompt": "Video Dimension",
        "valueList": []
      }],
      "pageNumber": 0,
      "countPerPage": 50,
      "totalCount": 5,
      "originalSearchReq": {
        "keyword": "agra fort",
        "pageNumber": 0,
        "countPerPage": 50,
        "modeFFU": true,
        "facets": [],
        "sortFields": [{
          "sortFieldId": "ARTESIA.FIELD.DATE IMPORTED",
          "sortOrder": "desc"
        }],
        "metadataFields": [],
        "facetRestrictionFields": [{
          "fieldId": "DAL.FIELD.BUSINESS UNIT RIGHTS",
          "fieldPrompt": null,
          "valueList": [{
            "value": "MHE World",
            "count": 0
          }, {
            "value": "MHE USA",
            "count": 0
          }]
        }, {
          "fieldId": "DAL.FIELD.ADAPTATION RIGHTS",
          "fieldPrompt": null,
          "valueList": [{
            "value": "Yes",
            "count": 0
          }]
        }]
      },
      "originalExpertSearchRequest": null
    },
    "message": ""
  }
  allComplete: boolean = false;

  updateAllComplete() {
    this.allComplete = this.task.subtasks != null && this.task.subtasks.every(t => t.completed);
  }

  someComplete(): boolean {
    if (this.task.subtasks == null) {
      return false;
    }
    return this.task.subtasks.filter(t => t.completed).length > 0 && !this.allComplete;
  }

  setAll(completed: boolean) {
    this.allComplete = completed;
    if (this.task.subtasks == null) {
      return;
    }
    this.task.subtasks.forEach(t => t.completed = completed);
  }

  changeSelectionState(){

    if(this.selectedAction === '1'){
      console.log("All");
      this.task.subtasks?.forEach(t=> t.completed = true)
    }else if(this.selectedAction === '2'){
      console.log("Remove All")
    }

    setTimeout(() => {
      this.selectedAction = '';
    }, 50) 

  }

}



export interface Task {
  name: string;
  completed: boolean;
  subtasks?: Task[];
}