import { HttpClient } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { ColDef, GridReadyEvent } from 'ag-grid-community';
import 'ag-grid-enterprise';
import { ActivatedRoute, Router} from '@angular/router';


@Component({
  selector: 'app-ag-grid',
  templateUrl: './ag-grid.component.html',
  styleUrls: ['./ag-grid.component.scss']
})
export class AgGridComponent implements OnInit {

rowData?: any[] | null ;
@ViewChild('agGrid') agGrid!: AgGridAngular;

  title:boolean = false;
  pageLoadMethod:any;
  txt:string = '';


  constructor(private http: HttpClient, private route: ActivatedRoute, public router: Router) { 
  }

  ngOnInit(): void {
    this.loadData();
  }

  columnDefs: ColDef[] = [
    {minWidth: 200, maxWidth:500, resizable: true, field: 'make', sortable: true, filter:true },
    {minWidth: 200, maxWidth:500, resizable: true, field: 'model', sortable: true, filter:true },
    {minWidth: 200, maxWidth:500, resizable: true, field: 'price', sortable: true, filter:true },
    
];

onFirstDataRendered(params:any) {
  params.api.sizeColumnsToFit();
}

  loadData(){
    this.http.get<any[]>('https://www.ag-grid.com/example-assets/row-data.json').subscribe(sdata =>{
      this.rowData = sdata
    });
  }

  getSelectedRows(): void {
    const selectedNodes = this.agGrid.api.getSelectedNodes();
        const selectedData = selectedNodes.map(node => {
          if (node.groupData) {
            return { make: node.key, model: 'Group' };
          }
          return node.data;
        });
        const selectedDataStringPresentation = selectedData.map(node => `${node.make} ${node.model}`).join(', ');

        alert(`Selected nodes: ${selectedDataStringPresentation}`);
  }

  

}
