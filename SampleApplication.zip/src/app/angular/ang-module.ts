import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { AngQuestionComponent } from "./ang-question/ang-question.component";
import { EcmaQuestionComponent } from "./ecma-question/ecma-question.component";
import { JsQuestionComponent } from "./js-question/js-question.component";
import { VueQuestionComponent } from "./vue-question/vue-question.component";

@NgModule({
    declarations:[
        AngQuestionComponent,
        JsQuestionComponent,
        VueQuestionComponent,
        EcmaQuestionComponent
    ],
    exports:[
        AngQuestionComponent,
        JsQuestionComponent,
        VueQuestionComponent,
        EcmaQuestionComponent
    ],
    imports:[
        CommonModule,
    ],
    providers:[]
})


export class angModule{ }