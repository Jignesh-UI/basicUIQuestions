import { Component, OnInit } from '@angular/core';
import { TechdataService } from '../service/angdata.service';

@Component({
  selector: 'app-ang-question',
  templateUrl: './ang-question.component.html',
  styleUrls: ['./ang-question.component.scss']
})
export class AngQuestionComponent implements OnInit {

  dataArray:dataInterface[]=[];

  constructor(private angdata: TechdataService) { }

  ngOnInit(): void {
    this.loadData();
  }

  loadData(){
    this.angdata.listData('ang').subscribe((data: dataInterface[])=>{
      this.dataArray = data;
      return data;
    })
  }

}

export interface dataInterface{
  question:string
}