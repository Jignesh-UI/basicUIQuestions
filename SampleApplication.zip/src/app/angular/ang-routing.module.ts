import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { AiComponent } from "./ai/ai.component";
import { AngQuestionComponent } from "./ang-question/ang-question.component";
import { DjangoComponent } from "./django/django.component";
import { EcmaQuestionComponent } from "./ecma-question/ecma-question.component";
import { JavaComponent } from "./java/java.component";
import { JsQuestionComponent } from "./js-question/js-question.component";
import { MatlabComponent } from "./matlab/matlab.component";
import { OracleComponent } from "./oracle/oracle.component";
import { PhpComponent } from "./php/php.component";
import { PythonComponent } from "./python/python.component";
import { VueQuestionComponent } from "./vue-question/vue-question.component";


const angRoutes: Routes = [
    { path: 'angQuestion', component:AngQuestionComponent },
    { path: 'jsQuestion', component:JsQuestionComponent },
    { path: 'vueQuestion', component:VueQuestionComponent},
    { path: 'ecmaQuestion', component:EcmaQuestionComponent},
    { path: 'oracle', component:OracleComponent},
    { path: 'php', component:PhpComponent},
    { path: 'django', component:DjangoComponent},
    { path: 'matlab', component:MatlabComponent},
    { path: 'java', component:JavaComponent},
    { path: 'python', component:PythonComponent},
    { path: 'ai', component:AiComponent},

];

@NgModule({
    imports:[RouterModule.forChild(angRoutes)],
    exports:[RouterModule]
})

export class angRoutingModule{}
