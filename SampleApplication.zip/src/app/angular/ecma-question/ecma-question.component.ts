import { Component, OnInit } from '@angular/core';
import { TechdataService } from '../service/angdata.service';

@Component({
  selector: 'app-ecma-question',
  templateUrl: './ecma-question.component.html',
  styleUrls: ['./ecma-question.component.scss']
})
export class EcmaQuestionComponent implements OnInit {

  dataArray:dataInterface[]=[];

  constructor(private angdata: TechdataService) { }

  ngOnInit(): void {
    this.loadData();
  }

  loadData(){
    this.angdata.listData('ecma').subscribe((data: any[])=>{
      this.dataArray = data;
    })
  }

}

export interface dataInterface{
  title:string
}
