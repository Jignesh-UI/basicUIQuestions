import { HttpClient, HttpHandler } from '@angular/common/http';
import { NO_ERRORS_SCHEMA } from '@angular/compiler';
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JsQuestionComponent } from './js-question.component';

describe('JsQuestionComponent', () => {
  let component: JsQuestionComponent;
  let fixture: ComponentFixture<JsQuestionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      providers:[HttpClient, HttpHandler],
      declarations: [ JsQuestionComponent ],
      schemas:[NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(JsQuestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
