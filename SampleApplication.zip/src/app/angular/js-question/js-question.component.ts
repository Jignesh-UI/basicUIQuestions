import { Component, OnInit } from '@angular/core';
import { TechdataService } from '../service/angdata.service';

@Component({
  selector: 'app-js-question',
  templateUrl: './js-question.component.html',
  styleUrls: ['./js-question.component.scss']
})
export class JsQuestionComponent implements OnInit {

  dataArray:dataInterface[]=[];

  constructor(private angdata: TechdataService) { }

  ngOnInit(): void {
    this.loadData();
  }

  loadData(){
    this.angdata.listData('javascript').subscribe((data: dataInterface[])=>{
      this.dataArray = data;
      return data;
    })
  }

}

export interface dataInterface{
  question:string
}