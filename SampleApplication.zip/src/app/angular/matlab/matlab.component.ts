import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-matlab',
  templateUrl: './matlab.component.html',
  styleUrls: ['./matlab.component.scss']
})
export class MatlabComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
