import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oracle',
  templateUrl: './oracle.component.html',
  styleUrls: ['./oracle.component.scss']
})
export class OracleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
