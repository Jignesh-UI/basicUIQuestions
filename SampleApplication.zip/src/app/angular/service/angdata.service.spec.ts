import { HttpClient, HttpHandler } from '@angular/common/http';
import { NO_ERRORS_SCHEMA } from '@angular/compiler';
import { TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';

import { TechdataService } from './angdata.service';

describe('TechdataService', () => {
  let service: TechdataService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[RouterTestingModule, FormsModule, ReactiveFormsModule],
      providers:[HttpClient, HttpHandler],
      schemas:[NO_ERRORS_SCHEMA]
    });
    service = TestBed.inject(TechdataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
