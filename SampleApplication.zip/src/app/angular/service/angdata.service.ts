import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TechdataService {

  urlang:string = "../../assets/localData/angular.data.json";
  arrayData:dataInterface[]=[];
  constructor(private http: HttpClient) { }

  listData(tech:string){
    if(tech === 'ang'){
      this.urlang = "../../assets/localData/angular.data.json";
    }else if(tech === 'javascript'){
      this.urlang = "../../assets/localData/js.data.json";
    }else if(tech === 'vue'){
      this.urlang = "../../assets/localData/vue.data.json";
    }else if(tech === 'ecma'){
      this.urlang = "../../assets/localData/ecma.data.json";
    }
    return this.http.get<dataInterface[]>(this.urlang);
  }

}


export interface dataInterface{
  question:string;
}