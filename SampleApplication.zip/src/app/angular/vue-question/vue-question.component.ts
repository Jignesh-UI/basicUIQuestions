import { Component, OnInit } from '@angular/core';
import { TechdataService } from '../service/angdata.service';

@Component({
  selector: 'app-vue-question',
  templateUrl: './vue-question.component.html',
  styleUrls: ['./vue-question.component.scss']
})
export class VueQuestionComponent implements OnInit {

  dataArray:dataInterface[]=[];

  constructor(private angdata: TechdataService) { }

  ngOnInit(): void {
    this.loadData();
  }

  loadData(){
    this.angdata.listData('vue').subscribe((data: dataInterface[])=>{
      this.dataArray = data;
      return data;
    })
  }

}

export interface dataInterface{
  question:string
}
