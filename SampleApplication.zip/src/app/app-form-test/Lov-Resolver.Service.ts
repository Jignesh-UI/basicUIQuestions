import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from "@angular/router";
import { Observable } from "rxjs";
import { LovDataService } from "./lov-data.service";

@Injectable({providedIn:'root'})
export class LOVResolverService implements Resolve<any[]>{

    constructor(private lovDataService: LovDataService){}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): any[] | Observable<any[]> | Promise<any[]> {
        return this.lovDataService.loadListofLovs();
    } 

}