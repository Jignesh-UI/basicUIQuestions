import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Component, ComponentFactoryResolver, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, Subscription } from 'rxjs';

import { map } from 'rxjs/operators';
import { AlertDynamicComponent } from '../shared/alert-dynamic/alert-dynamic.component';
import { DialogComponent } from '../shared/dialog/dialog.component';
import { PlaceholderDirective } from '../shared/placeholder/placeholder.directive';
import { Details, chkInterface, leadData, lovInterface, Summary } from './arc-record.model';
import { LovDataService } from './lov-data.service';
import { NotificationService } from './notification.service';

@Component({
  selector: 'app-app-form-test',
  templateUrl: './app-form-test.component.html',
  styleUrls: ['./app-form-test.component.scss']
})
export class AppFormTestComponent implements OnInit {

  archiveData = new Summary();
  archiveInfo = new Details();
  compositors: any[]=[];
  layeredArt = true;
  Scans = true;
  Endsheets = true;
  Insert = true;
  message = '';
  iserror = false;
  isShow = false;
  today = '';
  userName: string='';
  commnetsRows = 5;
  archiveNotesRows = 8;
  repcommnetsRows = 2;
  disabledPDHField: boolean = true;

  archivistArray: lovInterface[] = [];
  compVendorArray: lovInterface[] = [];

  pagingFilesArray: chkInterface[] = [];
  otherFilesArray: chkInterface[] = [];
  PDFsArray: chkInterface[] = [];

  compVendorOther:string = '';
  reprintContactOther:string ='';
  pagingFilesOther:string = '';
  otherFilesOther:string = '';

  maxLengthofControls = {
    'mhidMaxLength': 15,
    'ISBN13MaxLength': 50,
    'PREVIOUS_ISBNMaxLength': 15,
    'NEW_ISBNMaxLength': 15,
    'authorMaxLength': 240,
    'titleMaxLength': 1500,
    'editionMaxLength': 22,
    'priorityMaxLength': 16,
    'ODDMaxLength': 150,
    'SDDMaxLength': 150,
    'CopyYearMaxLength': 22,
    'calculatedBBDMaxLength': 7,
    'PermissionEndDateMaxLength': 7,
    'projectOPDateMaxLength': 7,
    'DeliveryFormatMaxLength': 150,
    'TitleTypeMaxLength': 240,
    'GradeRangeMaxLength': 5,
    'SpecificMarketMaxLength': 150,
    'ipubPublishingGroupMaxLength': 20,
    'iPubProgramTitleMaxLength': 500,
    'noOfPagesMaxLength': 22,
    'LibraryLocationMaxLength': 500,
    'PrintingMaxLength': 22,
    'SetsofDiscsMaxLength': 22,
    'DiscsinSetMaxLength': 22,
    'DiscSizeMaxLength': 22,
    'ArchiveNotesMaxLength': 4000,
    'MB_GBMaxLength': 2
  };

  recordInformation = {
    recordid: null,
    dateCreated: null,
    createdBy: '',
    dateLastModified: null,
    lastModifiedBy: null,
  }

  showReprintInput: boolean = false;
  showCompVendor: boolean = false;

  searchedMHID="";
  searchedISBN="";
  unSaved: boolean = true;

  flagShowCmp:boolean=false;

  @ViewChild(PlaceholderDirective) alertHost!: PlaceholderDirective;

  private headers = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }

  downloadDueDate:string = "";

  private closeSub: Subscription = new Subscription();
  constructor(private http: HttpClient,
    private activatedRoute: ActivatedRoute, private router: Router, private notify: NotificationService,
    private lovData: LovDataService,
    private dialog: MatDialog,
    private componentFactoryResolver: ComponentFactoryResolver) {
    this.router.onSameUrlNavigation = 'reload';

      activatedRoute.params.subscribe(val => {
        console.log('Route Re-Loaded');
        // put the code from `ngOnInit` here
      });
  }

  searchChange(event:any) {
    if(this.downloadDueDate.length < 1){
      this.downloadDueDate = "";
    }else{
      this.downloadDueDate = this.downloadDueDate.trim();
    }
  }

  showCmp(){
    this.showErrorAlert();
    this.router.navigate(['/testApp'], { queryParams: { index: 1 } });
  }
  onHandleAlert(){
    this.message='';
    this.flagShowCmp=false;
  }

  showErrorAlert(){
    this.message = "This is the Dynamic Content message. ";
    this.flagShowCmp = !this.flagShowCmp;
    const alertDynCmpFactory =  this.componentFactoryResolver.resolveComponentFactory(AlertDynamicComponent);
    const hostViewContainerRef = this.alertHost.viewContainerRef;
    hostViewContainerRef.clear();
    const cmpRef = hostViewContainerRef.createComponent(alertDynCmpFactory);
    cmpRef.instance.infoData = this.archiveInfo;
    cmpRef.instance.detailData = this.archiveData;
    this.closeSub = cmpRef.instance.close.subscribe(()=>{
      this.closeSub.unsubscribe();
      hostViewContainerRef.clear();
    });

  }

  canDeactivate(): Observable<boolean> | boolean {

      const data = {
        title:'Please Confirm!',
        message: 'You have not saved your current work. Do you want to proceed and discard?',
        buttonYesCaption: 'Stay On the Page!',
        buttonNoCaption: 'Navigate to Another Page!',
        success: (e: any) => {
          console.log(e);
          return false;
        },
        cancel: (e: any) => {
          console.log(e);
          return true;
        }
      };
      const dialogRef = this.dialog.open(DialogComponent, {
        width: '600px',
        height: '250px',
        data: data
      });
      return dialogRef.afterClosed();
}

  async ngOnInit(): Promise<void> {
    this.archiveData = new Summary();
    this.archiveInfo = new Details();
    await this.loadLovs();
  }

  searchByMHID(input: string) {
    const url: string = "../../assets/localData/data.json";
    this.http.get<leadData[]>(url)
      .pipe(map(responseData => {
        console.log(responseData)
        const summaryData:any[]=[];
        for (const keys in responseData) {
          if (responseData.hasOwnProperty(keys) && keys === 'data') {
            summaryData.push(responseData[keys]);
          }
        }
        return summaryData[0];
      })).
    subscribe(responseData => {
      if (responseData) {
        console.log(responseData)
        this.resetCheckboxes();
        this.archiveData = responseData['summary'] as Summary
        this.archiveInfo = responseData['details'] as Details;
        this.searchedMHID = this.archiveData.mhid;
        this.searchedISBN = this.archiveData.isbn13;
        this.disablePDHControls();
        this.setArchivest();
        this.setCompVendor();
        this.setPaggingFiles();
        this.setOtherFiles();
        this.setPDFLists();
      } else {
        this.notify.showSuccess('', 'Entered ' + ' mhid ' + ' was not found in Database!');
      }
    }, err => {
      this.notify.showSuccess('', 'Something went wrong, Please try again!');
    });

    return false;
  }

  onCommentAdd(comment: any) {
    this.archiveData.comments = this.archiveData.comments || '';
    if(this.archiveData.comments.length > 0){
      this.archiveData.comments += '\n' + this.userName + " " + this.getDate() + '\n' + comment + '\n';
    }else{
      this.archiveData.comments += this.userName + " " + this.getDate() + '\n' + comment + '\n';
    }
  }

  onSubmit() {
    console.log(this.archiveData);
  }

  DateFormat(date: string, from: string, to: string, source: string): string {
    if (date) {
      if (source === 'html') {
        const d = new Date(date + ' 00:00:00.00');
        const dd = d.getDate();
        const mm = d.getMonth() + 1;
        const yy = d.getFullYear();
        const newdate = mm + '/' + dd + '/' + yy;
        return newdate;
      } else if (source === 'server') {
        const d = new Date(date + ' 00:00:00.00');
        const dd = d.getDate();
        const mm = d.getMonth() + 1;
        const yy = d.getFullYear();
        const newdate = mm + '-' + dd + '-' + yy;
        return newdate;
      }
    } else {
      return '';
    }
    return '';
  }

  dateFormatChange(from: string, to: string, source: string) {
    this.archiveData.boundBookDate = this.DateFormat(this.archiveData.boundBookDate, from, to, source);
  }

  getDate() {
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ':' + today.getMinutes() + ':' + today.getSeconds();
    var dateTime = date + ' ' + time;
    return dateTime;
  }

  reprintValueChange(selectedValue: any) {
    let cdata: any;
    if (selectedValue.currentTarget) {
      cdata = selectedValue.currentTarget.options[selectedValue.currentTarget.selectedIndex].text.trim().toLocaleLowerCase();
    } else {
      cdata = selectedValue;
    }
    this.showReprintInput = cdata.trim().toLowerCase() == "other" ? true : false;
  }

  pagingFilesSeletionChange(event: any): void {
    if (event.target.value == "None" && event.target.checked) {
      this.pagingFilesArray.forEach(v => {
        v.description != 'None' ? v.enabled = 'N' : v.enabled = 'Y';
      })
    } else {
      this.pagingFilesArray.forEach(v => v.enabled = 'Y');
    }
  }

  otherFilesSelectionChange(event: any): void {
    if (event.target.value == "None" && event.target.checked) {
      this.otherFilesArray.forEach(v => {
        v.description != 'None' ? v.enabled = 'N' : v.enabled = 'Y';
      });
    } else {
      this.otherFilesArray.forEach(v => v.enabled = "Y");
    }
  }

  compVendorChange(selectedValue: any) {
    let cdata: any;
    if (selectedValue.currentTarget) {
      cdata = selectedValue.currentTarget.options[selectedValue.currentTarget.selectedIndex].text.trim().toLocaleLowerCase();
    } else {
      cdata = selectedValue;
    }

    this.showCompVendor = cdata.trim().toLowerCase() == "other" ? true : false;
  }

  async loadLovs() {
    this.archivistArray = this.lovData.returnArchivistLOV();
    this.compVendorArray = this.lovData.returnSingleLOV('COMPOSITOR_VENDOR');

    this.pagingFilesArray = this.lovData.returnSingleLOV('PAGINGFILES');
    this.otherFilesArray = this.lovData.returnSingleLOV('OTHERFILES');
    this.PDFsArray = this.lovData.returnSingleLOV("PDFS");

    this.archiveInfo.archivist = +'-1';
    this.archiveInfo.compositorVendor = +'-1';
  }

  private disablePDHControls() {
    this.disabledPDHField = true;
  }

  private setArchivest() {
    let dbData: string;
    let flag: boolean=false;
    if (this.archiveInfo.archivist != null) {
      dbData = this.archiveInfo.archivist.description;
    } else {
      this.archivistArray = this.lovData.returnArchivistLOV();
      this.archiveInfo.archivist = +'-1';
      return false;
    }
    this.archivistArray.filter(ary => {
      if (ary.description == dbData) {
        flag = true;
      }
    });

    if (flag) {
      this.archivistArray.push({ ...this.archiveInfo.archivist });
    }
    if (this.archiveInfo && this.archiveInfo.archivist) {
      for (const keys in this.archivistArray) {
        if (dbData == this.archivistArray[keys].description) {
          this.archiveInfo.archivist = this.archivistArray[keys].lovid;
        }
      }
    }
    return false;

  }

  private setCompVendor() {
    if (this.archiveInfo && this.archiveInfo.compositorVendor) {

      const dbData: string = this.archiveInfo.compositorVendor.description;
      for (const keys in this.compVendorArray) {
        if (dbData == this.compVendorArray[keys].description) {
          if(dbData.trim().toLowerCase() ==='other'){
            this.compVendorOther = this.archiveInfo.compositorVendor.otherValue;
          }
          this.archiveInfo.compositorVendor = this.compVendorArray[keys].lovid;
          this.compVendorChange(dbData);
        }
      }
    } else {
      this.archiveInfo.compositorVendor = + '-1';
      this.compVendorChange('-1')
    }
  }

  private setPaggingFiles() {
    if (this.archiveInfo && this.archiveInfo.pagingFilesList) {
      this.pagingFilesArray.forEach(arrData => {
        this.archiveInfo.pagingFilesList.forEach((respData: { description: string; otherValue: string }) => {
          if (arrData.description?.trim().toLowerCase() == respData.description.trim().toLowerCase()) {
            if(respData.description.trim().toLowerCase()==='other'){
              this.pagingFilesOther = respData.otherValue;
            }
            arrData.checked = true;
          }
        })
      });
    }
  }

  private setOtherFiles() {
    if (this.archiveInfo && this.archiveInfo.otherFilesList) {
      this.otherFilesArray.forEach(arrData => {
        this.archiveInfo.otherFilesList.forEach((respData: { description: string; otherValue:string; }) => {
          if (arrData.description?.trim().toLowerCase() == respData.description.trim().toLowerCase()) {
            if(respData.description.trim().toLowerCase() === 'other'){
              this.otherFilesOther = respData.otherValue;
            }
            arrData.checked = true;
          }
        })
      });
    }
  }

  private setPDFLists() {
    if (this.archiveInfo && this.archiveInfo.pdfsList) {
      this.PDFsArray.forEach(arrData => {
        this.archiveInfo.pdfsList.forEach((respData: { description: string; }) => {
          if (arrData.description?.trim().toLowerCase() == respData.description.trim().toLowerCase()) {
            arrData.checked = true;
          }
        })
      });
    }
  }

  private resetCheckboxes() {
    this.pagingFilesArray.forEach(v => v.checked = false);
    this.otherFilesArray.forEach(v => v.checked = false);
    this.PDFsArray.forEach(v => v.checked = false);
  }

}
