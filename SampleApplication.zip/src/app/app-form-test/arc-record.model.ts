export class Summary{
    recordid?: number;
    mhid: any;
    isbn13: any;
    previousISBN: string | undefined;
    newISBN: string | undefined;
    author: string | undefined;
    title: string | undefined;    
    copyrightYear: number | undefined;
    boundBookDate: any;
    ipubPublishingGroup: string | undefined;
    ipubProgrammingTitle: string | undefined;
    comments: string | undefined;
}

export class Details{
    archivist: any;
    compositorVendor: any;
    downloadDueDate: string | undefined;
    downloadReceivedDate:any;
    pagingFilesList:any;
    otherFilesList:any;
    pdfsList:any;
    createdDate: Date | undefined;
    createdBy: string | undefined;
    modifiedDate: Date | undefined;
    modifiedBy: string | undefined;
}

export interface lovInterface{
    lovid?: number,
    lovType?: string,
    lovCode?: string,
    description?: string,
    valueField?: string,
    enabled?: string,
    orderSeq?: number,
    otherValue?:string
}

export interface chkInterface{
    lovid?: number,
    lovType?: string,
    lovCode?: string,
    description?: string,
    valueField?: string,
    enabled?: string,
    checked?:boolean,
    orderSeq?: number,
    otherValue?:string
}


export interface lovDataInterface{
    lovGroupType:string,
    lovItemList:lovInterface[]
}

export interface leadData{
    succeeded:string,
    data:mainData[],
    message:string
}

export interface mainData{
    summary:Summary[],
    details:Details[]
}
