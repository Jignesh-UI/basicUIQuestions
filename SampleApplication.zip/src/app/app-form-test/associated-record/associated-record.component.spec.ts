import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HttpClient, HttpHandler } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
  MatDialogModule,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { RouterTestingModule } from '@angular/router/testing';
import { ToastrModule } from 'ngx-toastr';

import { AssociatedRecordComponent } from './associated-record.component';
import {
  associatedDetails,
  associatedSummary,
} from './associated-record.model';
import { chkInterface } from '../arc-record.model';

describe('AssociatedRecordComponent', () => {
  let component: AssociatedRecordComponent;
  let fixture: ComponentFixture<AssociatedRecordComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        FormsModule,
        ReactiveFormsModule,
        ToastrModule.forRoot(),
        MatDialogModule,
        MatButtonModule,
      ],
      declarations: [AssociatedRecordComponent],
      providers: [
        HttpClient,
        HttpHandler,
        { provide: MAT_DIALOG_DATA, useValue: {} },
        { provide: MatDialogRef, useValue: {} },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssociatedRecordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    fixture.destroy();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should disable when MHID and ISBN is empty', () => {
    let component = fixture.debugElement.componentInstance;
    component.searchedMHID = '';
    component.searchedISBN = '';
    fixture.detectChanges();
    expect(
      fixture.debugElement.nativeElement.querySelector('.btn.btn-primary')
        .disabled
    ).toBeTruthy();
  });

  it('should add Archive comment when comment is added', () => {
    let component = fixture.debugElement.componentInstance;
    component.associatedSummary = new associatedSummary();
    component.onCommentAdd('Test Message');
    expect(component.associatedSummary.comments).not.toBeNull();
  });

  it('should add Associated comment when comment is added', () => {
    component.assocDetails = new associatedDetails();
    component.onAssocProductCommentAdd('Test Message');
    expect(component.assocDetails.productNotes).not.toBeNull();
  });

  it('should show others input when Other Comp Vendor is selected', () => {
    component.assocDetails = new associatedDetails();
    component.compVendorChange('other');
    component.assocDetails.compositorVendor = 'other';
    expect(component.showCompVendor).toBeTruthy();
  });

  it('should show others input when Other Reprint Contact is selected', () => {
    component.assocDetails = new associatedDetails();
    component.reprintValueChange('other');
    component.assocDetails.reprintContact = 'other';
    expect(component.showReprintInput).toBeTruthy();
  });

  it('should disabled PDH Field', () => {
    let cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.disablePDHControls();
    expect(cmpInstance.disabledPDHField).toBeTruthy();
  });

  it('should enabled Summary Fields when MHID/ISBN is not Null',()=>{
    let cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.searchedMHID = 'test';
    cmpInstance.searchedISBN = 'test';
    fixture.detectChanges();
    console.log(cmpInstance.disabledDetailsField)
    expect(cmpInstance.disabledDetailsField).toBeTruthy();
  })

  it('should check PDF List are added in the Save Array List', () => {
    component.assocDetails = new associatedDetails();
    let data = component.savePdfsList([
      {
        lovid: 34001,
        lovType: 'PDFS',
        lovCode: 'PDFS-ALL',
        description: 'Printer PDFs',
        valueField: null,
        enabled: 'Y',
        orderSeq: 2,
      },
    ]);
    component.assocDetails.pdfsList = data;
    expect(component.assocDetails.pdfsList).not.toBeNull();
  });

  it('should check PDF List are added in the Save Other Files List', () => {
    let cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    let data = cmpInstance.saveOtherFilesList([{
          "lovid": 25000,
          "lovType": "OTHERFILES",
          "lovCode": "OTHERFILES-ALL",
          "description": "Cover/Design",
          "valueField": null,
          "enabled": "Y",
          "orderSeq": 2,
          "checked": true
        }]);
    cmpInstance.assocDetails.otherFilesList = data;
    expect(cmpInstance.assocDetails.otherFilesList).not.toBeNull();
  });

  it('should check PDF List are added in the Save Pagging Files List', () => {
    let cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    let data = cmpInstance.savePaggingFiles([{
          "lovid": 31000,
          "lovType": "PAGINGFILES",
          "lovCode": "PAGINGFILES-MHHE",
          "description": "InDesign",
          "valueField": null,
          "enabled": "Y",
          "orderSeq": 1,
          "checked": true
      }]);
    cmpInstance.assocDetails.pagingFilesArray = data;
    expect(cmpInstance.assocDetails.pagingFilesArray).not.toBeNull();
  });


});
