import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appInputHover]'
})
export class InputHoverDirective {
  @Input() appInputHover = 0;
  

  constructor(private el: ElementRef) { 
  }
  
  @HostListener('mouseenter') OnMouseEnter(){
    const childList = this.el.nativeElement.childNodes;
    for (const keys in childList) {
      if(childList[keys].classList != undefined && childList[keys].classList.contains('form-control') && childList[keys].selectedIndex == null){
        const inputValue = childList[keys].value;
        if(inputValue.length > this.appInputHover){
          const div: HTMLLabelElement = document.createElement('label');
          div.innerHTML = '<label class="popUphover"> '+ inputValue +' </label>';
          const insert: HTMLElement = div.firstChild as HTMLElement;
          const before: HTMLElement = this.el.nativeElement;
          before.appendChild(insert);
        }
        break;
      }
    }
  }

  @HostListener('mouseleave') OnMouseLeave(){
    if(this.el.nativeElement.lastChild.className == "popUphover"){
      this.el.nativeElement.lastChild.remove()
    }
  }

  private highlight(color: string) {
    this.el.nativeElement.style.backgroundColor = color;
  }

}
