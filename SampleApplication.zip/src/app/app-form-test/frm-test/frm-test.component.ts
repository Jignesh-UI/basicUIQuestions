import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { APP_Messages } from 'src/app/shared/app-defaults';
import { LovDataService } from '../lov-data.service';
import { NotificationService } from '../notification.service';

@Component({
  selector: 'app-frm-test',
  templateUrl: './frm-test.component.html',
  styleUrls: ['./frm-test.component.scss']
})
export class FrmTestComponent implements OnInit {

  dataForm: FormGroup;
  searchPageArray: any[] = [];
  searchPropertiesArray: any[] = [];
  conditionsArray: any[] = [];

  constructor(private fb: FormBuilder,private lovData: LovDataService,private notify: NotificationService) { 
    this.dataForm = new FormGroup({
      scPage:new FormControl('',Validators.required),
      propertiesArray: this.fb.array([])
    });
    this.addanswers();
  }

  async ngOnInit(){
    this.loadLovs();
  }

  get propertiesArray(): FormArray{
    return this.dataForm.get('propertiesArray') as FormArray;
  }

  addanswers(){
    console.log(this.propertiesArray.length)
    const lForm = this.fb.group({
      order:[this.propertiesArray.length, Validators.required],
      operator:['', Validators.required],
      propertyName:['', Validators.required],
      condition: [''],
      value: ['']
    });
    this.propertiesArray.push(lForm);
  }

  onSubmit(){
    console.log(this.dataForm.value)
  }

  async loadLovs() {
    this.searchPageArray = this.lovData.returnSingleLOV('SEARCH_TYPE');
  }

  deleteLesson(lessonIndex: number){
    this.propertiesArray.removeAt(lessonIndex);
  }

  onTableChange(ctrl: any, dtvalue: string = ''){ 
    let filterValue: string = '';
    if (dtvalue != '') {
      filterValue = dtvalue.replace('_', ' ');
    } else {
      filterValue =
        ctrl.currentTarget.options[
          ctrl.currentTarget.selectedIndex
        ].text.trim();
    }

    let getPropertyArray: any;
  
      getPropertyArray = [
        ...this.lovData.returnSingleLOV('COMMON_CRITERIA'),
        ...this.lovData.returnSingleLOV('ARCHIVE_RECORD_CRITERIA'),
      ];
      // this.adjustProperties(getPropertyArray);
     
    this.searchPropertiesArray = getPropertyArray;
    // this.propertyNameDrp = '-1';
    // this.isLoading = false;
    // this.searchType = this.selecteTableDrp;
  }

  onPropertyChange(obj: any) {

    let filterConditionType = this.searchPropertiesArray.filter((svalue) => {
      if (svalue.valueField == obj.value.propertyName) {
        return svalue.valueField;
      }
    })[0].lovCode;

    if (filterConditionType.search('NUMBER') > 0) {
      this.conditionsArray = this.lovData.returnSingleLOV("CONTAINS_VALUES_NUMBER");
      obj.isDateProperty = false;
    } else if (filterConditionType.search('STRING') > 0) {
      this.conditionsArray = this.lovData.returnSingleLOV('CONTAINS_VALUES_STRING');
      obj.isDateProperty = false;
    } else if (filterConditionType.search('DATE') > 0) {
      this.conditionsArray = this.lovData.returnSingleLOV('CONTAINS_VALUES_DATE');
      obj.isDateProperty = true;
    } else {
      this.notify.showSuccess('', APP_Messages.differentCriteria);
    }

    debugger;
    // this.conditionsArray = obj.conditions[0].value
    return true;
  }

}

export interface formInterface{
  question:string,
  propertiesArray: propertieListsArray[]
}

export interface propertieListsArray{
  order: number,
  propertyName: string,
  condition: string,
  operator: string,
  value: string,
  properties?: [],
  drpvalues?: [],
  conditions?: [],
  isDateProperty?: boolean,
  isDropdown?: boolean
}