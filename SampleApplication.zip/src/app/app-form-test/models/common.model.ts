
export interface lovInterface {
  lovid?: number,
  lovType?: string,
  lovCode?: string,
  description?: string,
  valueField?: string,
  enabled?: string,
  orderSeq?: number,
  otherValue?: string
}

export interface chkInterface {
  lovid?: number,
  lovType?: string,
  lovCode?: string,
  description?: string,
  valueField?: string,
  enabled?: string,
  checked?: boolean,
  orderSeq?: number,
  otherValue?: string
}
