import { HttpClient } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { APP_Messages } from 'src/app/shared/app-defaults';
import { CommonService } from 'src/app/shared/common.service';
import { ComponentService } from 'src/app/shared/component.service';
import { FluidHeightDirective } from 'src/app/shared/fluid-height.directive';
import { LovDataService } from '../lov-data.service';
import { NotificationService } from '../notification.service';

@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.scss'],
})
export class ReactiveFormComponent implements OnInit {
  @ViewChild(FluidHeightDirective) setHeight: FluidHeightDirective | undefined;

  isLoading: boolean = false;
  searchPageArray: any[] = [];
  searchPropertiesArray: any[] = [];

  showSearch: boolean = false;
  showSearchResultContainer: boolean = false;

  selecteTableDrp: string = '';
  propertyNameDrp: string = '';
  conditionDrp: string = '';

  userName: string = '';
  isDropdown = false;
  dropDownOptions = [
    'ARCHIVIST',
    'STORAGE_LOCATION',
    'IN_PROCESS',
    'FILESREQUESTED',
  ];

  properties: propObjects[] = [
    {
      order: 1,
      propertyName: '',
      condition: '',
      operator: '',
      value: '',
      properties: [],
      conditions: [],
      drpvalues: [],
      isDateProperty: false,
      isDropdown: false,
    },
  ];

  searchType: string = '';
  message: string = '';
  iserror = false;
  userNameSR: string;

  columnDefs: columnInterface[] = [
    { headerName: 'System ID', field: 'SYSTEMID', width: 100, order: '' },
    { headerName: 'MHID', field: 'MHID', width: 130, order: 'asc' },
    { headerName: 'ISBN-13', field: 'ISBN13', width: 130, order: '' },
    { headerName: 'Author', field: 'AUTHOR', width: 170, order: '' },
    { headerName: 'Marketing Title', field: 'TITLE', width: 200, order: '' },
    { headerName: 'Edition', field: 'EDITION', width: 80, order: '' },
    { headerName: 'Copyright', field: 'COPYRIGHTYEAR', width: 80, order: '' },
    {
      headerName: 'Date Received',
      field: 'REQUEST_RECEIVED_DATE',
      width: 120,
      order: '',
    },
    { headerName: 'Due Date', field: 'DUE_DATE', width: 120, order: '' },
    {
      headerName: 'Files Requested',
      field: 'PAGINGFILES||OTHERFILES||PDFFILES||REQUESTEDFILES',
      width: 150,
      order: '',
    },
    { headerName: 'Requestor', field: 'REQUESTED_BY', width: 150, order: '' },
    { headerName: 'Archivist', field: 'ARCHIVIST', width: 150, order: '' },
    { headerName: 'Owning Division', field: 'OWNDIV', width: 120, order: '' },
    {
      headerName: 'Publication Status',
      field: 'PRIORITY',
      width: 130,
      order: '',
    },
    { headerName: 'Grade Range', field: 'GRADE_RANGE', width: 100, order: '' },
    {
      headerName: 'Specific Market',
      field: 'SPECIFIC_MARKET',
      width: 110,
      order: '',
    },
    {
      headerName: 'Title Type',
      field: 'TITLE_TYPE_DESC',
      width: 200,
      order: '',
    },
  ];

  rowData?: any[] | null;
  sortOrderType = '';
  sortField = '';

  pageSize: pageSizeProperties[] = [];
  pageSizeSelect: pageSizeProperties[] = [];
  totalPagesCount: number = 0;

  paginationSelect: any;
  isSearched: boolean = false;

  url: string = 'services/searches';

  jjj:any;
  regexStr = '^[a-zA-Z0-9_ ]*$';
  constructor(
    private http: HttpClient,
    private router: Router,
    private commuincationService: ComponentService,
    private cs: CommonService,
    private lovData: LovDataService,
    private notify: NotificationService, private el: ElementRef
  ) {
    this.properties = [
      {
        order: 1,
        propertyName: '',
        condition: '',
        operator: '',
        value: '',
        properties: [],
        conditions: [],
        drpvalues: [],
        isDateProperty: false,
        isDropdown: false,
      },
    ];
    this.userNameSR = 'hellojiger@gmail.com';
    this.userName = 'hellojiger@gmail.com';
    this.isLoading = true;
    this.commuincationService.searchCriteria.subscribe((search) => {
      // if (search['searchSummary'] && search['searchFields']) {
      //   if (
      //     this.selecteTableDrp == null ||
      //     this.selecteTableDrp == undefined ||
      //     this.selecteTableDrp == ''
      //   ) {
      //     this.onTableChange(null, search['searchSummary'].searchType);
      //     this.selecteTableDrp = search['searchSummary'].searchType;
      //   }
      //   search['searchFields'].forEach((v) => {
      //     if (v.isDropdown) {
      //       this.drpDataFilled(v);
      //     }
      //   });
      //   this.searchType = search['searchSummary'].searchType;
      //   this.properties = search['searchFields'];
      //   this.sortField = search['searchSummary'].sortBy;
      //   this.totalPagesCount = search['searchSummary'].totalCount;
      //   this.sortOrderType = search['searchSummary'].sortOrder;
      //   this.searchResultClicked(search);
      // }
    });
    this.isLoading = false;
  }

  async ngOnInit() {
    this.isLoading = true;

    await this.loadLovs();
    this.isLoading = false;
  }

  public searchChange(event:any) {
    if(this.jjj.length === 1){
      this.jjj = null;
    }else{
      this.jjj = this.jjj.trim();
    }
  }

  onAddProperty() {
    if (this.properties.length <= 4) {
      this.properties.push({
        order: this.properties.length + 1,
        propertyName: '',
        condition: '',
        operator: '',
        value: '',
        properties: [],
        drpvalues: [],
        conditions: [],
        isDateProperty: false,
        isDropdown: false
      });
    }
  }

  onTableChange(ctrl: any, dtvalue: string = '') {
    this.isLoading = true;
    let filterValue: string = '';
    if (dtvalue != '') {
      filterValue = dtvalue.replace('_', ' ');
    } else {
      filterValue =
        ctrl.currentTarget.options[
          ctrl.currentTarget.selectedIndex
        ].text.trim();
    }

    let getPropertyArray: any;
  
      getPropertyArray = [
        ...this.lovData.returnSingleLOV('COMMON_CRITERIA'),
        ...this.lovData.returnSingleLOV('ARCHIVE_RECORD_CRITERIA'),
      ];
      this.adjustProperties(getPropertyArray);
     
    this.searchPropertiesArray = getPropertyArray;
    this.propertyNameDrp = '-1';
    this.isLoading = false;
    this.searchType = this.selecteTableDrp;
  }

  adjustProperties(paramdata: any[]) {
    this.properties = [{
        order: 1,
        propertyName: '',
        condition: '',
        operator: '',
        value: '',
        properties: [],
        drpvalues: [],
        conditions: [],
        isDateProperty: false,
        isDropdown: false
      },
    ];
  }

  onPropertyChange(obj: any) {
    this.isLoading = true;
    obj.condition = '';

    if (this.selecteTableDrp == '-1') {
      this.notify.showSuccess('', APP_Messages.selectPage);
      this.isLoading = false;
      return false;
    }

    let filterConditionType = this.searchPropertiesArray.filter((svalue) => {
      if (svalue.valueField == obj.propertyName) {
        return svalue.valueField;
      }
    })[0].lovCode;

    if (filterConditionType.search('NUMBER') > 0) {
      obj.conditions = this.lovData.returnSingleLOV("CONTAINS_VALUES_STRING");
      this.conditionDrp = '-1';
      obj.isDateProperty = false;
    } else if (filterConditionType.search('STRING') > 0) {
      obj.conditions = this.lovData.returnSingleLOV('CONTAINS_VALUES_STRING');
      this.conditionDrp = '-1';
      obj.isDateProperty = false;
    } else if (filterConditionType.search('DATE') > 0) {
      obj.conditions = this.lovData.returnSingleLOV('CONTAINS_VALUES_DATE');
      this.conditionDrp = '-1';
      obj.isDateProperty = true;
    } else {
      this.notify.showSuccess('', APP_Messages.differentCriteria);
    }

    obj.isDropdown = false;
    obj.condition = obj.conditions[0].value;
    this.isLoading = false;
    return true;
  }

  onConditionChange(obj: any) {
    if (
      this.dropDownOptions.indexOf(obj.propertyName) >= 0 &&
      obj.condition.trim().toLowerCase() == 'equals'
    ) {
      this.isLoading = true;
      this.drpDataFilled(obj);
      obj.isDropdown = true;
      this.isLoading = false;
    } else {
      obj.isDropdown = false;
    }
  }

  drpDataFilled(propObj: any) {
    if (propObj.propertyName == 'ARCHIVIST') {
      const newDataArray = this.lovData.returnSingleLOV(propObj.propertyName);
      propObj.drpvalues = newDataArray.map((v: { description: any }) => {
        return { text: v.description, value: v.description };
      });
    } else if (propObj.propertyName == 'STORAGE_LOCATION') {
      const newDataArray = this.lovData.returnSingleLOV(propObj.propertyName);
      propObj.drpvalues = newDataArray.map((v: { description: any }) => {
        return { text: v.description, value: v.description };
      });
    } else if (propObj.propertyName == 'IN_PROCESS') {
      propObj.drpvalues = [
        { text: 'Yes', value: 'Y' },
        { text: 'No', value: 'N' },
      ];
    } else if (propObj.propertyName == 'FILESREQUESTED') {
      const newDataArray = [
        ...this.lovData.returnSingleLOV('PDFS'),
        ...this.lovData.returnSingleLOV('REQUESTEDFILES'),
      ];
      propObj.drpvalues = newDataArray.map((v) => {
        return { text: v.description, value: v.description };
      });
    }
  }

  onClear() {
    this.selecteTableDrp = '';
    this.properties = [{
        order: 1,
        propertyName: '',
        condition: '',
        operator: '',
        value: '',
        properties: [],
        conditions: [],
        isDateProperty: false,
        isDropdown: false
      },
    ];
  }

  onRemoveProperty(obj: any) {
    if (obj.order !== 1) {
      this.properties = this.properties.filter((prop) => prop !== obj);
    }
  }

  onSearch() {
    this.sortOrderType = '';
    this.sortField = '';
    const clone: {} = this.searchQuery();
    if (!this.searchStringErrorHandler(clone)) {
      return false;
    } else {
      this.commuincationService.changeMessage(clone);
    }
    return true;
  }

  showSearchSection() {
    this.showSearch = !this.showSearch;
    this.setHeight?.setHeight();
  }

  searchResultClicked(requestedData: any) {
    this.isLoading = true;
    this.showSearchResultContainer = true;
    this.http.post(this.url, requestedData).subscribe(
      (response) => {
        // if (response['data']) {
        //   if (response['data']['searchResults'].length > 0) {
        //     this.rowData = response['data']['searchResults'];
        //     this.adjustSorting(response['data'].searchSummary.sortBy, response['data'].searchSummary.sortOrder);
        //     this.adjustPagination(response['data']['searchSummary'].pageNumber, response['data']['searchSummary'].pageSize, response['data']['searchSummary'].totalCount);
        //     this.isSearched = true;
        //   } else {
        //     this.resetRowsWithMessage(response['message']);
        //     this.pageSize = [];
        //     this.pageSizeSelect = [];
        //     this.isSearched = false;
        //   }
        // } else {
        //   this.resetRowsWithMessage(response['message']);
        //   this.pageSize = [];
        //   this.pageSizeSelect = [];
        //   this.isSearched = false;
        // }
        this.setHeight?.setHeight();
        this.isLoading = false;
      },
      (err) => {
        this.isLoading = false;
        this.notify.showSuccess('', APP_Messages.ServerErrorMessage);
      }
    );
  }

  resetRowsWithMessage(msgResponse: string) {
    this.rowData = [];
    this.notify.showSuccess('', msgResponse);
  }

  onRowClicked(params: any) {
    if (this.searchType == 'Archive_Record') {
      this.router.navigate(['archiveRec', params.mhid]);
    } else if (this.searchType == 'Archive_Request') {
      this.router.navigate(['archiveReq', params.systemid]);
    }
  }

  onHeaderClicked(params: columnInterface) {
    this.sortField = params.field;
    if (params.order == 'asc') {
      this.sortOrderType = 'desc';
    } else if (params.order == 'desc') {
      this.sortOrderType = 'asc';
    } else {
      this.sortOrderType = 'asc';
    }

    const clone: {} = this.searchQuery();
    this.commuincationService.changeMessage(clone);
    // this.searchResultClicked(clone);
  }

  onSave(searchName: any) {
    this.isLoading = true;
    const url = 'services/savedSearches';
    const clone: {} = this.searchQuery();
    const request = {
      savedSearchSummary: {
        id: 0,
        searchName: searchName,
        searchType: this.searchType,
        createdBy: this.userNameSR,
        createdDate: this.cs.getDate(),
        modifiedDate: this.cs.getDate(),
        modifiedBy: this.userNameSR,
      },
      // searchSummary: clone['searchSummary'],
      // searchFields: clone['searchFields'],
    };

    this.http.post(url, request).subscribe(
      (response) => {
        // this.notify.showSuccess('', response['message']);
        this.isLoading = false;
      },
      (err) => {
        this.isLoading = false;
        this.notify.showSuccess('', APP_Messages.ServerErrorMessage);
      }
    );
  }

  async loadLovs() {
    this.searchPageArray = this.lovData.returnSingleLOV('SEARCH_TYPE');
    if (this.searchType == '') {
      this.selecteTableDrp = '-1';
    }
  }

  searchQuery() {
    const clone: {} = {};
    // clone['searchSummary'] = {
    //   searchType: this.searchType,
    //   pageNumber: 1,
    //   pageSize: 50,
    //   totalCount: 0,
    //   sortBy: this.sortField == '' ? 'mhid' : this.sortField,
    //   sortOrder: this.sortOrderType == '' ? 'asc' : this.sortOrderType,
    // };
    // clone['searchFields'] = JSON.parse(JSON.stringify(this.properties));
    // clone['searchFields'].forEach((element) => {
    //   // delete element.properties;
    //   // delete element.conditions;
    //   delete element.isDateProperty;
    //   // delete element.isDropdown;
    //   element.value =
    //     element.value.split('-').length === 3
    //       ? this.cs.getDatewithParam(element.value)
    //       : element.value;
    // });
    // this.commuincationService.changeMessage(clone);
    return clone;
  }

  adjustPagination(pageNumber: number, pSize: number, totalCount: number) {
    this.pageSize = [];
    this.pageSizeSelect = [];
    const pageCount = Math.ceil(totalCount / pSize);
    this.totalPagesCount = pageCount;
    const actPageNo = pageNumber;
    if (pageNumber >= 5) {
      pageNumber = pageNumber - 2;
    } else {
      pageNumber = 1;
    }

    for (let i: number = 1; i <= pageCount; i++) {
      this.pageSizeSelect.push({ pageNumber: i, activePage: false });
    }

    for (let i: number = pageNumber; i <= pageCount; i++) {
      if (i > pageNumber + 4) {
        this.pageSize.push({ pageNumber: -1, activePage: false });
        this.pageSize.push({ pageNumber: pageCount, activePage: false });
        break;
      }

      if (i == actPageNo) {
        this.pageSize.push({ pageNumber: i, activePage: true });
        this.paginationSelect = i;
      } else {
        this.pageSize.push({ pageNumber: i, activePage: false });
      }
    }
  }

  paginationFunc(param: any) {
    let nextPageNo: number = 0;
    if (param == 'p') {
      param =
        this.pageSize.filter((pgObj) => {
          return pgObj.activePage == true;
        })[0].pageNumber - 1;
    } else if (param == 'n') {
      param =
        this.pageSize.filter((pgObj) => {
          return pgObj.activePage == true;
        })[0].pageNumber + 1;
    } else if (param == '-1') {
    }
    nextPageNo = param;

    if (param < 1 || param > this.totalPagesCount) {
      return false;
    }

    const clone: {} = this.searchQuery();
    this.commuincationService.changeMessage(clone);
    // clone['searchSummary'].pageNumber = nextPageNo;

    this.pageSize.forEach((pgObj) => {
      if (pgObj.pageNumber == param) {
        pgObj.activePage = true;
      } else {
        pgObj.activePage = false;
      }
    });
    // this.showSearchResultContainer = true;
    // this.searchResultClicked(clone);
    return true;
  }

  searchStringErrorHandler(clone: any) {
    let searchFlag: boolean = false;

    clone.searchFields.forEach(
      (element: {
        propertyName: string;
        condition: string;
        value: string;
        order: number;
        operator: string;
      }) => {
        if (
          element.propertyName == null ||
          element.propertyName == undefined ||
          element.propertyName == ''
        ) {
          searchFlag = true;
          this.notify.showSuccess('', APP_Messages.selectPropertyName);
          return false;
        } else if (
          element.condition == null ||
          element.condition == undefined ||
          element.condition == ''
        ) {
          searchFlag = true;
          this.notify.showSuccess('', APP_Messages.selectContains);
          return false;
        } else if (
          element.condition != 'isNotNull' &&
          element.condition != 'isNull' &&
          (element.value == null ||
            element.value == undefined ||
            element.value == '')
        ) {
          searchFlag = true;
          this.notify.showSuccess('', APP_Messages.enterValue);
          return false;
        } else if (element.order > 1) {
          if (
            element.operator == null ||
            element.operator == undefined ||
            element.operator == ''
          ) {
            searchFlag = true;
            this.notify.showSuccess('', APP_Messages.selectOperator);
            return false;
          }
        }
        return true;
      }
    );

    if (searchFlag) {
      return false;
    }
    return true;
  }

  adjustSorting(sortBy: string, sortOrder: string) {
    this.columnDefs.forEach((cl) => {
      if (cl.field.toLowerCase().trim() == sortBy.toLowerCase().trim()) {
        cl.order = sortOrder;
      } else {
        cl.order = '';
      }
    });
  }
}

export interface pageSizeProperties {
  pageNumber: number;
  activePage: boolean;
}

export interface columnInterface {
  headerName: string;
  field: string;
  width: number;
  order: string;
}

export interface propObjects {
  order: number;
  propertyName: string;
  condition: string;
  operator: string;
  value: string;
  conditions?: any[];
  properties?: any[];
  drpvalues?: any[];
  isDateProperty: boolean;
  isDropdown: boolean;
}
