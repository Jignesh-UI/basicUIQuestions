import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RecordInformationComponentComponent } from './record-information-component.component';

describe('RecordInformationComponentComponent', () => {
  let component: RecordInformationComponentComponent;
  let fixture: ComponentFixture<RecordInformationComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RecordInformationComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RecordInformationComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
