import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-record-information-component',
  templateUrl: './record-information-component.component.html',
  styleUrls: ['./record-information-component.component.scss']
})
export class RecordInformationComponentComponent implements OnInit {

  @Input('recInfoData') recInfoData: any = ''; //Data will received from Parent Component

  constructor() { }

  ngOnInit(): void {
  }

}
