import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AgGridComponent } from './ag-grid/ag-grid.component';
import { AppFormTestComponent } from './app-form-test/app-form-test.component';
import { FrmTestComponent } from './app-form-test/frm-test/frm-test.component';
import { LOVResolverService } from './app-form-test/Lov-Resolver.Service';
import { ReactiveFormComponent } from './app-form-test/reactive-form/reactive-form.component';
import { AssociatedRecordComponent } from './app-form-test/associated-record/associated-record.component';
import { Assignment3Component } from './assignments/assignment3/assignment3.component';
import { Assignment4Component } from './assignments/assignment4/assignment4.component';
import { AssignmentsComponent } from './assignments/assignments.component';
import { CanDeactivateGuardService } from './can-deactivate-guard.service';
import { HomeComponent } from './home/home.component';
import { ReportsComponent } from './reports/reports.component';
import { ExamTestComponent } from './exam-test/exam-test.component';
import { OnlineTestComponent } from './online-test/online-test.component';

const routes: Routes = [
  { path:'', component:HomeComponent },
  { path:'home', component:HomeComponent},
  { path:'assignments', component:AssignmentsComponent},
  { path:'assignment3', component:Assignment3Component},
  { path:'assignment4', component:Assignment4Component},
  { path:'testApp', component:AppFormTestComponent, resolve:[LOVResolverService], canDeactivate:[CanDeactivateGuardService]},
  { path:'reactiveForm', component:ReactiveFormComponent, resolve:[LOVResolverService], canDeactivate:[CanDeactivateGuardService]},
  { path:'frmTest', component:FrmTestComponent, resolve:[LOVResolverService], canDeactivate:[CanDeactivateGuardService]},
  { path:'simpleDataGrid', component:AgGridComponent },
  { path:'reports', component: ReportsComponent, resolve:[LOVResolverService] },
  { path:'associated', component:AssociatedRecordComponent, resolve:[LOVResolverService],  canDeactivate:[CanDeactivateGuardService]},
  { path:'exampleSample', component:ExamTestComponent },
  { path:'mytest', component: OnlineTestComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    // onSameUrlNavigation:'reload'
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
