import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CoursesService } from './shared/services/courses.service';
import { HomeComponent } from './home/home.component';
import { NavigationComponent } from './navigation/navigation.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AllmatcompModule } from './shared/allmatcomp.module';
import { WarningAlertComponent } from './warning-alert/warning-alert.component';
import { SuccessAlertComponent } from './success-alert/success-alert.component';
import { Assignment3Component } from './assignments/assignment3/assignment3.component';
import { Assignment4Component } from './assignments/assignment4/assignment4.component';
import { AssignmentsComponent } from './assignments/assignments.component';
import { AssignmentNavComponent } from './assignments/assignmentNav.component';
import { HttpClientModule } from '@angular/common/http';
import { AppFormTestComponent } from './app-form-test/app-form-test.component';
import { RecordInformationComponentComponent } from './app-form-test/record-information-component/record-information-component.component';
import { ToastrModule } from 'ngx-toastr';
import { InputHoverDirective } from './app-form-test/directive/input-hover.directive';
import { DialogcontentComponent } from './dialogcontent/dialogcontent.component';
import { ScrumModule } from './scrum-q/scrum-module';
import { SharedModule } from './shared/shared-module';
import { scrumRoutingModule } from './scrum-q/scrum-routing-module';
import { SamplesModule } from './Samples/samples-module';
import { SamplesRoutingModule } from './Samples/samples-routing-module';
import { ReactiveFormComponent } from './app-form-test/reactive-form/reactive-form.component';
import { AgGridComponent } from './ag-grid/ag-grid.component';
import { AgGridModule } from 'ag-grid-angular';
import { FluidHeightDirective } from './shared/fluid-height.directive';
import { FrmTestComponent } from './app-form-test/frm-test/frm-test.component';
import { angModule } from './angular/ang-module';
import { angRoutingModule } from './angular/ang-routing.module';
import { OracleComponent } from './angular/oracle/oracle.component';
import { PhpComponent } from './angular/php/php.component';
import { DjangoComponent } from './angular/django/django.component';
import { MatlabComponent } from './angular/matlab/matlab.component';
import { JavaComponent } from './angular/java/java.component';
import { PythonComponent } from './angular/python/python.component';
import { AiComponent } from './angular/ai/ai.component';
import { ReportsComponent } from './reports/reports.component';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { TrimFuncDirective } from './home/trim-func.directive';
import { AssociatedRecordComponent } from './app-form-test/associated-record/associated-record.component';
import { PopupComponent } from './app-form-test/popup/popup.component';
import { SummaryPipe } from './shared/pipe/summary.pipe';
import { SortPaginationPipe } from './shared/pipe/sort-pagination.pipe';
import { DateFormatChangeDirective } from './shared/directives/date-format-change.directive';
import { ExamTestComponent } from './exam-test/exam-test.component';
import { OnlineTestComponent } from './online-test/online-test.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent, NavigationComponent, WarningAlertComponent,
    SuccessAlertComponent, Assignment3Component,
    Assignment4Component, AssignmentsComponent, AssignmentNavComponent,
    AppFormTestComponent,
    RecordInformationComponentComponent,
    InputHoverDirective,
    DialogcontentComponent,
    ReactiveFormComponent,
    AgGridComponent,
    FluidHeightDirective,
    FrmTestComponent,
    OracleComponent,
    PhpComponent,
    DjangoComponent,
    MatlabComponent,
    JavaComponent,
    PythonComponent,
    AiComponent,
    ReportsComponent,
    TrimFuncDirective,
    AssociatedRecordComponent,
    PopupComponent,
    SummaryPipe,
    SortPaginationPipe,
    DateFormatChangeDirective,
    ExamTestComponent,
    OnlineTestComponent
  ],
  imports: [
    AllmatcompModule,
    BrowserModule,
    SamplesModule,
    AppRoutingModule,
    SamplesRoutingModule,
    scrumRoutingModule,
    angRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    HttpClientModule,
    SharedModule,
    ScrumModule,
    angModule,
    NgxTrimDirectiveModule,
    ToastrModule.forRoot({positionClass: 'toast-center-center', closeButton: true , toastClass: 'ngx-toastr' }),
    AgGridModule.withComponents([])
  ],
  providers: [CoursesService, SummaryPipe, DateFormatChangeDirective],
  bootstrap: [AppComponent],
  // entryComponents:[AlertDynamicComponent]
})
export class AppModule { }
