import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assignment3',
  templateUrl: './assignment3.component.html',
  styleUrls: ['./assignment3.component.scss']
})
export class Assignment3Component implements OnInit {

  showSecrate = false;
  consolelog: any=[];
  constructor() { }

  ngOnInit(): void {
  }

  showSecrates(){
    this.showSecrate = !this.showSecrate;
    this.consolelog.push(this.consolelog.length + 1)
  }
  resetSecrates(){
    this.showSecrate = false;
    this.consolelog=[];
  }
}
