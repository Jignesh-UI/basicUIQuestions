import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assignment4',
  templateUrl: './assignment4.component.html',
  styleUrls: ['./assignment4.component.scss']
})
export class Assignment4Component implements OnInit {

  listItems:any =[];
  constructor() { }

  ngOnInit(): void {
  }

  addServer(){
    this.listItems.push('My List');
  }
  removeSelected(event:any){
    this.listItems.splice(event,1);
  }

}
