import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assignment-nav',
  templateUrl: './assignments.nav.component.html',
  styleUrls: ['./assignments.component.scss']
})

export class AssignmentNavComponent{

}