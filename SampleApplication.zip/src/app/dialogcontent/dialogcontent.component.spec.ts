import { NO_ERRORS_SCHEMA } from '@angular/compiler';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialog, MatDialogActions, MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { of } from 'rxjs';

import { DialogcontentComponent } from './dialogcontent.component';

describe('DialogcontentComponent', () => {
  let component: DialogcontentComponent;
  let fixture: ComponentFixture<DialogcontentComponent>;
  let dialogRefSpyObj = jasmine.createSpyObj({ afterClosed : of({}), close: null });
  dialogRefSpyObj.componentInstance = { body: '' }; // attach componentInstance to the spy object...

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DialogcontentComponent ],
      imports:[MatDialogModule],
      providers: [

        {provide: MAT_DIALOG_DATA, useValue: {}},
        { provide: MatDialogRef, useValue: {} }],
      schemas:[NO_ERRORS_SCHEMA]
    })
    .compileComponents();
    // modalService = TestBed.get(ModalService);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogcontentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
