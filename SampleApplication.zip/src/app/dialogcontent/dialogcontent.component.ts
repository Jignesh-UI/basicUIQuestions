import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dialogcontent',
  templateUrl: './dialogcontent.component.html',
  styleUrls: ['./dialogcontent.component.scss']
})
export class DialogcontentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
