import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ExamService } from '../shared/services/exam.service';

interface Question {
  text: string;
  options: string[];
  correctAnswer: string;
}

@Component({
  selector: 'app-exam-test',
  templateUrl: './exam-test.component.html',
  styleUrls: ['./exam-test.component.scss']
})
export class ExamTestComponent implements OnInit {

  duration: number = 180; // Exam duration in seconds (e.g., 180 seconds = 3 minutes)
  timerSubscription: Subscription | any;
  remainingMinutes: number | any;
  remainingSeconds: number | any;

  constructor(private examService: ExamService) { }

  ngOnInit(): void {
  }

  isSubmitted: boolean = false;
  selectedAnswers: string[] = [];

  questions: Question[] = [
    {
      text: 'What is the capital of France?',
      options: ['London', 'Paris', 'Berlin', 'Madrid'],
      correctAnswer: 'Paris'
    },
    {
      text: 'Who painted the Mona Lisa?',
      options: ['Pablo Picasso', 'Leonardo da Vinci', 'Vincent van Gogh', 'Michelangelo'],
      correctAnswer: 'Leonardo da Vinci'
    },
    {
      text: 'What is the largest planet in our solar system?',
      options: ['Earth', 'Jupiter', 'Mars', 'Saturn'],
      correctAnswer: 'Jupiter'
    }
  ];

  submitTest() {
    this.isSubmitted = true;
  }


}
