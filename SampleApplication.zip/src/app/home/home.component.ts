import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DialogcontentComponent } from '../dialogcontent/dialogcontent.component';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';



@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {


  myControl = new FormControl();
  options: string[] = ["caucasian", "c", "close", "cut", "children", "contact", "century", "corbis", "companies", "copy", "camera", "computers", "cheerfulness", "communication", "cities", "city", "computer", "culture", "couples", "childhood", "collection", "clouds", "county", "classrooms", "couple", "california", "color", "confidence", "concentrating", "congress", "composite", "cropped", "closed", "cell", "cm", "concept", "central", "containers", "collar", "celebrations", "colorful", "clothing", "connection", "ca", "class", "college", "care", "center", "canada", "comstock", "clear", "columbia", "credit", "construction", "chinese", "colored", "commerce", "chairs", "communications", "carrying", "cold", "co", "copyright", "conservation", "classroom", "clothes", "cooperation", "can", "car", "cityscapes", "cross", "colleagues", "cartography", "capital", "corporate", "coast", "circles", "control", "creativity", "created", "competitions", "creatas", "child", "company", "conversations", "carefree", "china", "contemplating", "climates", "concepts", "creative", "cultural", "cups", "courtesy", "cats", "coffee", "coasts", "community", "clip", "chemistry"];
  filteredOptions: Observable<string[]> | undefined;
  @ViewChild('txtquestion') question!: ElementRef<HTMLInputElement>;

  dataForm: FormGroup;

  constructor(public dialog: MatDialog, private fb: FormBuilder) {
    this.dataForm = new FormGroup({
      'question':new FormControl('',Validators.required),
      'description': new FormControl(''),
      'txtname': new FormControl(''),
      'txtemail': new FormControl(''),
    });
  }

  ngOnInit(): void {
    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value))
    );
  }

  openDialog(){
    const dialogRef = this.dialog.open(DialogcontentComponent);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

  setFocus(){
    this.question.nativeElement.focus();
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();
    console.log(this.options.filter(option => option.toLowerCase().includes(filterValue)).length)
    if(filterValue.length>0){

      return this.options.filter(option => option.toLowerCase().includes(filterValue));
    }else{
      return [];
    }
  }

}

