import { TrimFuncDirective } from './trim-func.directive';

describe('TrimFuncDirective', () => {
  it('should create an instance', () => {
    let elRefMock = {
      nativeElement: document.createElement('div')
    };
    const directive = new TrimFuncDirective(elRefMock);
    expect(directive).toBeTruthy();
  });
});
