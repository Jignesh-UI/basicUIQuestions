import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  // selector: '[appTrimData]'
  selector: 'input [type="text"],input [type="email"]'
})
export class TrimFuncDirective {

  constructor(private el: ElementRef) { }

    @HostListener('blur') applyTrim() {
      let ele = this.el.nativeElement as HTMLInputElement;
        if (typeof ele.value === 'string') {
            ele.value = ele.value.trim();
        }
    }


}
