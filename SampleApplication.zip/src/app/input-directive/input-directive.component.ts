import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-input-directive',
  templateUrl: './input-directive.component.html',
  styleUrls: ['./input-directive.component.scss']
})
export class InputDirectiveComponent implements OnInit {

  maxLengthofControls = {
    'mhidMaxLength': 15,
    'ISBN13MaxLength': 50,
    'PREVIOUS_ISBNMaxLength': 15,
    'NEW_ISBNMaxLength': 15,
    'AUTHORMaxLength': 240,
    'TITLEMaxLength': 1500,
    'EDITIONMaxLength': 22,
    'PublicationstatusMaxLength': 16,
    'ODDMaxLength': 150,
    'SDDMaxLength': 150,
    'CopyYearMaxLength': 22,
    'BoundBookDateMaxLength': 7,
    'PermissionEndDateMaxLength': 7,
    'ProjectOPdateMaxLength': 7,
    'DeliveryFormatMaxLength': 150,
    'TitleTypeMaxLength': 240,
    'GradeRangeMaxLength': 5,
    'SpecificMarketMaxLength': 150,
    'iPubPublishingGroupMaxLength': 20,
    'iPubProgramTitleMaxLength': 500,
    'PageCountMaxLength': 22,
    'LibraryLocationMaxLength': 500,
    'PrintingMaxLength': 22,
    'SetsofDiscsMaxLength': 22,
    'DiscsinSetMaxLength': 22,
    'DiscSizeMaxLength': 22,
    'ArchiveNotesMaxLength': 4000
  };

  showReprintInput: boolean = false;

  pagingFilesList = [
    { label: 'InDesign', listVar: 'InDesign', disabled: false, checked: false },
    { label: 'Quark', listVar: 'Quark', disabled: false, checked: false },
    { label: 'TeX', listVar: 'TeX', disabled: false, checked: false },
    { label: 'MSWord', listVar: 'MSWord', disabled: false, checked: false },
    { label: 'None', listVar: 'None', disabled: false, checked: false },
    { label: 'Other', listVar: 'Other', disabled: false, checked: false }
  ];

  otherFilesList = [
    { label: 'Cover/Design', listVar: 'Cover/Design', disabled: false, checked: false },
    { label: 'Images', listVar: 'Images', disabled: false, checked: false },
    { label: 'None', listVar: 'NoneOther', disabled: false, checked: false },
    { label: 'Other', listVar: 'OtherFiles', disabled: false, checked: false }
  ];
  
  condition = false;
  
  constructor() { }

  ngOnInit(): void {
  }

  over(){
    console.log("Mouseover called");
  }

  pagingFilesSeletionChange(event: any): void {
    if (event.target.value == "None" && event.target.checked) {
      this.pagingFilesList.forEach(v => v.disabled = !v.disabled);
      this.pagingFilesList.filter(v => v.listVar == "None")[0].disabled = false;
    } else {
      this.pagingFilesList.forEach(v => v.disabled = false);
    }
  }

  otherFilesSelectionChange(event: any): void {
    if (event.target.value == "NoneOther" && event.target.checked) {
      this.otherFilesList.forEach(v => v.disabled = !v.disabled);
      this.otherFilesList.filter(v => v.listVar == "NoneOther")[0].disabled = false;
    } else {
      this.otherFilesList.forEach(v => v.disabled = false);
    }
  }

  
  reprintValueChange(selectedValue: any) {
    this.showReprintInput = selectedValue.toLowerCase() == "other" ? true : false;
  }


  onSubmit():void{

  }

}
