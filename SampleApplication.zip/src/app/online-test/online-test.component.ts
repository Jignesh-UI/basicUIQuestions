import { Component, OnInit } from '@angular/core';
import { MyExamService } from '../shared/services/my-exam.service';

@Component({
  selector: 'app-online-test',
  templateUrl: './online-test.component.html',
  styleUrls: ['./online-test.component.scss']
})
export class OnlineTestComponent implements OnInit {
  isSubmitted: boolean = false;
  currentQuestionIndex: number = 0;
  currentQuestion: Question | undefined;
  selectedAnswer: string = '';
  results: TestResult[] = [];
  remainingMinutes: number | any;
  remainingSeconds: number | any;
  constructor(private examService: MyExamService) { }

  ngOnInit(): void {
    // this.examService.startTimer()
    this.loadQuestion();
  }

  loadQuestion() {
    this.currentQuestion = this.examService.getQuestion(this.currentQuestionIndex);
    this.selectedAnswer = '';
  }

  submitAnswer() {
    const result: TestResult = {
      question: this.currentQuestion!,
      selectedAnswer: this.selectedAnswer
    };
    this.results.push(result);

    if (this.currentQuestionIndex === this.examService.getTotalQuestions() - 1) {
      this.isSubmitted = true;
    } else {
      this.currentQuestionIndex++;
      this.loadQuestion();
    }
  }

}



export interface Question {
  text: string;
  options: string[];
  correctAnswer: string;
}

export interface TestResult {
  question: Question;
  selectedAnswer: string;
}

