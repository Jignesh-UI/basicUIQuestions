import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LovDataService } from '../app-form-test/lov-data.service';
import { NotificationService } from '../app-form-test/notification.service';
import { ComponentService } from '../shared/component.service';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss'],
})
export class ReportsComponent implements OnInit {
  isLoading: boolean = false;
  showSearch: boolean = false;

  selecteTableDrp: string = '';
  conditionDrp: string = '';

  columns:colProperties[] = [];
  selectedColumns: any = [];
  displayColumns: any = [];
  properties: propInterface[] = [
    {
      order: 1,
      propertyName: '',
      condition: '',
      operator: '',
      value: '',
      properties: [],
      conditions: [],
      drpvalues: [],
    },
  ];

  displaySelected: any[] = [];
  message: string = '';
  today: string;
  referenceProp = [];
  userName: string = '';
  dropDownOptions = [
    'ARCHIVIST',
    'STORAGE_LOCATION',
    'IN_PROCESS',
    'FILESREQUESTED',
  ];
  searchPageArray: any[] = [];
  searchPropertiesArray: any[] = [];

  constructor(
    private activatedRoute: ActivatedRoute,
    private http: HttpClient,
    private communicationService: ComponentService,
    private lovData: LovDataService,
    private notify: NotificationService
  ) {
    const today = new Date();
    const date =
      today.getFullYear() +
      '-' +
      (today.getMonth() + 1) +
      '-' +
      today.getDate();
    const time =
      today.getHours() + ':' + today.getMinutes() + ':' + today.getSeconds();
    const dateTime = date + ' ' + time;
    this.today = dateTime;
  }

  async ngOnInit(): Promise<void> {
    this.properties = [
      {
        order: 1,
        propertyName: '',
        condition: '',
        operator: '',
        value: '',
        properties: [],
        conditions: [],
        drpvalues: [],
      },
    ];
    await this.loadLovs();
  }

  onAddProperty() {
    if (this.properties.length <= 4) {
      this.properties.push({
        order: this.properties.length + 1,
        propertyName: '',
        condition: '',
        operator: '',
        value: '',
        // properties: { text: '', value: '' },
        drpvalues: [],
      });
    }
  }

  onTableChange(ctrl: any, obj: any) {
    const filterValue = ctrl.currentTarget.options[
      ctrl.currentTarget.selectedIndex
    ].value
      .trim()
      .replace('_', ' ');
    obj.isDropdown = false;
    obj.isDateProperty = false;
    this.columns = [];
    this.displayColumns = [];
    this.selectedColumns = [];
    this.displaySelected = [];
    if (filterValue == '-1') {
      this.searchPropertiesArray = [];
      this.properties = [
        {
          order: 1,
          propertyName: '',
          condition: '',
          operator: '',
          value: '',
          properties: [],
          conditions: [],
          drpvalues: [],
        },
      ];
      this.notify.showSuccess('', 'asd');
      return false;
    }
    this.isLoading = true;
    let getPropertyArray: any;
    if (filterValue === 'Archive Record') {
      getPropertyArray = [
        ...this.lovData.returnSingleLOV('COMMON_CRITERIA'),
        ...this.lovData.returnSingleLOV('ARCHIVE_RECORD_CRITERIA'),
      ];
      this.columns = getPropertyArray;
      this.sortAvailableColumns();
      this.adjustProperties(getPropertyArray);
    } else if (filterValue === 'Archive Request') {
      getPropertyArray = [
        ...this.lovData.returnSingleLOV('COMMON_CRITERIA'),
        ...this.lovData.returnSingleLOV('ARCHIVE_REQUEST_CRITERIA'),
      ];
      this.columns = getPropertyArray;
      this.sortAvailableColumns();
      this.adjustProperties(getPropertyArray);
    } else if (filterValue === 'Associated' || filterValue === 'NIMAS') {
      this.columns = [];
      this.searchPropertiesArray = [];
      this.properties = [
        {
          order: 1,
          propertyName: '',
          condition: '',
          operator: '',
          value: '',
          properties: [],
          conditions: [],
          drpvalues: [],
        },
      ];
    }

    // this.columns = getPropertyArray;
    this.searchPropertiesArray = getPropertyArray;
    this.isLoading = false;
    return true;
  }

  adjustProperties(paramdata: any[]) {
    this.properties = [
      {
        order: 1,
        propertyName: '',
        condition: '',
        operator: '',
        value: '',
        properties: paramdata,
        conditions: [],
        isDateProperty: false,
      },
    ];
  }

  onPropertyChange(obj: any) {
    obj.condition = '';
    obj.conditions = [];

    this.isLoading = true;

    let filterConditionType = this.searchPropertiesArray.filter((svalue) => {
      if (svalue.valueField == obj.propertyName) {
        return svalue.valueField;
      }
    })[0].lovCode;

    if (filterConditionType.search('NUMBER') > 0) {
      obj.conditions = this.lovData.returnSingleLOV('CONTAINS_VALUES_NUMBER');
      this.conditionDrp = '-1';
      obj.isDateProperty = false;
    } else if (filterConditionType.search('STRING') > 0) {
      obj.conditions = this.lovData.returnSingleLOV('CONTAINS_VALUES_STRING');
      this.conditionDrp = '-1';
      obj.isDateProperty = false;
    } else if (filterConditionType.search('DATE') > 0) {
      obj.conditions = this.lovData.returnSingleLOV('CONTAINS_VALUES_DATE');
      this.conditionDrp = '-1';
      obj.isDateProperty = true;
    } else {
      this.notify.showSuccess('', '');
    }
    obj.isDropdown = false;
    obj.condition = obj.conditions[0].value;
    this.isLoading = false;
  }

  onConditionChange(obj: any) {
    if (
      this.dropDownOptions.indexOf(obj.propertyName) >= 0 &&
      obj.condition.trim().toLowerCase() == 'equals'
    ) {
      this.isLoading = true;
      this.drpDataFilled(obj);
      obj.isDropdown = true;
      this.isLoading = false;
    } else {
      obj.isDropdown = false;
    }
  }

  drpDataFilled(propObj: any) {
    if (propObj.propertyName == 'ARCHIVIST') {
      const newDataArray = this.lovData.returnSingleLOV(propObj.propertyName);
      propObj.drpvalues = newDataArray.map((v: { description: any }) => {
        return { text: v.description, value: v.description };
      });
    } else if (propObj.propertyName == 'STORAGE_LOCATION') {
      const newDataArray = this.lovData.returnSingleLOV(propObj.propertyName);
      propObj.drpvalues = newDataArray.map((v: { description: any }) => {
        return { text: v.description, value: v.description };
      });
    } else if (propObj.propertyName == 'IN_PROCESS') {
      propObj.drpvalues = [
        { text: 'Yes', value: 'Y' },
        { text: 'No', value: 'N' },
      ];
    } else if (propObj.propertyName == 'FILESREQUESTED') {
      const newDataArray = [
        ...this.lovData.returnSingleLOV('PDFS'),
        ...this.lovData.returnSingleLOV('REQUESTEDFILES'),
      ];
      propObj.drpvalues = newDataArray.map((v) => {
        return { text: v.description, value: v.description };
      });
    }
  }

  onClear() {
    this.selecteTableDrp = '-1';
    this.properties = [
      {
        order: 1,
        propertyName: '',
        condition: '',
        operator: '',
        value: '',
        properties: [],
        conditions: [],
      },
    ];
    this.columns = [];
    this.selectedColumns = [];
    this.displayColumns = [];
    this.displaySelected = [];
    this.message = '';
  }

  onRemoveProperty(obj: any) {
    if (obj.order !== 1) {
      this.properties = this.properties.filter((prop: any) => prop !== obj);
    }
  }

  moveToSelected() {
    let selectedObjs = this.columns.filter(
      (col: any) => this.selectedColumns.indexOf(col.valueField) >= 0
    );
    this.columns = this.columns.filter(
      (col: any) => this.selectedColumns.indexOf(col.valueField) < 0
    );
    this.displayColumns = this.displayColumns.concat(selectedObjs);
    this.selectedColumns = this.displayColumns.map((dc: any) => dc.valueField);
  }

  moveToAvailable() {
    for (let i = 0; i < this.displaySelected.length; i++) {
      const element: any[] = this.displayColumns.filter(
        (col: any) => this.displaySelected.indexOf(col.valueField) >= 0
      );
      this.columns.splice(2, 0, element[i]);
    }
    this.columns.sort((col: any) => col.description);
    this.displayColumns = this.displayColumns.filter(
      (col: any) => this.displaySelected.indexOf(col.valueField) < 0
    );
    this.displaySelected = [];
    this.selectedColumns = [];
    this.sortAvailableColumns();
  }

  sortAvailableColumns() {
    console.log(this.columns);
    let data0:colProperties[] = [];
    let data1:colProperties[] = [];
    let data2:colProperties[] = [];

    this.columns.forEach((v: colProperties) =>{
      if(v.description == "MHID" || v.description == "ISBN-13"){
        data0.push(v);
      }else{
        if(v.lovType == "COMMON_CRITERIA"){
          data1.push(v);
        }else{
          data2.push(v);
        }
      }
    });

    data1.sort((a,b) => {
      return a.description.localeCompare(b.description)
    });

    data2.sort((a,b) => {
      return a.description.localeCompare(b.description)
    });

    this.columns = [];
    this.columns.push(...data0, ...data1, ...data2);
    console.log(this.columns.length);

  }

  resetColumns(paramdata1: any, data3: colProperties[]) {

    let data0:colProperties[] = [];
    let data1:colProperties[] = [];
    paramdata1.forEach((v: colProperties) => {
      if(v.description == "MHID" || v.description == "ISBN-13"){
        data0.push(v);
      }else{
        data1.push(v)
      }
    });

    data1.sort((a,b) => {
      return a.description.localeCompare(b.description)
    });

    data3.sort((a,b) => {
      return a.description.localeCompare(b.description)
    });

    this.columns = [];
    this.columns.push(...data0, ...data1, ...data3);
    console.log(this.columns.length);
  }

  createReport() {}

  adjustDisplayedColumns() {
    return this.displayColumns.map(
      (dc: { valueField: any; description: any }, index: any) =>
        [
          {
            order: index,
            propertyName: dc.valueField,
            displayName: dc.description,
          },
        ][0]
    );
  }

  saveReport(reportName: any) {}

  moveUp() {
    let isUndefined: any;
    if (this.displaySelected.length === this.displayColumns.length) {
      return;
    } else {
      for (let i = 0; i < this.displaySelected.length; i++) {
        for (let j = 0; j < this.displayColumns.length; j++) {
          if (this.displaySelected[i] === this.displayColumns[j].valueField) {
            const temp = this.displayColumns[j - 1];
            isUndefined = temp;
            if (isUndefined !== undefined) {
              this.displayColumns[j - 1] = this.displayColumns[j];
              this.displayColumns[j] = temp;
            } else {
              break;
            }
          }
        }
        if (isUndefined === undefined) {
          break;
        }
      }
      this.selectedColumns = this.displayColumns.map(
        (dc: { valueField: any }) => dc.valueField
      );
    }
  }

  moveDown() {
    let isUndefined: any;
    if (this.displaySelected.length === this.displayColumns.length) {
      return;
    } else {
      for (let j = this.displaySelected.length - 1; j >= 0; j--) {
        for (let i = this.displayColumns.length - 1; i >= 0; i--) {
          if (this.displayColumns[i].valueField === this.displaySelected[j]) {
            const temp = this.displayColumns[i + 1];
            isUndefined = temp;
            if (isUndefined !== undefined) {
              this.displayColumns[i + 1] = this.displayColumns[i];
              this.displayColumns[i] = temp;
            } else {
              break;
            }
          }
        }
        if (isUndefined === undefined) {
          break;
        }
      }
      this.selectedColumns = this.displayColumns.map(
        (dc: { valueField: any }) => dc.valueField
      );
    }
  }

  async loadLovs() {
    this.searchPageArray = this.lovData.returnSingleLOV('SEARCH_TYPE');
    this.selecteTableDrp = '-1';
  }

  searchStringErrorHandler(
    selecteTable: string,
    selectedColumns: DisplayColumns[],
    properties: object[],
    fromSaveReport: boolean = false
  ) {
    let searchFlag: boolean = false;

    if (
      selecteTable == '-1' ||
      selecteTable == null ||
      selecteTable == undefined
    ) {
      searchFlag = true;
      this.notify.showSuccess('', 'not working ');
      return false;
    }

    if (!searchFlag) {
      if (
        selectedColumns == null ||
        selectedColumns == undefined ||
        selectedColumns.length < 1
      ) {
        searchFlag = true;
        this.notify.showSuccess('', 'not working 383');
        return false;
      }
    }

    if (searchFlag) {
      return false;
    }
    return true;
  }
}

export class DisplayColumns {
  order: number | undefined;
  propertyName: string | undefined;
  displayName: string | undefined;
}

export interface propInterface {
  order: number;
  propertyName: string;
  condition: string;
  operator: string;
  value: string;
  properties?: propertiesChild[];
  conditions?: any[];
  drpvalues?: any[];
  isDateProperty?: boolean;
  isDropdown?: boolean;
}

export interface colProperties {
  lovid:number;
  lovType:string;
  lovCode:string;
  description:string;
  valueField:string;
  enabled:string;
  orderSeq?:number;
}

export interface propertiesChild{
  text: string
  value: string
}
