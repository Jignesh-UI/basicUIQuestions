import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scrum-mikhil',
  templateUrl: './scrum-mikhil.component.html',
  styleUrls: ['./scrum-mikhil.component.scss']
})
export class ScrumMikhilComponent implements OnInit {

  scrumData:listData[] = [];
  localData:listData[] = [
    {
    "question": "What is the input to the Sprint Planning? Select four.",
    "answersList": [
      { "option": "Past performance of the Development Team", "correct":'true' },
      { "option": "Feedback from the Organization CEO"},
      { "option": "Projected capacity of the Development Team during the Sprint", "correct":'true' },
      { "option": "The latest product Increment", "correct":'true' },
      { "option": "The Product Backlog", "correct":'true' }
    ],
    "description":"The input to the Sprint Planning is the Product Backlog, the latest product Increment, projected capacity of the Development Team during the Sprint, and past performance of the Development Team."
  },{
    "question": "What are Product Backlog features? Select three.",
    "answersList": [
      { "option": "It is never complete", "correct":'true' },
      { "option": "It is dynamic", "correct":'true' },
      { "option": "A Product Backlog could be closed when it contains no items to include into the next Sprint"},
      { "option": "As long as a product exists, its Product Backlog also exists", "correct":'true' }
    ],
    "description":"A Product Backlog is never complete. The earliest development of it only lays out the initially known and best-understood requirements. The Product Backlog evolves as the product and the environment in which it will be used evolves. The Product Backlog is dynamic; it constantly changes to identify what the product needs to be appropriate, competitive, and useful. As long as a product exists, its Product Backlog also exists."
  },{
    "question": "Who participates in the Sprint Planning? Select three.",
    "answersList": [
      { "correct":'true', "option": "The Product Owner" },
      { "correct":'true', "option": "The Scrum Master" },
      { "option": "The Team Manager" },
      { "correct":'true', "option": "The Development Team" }
    ],
    "description":"The work to be performed in the Sprint is planned at the Sprint Planning. This plan is created by the collaborative work of the entire Scrum Team."
  },{
    "question": " ",
    "answersList": [
      { "correct":'true', "option": "" },
      { "correct":'true', "option": "" },
      { "option": "" },
      { "correct":'true', "option": "" }
    ],
    "description":""
  }
];


  constructor() { }

  ngOnInit(): void {
  }

}

export interface listData{
  id?:string;
  question: string;
  answersList: answerLists[];
  description?:string;
}

export interface answerLists{
  option:string;
  correct?:string;
}

export interface correctAnswerLists{
  option:string;
}

