import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { SharedModule } from "../shared/shared-module";

import { ScrumMikhilComponent } from "./scrum-mikhil/scrum-mikhil.component";
import { ScrumQComponent } from "./scrum-q.component";
import { ScrumQFormComponent } from "./scrum-qform/scrum-qform.component";
import { ScrumSet1Component } from "./scrum-set1/scrum-set1.component";
import { VocabularyComponent } from "./vocabulary/vocabulary.component";


@NgModule({
    declarations:[
        ScrumMikhilComponent,
        ScrumSet1Component,
        ScrumQFormComponent,
        ScrumQComponent,
        VocabularyComponent
    ],
    exports:[
        ScrumMikhilComponent,
        ScrumSet1Component,
        ScrumQFormComponent,
        ScrumQComponent,
        VocabularyComponent
    ],
    imports:[
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        SharedModule
    ],
    providers:[]
})


export class ScrumModule{ }
