import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';


@Component({
  selector: 'app-scrum-q',
  templateUrl: './scrum-q.component.html',
  styleUrls: ['./scrum-q.component.scss']
})
export class ScrumQComponent implements OnInit {
  isLoading:boolean = false;
  dbUrl = 'https://scrumquestions-215e9-default-rtdb.firebaseio.com/scrum.json';

  scrumData:listData[] = [];

  constructor(private http: HttpClient) { }

  async ngOnInit() {
    this.loadData();
  }

  onSubmit(form: NgForm){
    this.uploadData(form);
  }

  uploadData(form: NgForm){
    this.isLoading = true;
      return this.http.post(this.dbUrl,{
          question: form.value.quest,
          answer: form.value.answ,
          description: form.value.desc
      })
      .pipe(catchError(this.handleError),
      tap(resData => {
          // this.handleAuthentication(resData.email, resData.localId, resData.idToken, +resData.expiresIn)
      })
      ).subscribe(resData=>{
        console.log(resData);
        this.loadData();
        form.reset();
        this.isLoading = false;
        form.value.quest.focus();
      });
  }

  loadData(){
    this.isLoading = true;
    return this.http.get<listData[]>(this.dbUrl)
    .pipe(
      map(responseData =>{
        const postArray = [];
        for(const keys in responseData){
          postArray.push({...responseData[keys], id:keys})
        }
        console.log(postArray)
        return postArray;
      })
    )
    .pipe(catchError(this.handleError))
    .subscribe(respData => {
      console.log(respData);
      this.scrumData = respData;
      this.isLoading = false;
    })
  }

  private handleError(errorRes: HttpErrorResponse){
    let errorMessage = 'Server not responding! Please try after sometimg.';
    if(!errorRes.error || !errorRes.error.error){
        return throwError(errorMessage);
    }
    switch(errorRes.error.error.message){
        case 'EMAIL_EXISTS':
            errorMessage = 'This email already exists!';
            break;
        case 'OPERATION_NOT_ALLOWED':
            errorMessage = 'This email already exists!';
            break;
        case 'TOO_MANY_ATTEMPTS_TRY_LATER':
            errorMessage = 'This email already exists!';
            break;
        case 'EMAIL_NOT_FOUND':
            errorMessage = 'This email not found try to signUp!';
            break;
        case 'INVALID_PASSWORD':
            errorMessage = 'Email and Password combination is not matched!';
            break;
        case 'USER_DISABLED':
            errorMessage = 'Your account is temporarly disabled!';
            break;
        default:
            errorMessage = 'Server Not Responding';
            break;
    }

    console.log(errorMessage);

    return throwError(errorMessage);
  }

}


export interface listData{
  // id:string;
  question: string;
  answer: string;
  description: string;
}