import { HttpClient } from '@angular/common/http';
import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators, NgModel } from '@angular/forms';
import { ErrorMessagesService } from 'src/app/shared/services/error-messages.service';
import { catchError, map } from 'rxjs/operators';

@Component({
  selector: 'app-scrum-qform',
  templateUrl: './scrum-qform.component.html',
  styleUrls: ['./scrum-qform.component.scss']
})
export class ScrumQFormComponent implements OnInit {
  isLoading:boolean = false;
  dbUrl = 'https://scrumquestions-215e9-default-rtdb.firebaseio.com/scrumSet2.json';
  dataForm: FormGroup;
  dataArray:formInterface[]=[];
  check: any;
  @ViewChild('txtquestion', {static:true, read:ElementRef}) question: ElementRef<HTMLInputElement>;

  // @ViewChild('txtquestion',{ static: true }) question!: ElementRef<HTMLInputElement>;
  

  constructor(private http: HttpClient, private ems: ErrorMessagesService, private fb:FormBuilder) {
    this.dataForm = new FormGroup({
      'question':new FormControl('',Validators.required),
      'description': new FormControl(''),
      answers: this.fb.array([ ])
    });
    this.question = {} as ElementRef;
  }

  ngOnInit(): void {
    // this.loadData();
  }

  get answers(): FormArray{
    return this.dataForm.get('answers') as FormArray;
  }

  addanswers(){
    const newRows:number = 4;
    for(let i=0;i<newRows;i++){
      const lForm = this.fb.group({
        cAnswer:[false, Validators.required],
        answer:['', Validators.required]
      });
      this.answers.push(lForm);
    }
  }

  deleteLesson(lessonIndex: number){
    this.answers.removeAt(lessonIndex);
  }

  onSubmit(){
    // this.isLoading = true;
    return this.http.post(this.dbUrl,this.dataForm.value)
    .pipe(map(ts=>{
      this.isLoading = true;
    }))
      .pipe(catchError(this.ems.handleError)).subscribe(resData=>{
        this.isLoading = false;
        this.dataArray.push({... this.dataForm.value});
        this.resetForm();
        this.question.nativeElement.focus();
      });
  }

  resetForm(){
    this.dataForm.reset();
    (this.dataForm.get('answers') as FormArray).clear();
    this.question.nativeElement.focus();
  }

  resetAnswers(){
    (this.dataForm.get('answers') as FormArray).clear();
  }

  loadData(){
    this.isLoading = true;
    return this.http.get<formInterface[]>(this.dbUrl)
    .pipe(
      map(responseData =>{
        const postArray:any[] = [];
        for (const keys in responseData) {
          if (responseData.hasOwnProperty(keys) ) {
            postArray.push(Object.values(responseData));
          }
        }
        return Object.values(postArray)[0];
      })
    )
    .pipe(catchError(this.ems.handleError))
    .subscribe(respData => {
      this.dataArray = respData.slice().reverse();
      // this.isLoading = false;

    })
  }

}


export interface formInterface{
    question:string,
    answers: answerListsArray[],
    description:string
}

export interface answerListsArray{
  cAnswer?:boolean;
  answer:string
}