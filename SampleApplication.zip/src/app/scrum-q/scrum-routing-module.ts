import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { ScrumMikhilComponent } from "./scrum-mikhil/scrum-mikhil.component";
import { ScrumQComponent } from "./scrum-q.component";
import { ScrumQFormComponent } from "./scrum-qform/scrum-qform.component";
import { ScrumSet1Component } from "./scrum-set1/scrum-set1.component";
import { VocabularyComponent } from "./vocabulary/vocabulary.component";


const scrumRoutes: Routes = [
    { path: 'scrum', component:ScrumQComponent },
    { path: 'scrumm', component:ScrumMikhilComponent },
    { path: 'scrumset1', component:ScrumSet1Component},
    { path: 'scrumfrm', component:ScrumQFormComponent},
    { path: 'vocabulary', component: VocabularyComponent }
];

@NgModule({
    imports:[RouterModule.forChild(scrumRoutes)],
    exports:[RouterModule]
})

export class scrumRoutingModule{}
