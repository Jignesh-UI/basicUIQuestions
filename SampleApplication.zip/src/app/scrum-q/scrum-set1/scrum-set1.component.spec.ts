import { HttpClient, HttpHandler } from '@angular/common/http';
import { NO_ERRORS_SCHEMA } from '@angular/compiler';
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ScrumSet1Component } from './scrum-set1.component';

describe('ScrumSet1Component', () => {
  let component: ScrumSet1Component;
  let fixture: ComponentFixture<ScrumSet1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ScrumSet1Component ],
      providers:[HttpClient, HttpHandler],
      schemas:[NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ScrumSet1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
