import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { ErrorMessagesService } from 'src/app/shared/services/error-messages.service';

@Component({
  selector: 'app-scrum-set1',
  templateUrl: './scrum-set1.component.html',
  styleUrls: ['./scrum-set1.component.scss']
})
export class ScrumSet1Component implements OnInit {
  isLoading:boolean = false;
  dbUrl = 'https://scrumquestions-215e9-default-rtdb.firebaseio.com/scrumSet1.json';

  scrumData:listDataSet2[] = [];

//   newJSON = [{
//     "question": "What does the Product Owner do during a Sprint?",
//     "answersList": [
//         {"option": "Protects the Team and the process"},
//         {"option": "Clarifies requirements and answers questions"},
//         {"option": "Guides the Team in its work"},
//         {"option": "Intervenes when required to make sure the pace of work is sustainable"}
//     ],
// "answer":"Clarifies requirements and answers questions"
// },
// {
//     "question": "Which role is responsible for turning the Product Backlog into incremental pieces of functionality?",
//     "answersList": [
//         {"option": "Product Owner"},
//         {"option": "ScrumMaster"},
//         {"option": "Team"},
//         {"option": "Everyone within the Project"}
//     ],
// "answer":"Team"
// },{
//     "question": "If a Team member is consistently late for the Daily Scrum, what is usually the first thing a Team should do?",
//     "answersList": [
//         {"option": "Report the Team member to his or her manager"},
//         {"option": "Have the Team member do the testing"},
//         {"option": "Meet with the Team member to determine a solution"},
//         {"option": "Ask the ScrumMaster to move the Team member off the Team"}
//     ],
// "answer":"Meet with the Team member to determine a solution"
// },{
//     "question": "Who is responsible for facilitating the Sprint Retrospective Meeting?",
//     "answersList": [
//         {"option": "Team"},
//         {"option": "Product Owner"},
//         {"option": "Scrum Master"},
//         {"option": "No One"}
//     ],
// "answer":"ScrumMaster"
// },{
//     "question": "During a Daily Scrum meeting, Olivia mentions she has found some open source code she thinks will solve one of the problems she has been working on. She wants to implement it immediately. What is the best next step?",
//     "answersList": [
//         {"option": "The ScrumMaster tells Olivia to prepare an example and presentation for the Team so they can consider using the code"},
//         {"option": "After the Daily Scrum meeting is held, a separate meeting is conducted to discuss the open source solution"},
//         {"option": "All members of the Team are told to evaluate Olivia's solution and report back to the team at the next Daily Scrum meeting."},
//         {"option": "The Product Owner notes the impediment and solves the problem after the meeting"}
//     ],
// "answer":"After the Daily Scrum meeting is held, a separate meeting is conducted to discuss the open source solution"
// },{
//     "question": "What is the ScrumMaster's role in the Sprint Retrospective?",
//     "answersList": [
//         {"option": "To determine the re-composition of the Team"},
//         {"option": "To facilitate the Team's search for improvements"},
//         {"option": "To lead the Team in the evaluation of each individual Team member"},
//         {"option": "To provide answers to the challenges that the Team identifies"}
//     ],
// "answer":"To facilitate the Team's search for improvements"
// },{
//     "question": "Who is primarily responsible for maintaining the Product Backlog?",
//     "answersList": [
//         {"option": "Scrum Team"},
//         {"option": "ScrumMaster"},
//         {"option": "Product Owner"},
//         {"option": "Stakeholders"}
//     ],
// "answer":"Product Owner"
// },{
//     "question": "Which role is MOST LIKELY to communicate an impediment during a Daily Scrum?",
//     "answersList": [
//         {"option": "Product Owner"},
//         {"option": "Team"},
//         {"option": "Stakeholders"},
//         {"option": "Scrum Master"}
//     ],
// "answer":"Team"
// },{
//     "question": "Why should the Product Owner attend the Daily Scrum?",
//     "answersList": [
//         {"option": "To comment on the Team's progress"},
//         {"option": "To make sure the Team is still on target for its Sprint goals"},
//         {"option": "To tell the Team which tasks to work on next and update the Product Backlog"},
//         {"option": "To see the progress being made and determine whether the Team needs help"}        
//     ],
// "answer":"To see the progress being made and determine whether the Team needs help"
// },{
//     "question": "Which of the following is true concerning impediments?",
//     "answersList": [
//         {"option": "The Team should not use daily Scrum meetings to report impediments"},
//         {"option": "It is the ScrumMaster's top priority to remove impediments"},
//         {"option": "It is the Product Owner's job to remove impediments."},
//         {"option": "A slow running server is not considered an impediment"}
//     ],
// "answer":"It is the ScrumMaster's top priority to remove impediments"
// },{
//     "question": "In a 30-day Sprint, how long is the Sprint Review Meeting?",
//     "answersList": [
//         {"option": "Four hours maximum"},
//         {"option": "Four to eight hours"},
//         {"option": "At least eight hours"},
//         {"option": "As long as required"}
//     ],
// "answer":"Four hours maximum"
// },{
//     "question": "Which of the following is a responsibility of the Product Owner?",
//     "answersList": [
//         {"option": "Determine the appropriate release dates"},
//         {"option": "Determine the appropriate technical solution for the project."},
//         {"option": "Determine the Team composition necessary for success"},
//         {"option": "Determine the length of the Sprints"}
//     ],
// "answer":"Determine the appropriate release dates"
// },{
//     "question": "According to Scrum guidelines, who is responsible for hiring or assigning a new person into a Team?",
//     "answersList": [
//         {"option": "ScrumMaster"},
//         {"option": "Product Owner"},
//         {"option": "This is outside of the scope of Scrum"},
//         {"option": "The self-managing Team"}
//     ],
// "answer":"The self-managing Team"
// },{
//     "question": "What are the desirable qualities of a Product Vision?",
//     "answersList": [
//         {"option": "Features a detailed overview that enlightens and inspires"},
//         {"option": "Provides a complete breakdown structure of the ROI formula"},
//         {"option": "Describes why the project is pursued and the product desired end state"},
//         {"option": "Outlines traceability back to overall corporate governance in IT investment"}
//     ],
// "answer":"Describes why the project is pursued and the product desired end state"
// },{
//     "question": "Which of the following statements is TRUE about Scrum teams and planning?",
//     "answersList": [
//         {"option": "Scrum Teams place value in following a plan, but they value responding to change even more"},
//         {"option": "Planning is not important in Scrum."},
//         {"option": "Scrum is intended to be an efficient way to carry out plans that have already been made"},
//         {"option": "Traditional planning is replaced by the Sprint Burndown chart"}
//     ],
// "answer":"Scrum Teams place value in following a plan, but they value responding to change even more"
// },{
//     "question": "The ScrumMaster…",
//     "answersList": [
//         {"option": "Controls the priority order of items in the team's backlog"},
//         {"option": "Is the Team's Scrum expert."},
//         {"option": "Creates, refines and communicates customer requirements to the Team"},
//         {"option": "Is the keeper of the product vision"}
//     ],
// "answer":"Is the Team's Scrum expert."
// },{
//     "question": "How do the principles behind the Agile Manifesto suggest approaching architecture?",
//     "answersList": [
//         {"option": "Architecture emerges"},
//         {"option": "Architecture is not important, but functionality is important"},
//         {"option": "Architecture is defined and planned up front"},
//         {"option": "Architecture is defined and implemented in the first iterations"}
//     ],
// "answer":"Architecture emerges"
// },{
//     "question": "How are the Product Owner's responsibilities BEST described?",
//     "answersList": [
//         {"option": "Directing the Team's daily activities"},
//         {"option": "Keeping stakeholders from distracting the Team"},
//         {"option": "Managing the project and ensuring that the work meets the commitments to the stakeholders"},
//         {"option": "Optimizing the business value of the work"}
//     ],
// "answer":"Optimizing the business value of the work"
// },{
//     "question": "If a Team determines that it has over-committed itself for a Sprint, who should be present when reviewing and adjusting the Sprint goal and work?",
//     "answersList": [
//         {"option": "Product Owner and Stakeholders"},
//         {"option": "Product Owner, ScrumMaster, and Team"},
//         {"option": "ScrumMaster, Project Manager, Team"},
//         {"option": "Team"}
//     ],
// "answer":"Product Owner, ScrumMaster, and Team"
// },{
//     "question": "What does Scrum's definition of done help a Team produce?",
//     "answersList": [
//         {"option": "Functionality that has been deployed to the users and delivers real business value"},
//         {"option": "Functionality that has been designed and analyzed"},
//         {"option": "Product functionality ready to be tested"},
//         {"option": "An increment of potentially shippable product"}
//     ],
// "answer":"An increment of potentially shippable product"
// },{
//     "question": "After a Team has committed to a Sprint goal, what authority does it have?",
//     "answersList": [
//         {"option": "The Team has authority to swap Sprint backlog items with Product Backlog items if it cannot finish them."},
//         {"option": "The Team works under the authority of the Product Architect, who has set the definition of done"},
//         {"option": "The Team works according to the priorities set by the ScrumMaster, as the ScrumMaster is committed to the Scrum framework"},
//         {"option": "The Team does whatever is necessary to achieve the goal"}
//     ],
// "answer":"The Team does whatever is necessary to achieve the goal"
// },{
//     "question": "Which of the following is a MAIN purpose of a Sprint Backlog?",
//     "answersList": [
//         {"option": "For the ScrumMaster to manage the progress during the Sprint"},
//         {"option": "For the Team to manage themselves during the Sprint"},
//         {"option": "For the Team to manage the number of hours spent on tasks in the Sprint"},
//         {"option": "For the Product Owner to understand what the Team has committed to for a Sprint"}
//     ],
// "answer":"For the Team to manage themselves during the Sprint"
// },{
//     "question": "What is the main purpose of a Sprint Review?",
//     "answersList": [
//         {"option": "For the Team to review their work and to determine what is needed to complete the next set of backlog items"},
//         {"option": "For Stakeholders to review what the Team has built and to give input on what to do next"},
//         {"option": "For Stakeholders to “hold the Team's feet to the fire” - to make sure something is produced during the Sprint"},
//         {"option": "For the Product Manager to be able to show progress to the Stakeholders"}
//     ],
// "answer":"For Stakeholders to review what the Team has built and to give input on what to do next"
// },{
//     "question": "What does the Team do during the first Sprint?",
//     "answersList": [
//         {"option": "Delivers design documents"},
//         {"option": "Develops a plan for the rest of the Sprints"},
//         {"option": "Predetermines the complete architecture and infrastructure"},
//         {"option": "Accomplishes the Sprint goal"}
//     ],
// "answer":"Accomplishes the Sprint goal"
// },{
//     "question": "When using Scrum, who is primarily responsible for making scope versus schedule trade-off decisions?",
//     "answersList": [
//         {"option": "The Project Manager"},
//         {"option": "The Team"},
//         {"option": "The Product Owner"},
//         {"option": "The Scrum Master"}
//     ],
// "answer":"The Product Owner"
// },{
//     "question": "Can the Product Owner and the ScrumMaster be the same person?",
//     "answersList": [
//         {"option": "No. The person would have too much power and it would create confusion"},
//         {"option": "Yes, if the person has the authority and empowerment to do both things"},
//         {"option": "No. It would take too much of one person's time"},
//         {"option": "Yes, as long as the person can balance both responsibilities with care"}
//     ],
// "answer":"No. The person would have too much power and it would create confusion"
// },{
//     "question": "How does the Agile Manifesto address planning?",
//     "answersList": [
//         {"option": "Planning is not required in an agile project, as the project is focused on current status"},
//         {"option": "Responding to change is more important than following a plan"},
//         {"option": "Sign-off on the detail of Product Backlog items is mandatory before any item can be planned into an iteration."},
//         {"option": "Upfront planning and design is an integral stage before development can begin."}
//     ],
// "answer":"Responding to change is more important than following a plan"
// },{
//     "question": "When should the Burndown Chart be updated?",
//     "answersList": [
//         {"option": "After every Sprint"},
//         {"option": "After every day"},
//         {"option": "After every release"},
//         {"option": "After every week"}
//     ],
// "answer":"After every day"
// },{
//     "question": "Once a Team starts a Sprint, who determines how the Team does its work?",
//     "answersList": [
//         {"option": "Project Manager"},
//         {"option": "Team lead"},
//         {"option": "ScrumMaster"},
//         {"option": "Team"}
//     ],
// "answer":"Team"
// },{
//     "question": "Which statement is accurate about the role of the Product Owner during the Daily Scrum?",
//     "answersList": [
//         {"option": "The Product Owner's participation is defined by the Team"},
//         {"option": "The Product Owner outlines the additional changes that must be absorbed by the Team in the Sprint"},
//         {"option": "The Product Owner ensures the Burndown rate is maintained at the estimated rate"},
//         {"option": "The Product Owner provides instruction to the Team on how to implement a workable solution"}
//     ],
// "answer":"The Product Owner's participation is defined by the Team"
// },{
//     "question": "The CEO asks the Team to add a story to the current Sprint. What should the Team do?",
//     "answersList": [
//         {"option": "Respect the CEO's authority and add the story to the current Sprint without any adjustments"},
//         {"option": "Add the story to the next Sprint."},
//         {"option": "Inform the Product Owner so he/she can work with the CEO"},
//         {"option": "Add the story to the current Sprint and drop a story of equal size"}
//     ],
// "answer":"Inform the Product Owner so he/she can work with the CEO"
// },{
//     "question": "What is MOST likely to result if the Product Owner is not available during a Sprint?",
//     "answersList": [
//         {"option": "The Team extends the length of the Sprint until the Product Owner returns"},
//         {"option": "The ScrumMaster assumes the responsibilities of the Product Owner."},
//         {"option": "The Sprint is abnormally terminated"},
//         {"option": "The product increment may not meet expectations"}
//     ],
// "answer":"The product increment may not meet expectations"
// },{
//     "question": "Agile Manifesto says to value responding to change over following a plan. Which of the following statements illustrates this?",
//     "answersList": [
//         {"option": "Changes are accepted only if other features are removed from the backlog such that a fixed end-date is maintained"},
//         {"option": "Changes are accepted up until the point that the first Sprint begins. Then, changes are deferred to a future release"},
//         {"option": "Changes are accepted at any time during the development effort depending on the business value of the change, the Product Owner's acceptance, and the ability of the team to respond in a timeframe acceptable to the Product Owner"},
//         {"option": "Changes are accepted up until about halfway through the project, then all changes are deferred to a future release"}
//     ],
// "answer":"Changes are accepted at any time during the development effort depending on the business value of the change, the Product Owner's acceptance, and the ability of the team to respond in a timeframe acceptable to the Product Owner"
// },{
//     "question": "What is the approach that Scrum encourages when a Team determines it will be difficult to deliver any value by the end of a Sprint?",
//     "answersList": [
//         {"option": "Together with the Product Owner, focus on what can be done and identify a way to deliver something valuable at the end of each Sprint"},
//         {"option": "Extend the Sprint by a few days to accommodate the extra work"},
//         {"option": "Suggest the Product Owner abnormally terminate the Sprint"},
//         {"option": "Immediately escalate to Senior Management."}
//     ],
// "answer":"Together with the Product Owner, focus on what can be done and identify a way to deliver something valuable at the end of each Sprint"
// },{
//     "question": "Who is required to attend the Daily Scrum?",
//     "answersList": [
//         {"option": "Development Team"},
//         {"option": "The Scrum team."},
//         {"option": "The Development Team and Scrum Master."},
//         {"option": "The Development Team and Product Owner."},
//         {"option": "The Scrum Master and Product Owner."}
//     ],
// "answer":"Development Team"
// },{
//     "question": "The CEO asks the Development Team to add a “very important” item to the current Sprint. What should the Development Team do?",
//     "answersList": [
//         {"option": "Add the item to the current Sprint without any adjustments."},
//         {"option": "Add the item to the current Sprint and drop an item of equal siz"},
//         {"option": "Add the item to the next Sprint."},
//         {"option": "Inform the Product Owner so he/she can work with the CEO."}
//     ],
// "answer":"Inform the Product Owner so he/she can work with the CEO."
// },{
//     "question": "The purpose of a Sprint is to have a working increment of product done before the Sprint Review.",
//     "answersList": [
//         {"option": "True"},
//         {"option": "False"}
//     ],
// "answer":"True"
// },{
//     "question": "Why is the Daily Scrum held at the same time and same place?",
//     "answersList": [
//         {"option": "The place can be named."},
//         {"option": ""},
//         {"option": "The Product Owner demands it."},
//         {"option": "Rooms are hard to book and this lets it be booked in advance."}
//     ],
// "answer":"The consistency reduces complexity and overhea"
// },{
//     "question": "How much work must a Development Team do to a Product Backlog item it selects for a Sprint?",
//     "answersList": [
//         {"option": "As much as it has told the Product Owner will be done for every Product Backlog item it selects in conformance with the definition of done."},
//         {"option": "As much as it can fit into the Sprint."},
//         {"option": "The best it can do given that it is usually impossible for QA to finish all of the testing that is needed to prove shippability."},
//         {"option": "Analysis, design, programming, testing and documentation."}
//     ],
// "answer":"As much as it has told the Product Owner will be done for every Product Backlog item it selects in conformance with the definition of done."
// },{
//     "question": "What does it mean to say that an event has a timebox?",
//     "answersList": [
//         {"option": "The event must happen at a set time"},
//         {"option": "The event must happen by a given time."},
//         {"option": "The event must take at least a minimum amount of time"},
//         {"option": "The event can take no more than a maximum amount of time."}
//     ],
// "answer":"The event can take no more than a maximum amount of time."
// },{
//     "question": "The time box for the complete Sprint Planning meeting is?",
//     "answersList": [
//         {"option": "4 Hours"},
//         {"option": "8 hours for a monthly Sprint. For shorter Sprints it is usually shorter."},
//         {"option": "Whenever it is done"},
//         {"option": "Monthly"}
//     ],
// "answer":"8 hours for a monthly Sprint. For shorter Sprints it is usually shorter."
// },{
//     "question": "The three pillars of empirical process control are:",
//     "answersList": [
//         {"option": "Respect For People, Kaizen, Eliminating Waste"},
//         {"option": "Planning, Demonstration, Retrospective"},
//         {"option": "Inspection, Transparency, Adaptation"},
//         {"option": "Planning, Inspection, Adaptation"},
//         {"option": " Transparency, Eliminating Waste, Kaizen"}
//     ],
// "answer":"Inspection, Transparency, Adaptation"
// },{
//     "question": "Who is responsible for registering the work estimates during a Sprint?",
//     "answersList": [
//         {"option": "The Development Team."},
//         {"option": "The Scrum Master."},
//         {"option": "The Product Owner."},
//         {"option": "The most junior member of the Team."}
//     ],
// "answer":"The Development Team."
// },{
//     "question": "Scrum Master is a “management” position?",
//     "answersList": [
//         {"option": "True"},
//         {"option": "False"}
//     ],
// "answer":"True"
// },{
//     "question": "What is the role of Management in Scrum?",
//     "answersList": [
//         {"option": "To continually monitor staffing levels of the Development Team."},
//         {"option": "To monitor the Development Team's productivity."},
//         {"option": "Management supports the Product Owner with insights and information into high-value product and system capabilities. Management supports the Scrum Master to cause organizational change that fosters empiricism, self-organization, bottom-up intelligence, and intelligent release of softwar"},
//         {"option": "To identify and remove people that aren't working hard enough."}
//     ],
// "answer":"Management supports the Product Owner with insights and information into high-value product and system capabilities. Management supports the Scrum Master to cause organizational change that fosters empiricism, self-organization, bottom-up intelligence, and intelligent release of softwar"
// },{
//     "question": "Which statement best describes a Product Owner's responsibility?",
//     "answersList": [
//         {"option": "Optimizing the value of the work the Development Team does."},
//         {"option": "Directing the Development Team."},
//         {"option": "Managing the project and ensuring that the work meets the commitments to the stakeholders."},
//         {"option": "Keeping stakeholders at bay."}
//     ],
// "answer":"Optimizing the value of the work the Development Team does."
// },{
//     "question": "During a Sprint, a Development Team determines that it will not be able to finish the complete forecast. Who should be present to review and adjust the Sprint work selected?",
//     "answersList": [
//         {"option": "The Scrum Master, the project manager and the Development Team."},
//         {"option": "The Product Owner and the Development Team."},
//         {"option": "The Product Owner and all stakeholders."},
//         {"option": "The Development Team."}
//     ],
// "answer":"The Product Owner and the Development Team."
// },{
//     "question": "Development Team membership should change:",
//     "answersList": [
//         {"option": "Every Sprint to promote shared learning."},
//         {"option": "Never, because it reduces productivity."},
//         {"option": "As needed, while taking into account a short term reduction in productivity."},
//         {"option": "Just as it would on any development team, with no special allowance for changes in productivity."}
//     ],
// "answer":"As needed, while taking into account a short term reduction in productivity."
// },{
//     "question": "An abnormal termination of a Sprint is called when?",
//     "answersList": [
//         {"option": "When it is clear at the end of a Sprint that everything won't be finished."},
//         {"option": "When the Team feels that the work is too hard."},
//         {"option": "When Sales has an important opportunity."},
//         {"option": "When the Product Owner determines that it makes no sense to finish it"}
//     ],
// "answer":"When the Product Owner determines that it makes no sense to finish it"
// },{
//     "question": "The Product Backlog is ordered by",
//     "answersList": [
//         {"option": "Small items at the top to large items at the bottom."},
//         {"option": "Safer items at the top to riskier items at the bottom."},
//         {"option": "Least valuable items at the top to most valuable at the bottom."},
//         {"option": "Items are randomly arranged."},
//         {"option": "Whatever is deemed most appropriate by the Product Owner."}
//     ],
// "answer":"Whatever is deemed most appropriate by the Product Owner."
// },{
//     "question": "When does the next Sprint begin?",
//     "answersList": [
//         {"option": "Next Monday."},
//         {"option": "Immediately following the next Sprint Planning."},
//         {"option": "When the Product Owner is ready."},
//         {"option": "Immediately after the conclusion of the previous Sprint"}
//     ],
// "answer":"Immediately after the conclusion of the previous Sprint"
// },{
//     "question": "Which statement best describes the Sprint Review?",
//     "answersList": [
//         {"option": "It is a review of the team's activities during the Sprint."},
//         {"option": "It is when the Scrum Team and stakeholders inspect the outcome of the Sprint and figure out what to do in the upcoming Sprint."},
//         {"option": "It is a demo at the end of the Sprint for everyone in the organization to provide feedback on the work done."},
//         {"option": "It is used to congratulate the Development Team if it did what it committed to doing, or to punish the Development Team if it failed to meet its commitments."}
//     ],
// "answer":"It is when the Scrum Team and stakeholders inspect the outcome of the Sprint and figure out what to do in the upcoming Sprint."
// },{
//     "question": "Upon what type of process control is Scrum based?",
//     "answersList": [
//         {"option": "Empirical"},
//         {"option": "Hybrid"},
//         {"option": "Defined"},
//         {"option": "Complex"}
//     ],
// "answer":"Empirical"
// },{
//     "question": "When is a Sprint over?",
//     "answersList": [
//         {"option": "When all Product Backlog items meet their definition of done."},
//         {"option": "When the Product Owner says it is don"},
//         {"option": "When all the tasks are complete"},
//         {"option": "When the timebox expires."}
//     ],
// "answer":"When the timebox expires."
// },{
//     "question": "When multiple teams are working together, each team should maintain a separate Product Backlog.",
//     "answersList": [
//         {"option": "True"},
//         {"option": "False"}
//     ],
// "answer":"False"
// },{
//     "question": "What is the primary way a Scrum Master keeps a Development Team working at its highest level of productivity?",
//     "answersList": [
//         {"option": "By facilitating Development Team decisions and removing impediments."},
//         {"option": "By ensuring the meetings start and end at the proper time."},
//         {"option": "By preventing changes to the backlogs once the Sprint begins."},
//         {"option": "By keeping high value features high in the Product Backlog."}
//     ],
// "answer":"By facilitating Development Team decisions and removing impediments."
// },{
//     "question": "When many Development Teams are working on a single product, what best describes the definition of “done?”",
//     "answersList": [
//         {"option": "Each Development Team defines and uses its own. The differences are discussed and reconciled during a hardening Sprint."},
//         {"option": "Each Development Team uses its own but must make their definition clear to all other Teams so the differences are known."},
//         {"option": "All Development Teams must have a definition of “done” that makes their combined work potentially releasabl"},
//         {"option": "It depends."}
//     ],
// "answer":"All Development Teams must have a definition of “done” that makes their combined work potentially releasabl"
// },{
//     "question": "During the Daily Scrum, the Scrum Master's role is to:",
//     "answersList": [
//         {"option": "Lead the discussions of the Development Team."},
//         {"option": "Make sure that all 3 questions have been answered."},
//         {"option": "Manage the meeting in a way that each team member has a chance to speak."},
//         {"option": "Teach the Development Team to keep the Daily Scrum within the 15 minute timebox. All of the above."}
//     ],
// "answer":"Teach the Development Team to keep the Daily Scrum within the 15 minute timebox. All of the above."
// },{
//     "question": "Which statement best describes Scrum?",
//     "answersList": [
//         {"option": "A complete methodology that defines how to develop softwar"},
//         {"option": "A cookbook that defines best practices for software development."},
//         {"option": "A framework within which complex products in complex environments are developed."},
//         {"option": "A defined and predictive process that conforms to the principles of Scientific Management."}
//     ],
// "answer":"A framework within which complex products in complex environments are developed."
// },{
//     "question": "What is the typical size for a Scrum Team?",
//     "answersList": [
//         {"option": "Minimal 7"},
//         {"option": "10 or fewer."},
//         {"option": "7 plus or minus 2"},
//         {"option": "9"}
//     ],
// "answer":"10 or fewer."
// },{
//     "question": "The Development Team should not be interrupted during the Sprint. The Sprint Goal should remain intact. These are conditions that foster creativity, quality and productivity. Based on this, which of the following is false?",
//     "answersList": [
//         {"option": "The Product Owner can help clarify or optimize the Sprint when asked by the Development Team."},
//         {"option": "The Sprint Backlog and its contents are fully formulated in the Sprint Planning meeting and do not change during the Sprint."},
//         {"option": "As a decomposition of the selected Product Backlog Items, the Sprint Backlog changes and may grow as the work emerges."},
//         {"option": "The Development Team may work with the Product Owner to remove or add work if it finds it has more or less capacity than it expected."}
//     ],
// "answer":"The Sprint Backlog and its contents are fully formulated in the Sprint Planning meeting and do not change during the Sprint."
// },{
//     "question": "What is the approach that Scrum encourages when a team determines it will be difficult to deliver any values by the end of a Spint?",
//     "answersList": [
//         {"option": "Together with the Product Owner, focus on what can be done and identify a way to deliver something valuable at the end of each Sprint."},
//         {"option": "Suggest the Product Owner abnormally terminate the Sprint."},
//         {"option": "Extend the Sprint by a few days to accommodate the extra work."},
//         {"option": "Immediately escalate to Senior Management"}
//     ],
// "answer":"Together with the Product Owner, focus on what can be done and identify a way to deliver something valuable at the end of each Sprint."
// },{
//     "question": "What is MOST likely to result if the Product Owner is not available during a Sprint?",
//     "answersList": [
//         {"option": "The product increment may not meet expectations."},
//         {"option": "The Sprint is abnormally terminated."},
//         {"option": "The Development Team extends the length of the Sprint until the Product Owner returns."},
//         {"option": "The ScrumMaster assumes the responsibilities of the Product Owner."}
//     ],
// "answer":"The product increment may not meet expectations."
// },{
//     "question": "Who is primarily responsible for maintaining the Product Backlog?",
//     "answersList": [
//         {"option": "Stakeholders"},
//         {"option": "CEO"},
//         {"option": "ScrumMaster"},
//         {"option": "Product Owner"},
//         {"option": "Scrum Development Team"}
//     ],
// "answer":"Product Owner"
// },{
//     "question": "Can the Product Owner and the ScrumMaster be the same person?",
//     "answersList": [
//         {"option": "No. The role responsibilities are in conflict."},
//         {"option": "No. It would take too much of one person's time"},
//         {"option": "Yes, if the person has the authority and empowerment to do both things."},
//         {"option": "Yes, as long as the person can balance both responsibilities with care."}
//     ],
// "answer":"No. The role responsibilities are in conflict."
// },{
//     "question": "If a Development Team determines that it has over-committed itself for a Sprint, who should be present when reviewing and adjusting the Sprint goal and work?",
//     "answersList": [
//         {"option": "Development Team"},
//         {"option": "ScrumMaster, Project Manager, Development Team."},
//         {"option": "Product Owner and Stakeholders"},
//         {"option": "Product Owner, SCrumMaster and Development Team."}
//     ],
// "answer":"Product Owner, SCrumMaster and Development Team."
// },{
//     "question": "During a Daily Scrum meeting, Olivia mentions she has found an available solution and she thinks that will solve one of the problems she has been working on. She wants to implement it immediately. What is the best next step?",
//     "answersList": [
//         {"option": "The ScrumMaster tells Olivia to prepare an example and presentation for the Team so they can consider using the code."},
//         {"option": "The Product Owner notes the impediment and solves the problem after the meeting."},
//         {"option": "All members of the Team are told to evaluate Olivia's solution and report back to the team at the next Daily Scrum meeting."},
//         {"option": "After the Daily Scrum a separate meeting is conducted to discuss the proposed solution"}
//     ],
// "answer":"After the Daily Scrum a separate meeting is conducted to discuss the proposed solution"
// },{
//     "question": "Which of the following is true concerning impediments?",
//     "answersList": [
//         {"option": "A slow running serve is not considered an impediment."},
//         {"option": "The Team should not use Daily Scrum meetings to report impediments."},
//         {"option": "It is the ScrumMaster's top priority to remove impediments."},
//         {"option": "It is the Product Owner's job to remove impediments."}
//     ],
// "answer":"It is the ScrumMaster's top priority to remove impediments."
// },{
//     "question": "The ScrumMaster… is the Scrum Team's Scrum expert and focuses on continual improvement.",
//     "answersList": [
//         {"option": "Creates, refines and communicates customer requirements to the Development Team."},
//         {"option": "Is the keeper of the product vision."},
//         {"option": "Control the priority order of items in the Development Team's backlog."},
//         {"option": "Is the Scrum Team's Scrum expert and focuses on continual improvement."}
//     ],
// "answer":"Is the Scrum Team's Scrum expert and focuses on continual improvement."
// },{
//     "question": "Which of the following is likely the best option when a Product Owner is overworked?",
//     "answersList": [
//         {"option": "Free the Product Owner from other responsibilities."},
//         {"option": "Split the Product Owner role and distribute the duties among more people."},
//         {"option": "Limit the amount of the time the Product Owner spends with the Scrum Team."},
//         {"option": "Ask, the Project Manager to pick up some of the Product Owner's responsibilities."}
//     ],
// "answer":"Free the Product Owner from other responsibilities."
// },{
//     "question": "When using Scrum, who is primarily responsible for making scope versus schedule trade-off decisions?",
//     "answersList": [
//         {"option": "The Project Manager."},
//         {"option": "The Product Owner"},
//         {"option": "The Development Team"},
//         {"option": "The ScrumMaster"}
//     ],
// "answer":"The Product Owner"
// },{
//     "question": "Who is accountable for the business value delivered by a Scrum Team?",
//     "answersList": [
//         {"option": "ScrumMaster."},
//         {"option": "Project Manager."},
//         {"option": "Product Owner"},
//         {"option": "Program Manager"}
//     ],
// "answer":"Product Owner"
// },{
//     "question": "What is the main purpose of a Sprint Review?",
//     "answersList": [
//         {"option": "For the Product Manager to be able to show progress to the Stakeholders"},
//         {"option": "For Stakeholders to “hold the Scrum Team's feet to the fire”- to make sure something is produced during the Sprint."},
//         {"option": "For the Scrum Team and stakeholders to review what the Scrum Team has built, and to collaborate on what could be done next to create valu"},
//         {"option": "For the Scrum Team to review their work and to determine what is needed to complete the next set of backlog items."}
//     ],
// "answer":"For the Scrum Team and stakeholders to review what the Scrum Team has built, and to collaborate on what could be done next to create valu"
// },{
//     "question": "How do the principles behind the Agile Manifesto suggest approaching architecture?",
//     "answersList": [
//         {"option": "Architecture is not important, but functionality is important."},
//         {"option": "Architecture is defined and planned up front."},
//         {"option": "Architecture emerges."},
//         {"option": "Architecture is defined and implemented in the first iterations."}
//     ],
// "answer":"Architecture emerges."
// },{
//     "question": "For what type of work is Scrum MOST suitable?",
//     "answersList": [
//         {"option": "Simple"},
//         {"option": "Complex"},
//         {"option": "Pre-defined"},
//         {"option": "Low-risk"}
//     ],
// "answer":"Complex"
// },{
//     "question": "According to Scrum guidelines, who is responsible for hiring or assigning a new person into a Team?",
//     "answersList": [
//         {"option": "This is outside of the scope of Scrum."},
//         {"option": "ScumMaster"},
//         {"option": "Product Owner"},
//         {"option": "The self-managing Team"}
//     ],
// "answer":"This is outside of the scope of Scrum."
// },{
//     "question": "Why should the Product Owner attend the Daily Scrum?",
//     "answersList": [
//         {"option": "To help clarify requirements."},
//         {"option": "To tell the Development Team members which task to work on next."},
//         {"option": "To connect on the Development Team's progress."},
//         {"option": "To make sure the Development Team is still on target to meet its Sprint Goals."}
//     ],
// "answer":"To help clarify requirements."
// },{
//     "question": "Who is primarily responsible for ensuring that everyone follows Scrum rules and practices?",
//     "answersList": [
//         {"option": "The Product Owner."},
//         {"option": "The ScrumMaster"},
//         {"option": "Each individual Scrum Team member"},
//         {"option": "All Scrum Team members collectively"}
//     ],
// "answer":"The ScrumMaster"
// },{
//     "question": "What are the desirable qualities of a Product Vision?",
//     "answersList": [
//         {"option": "Describe why the projects is pursued and the product desired end state."},
//         {"option": "Features a detailed overview that enlightens and inspires"},
//         {"option": "Outlines traceability back to overall corporate governance in IT investment"},
//         {"option": "Provides a complete breakdown structure of the ROI formula"}
//     ],
// "answer":"Describe why the projects is pursued and the product desired end state."
// },{
//     "question": "Who is primarily responsible for facilitation, when required, in Scrum meetings?",
//     "answersList": [
//         {"option": "Product Owner"},
//         {"option": "ScrumMaster"},
//         {"option": "Development Team"},
//         {"option": "No one."}
//     ],
// "answer":"ScrumMaster"
// },{
//     "question": "In a 30-day Sprint, how long is the Sprint Review Meeting?",
//     "answersList": [
//         {"option": "Four hours maximum"},
//         {"option": "For to eight hours"},
//         {"option": "At least eight hours"},
//         {"option": "As long as required"}
//     ],
// "answer":"Four hours maximum"
// },{
//     "question": "Considering the Agile Manifesto, which of the following statements best describes Scrum Teams and planning?",
//     "answersList": [
//         {"option": "Scrum Team place value in following a plan, but they value responding to change even more."},
//         {"option": "Scrum is intended to an efficient way to carry out plans that have already been made."},
//         {"option": "Planning is not important in Scrum."},
//         {"option": "Traditional planning is replaced by the Sprint Burndown Chart."}
//     ],
// "answer":"Scrum Team place value in following a plan, but they value responding to change even more."
// },{
//     "question": "During a Sprint planning meeting, the Product Owner…",
//     "answersList": [
//         {"option": "Divides selected stories in to specific tasks."},
//         {"option": "Determines how the Development Team accomplishes it work."},
//         {"option": "Present stories he/she would like the Development Team to complete during the Sprint."},
//         {"option": "Decides how many stories will be delivered by the end of the Sprint."}
//     ],
// "answer":"Present stories he/she would like the Development Team to complete during the Sprint."
// },{
//     "question": "When is the Sprint finished?",
//     "answersList": [
//         {"option": "As determined by the size of the Team"},
//         {"option": "When the timebox expires"},
//         {"option": "When committed items have met their definition of done"},
//         {"option": "When task are complete"}
//     ],
// "answer":"When the timebox expires"
// },{
//     "question": "Once a Sprint begins, who determines how the Development Team will do its work?",
//     "answersList": [
//         {"option": "Development Team"},
//         {"option": "ScrumMaster"},
//         {"option": "Project Manager"},
//         {"option": "Development Team Lead"}
//     ],
// "answer":"Development Team"
// },{
//     "question": "Which of the following is a MAIN purpose of a Sprint Backlog?",
//     "answersList": [
//         {"option": "For the Development Team to manage the number of hours spent on tasks in the Sprint"},
//         {"option": "For the ScrumMaster to manage the Development Team's progress during the Sprint"},
//         {"option": "For the Product Owner to understand what the Development Team has committed to for a Sprint"},
//         {"option": "For the Development Team to organize themselves during the Sprint."}
//     ],
// "answer":"For the Development Team to organize themselves during the Sprint."
// },{
//     "question": "What is the ScrumMaster's role in the Sprint Retrospective?",
//     "answersList": [
//         {"option": "To lead the Scrum Team in the evaluation of each individual Scrum Team member."},
//         {"option": "To determine the re-composition of the Scrum Team"},
//         {"option": "To provide answers to the challenges that the Scrum Team identifies"},
//         {"option": "To facilitate the Scrum Team's search for improvements."}
//     ],
// "answer":"To facilitate the Scrum Team's search for improvements."
// },{
//     "question": "The Agile Manifesto says that “[we] value responding to change over following a plan.” Which of the following statements best illustrates this?",
//     "answersList": [
//         {"option": "Changes are accepted at any time at the discretion of the Product Owner."},
//         {"option": "Changes are accepted only if other Product Backlog items are removed from the Product Backlog so that a fixed end-date is maintaine"},
//         {"option": "Changes are accepted up until the point that the first Sprint begins. Then, changes are deferred to a future releas"},
//         {"option": "Changes are accepted up until about halfway through the project, then all changes are deferred to a future release."}
//     ],
// "answer":"Changes are accepted at any time at the discretion of the Product Owner."
// },{
//     "question": "What does the Product Owner do during a Sprint?",
//     "answersList": [
//         {"option": "Protects the Development Team and the process"},
//         {"option": "Clarifies requirements and answers questions"},
//         {"option": "Guides the Development Team in its work"},
//         {"option": "Intervenes when required to make sure the pace of work is sustainable."}
//     ],
// "answer":"Clarifies requirements and answers questions"
// },{
//     "question": "Which of the following best describes the Agile Manifesto attitude towards customer collaboration?",
//     "answersList": [
//         {"option": "The Team must communicate what functionality will be produced in a Sprint and the goal of the Team for the releas"},
//         {"option": "Regular and frequent feedback from the customer is essential."},
//         {"option": "Consensus from customers is required before new functional requirements can be inserted into a Sprint."},
//         {"option": "Collaborate closely with the customer and ensure all functionality is defined prior to the build phase of a project."}
//     ],
// "answer":"Regular and frequent feedback from the customer is essential."
// },{
//     "question": "What should usually happen if, during a Sprint, the Product Owner identifies a new, important Product Backlog Item (PBI)?",
//     "answersList": [
//         {"option": "The ScrumMaster encourages the Development Team to include the extra item."},
//         {"option": "The Development Team works overtime to finish the PBI in the current Sprint."},
//         {"option": "The Product Owner adds the new PBI to the Product Backlog"},
//         {"option": "The Scrum Team extends the Sprint duration to include the new item."}
//     ],
// "answer":"The Development Team works overtime to finish the PBI in the current Sprint."
// },{
//     "question": "If a Team member is consistently late for the Daily Scrum, what is usually the first thing a Team should do?",
//     "answersList": [
//         {"option": "Report the Team member to his or her manager."},
//         {"option": "Have the Team member do the testing."},
//         {"option": "Meet with the Team member to determine a solution."},
//         {"option": "Ask the ScrumMaster to move the Team member off the Team."}
//     ],
// "answer":"Meet with the Team member to determine a solution."
// },{
//     "question": "Which role is MOST LIKELY to communicate an impediment during a Daily Scrum?",
//     "answersList": [
//         {"option": "Scrum Team"},
//         {"option": "ScumMaster"},
//         {"option": "Product Owner"},
//         {"option": "Stakeholders"}
//     ],
// "answer":"Scrum Team"
// },{
//     "question": "Which of the following BEST represents the Product Owner's responsibility?",
//     "answersList": [
//         {"option": "Optimizing the business value of the work"},
//         {"option": "Directing the Development Team's daily activities."},
//         {"option": "Keeping stakeholders from distracting the Development Team"},
//         {"option": "Holding the Scrum Team responsible for commitments made to stakeholders"}
//     ],
// "answer":"Optimizing the business value of the work"
// },{
//     "question": "Which statement accurately reflects the role of the Product Owner during the Daily Scrum?",
//     "answersList": [
//         {"option": "The Product Owner provides instructions to the Development Team on how to implement a workable solution."},
//         {"option": "The Product Owner outlines the additional changes that the Development Team must add to the Sprint."},
//         {"option": "The Product Owner ensures the burndown rate is maintained so the Development Team can satisfy the Sprint goals."},
//         {"option": "The Product Owner's participations is desirable but optional"}
//     ],
// "answer":"The Product Owner's participations is desirable but optional"
// },{
//     "question": "How are Development Teams guided during a Sprint?",
//     "answersList": [
//         {"option": "By project documentation and the Scrum process"},
//         {"option": "By the ScrumMaster who ensures they are not wasting time"},
//         {"option": "By their collective knowledge and experience"},
//         {"option": "By the Product Owner who attends the Daily Stand-up"}
//     ],
// "answer":"By their collective knowledge and experience"
// }
// ];

  constructor(private http: HttpClient, private ems: ErrorMessagesService) { }

  async ngOnInit() {
    this.loadData();
  }

  onSubmit(form: NgForm){
    this.uploadData(form);
  }

  uploadData(form: NgForm){
    this.isLoading = true;
      return this.http.post(this.dbUrl,{
          question: form.value.quest,
          answer: form.value.answ,
          description: form.value.desc
      })
      .pipe(catchError(this.ems.handleError),
      tap(resData => {
          // this.handleAuthentication(resData.email, resData.localId, resData.idToken, +resData.expiresIn)
      })
      ).subscribe(resData=>{
        console.log(resData);
        this.loadData();
        form.reset();
        this.isLoading = false;
        form.value.quest.focus();
      });
  }

  loadData(){
    this.isLoading = true;
    return this.http.get<listDataSet2[]>(this.dbUrl)
    .pipe(
      map(responseData =>{
        const postArray = [];
        for (const keys in responseData) {
          console.log(responseData.hasOwnProperty(keys))
          if (responseData.hasOwnProperty(keys) ) {
            postArray.push(Object.values(responseData[keys]));
          }
        }
        console.log(postArray[0]);


        return Object.values(postArray[0]);
      })
    )
    .pipe(catchError(this.ems.handleError))
    .subscribe(respData => {
      this.scrumData = respData;
      this.isLoading = false;
    })
  }


}

export interface listDataSet2{
  id?:string;
  question: string;
  answersList: answerLists[];
  answer: string;
}

export interface answerLists{
  option:string;
}
