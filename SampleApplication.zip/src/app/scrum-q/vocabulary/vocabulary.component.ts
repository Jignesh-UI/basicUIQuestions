import { HttpClient } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { catchError, map } from 'rxjs/operators';
import { ErrorMessagesService } from 'src/app/shared/services/error-messages.service';




@Component({
  selector: 'app-vocabulary',
  templateUrl: './vocabulary.component.html',
  styleUrls: ['./vocabulary.component.scss']
})
export class VocabularyComponent implements OnInit {
  isLoading:boolean = false;
  dbUrl = 'https://scrumquestions-215e9-default-rtdb.firebaseio.com/vocabularySet.json';
  dataForm: FormGroup;
  dataArray:vocabInterface[]=[];
  @ViewChild('txtagileword') agileword: ElementRef<HTMLInputElement>;

  constructor(private http: HttpClient, private ems: ErrorMessagesService, private fb:FormBuilder) { 
    this.dataForm = new FormGroup({
      'agileword':new FormControl('',Validators.required),
      'description': new FormControl('', Validators.required)
    });
    this.agileword = {} as ElementRef;
  }

  ngOnInit(): void {
    this.loadData();
  }

  loadData(){
    this.isLoading = true;
    return this.http.get<vocabInterface[]>(this.dbUrl)
    .pipe(
      map(responseData =>{
        const postArray:any[] = [];
        for (const keys in responseData) {
          if (responseData.hasOwnProperty(keys) ) {
            postArray.push(Object.values(responseData));
          }
        }
        return Object.values(postArray)[0];
      })
    )
    .pipe(catchError(this.ems.handleError))
    .subscribe(respData => {
      this.dataArray = respData.slice().reverse();
      this.isLoading = false;

    })
  }

  onSubmit(){
    // this.isLoading = true;
    console.log(this.dataForm.value)
    return this.http.post(this.dbUrl,this.dataForm.value)
    .pipe(map(ts=>{
      this.isLoading = true;
    }))
      .pipe(catchError(this.ems.handleError)).subscribe(resData=>{
        this.isLoading = false;
        this.dataArray.push({... this.dataForm.value});
        this.dataArray = this.dataArray.slice().reverse();
        this.resetForm();
        this.agileword.nativeElement.focus();
      });
  }

  resetForm(){
    this.dataForm.reset();
    this.agileword.nativeElement.focus();
  }

}

export interface vocabInterface{
  agileword:string,
  description:string
}
