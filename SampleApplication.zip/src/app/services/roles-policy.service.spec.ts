import { TestBed } from '@angular/core/testing';

import { RolesPolicyService } from './roles-policy.service';

describe('RolesPolicyService', () => {
  let service: RolesPolicyService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RolesPolicyService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
