import { NO_ERRORS_SCHEMA } from '@angular/compiler';
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AlertDynamicComponent } from './alert-dynamic.component';

describe('AlertDynamicComponent', () => {
  let component: AlertDynamicComponent;
  let fixture: ComponentFixture<AlertDynamicComponent>;
  let mhid:string = "test";

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AlertDynamicComponent ],
      schemas:[NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AlertDynamicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
