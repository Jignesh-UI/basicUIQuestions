import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-alert-dynamic',
  templateUrl: './alert-dynamic.component.html',
  styleUrls: ['./alert-dynamic.component.scss']
})

export class AlertDynamicComponent {

  @Input() detailData: any;
  @Input() infoData: any;
  @Output() close = new EventEmitter<void>();

  details: Details = new Details;
  summary: Summary = new Summary;

  constructor() {
  }


  onClose(){
    this.close.emit();
  }

}


export class Summary{
  recordid?: number;
  mhid?: any;
  isbn13?: any;
  previousISBN: string | undefined;
  newISBN: string | undefined;
  author: string | undefined;
  title: string | undefined;
  edition: number | undefined;
  copyrightYear: number | undefined;
  boundBookDate: any;
  permissionEndDate: string | undefined;
  projectOPDate: string | undefined;
  ipubPublishingGroup: string | undefined;
  ipubProgrammingTitle: string | undefined;
  noOfPages: number | undefined;
  comments: string | undefined;
}

export class Details{
  archivist: any;
  compositorVendor: any;
  downloadDueDate: string | undefined;
  downloadReceivedDate:any;
  printingVersion:number | undefined;
  reprintContact: any;
  pagingFilesList:any;
  otherFilesList:any;
  pdfsList:any;
  createdDate: Date | undefined;
  createdBy: string | undefined;
  modifiedDate: Date | undefined;
  modifiedBy: string | undefined;
}
