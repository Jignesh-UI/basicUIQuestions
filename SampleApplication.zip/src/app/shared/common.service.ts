import { Injectable } from '@angular/core';
import { lovInterface } from '../app-form-test/models/common.model';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor() { }


  getDate(): any {
    var today = new Date();
    let month = today.getMonth() < 10 ? '0' + (today.getMonth()+1) : today.getMonth()+1;
    let todayDate = today.getDate() <  10 ? '0' + today.getDate() : today.getDate();
    var date = today.getFullYear() + '-' + month + '-' + todayDate;
    return date;
  }

  getDateTime(): any {
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ':' + today.getMinutes() + ':' + today.getSeconds();
    var dateTime = date + ' ' + time;
    return dateTime;
  }

  DateFormat(date: string, from: string, to: string, source: string): string {
    if (date) {
      if (source === 'html') {
        const d = new Date(date + ' 00:00:00.00');
        const dd = d.getDate();
        const mm = d.getMonth() + 1;
        const yy = d.getFullYear();
        const newdate = mm + '/' + dd + '/' + yy;
        return newdate;
      } else if (source === 'server') {
        const d = new Date(date + ' 00:00:00.00');
        const dd = d.getDate();
        const mm = d.getMonth() + 1;
        const yy = d.getFullYear();
        const newdate = mm + '-' + dd + '-' + yy;
        return newdate;
      }
    } else {
      return '';
    }
    return '';
  }

  getDatewithParam(date: string): any {
    const d = new Date(date + ' 00:00:00.00');
    const dd = d.getDate();
    const mm = d.getMonth() + 1;
    const yy = d.getFullYear();
    const newdate = mm + '/' + dd + '/' + yy;
    return newdate;
  }

  calculateDays(date1:Date, date2:Date) {
    let days = 0;
    var Time = new Date(date2).getTime() - new Date(date1).getTime();
    days = Time / (1000 * 3600 * 24); //Diference in Days
    return days >= 0 ? (days+1) : null;
  }

  getDateforSearchGrid(date: string): any {
    const d = new Date(date);
    const dd = d.getDate() <  10 ? '0' + d.getDate() : d.getDate();
    const mm = d.getMonth() < 9 ? '0' + (d.getMonth()+1) : d.getMonth()+1;
    const yy = d.getFullYear();
    return mm + '/' + dd + '/' + yy;
  }

  removePreviousArray(objArray: lovInterface[], objActualArray: lovInterface[]) {
    const obj = objArray.filter(({ lovid: id1 }) => !objActualArray.some(({ lovid: id2 }) => id2 === id1))[0];
    if (obj) {
      objArray = objArray.filter((item) => {
        return item.lovid != obj.lovid;
      });
    }
    return objArray;
  }

}
