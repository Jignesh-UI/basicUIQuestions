import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ComponentService {

  private messageSource = new BehaviorSubject({});
  searchCriteria = this.messageSource.asObservable();
  private _isAuthenticated = new BehaviorSubject(false);
  isAuthenticated = this._isAuthenticated.asObservable();
  private taskIdObserver = new BehaviorSubject(0);
  taskId = this.taskIdObserver.asObservable();
  private recordIdObserver = new BehaviorSubject(0);
  recordId = this.recordIdObserver.asObservable();
  constructor() { }

  changeMessage(message: {}) {
    this.messageSource.next(message);
  }
  changeIsAuthenticate(isAuth:boolean){
    this._isAuthenticated.next(isAuth)
  }
  changeTaskId(id: number){
    this.taskIdObserver.next(id);

  }
  changeRecordId(id: number){
    this.recordIdObserver.next(id);

  }

}
