import { DateFormatChangeDirective } from './date-format-change.directive';

describe('DateFormatChangeDirective', () => {
  it('should create an instance', () => {
    const directive = new DateFormatChangeDirective();
    expect(directive).toBeTruthy();
  });
});
