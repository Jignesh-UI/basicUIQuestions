import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: 'input [type="date"], datechange'
})
export class DateFormatChangeDirective {

  constructor(private el: ElementRef) { }

  @HostListener('blur', ['$event'])
  @HostListener('change', ['$event'])
  @HostListener('ngModelChange', ['$event'])
  changeFormat(){
    let ele = this.el.nativeElement as HTMLInputElement;
    if(ele.value != ""){
      console.log('this is string value' + ele.value);
      ele.value = this.getDatewithParam(ele.value);
    }
  }

  getDatewithParam(date: string): any {
    const d = new Date(date + ' 00:00:00.00');
    const dd = d.getDate();
    const mm = d.getMonth() + 1;
    const yy = d.getFullYear();
    const newdate = mm + '/' + dd + '/' + yy;
    // const newdate = yy + '/' + mm + '/' + dd;
    console.log(newdate)
    return newdate;
  }



}


// import { Directive, ElementRef, HostListener } from '@angular/core';

// @Directive({
//   selector: 'input [type="text"],input [type="email"], textarea'
// })
// export class TrimValueDirective {

//   constructor(private el: ElementRef) { }

//   @HostListener('blur', ['$event'])
//   @HostListener('mouseover', ['$event'])
//   applyTrim() {
//     let ele = this.el.nativeElement as HTMLInputElement;
//     if (typeof ele.value === 'string') {
//       ele.value = ele.value.trim();
//     }
//   }

// }
