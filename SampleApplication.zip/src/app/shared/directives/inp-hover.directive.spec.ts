import { ComponentFixture, TestBed } from '@angular/core/testing';
import { InputDirectiveComponent } from 'src/app/input-directive/input-directive.component';
import { InpHoverDirective } from './inp-hover.directive';

// describe('InpHoverDirective', () => {
//   it('should create an instance', () => {
//     const directive = new InpHoverDirective();
//     expect(directive).toBeTruthy();
//   });
// });


describe('InpHoverDirective', () => {
  let fixture: ComponentFixture<InputDirectiveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [InpHoverDirective, InputDirectiveComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(InputDirectiveComponent);
    fixture.detectChanges();
  });
});
