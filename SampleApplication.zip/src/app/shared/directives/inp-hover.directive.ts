import { Directive, ElementRef, Input } from '@angular/core';

@Directive({
  selector: '[appInpHover]',
  host: {
    '(mouseenter)': 'onMouseEnter()',
    '(mouseleave)': 'onMouseLeave()'
  }
})
export class InpHoverDirective {

  private _defaultColor = 'blue';
  // private el: HTMLElement;
  private maxVal:number = 0;
  private actValue:number = 0;

  constructor(private el: ElementRef) {
    // this.el = el.nativeElement;
  }



  @Input('myHighlight') highlightColor: string | undefined;

  onMouseEnter(): void {
    this.maxVal = this.el.nativeElement.maxLength;
    this.actValue = this.el.nativeElement.value.length;
    if(this.actValue >= this.maxVal){
      this.el.nativeElement.title = this.el.nativeElement.value;
    }
    console.log(this.el.nativeElement);
    console.log(this.el.nativeElement.value);
    // debugger;
    // this.highlight(this.highlightColor || this._defaultColor);
  }

  onMouseLeave(): void {
    this.el.nativeElement.title = '';
    // this.highlight('transparent');
  }

   private highlight(color:string) {
    // this.el.style.backgroundColor = color;
  }

}
