import { ComponentFixture, TestBed } from '@angular/core/testing';
import { InputDirectiveComponent } from 'src/app/input-directive/input-directive.component';
import { UnlessDirective } from './unless.directive';

// describe('UnlessDirective', () => {
//   it('should create an instance', () => {
//     const directive = new UnlessDirective();
//     expect(directive).toBeTruthy();
//   });
// });


describe('UnlessDirective', () => {
  let fixture: ComponentFixture<InputDirectiveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UnlessDirective, InputDirectiveComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(InputDirectiveComponent);
    fixture.detectChanges();
  });
});



//InputDirectiveComponent
