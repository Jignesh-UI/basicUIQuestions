import { SortArrayPipe } from './sort-array.pipe';

describe('SortArrayPipe', () => {
  it('create an instance', () => {
    const pipe = new SortArrayPipe();
    expect(pipe).toBeTruthy();
  });
});
