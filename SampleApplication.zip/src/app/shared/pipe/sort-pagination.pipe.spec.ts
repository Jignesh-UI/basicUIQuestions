import { SortPaginationPipe } from './sort-pagination.pipe';
import { ComponentFixture, TestBed } from '@angular/core/testing';

describe('SortPaginationPipe', () => {

  TestBed.configureTestingModule({
    declarations: [ SortPaginationPipe]
})

  it('create an instance', () => {
    const pipe = new SortPaginationPipe();
    expect(pipe).toBeTruthy();
  });

  it(`should return '...'`, () =>{
    const pipe = new SortPaginationPipe();
    expect(pipe.transform(-1)).toEqual('...')
  })

});
