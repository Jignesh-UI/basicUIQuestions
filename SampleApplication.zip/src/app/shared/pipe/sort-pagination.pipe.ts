import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sortPaginationPipe',
})
export class SortPaginationPipe implements PipeTransform {
  transform(value: number): any {
    if (!value) {
      return null;
    }
    let actuallimit = value == -1 ? '...' : value;
    return actuallimit;
  }
}
