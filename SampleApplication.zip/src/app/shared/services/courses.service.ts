import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class CoursesService {

  constructor() { }
  getCourses(){
    return ['text 1','text 2','text 3','text 4','text 5'];
  }
}
