import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ErrorMessagesService {

  constructor() { }

  handleError(errorRes: HttpErrorResponse){
    let errorMessage = 'Server not responding! Please try after sometimg.';
    if(!errorRes.error || !errorRes.error.error){
        return throwError(errorMessage);
    }
    switch(errorRes.error.error.message){
        case 'EMAIL_EXISTS':
            errorMessage = 'This email already exists!';
            break;
        case 'OPERATION_NOT_ALLOWED':
            errorMessage = 'This email already exists!';
            break;
        case 'TOO_MANY_ATTEMPTS_TRY_LATER':
            errorMessage = 'This email already exists!';
            break;
        case 'EMAIL_NOT_FOUND':
            errorMessage = 'This email not found try to signUp!';
            break;
        case 'INVALID_PASSWORD':
            errorMessage = 'Email and Password combination is not matched!';
            break;
        case 'USER_DISABLED':
            errorMessage = 'Your account is temporarly disabled!';
            break;
        default:
            errorMessage = 'Server Not Responding';
            break;
    }

    console.log(errorMessage);

    return throwError(errorMessage);
  }

}
