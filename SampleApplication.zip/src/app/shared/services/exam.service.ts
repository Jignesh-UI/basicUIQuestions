import { Injectable } from '@angular/core';
import { Observable, Subject, timer } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ExamService {

  constructor() { }

  private countdown$: Observable<number> | any;
  private countdownTimer: Subject<number> = new Subject<number>();

  startExamTimer(duration: number): Observable<number> {
    this.countdown$ = timer(0, 1000).pipe(
      takeUntil(this.countdownTimer),
      takeUntil(timer(duration * 1000)),
    );

    return this.countdown$;
  }

  stopExamTimer(): void {
    this.countdownTimer.next();
  }

}
