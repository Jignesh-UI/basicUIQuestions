import { HttpClient, HttpHandler } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';

import { LocalDataService } from './local-data.service';

describe('LocalDataService', () => {
  let service: LocalDataService;
  let matDialogService: jasmine.SpyObj<MatDialog>;
  matDialogService = jasmine.createSpyObj<MatDialog>('MatDialog', ['open']);

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers:[HttpClient, HttpHandler,
        {
          provide: MatDialog,
          useValue: matDialogService,
        }],
    });
    service = TestBed.inject(LocalDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
