import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class LocalDataService {
  private url: string = '../../assets/localData/localdata.json';
  private lovData: any[] = [];

  constructor(private http: HttpClient) { }


  loadListofLovs() {
    return this.http.get(this.url, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams().set('enabled', 'Y')
    })
    .pipe(map(rData=>{
      const arrayR: any[] = [];
      for(const keys in rData){
        if(rData.hasOwnProperty(keys) && keys === 'data'){
          arrayR.push(Object.values(rData)[1]);
        }
      }
      return arrayR[0];
    }),
    tap(rData=>{
      this.lovData = rData;
      // console.log(this.lovData);
      return this.lovData;
    }));
  }

  returnSingleLOV(param: string) {
    let singleLovArray = [];
    for (const keys in this.lovData) {
      if (this.lovData[keys].lovGroupType == param) {
        singleLovArray = this.lovData[keys].lovItemList;
      }
    }
    return singleLovArray;
  }

}
