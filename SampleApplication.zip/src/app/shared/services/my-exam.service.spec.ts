import { TestBed } from '@angular/core/testing';

import { MyExamService } from './my-exam.service';

describe('MyExamService', () => {
  let service: MyExamService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MyExamService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
