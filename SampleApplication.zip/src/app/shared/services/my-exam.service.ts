import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MyExamService {

  constructor() { }

  private questions: Question[] = [
    {
      text: 'What is the capital of France?',
      options: ['London', 'Paris', 'Berlin', 'Madrid'],
      correctAnswer: 'Paris'
    },
    {
      text: 'Who painted the Mona Lisa?',
      options: ['Pablo Picasso', 'Leonardo da Vinci', 'Vincent van Gogh', 'Michelangelo'],
      correctAnswer: 'Leonardo da Vinci'
    },
    {
      text: 'What is the largest planet in our solar system?',
      options: ['Earth', 'Jupiter', 'Mars', 'Saturn'],
      correctAnswer: 'Jupiter'
    }
  ];

  private timeLimitPerQuestion: number = 60; // seconds
  private timer: any;

  getQuestion(index: number): Question {
    return this.questions[index];
  }

  getTotalQuestions(): number {
    return this.questions.length;
  }

  getTimeLimitPerQuestion(): number {
    return this.timeLimitPerQuestion;
  }

  startTimer(callback: () => void) {
    let remainingTime = this.timeLimitPerQuestion;
    this.timer = setInterval(() => {
      remainingTime--;
      if (remainingTime === 0) {
        clearInterval(this.timer);
        callback();
      }
    }, 1000);
  }

  stopTimer() {
    clearInterval(this.timer);
  }
}

export interface Question {
  text: string;
  options: string[];
  correctAnswer: string;
}
