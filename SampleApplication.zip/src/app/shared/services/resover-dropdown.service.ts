import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { LocalDataService } from './local-data.service';

@Injectable({
  providedIn: 'root'
})
export class ResoverDropdownService implements Resolve<any[]> {

  constructor(private lData: LocalDataService) { }

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): any[] | Observable<any[]> | Promise<any[]> {
      return this.lData.loadListofLovs();
  }

}
