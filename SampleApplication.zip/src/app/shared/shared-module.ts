import { NgModule } from "@angular/core";

import { AlertDynamicComponent } from "./alert-dynamic/alert-dynamic.component";
import { AllmatcompModule } from "./allmatcomp.module";
import { DialogComponent } from "./dialog/dialog.component";
import { InpHoverDirective } from "./directives/inp-hover.directive";
import { UnlessDirective } from "./directives/unless.directive";
import { LoadingSpinnerComponent } from "./loading-spinner/loading-spinner.component";
import { PlaceholderDirective } from "./placeholder/placeholder.directive";


@NgModule({
    declarations:[
        AlertDynamicComponent,
        DialogComponent,
        LoadingSpinnerComponent,
        PlaceholderDirective,
        InpHoverDirective,
        UnlessDirective,
    ],
    exports:[
        AlertDynamicComponent,
        DialogComponent,
        LoadingSpinnerComponent,
        PlaceholderDirective,
        InpHoverDirective,
        UnlessDirective,
    ],
    providers:[],
    imports:[AllmatcompModule]
})

export class SharedModule{}
