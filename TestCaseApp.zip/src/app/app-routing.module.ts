import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Ass1Component } from './component/ass1/ass1.component';
import { AssociatedRecordComponent } from './component/associated-record/associated-record.component';
import { HomeComponent } from './component/home/home.component';
import { Nim1Component } from './component/nim1/nim1.component';
import { NimasComponent } from './component/nimas/nimas.component';
import { RequestComponent } from './component/request/request.component';
import { LOVResolverService } from './services/lovresolver.service';
import { CanDeactivateGuardService } from './shared/guards/can-deactivate-guard.service';

const routes: Routes = [
  { path:'', component:HomeComponent },
  { path:'home', component:HomeComponent},
  { path:'associated', component:AssociatedRecordComponent, canDeactivate:[CanDeactivateGuardService], resolve:[LOVResolverService]},
  { path:'nimas', component:NimasComponent, canDeactivate:[CanDeactivateGuardService], resolve:[LOVResolverService]},
  { path:'request', component:RequestComponent, canDeactivate:[CanDeactivateGuardService], resolve:[LOVResolverService]},
  { path:'as1', component:Ass1Component, canDeactivate:[CanDeactivateGuardService], resolve:[LOVResolverService]},
  { path:'nim1', component:Nim1Component, canDeactivate:[CanDeactivateGuardService], resolve:[LOVResolverService]}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
