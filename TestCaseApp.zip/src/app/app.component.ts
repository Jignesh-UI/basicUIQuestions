import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'testingApp';

  persons =['jignesh','Teju','dhwani'];

  // write a function to return the addition of two numbers
  add(a:number,b:number){
    return a+b;
  }

}
