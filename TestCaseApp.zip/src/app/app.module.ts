import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './component/home/home.component';
import { AssociatedRecordComponent } from './component/associated-record/associated-record.component';
import { NavigationComponent } from './component/navigation/navigation.component';
import { ToastrModule } from 'ngx-toastr';
import { LoadingSpinnerComponent } from './shared/loading-spinner/loading-spinner.component';
import { CommonModule } from '@angular/common';
import { TrimValueDirective } from './shared/directives/trim-value.directive';
import { ConfirmDialogComponent } from './shared/components/confirm-dialog/confirm-dialog.component';
import { MatDialogModule, MAT_DIALOG_DEFAULT_OPTIONS } from '@angular/material/dialog';
import { AllmatcompModule } from './allmatcomp.module';
import { NimasComponent } from './component/nimas/nimas.component';
import { RecordInformationComponent } from './shared/components/record-information/record-information.component';
import { InputHoverPopUpDirective } from './shared/directives/input-hover-pop-up.directive';
import { PdhipubComponent } from './shared/components/pdhipub/pdhipub.component';
import { Ass1Component } from './component/ass1/ass1.component';
import { Nim1Component } from './component/nim1/nim1.component';
import { RequestComponent } from './component/request/request.component';
import { Cmp1Component } from './component/cmp1/cmp1.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AssociatedRecordComponent,
    NavigationComponent,
    LoadingSpinnerComponent,
    TrimValueDirective,
    ConfirmDialogComponent,
    NimasComponent,
    RecordInformationComponent,
    InputHoverPopUpDirective,
    PdhipubComponent,
    Ass1Component,
    Nim1Component,
    RequestComponent,
    Cmp1Component
  ],
  imports: [
    BrowserModule,
    AllmatcompModule,
    CommonModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatDialogModule,

    ToastrModule.forRoot({positionClass: 'toast-center-center', closeButton: true , toastClass: 'ngx-toastr' }),
  ],
   providers: [{
    provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: {hasBackdrop: false}
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
