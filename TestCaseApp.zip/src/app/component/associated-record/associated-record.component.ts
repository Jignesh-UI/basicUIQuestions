import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { APP_Messages } from 'src/app/models/app-defaults';
import {
  associatedDetails,
  associatedSummary,
  chkInterface,
  lovInterface,
} from 'src/app/models/common.model';
import { CommonService } from 'src/app/services/common.service';
import { LovDataService } from 'src/app/services/lov-data.service';
import { NotificationService } from 'src/app/services/notification.service';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { ConfirmDialogComponent } from 'src/app/shared/components/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-associated-record',
  templateUrl: './associated-record.component.html',
  styleUrls: ['./associated-record.component.scss'],
})
export class AssociatedRecordComponent implements OnInit {
  maxLengthofControls = {
    mhidMaxLength: 15,
    ISBN13MaxLength: 50,
    PREVIOUS_ISBNMaxLength: 15,
    NEW_ISBNMaxLength: 15,
    authorMaxLength: 240,
    titleMaxLength: 1500,
    editionMaxLength: 22,
    publicationstatusMaxLength: 16,
    ODDMaxLength: 150,
    SDDMaxLength: 150,
    copyYearMaxLength: 22,
    boundBookDateMaxLength: 7,
    permissionEndDateMaxLength: 7,
    projectOPdateMaxLength: 7,
    deliveryFormatMaxLength: 150,
    titleTypeMaxLength: 240,
    gradeRangeMaxLength: 5,
    specificMarketMaxLength: 150,
    iPubPublishingGroupMaxLength: 20,
    iPubProgramTitleMaxLength: 500,
    pageCountMaxLength: 22,
    archiveNotesMaxLength: 4000,
    requestedByMaxLength: 100,
    printingMaxLength: 22,
    statusNotesMaxLength: 4000,
    productTitleMaxLength: 500,
    downloadReceivedMaxLength: 7,
    dateArchivedMaxLength: 7,
    libraryLocationMaxLength: 500,
    compVendorOtherMaxLength: 22,
    reprintContactOtherMaxLength: 22,
    pagingLengthOthMaxLength: 30,
    othFilesOthMaxLength: 30,
  };

  showCompVendor: boolean = false;
  userName: string = '';
  message: string = '';
  commnetsRows = 5;
  libLocRows = 2;
  notesRows = 8;
  archiveNotesRows = 8;
  repcommnetsRows = 2;
  showReprintInput: boolean = false;

  assocSummary = new associatedSummary();
  assocDetails = new associatedDetails();

  archivistArray: lovInterface[] = [];
  actualArchivistArray: lovInterface[] = [];
  compVendorArray: lovInterface[] = [];
  locationArray: lovInterface[] = [];
  reprintContactArray: lovInterface[] = [];

  pagingFilesArray: chkInterface[] = [];
  otherFilesArray: chkInterface[] = [];
  PDFsArray: chkInterface[] = [];

  pagingFilesOther: string = '';
  otherFilesOther: string = '';
  reprintContactOther: string = '';
  compVendorOther: string = '';

  disabledPDHField: boolean = true;
  disabledDetailsField: boolean = true;
  url: string = 'services/associatedRecords/';
  searchedMHID!: string;
  searchedISBN!: string;
  isLoading: boolean = false;
  validationFlag: boolean = false;

  private headers = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
    }),
  };

  constructor(
    private http: HttpClient,
    private notify: NotificationService,
    private cs: CommonService,
    private lovData: LovDataService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private dialog: MatDialog
  ) {
    this.router.onSameUrlNavigation = 'reload';
    activatedRoute.params.subscribe((val) => {
      const recordId: string = val['keyword'];
      if (recordId != null) {
        if (recordId.search('&') > 1) {
          this.searchByTab(recordId.split('&')[1], 'assocId', true);
        } else {
          this.searchByTab(recordId, 'mhid', true);
        }
      }
    });
  }

  canDeactivate(): Observable<boolean> | boolean {
    const chkData = JSON.parse(localStorage.getItem('oData') || '{}');
    if (this.assocDetails['recordid']) {
      if (
        JSON.stringify(chkData.details) === JSON.stringify(this.assocDetails) &&
        JSON.stringify(chkData.summary) === JSON.stringify(this.assocSummary)
      ) {
        return true;
      }
      const dConfig = new MatDialogConfig();
      dConfig.data = {
        title: 'confirm Title',
        message: 'Confirm Message',
        confirmText: 'confirm Text',
        canceltext: 'Confirm Cancel Text',
        success: (e: any) => {
          return false;
        },
        close: (e: any) => {
          return true;
        },
      };
      const dialogRef = this.dialog.open(ConfirmDialogComponent, dConfig);
      return dialogRef.afterClosed();
    }
    return true;
  }

  async ngOnInit(): Promise<void> {
    this.assocSummary = new associatedSummary();
    this.resetDetails();
    await this.loadLovs();
  }

  async searchByTab(
    input: string,
    filterTyle: string,
    urlSearch: boolean = false
  ) {
    let dbCall: Observable<Object>;
    this.isLoading = true;

    if (
      input == this.searchedMHID ||
      input == this.searchedISBN ||
      input.trim().length < 1
    ) {
      this.isLoading = false;
      return false;
    }

    if (this.searchedMHID?.length > 1 && this.searchedISBN?.length > 1) {
      const chkData = JSON.parse(localStorage.getItem('oData') || '{}');
      const dataComparisonFlag: boolean = await this.cs.adjustData(
        chkData,
        this.assocDetails,
        this.assocSummary
      );
      if (!dataComparisonFlag) {
        const t = await this.cs.showModalConfirmation();
        if (!t) {
          this.assocSummary.mhid = this.searchedMHID;
          this.assocSummary.isbn13 = this.searchedISBN;
          this.isLoading = false;
          return false;
        }
      }
      this.assocSummary.mhid = this.searchedMHID;
      this.assocSummary.isbn13 = this.searchedISBN;
    }

    if (filterTyle == 'mhid' && input) {
      const url = this.url + '/mhId/' + input;
      dbCall = this.http.get(url, this.headers);
    } else if (filterTyle == 'isbn' && input) {
      const url = this.url + '/isbn13/' + input;
      dbCall = this.http.get(url, this.headers);
    } else if (filterTyle == 'assocId' && input) {
      const url = this.url + '/associatedId/' + input;
      dbCall = this.http.get(url, this.headers);
    } else {
      this.isLoading = false;
      return false;
    }
    dbCall = this.http.get('../../assets/localData/associated.data.json');

    dbCall.subscribe(
      (responseData: any) => {
        console.log(responseData);
        this.compVendorOther = '';
        this.reprintContactOther = '';
        this.pagingFilesOther = '';
        this.otherFilesOther = '';

        if (responseData['data'] && responseData['succeeded']) {
          this.resetArchiveModel();
          this.fillFormSubscription(responseData['data'], urlSearch);
        } else {
          this.resetArchiveModel();
          this.resetDrpLists();
          this.disabledDetailsField = true;
          this.validationFlag = false;
          this.notify.showSuccess('', responseData['message']);
        }
        this.isLoading = false;
      },
      (err) => {
        this.disabledDetailsField = true;
        this.isLoading = false;
        this.validationFlag = false;
        this.notify.showSuccess('', APP_Messages.ServerErrorMessage);
      }
    );

    this.isLoading = false;

    return true;
  }

  fillFormSubscription(data: any, urlSearch: boolean = false) {
    this.assocSummary = data['summary'] as associatedSummary;
    if (urlSearch) {
      this.resetDetails();
    } else {
      if (data['details']) {
        this.assocDetails = data['details'] as associatedDetails;
        this.disablePDHControls();
        this.setArchivest();
        this.setCompVendor();
        this.setLocation();
        this.setReprintContact();
        this.setPaggingFiles();
        this.setOtherFiles();
        this.setPDFLists();
      } else {
        this.resetDetails();
      }
    }
    this.adjustRecordId();
    this.searchedMHID = this.assocSummary.mhid;
    this.searchedISBN = this.assocSummary.isbn13;
    this.disabledDetailsField = false;
    this.validationFlag = true;

    if (data['details']) {
      localStorage.setItem(
        'oData',
        JSON.stringify({
          summary: this.assocSummary,
          details: this.assocDetails,
        })
      );
    } else {
      localStorage.setItem(
        'oData',
        JSON.stringify({ summary: this.assocSummary })
      );
    }
  }

  private resetDetails() {
    const emptyDetails = {
      productTitle: '',
      archivist: '',
      compositorVendor: '',
      downloadReceivedDate: '',
      archivedDate: '',
      storageLocation: '',
      libraryLocation: '',
      printingVersion: 0,
      reprintContact: '',
      pagingFilesList: [],
      otherFilesList: [],
      pdfsList: [],
      associatedid: 0,
      recordid: 0,
      productNotes: '',
      createdDate: '',
      createdBy: '',
      modifiedDate: '',
      modifiedBy: '',
    };
    this.assocDetails = emptyDetails;
    this.compVendorChange('');
  }
  adjustRecordId() {
    if (
      this.assocDetails.recordid == 0 ||
      this.assocDetails.recordid == null ||
      this.assocDetails.recordid == undefined
    ) {
      this.assocDetails.recordid = this.assocSummary.recordid;
    }
  }
  private resetArchiveModel() {
    this.assocSummary = new associatedSummary();
    this.resetDetails();
    this.resetCheckboxes();
    this.searchedMHID = '';
    this.searchedISBN = '';
  }

  private resetDrpLists() {
    this.setArchivest();
    this.setCompVendor();
    this.setLocation();
    this.setReprintContact();
  }

  private resetCheckboxes() {
    this.pagingFilesArray.forEach((v: chkInterface) => {
      v.checked = false;
      v.enabled = 'Y';
    });
    this.otherFilesArray.forEach((v) => {
      v.checked = false;
      v.enabled = 'Y';
    });
    this.PDFsArray.forEach((v) => {
      v.checked = false;
      v.enabled = 'Y';
    });
  }

  private disablePDHControls() {
    this.disabledPDHField = true;
  }

  private setArchivest() {
    if (
      this.assocDetails.archivist?.description == null ||
      this.assocDetails.archivist?.description == ''
    ) {
      this.assocDetails.archivist = '';
      return false;
    } else if (
      this.checkExistingArchiviest(this.assocDetails.archivist.description) !=
      true
    ) {
      return false;
    }

    let dbData: string;
    let flag: boolean = false;
    let lvid = this.assocDetails.archivist.lovid;

    if (this.assocDetails.archivist != null) {
      this.archivistArray = this.lovData.returnArchivistLOV();
      dbData = this.assocDetails.archivist['description'];
    }

    this.archivistArray.filter((ary: lovInterface) => {
      if (ary.description == dbData) {
        flag = true;
      }
    });

    if (flag) {
      this.archivistArray.push(this.assocDetails.archivist);
    }

    let lovId = this.archivistArray.filter((arryData) => {
      return arryData.description?.toLowerCase() == dbData.toLowerCase();
    });
    if (lovId.length > 0) {
      lvid = lovId[0].lovid;
    }
    this.assocDetails.archivist = lvid;
    return false;
  }

  checkExistingArchiviest(paramData: string = '') {
    this.archivistArray = this.cs.removePreviousArray(
      this.archivistArray,
      this.actualArchivistArray
    );
    const dataLength = this.archivistArray.filter((arData) => {
      return arData.description?.toLowerCase() === paramData.toLowerCase();
    });
    if (dataLength.length >= 1) {
      this.assocDetails.archivist = dataLength[0].lovid;
      return false;
    } else {
      return true;
    }
  }

  private setCompVendor() {
    if (this.assocDetails && this.assocDetails.compositorVendor) {
      const dbData: string = this.assocDetails.compositorVendor.description;
      for (const keys in this.compVendorArray) {
        if (dbData == this.compVendorArray[keys].description) {
          if (dbData.trim().toLowerCase() === 'other') {
            this.compVendorOther =
              this.assocDetails.compositorVendor.otherValue.trim();
          } else {
            this.compVendorOther = '';
          }
          this.assocDetails.compositorVendor = this.compVendorArray[keys].lovid;
          this.compVendorChange(dbData);
        }
      }
    } else {
      this.assocDetails.compositorVendor = '';
      this.compVendorChange('');
    }
  }

  private setLocation() {
    if (this.assocDetails && this.assocDetails.storageLocation) {
      const dbData: string = this.assocDetails.storageLocation.description;
      for (const keys in this.locationArray) {
        if (dbData == this.locationArray[keys].description) {
          this.assocDetails.storageLocation = this.locationArray[keys].lovid;
        }
      }
    } else {
      this.assocDetails.storageLocation = '';
    }
  }

  private setReprintContact() {
    if (this.assocDetails && this.assocDetails.reprintContact) {
      const dbData: string = this.assocDetails.reprintContact.description;
      for (const keys in this.reprintContactArray) {
        if (dbData == this.reprintContactArray[keys].description) {
          if (dbData.trim().toLowerCase() === 'other') {
            this.reprintContactOther =
              this.assocDetails.reprintContact.otherValue.trim();
          } else {
            this.reprintContactOther = '';
          }
          this.assocDetails.reprintContact =
            this.reprintContactArray[keys].lovid;
          this.reprintValueChange(dbData);
        }
      }
    } else {
      this.assocDetails.reprintContact = '';
      this.reprintValueChange('');
    }
  }

  private setPaggingFiles() {
    if (this.assocDetails && this.assocDetails.pagingFilesList) {
      let noneChecked = this.assocDetails.pagingFilesList.filter(
        (values: { description: string }) => {
          if (values.description == 'None') {
            this.pagingFilesArray.filter((arrayValues) => {
              if (arrayValues.description == 'None') {
                arrayValues.enabled = 'Y';
                arrayValues.checked = true;
              } else {
                arrayValues.enabled = 'N';
              }
            });
          }
          return values.description == 'None';
        }
      )[0];

      if (noneChecked) {
        this.pagingFilesOther = '';
        return false;
      }

      this.pagingFilesArray.forEach((arrData) => {
        this.assocDetails.pagingFilesList.forEach(
          (respData: { description: string; otherValue: string }) => {
            if (
              arrData.description?.trim().toLowerCase() ==
              respData.description.trim().toLowerCase()
            ) {
              if (respData.description.trim().toLowerCase() === 'other') {
                this.pagingFilesOther =
                  respData.otherValue == null
                    ? ' '
                    : respData.otherValue.trim();
              }
              arrData.checked = true;
            }
          }
        );
      });
    }
    return true;
  }

  private setOtherFiles() {
    if (this.assocDetails && this.assocDetails.otherFilesList) {
      let noneChecked = this.assocDetails.otherFilesList.filter(
        (values: { description: string }) => {
          if (values.description == 'None') {
            this.otherFilesArray.filter((arrayValues) => {
              if (arrayValues.description == 'None') {
                arrayValues.enabled = 'Y';
                arrayValues.checked = true;
              } else {
                arrayValues.enabled = 'N';
              }
            });
          }
          return values.description == 'None';
        }
      )[0];

      if (noneChecked) {
        this.otherFilesOther = '';
        return false;
      }

      this.otherFilesArray.forEach((arrData) => {
        this.assocDetails.otherFilesList.forEach(
          (respData: { description: string; otherValue: string }) => {
            if (
              arrData.description?.trim().toLowerCase() ==
              respData.description.trim().toLowerCase()
            ) {
              if (respData.description.trim().toLowerCase() === 'other') {
                this.otherFilesOther =
                  respData.otherValue == null
                    ? ' '
                    : respData.otherValue.trim();
              }
              arrData.checked = true;
            }
          }
        );
      });
    }
    return true;
  }

  private setPDFLists() {
    if (this.assocDetails && this.assocDetails.pdfsList) {
      this.PDFsArray.forEach((arrData) => {
        this.assocDetails.pdfsList.forEach(
          (respData: { description: string }) => {
            if (
              arrData.description?.trim().toLowerCase() ==
              respData.description.trim().toLowerCase()
            ) {
              arrData.checked = true;
            }
          }
        );
      });
    }
  }

  onAssocProductCommentAdd(comment: any) {
    this.assocDetails.productNotes = this.assocDetails.productNotes || '';
    if (this.assocDetails.productNotes.length > 0) {
      const newLine =
        this.assocDetails.productNotes.substr(
          this.assocDetails.productNotes.length - 1,
          2
        ) == '\n'
          ? ''
          : '\n';
      this.assocDetails.productNotes +=
        newLine +
        this.userName +
        ' ' +
        this.cs.getDateTime() +
        '\n' +
        comment +
        '\n';
    } else {
      this.assocDetails.productNotes +=
        this.userName + ' ' + this.cs.getDateTime() + '\n' + comment + '\n';
    }
  }

  onSubmit() {
    // changing the date format from mm-dd-yyyy to mm/dd/yyy
    // this.dateFormatChange('-', '/', 'html');
    this.isLoading = true;
    if (this.assocDetails['associatedid'] === undefined) {
      this.isLoading = false;
      return false;
    }
    this.url = this.url + this.assocDetails.associatedid;

    this.assocDetails.modifiedDate = this.cs.getDate();
    this.assocDetails.modifiedBy = this.userName;

    let data: any = { summary: this.assocSummary, details: this.assocDetails };
    data.details.archivist = this.saveArchivist(data);
    data.details.compositorVendor = this.saveCompVendor(data);
    data.details.storageLocation = this.saveLocation();
    data.details.reprintContact = this.saveRePrint(data);

    data.details.pagingFilesList = this.savePaggingFiles(
      data.details.pagingFilesList
    );
    data.details.otherFilesList = this.saveOtherFilesList(
      data.details.otherFilesList
    );
    data.details.pdfsList = this.savePdfsList(data.details.pdfsList);

    this.http.put(this.url, data).subscribe(
      (response) => {
        this.resetDrpLists();

        this.notify.showSuccess('', 'error');
        localStorage.setItem(
          'oData',
          JSON.stringify({
            summary: this.assocSummary,
            details: this.assocDetails,
          })
        );
        this.isLoading = false;
        // alert(this.message);
      },
      (err) => {
        this.isLoading = false;
        this.notify.showSuccess('', APP_Messages.ServerErrorMessage);
      }
    );
    return;
  }

  compVendorChange(selectedValue: any) {
    let cdata: any;
    if (selectedValue.currentTarget) {
      cdata = selectedValue.currentTarget.options[
        selectedValue.currentTarget.selectedIndex
      ].text
        .trim()
        .toLocaleLowerCase();
    } else {
      cdata = selectedValue;
    }

    this.showCompVendor = cdata.trim().toLowerCase() == 'other' ? true : false;
  }

  reprintValueChange(selectedValue: any) {
    let cdata: any;
    if (selectedValue.currentTarget) {
      cdata = selectedValue.currentTarget.options[
        selectedValue.currentTarget.selectedIndex
      ].text
        .trim()
        .toLocaleLowerCase();
    } else {
      cdata = selectedValue;
    }
    this.showReprintInput =
      cdata.trim().toLowerCase() == 'other' ? true : false;
  }

  pagingFilesSeletionChange(event: any): void {
    if (event.target.value == 'None' && event.target.checked) {
      this.pagingFilesArray.forEach((v) => {
        if (v.description != 'None') {
          v.enabled = 'N';
          v.checked = false;
          this.pagingFilesOther = '';
        } else {
          v.enabled = 'Y';
        }
      });
    } else if (event.target.value == 'None' && !event.target.checked) {
      this.pagingFilesArray.forEach((v) => (v.enabled = 'Y'));
    }

    if (
      event.target.value.trim().toLowerCase() == 'other' &&
      !event.target.checked
    ) {
      this.pagingFilesOther = '';
    }
  }

  otherFilesSelectionChange(event: any): void {
    if (event.target.value == 'None' && event.target.checked) {
      this.otherFilesArray.forEach((v) => {
        if (v.description != 'None') {
          v.enabled = 'N';
          v.checked = false;
          this.otherFilesOther = '';
        } else {
          v.enabled = 'Y';
        }
      });
    } else if (event.target.value == 'None' && !event.target.checked) {
      this.otherFilesArray.forEach((v) => (v.enabled = 'Y'));
    }

    if (
      event.target.value.trim().toLowerCase() == 'other' &&
      !event.target.checked
    ) {
      this.otherFilesOther = '';
    }
  }

  async loadLovs() {
    this.actualArchivistArray = this.archivistArray =
      this.lovData.returnArchivistLOV();
    this.compVendorArray = this.lovData.returnSingleLOV('COMPOSITOR_VENDOR');
    this.locationArray = this.lovData.returnSingleLOV('STORAGE_LOCATION');
    this.reprintContactArray = this.lovData.returnSingleLOV('REPRINT_CONTACT');
    this.PDFsArray = this.lovData.returnSingleLOV('PDFS');

    this.pagingFilesArray = this.lovData.returnSingleLOV('PAGINGFILES');
    this.otherFilesArray = this.lovData.returnSingleLOV('OTHERFILES');
    this.PDFsArray = this.lovData.returnSingleLOV('PDFS');

    this.assocDetails.archivist = '';
    this.assocDetails.compositorVendor = '';
    this.assocDetails.storageLocation = '';
    this.assocDetails.reprintContact = '';
  }

  pdfArrayChange(evt: any, dataList: chkInterface) {
    if (evt) {
      this.assocDetails.pdfsList.push(dataList);
    } else {
      this.assocDetails.pdfsList.forEach(
        (objList: { description: string }, index: any) => {
          if (
            objList.description.trim().toLowerCase() ==
            dataList.description?.trim().toLowerCase()
          ) {
            this.assocDetails.pdfsList.splice(index, 1);
          }
        }
      );
    }
  }

  pagingArrayChange(evt: any, dataList: chkInterface) {
    if (evt) {
      this.assocDetails.pagingFilesList.push(dataList);
    } else {
      this.assocDetails.pagingFilesList.forEach(
        (objList: { description: string }, index: any) => {
          if (
            objList.description.trim().toLowerCase() ==
            dataList.description?.trim().toLowerCase()
          ) {
            this.assocDetails.pagingFilesList.splice(index, 1);
          }
        }
      );
    }
  }

  othFilesArrayChange(evt: any, dataList: chkInterface) {
    if (evt) {
      this.assocDetails.otherFilesList.push(dataList);
    } else {
      this.assocDetails.otherFilesList.forEach(
        (objList: { description: string }, index: any) => {
          if (
            objList.description.trim().toLowerCase() ==
            dataList.description?.trim().toLowerCase()
          ) {
            this.assocDetails.otherFilesList.splice(index, 1);
          }
        }
      );
    }
  }

  private saveArchivist(data: any) {
    if (this.assocDetails.archivist == '') {
      return [];
    } else {
      const fdata = this.archivistArray.filter((arr) => {
        return arr.lovid === +this.assocDetails.archivist;
      })[0];
      // data.details.archivist = fdata;
      return fdata;
    }
  }

  private saveCompVendor(data: any) {
    if (this.assocDetails.compositorVendor == '') {
      return [];
    } else {
      let otherField: boolean = false;
      const fdata = this.compVendorArray.filter((arr) => {
        if (arr.lovid === +this.assocDetails.compositorVendor) {
          if (arr.description?.trim().toLowerCase() === 'other') {
            otherField = true;
          }
          return arr.lovid === +this.assocDetails.compositorVendor;
        }
        return;
      })[0];
      if (otherField) {
        fdata.otherValue = this.compVendorOther.trim();
      }
      // data.details.compositorVendor = fdata;
      return fdata;
    }
  }

  private saveLocation() {
    if (this.assocDetails.storageLocation == '') {
      return null;
    } else {
      const fdata: any = this.locationArray.filter((arr) => {
        return arr.lovid === +this.assocDetails.storageLocation;
      })[0];
      // data.details.storageLocation = fdata;
      return fdata;
    }
  }

  private saveRePrint(data: any) {
    if (this.assocDetails.reprintContact == '') {
      return [];
    } else {
      let otherField: boolean = false;
      const fdata = this.reprintContactArray.filter((arr) => {
        if (arr.lovid === +this.assocDetails.reprintContact) {
          if (arr.description?.trim().toLowerCase() === 'other') {
            otherField = true;
          }
          return arr.lovid === +this.assocDetails.reprintContact;
        }
        return;
      })[0];
      if (otherField) {
        fdata.otherValue = this.reprintContactOther.trim();
      }
      return fdata;
    }
  }

  private savePaggingFiles(data: any) {
    let otherField: boolean = false;
    const fdata: chkInterface[] = [];
    this.pagingFilesArray.filter((arr) => {
      if (arr.checked) {
        if (arr.description?.trim().toLowerCase() === 'other') {
          otherField = true;
          arr.otherValue = this.pagingFilesOther.trim();
        }
        fdata.push(arr);
      }
    });
    data = fdata;
    return data;
  }

  private saveOtherFilesList(data: any) {
    let otherField: boolean = false;
    const fdata: chkInterface[] = [];
    this.otherFilesArray.filter((arr) => {
      if (arr.checked) {
        if (arr.description?.trim().toLowerCase() === 'other') {
          otherField = true;
          arr.otherValue = this.otherFilesOther.trim();
        }
        fdata.push(arr);
      }
    });
    data = fdata;
    return data;
  }

  savePdfsList(data: any) {
    const fdata: chkInterface[] = [];
    this.PDFsArray.filter((arr) => {
      if (arr.checked) {
        fdata.push(arr);
      }
    });
    data = fdata;
    return data;
  }

  validation() {
    // Testcases are pending
    if (this.assocSummary.mhid == null || this.assocSummary.mhid == undefined) {
      return true;
    }
    if (
      this.assocSummary.isbn13 == null ||
      this.assocSummary.isbn13 == undefined
    ) {
      return true;
    }
    if (
      this.assocDetails.productTitle == null ||
      this.assocDetails.productTitle == undefined ||
      this.assocDetails.productTitle == ''
    ) {
      return true;
    }
    return false;
  }

  movetoArchiveRequestPageWithMHID() {
    if (
      this.assocSummary.mhid !== '0' ||
      this.assocSummary.mhid !== null ||
      this.assocSummary.mhid !== undefined
    ) {
      this.router.navigate(['archiveRec', this.assocSummary.mhid]);
    }
  }
}
