import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { RootObject } from '../../models/testModel';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  @Input() people: string[] = [];
  objModel: Observable<RootObject[]> | undefined;

  constructor(private http: HttpClient) {
    this.objModel = this.httpGetMethod();
  }

  ngOnInit(): void {}

  loadPeople(){
    this.people = [
      'Jignesh',
      'Darshan',
      'Romit',
      'Krunal',
      'Deval'
    ]
  }

  httpGetMethod(): Observable<RootObject[]> {
    return this.http.get<RootObject[]>('../../assets/localData/testData.json');
  }

  trackPeopleList(index: any, people: any){
    return people ? people : undefined;
  }
}
