import { HttpClient, HttpHandler } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA } from '@angular/compiler';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { ToastrModule } from 'ngx-toastr';
import { AllmatcompModule } from 'src/app/allmatcomp.module';
import { LovDataService } from 'src/app/services/lov-data.service';

import { Nim1Component } from './nim1.component';

describe('Nim1Component', () => {
  let component: Nim1Component;
  let fixture: ComponentFixture<Nim1Component>;
  let matDialogService: jasmine.SpyObj<MatDialog>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports:[RouterTestingModule, MatDialogModule, FormsModule, ToastrModule.forRoot(),
        BrowserAnimationsModule, AllmatcompModule, HttpClientTestingModule],
      declarations: [ Nim1Component ],
      providers:[HttpClient, HttpHandler, LovDataService,
        {
          provide: MatDialog,
          useValue: matDialogService,
        }],
      schemas:[NO_ERRORS_SCHEMA],
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Nim1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
