import { HttpClient, HttpHandler } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA } from '@angular/compiler';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { ToastrModule } from 'ngx-toastr';
import { AllmatcompModule } from 'src/app/allmatcomp.module';
import { arcReqDetails, arcReqSummary } from 'src/app/models/common.model';
import { LovDataService } from 'src/app/services/lov-data.service';

import { RequestComponent } from './request.component';

describe('RequestComponent', () => {
  let component: RequestComponent;
  let fixture: ComponentFixture<RequestComponent>;
  let matDialogService: jasmine.SpyObj<MatDialog>;

  let testData = {
    summary: {
      taskid: 257938,
      recordid: 2272100,
      mhid: 'test-mhid',
      isbn13: 'test-isbn',
      requestReceivedDate: '2023-01-17',
      requestedBy: 'test',
      requestorDepartment: '',
      archivist: 1013,
      dueDate: '2023-01-25',
      completedDate: null,
      inProgress: true,
      deliveryMedium: '',
      compositorVendor: '',
      printingVersion: 0,
      requestedFilesList: [],
      specialInstructions: null,
      statusNotes: null,
      createdDate: '2023-01-17',
      createdBy: 'Patel, Jignesh',
      modifiedDate: '2023-01-17',
      modifiedBy: 'Patel, Jignesh',
    },
    details: {
      recordid: 2272100,
      previousISBN: 'test_pd_4_123',
      newISBN: 'test_pd_4_000',
      author: 'test prax',
      title: 'testing api part 1',
      edition: 3,
      priority: 'test high',
      owningDivision: 'College',
      owningSubDivision: 'test own subdiv',
      copyrightYear: 2022,
      boundBookDate: '2022-12-25',
      permissionEndDate: '2022-11-20',
      projectOPDate: '2022-11-20',
      deliveryFormat: 'test delivery format 2',
      titleTypeDesc: 'test title desc 2',
      gradeRange: '13 - 17',
      specificMarket: 'testing market',
      ipubPublishingGroup: 'prax_grp_3',
      ipubProgrammingTitle: 'testing prog title - 2',
      noOfPages: 50,
      comments:
        'testing comment;\ntesting api update;\ntesting done by prakriti_de;\nDe, Prakriti 2023-1-2 19:37:45\nhello\n',
    },
  };

  let asDetails = {
    recordid: 2272100,
    previousISBN: 'test_pd_4_123',
    newISBN: 'test_pd_4_000',
    author: 'test prax',
    title: 'testing api part 1',
    edition: 3,
    priority: 'test high',
    owningDivision: 'College',
    owningSubDivision: 'test own subdiv',
    copyrightYear: 2022,
    boundBookDate: '2022-12-25',
    permissionEndDate: '2022-11-20',
    projectOPDate: '2022-11-20',
    deliveryFormat: 'test delivery format 2',
    titleTypeDesc: 'test title desc 2',
    gradeRange: '13 - 17',
    specificMarket: 'testing market',
    ipubPublishingGroup: 'prax_grp_3',
    ipubProgrammingTitle: 'testing prog title - 2',
    noOfPages: 50,
    comments:
      'testing comment;\ntesting api update;\ntesting done by prakriti_de;\nDe, Prakriti 2023-1-2 19:37:45\nhello\n',
  };
  let asSummary = {
    taskid: 257938,
    mhid: 'test-mhid',
    isbn13: 'test-isbn',
    recordid: 2272100,
    requestReceivedDate: '2023-01-17',
    requestedBy: 'test',
    requestorDepartment: '',
    archivist: 1013,
    dueDate: '2023-01-25',
    completedDate: null,
    inProgress: true,
    deliveryMedium: '',
    compositorVendor: '',
    printingVersion: 0,
    requestedFilesList: [],
    specialInstructions: null,
    statusNotes: null,
    createdDate: '2023-01-17',
    createdBy: 'Patel, Jignesh',
    modifiedDate: '2023-01-17',
    modifiedBy: 'Patel, Jignesh',
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        MatDialogModule,
        FormsModule,
        ToastrModule.forRoot(),
        BrowserAnimationsModule,
        AllmatcompModule,
        HttpClientTestingModule,
      ],
      declarations: [RequestComponent],
      providers: [
        HttpClient,
        HttpHandler,
        LovDataService,
        {
          provide: MatDialog,
          useValue: matDialogService,
        },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // it('should display popup confirmation if user have changed some data ', () => {
  //   let cmpInstance = fixture.debugElement.componentInstance;
  //   cmpInstance.arcReqDetails = new arcReqDetails();
  //   cmpInstance.arcReqSummary = new arcReqSummary();
  //   cmpInstance.searchedMHID = 'test-mhid';
  //   cmpInstance.searchedISBN = 'test-isbn';

  //   cmpInstance.searchByTab('test-mhid', 'mhid', false);
  //   fixture.detectChanges();
  //   expect(cmpInstance.arcReqSummary).not.toBeNull();
  // });

  // it('should add Archive Request Status Notes comment when comment is already added', () => {
  //   const message = 'Test Message \n';
  //   component.arcReqDetails.statusNotes = message;
  //   component.onARSNCommentAdd(message);
  //   expect(component.arcReqDetails.statusNotes).not.toBeNull();
  // });

  // it('should add Archive Request Status Notes comment when comment is blank ', () => {
  //   component.onARSNCommentAdd('new Test Message');
  //   expect(component.arcReqDetails.statusNotes).not.toBeNull();
  // });

  // it('should add Special Instructions when instructions is already added', () => {
  //   const message = 'Test Message \n';
  //   component.arcReqDetails.specialInstructions = message;
  //   component.onSICommentAdd(message);
  //   expect(component.arcReqDetails.specialInstructions).not.toBeNull();
  // });

  // it('should add Special Instructions when instructions is blank ', () => {
  //   component.onSICommentAdd('new Test Message');
  //   expect(component.arcReqDetails.specialInstructions).not.toBeNull();
  // });

  // it('should return true when record Id is not available', () => {
  //   let cmpInstance = fixture.debugElement.componentInstance;
  //   cmpInstance.searchedMHID = null;
  //   cmpInstance.searchedISBN = null;
  //   const flagNavigate = cmpInstance.canDeactivate();
  //   expect(flagNavigate).toBeTruthy();
  // });

  // it('should return true when record Id is not available', async () => {
  //   let cmpInstance = fixture.debugElement.componentInstance;
  //   cmpInstance.searchedMHID = 'test-mhid';
  //   cmpInstance.searchedISBN = 'test-mhid';
  //   jasmine.createSpyObj<MatDialog>('MatDialog', ['open']);
  //   const flagNavigate = cmpInstance.canDeactivate();
  //   expect(flagNavigate).toBeTruthy();
  // });

  // it('should call adjustData function to verify the changes on the form!', async () => {
  //   let cmpInstance = fixture.debugElement.componentInstance;
  //   const flag = await cmpInstance.adjustData(testData, asDetails, asSummary);
  //   console.log('first flag' + flag);
  //   expect(flag).toBeFalsy();
  //   asDetails.author = 'test prax asdf';
  //   const flag2 = await cmpInstance.adjustData(
  //     testData.details,
  //     asDetails,
  //     asSummary
  //   );
  //   console.log('second flag' + flag2);
  //   expect(flag2).toBeFalsy();
  // });

  // it('should compare previous summary data with current one', async () => {
  //   let cmpInstance = fixture.debugElement.componentInstance;
  //   cmpInstance.asSummary = asSummary;
  //   const flag = await cmpInstance.chkSummaryValidation(asSummary);
  //   expect(flag).toBeTruthy();
  // });

  // it('should search with mhid!', async () => {
  //   let cmpInstance = fixture.debugElement.componentInstance;
  //   cmpInstance.arcReqDetails = new arcReqDetails();
  //   cmpInstance.arcReqSummary = new arcReqSummary();
  //   cmpInstance.searchedMHID = '';
  //   cmpInstance.searchedISBN = '';
  //   cmpInstance.searchByTab('test-mhid', 'mhid', false);
  //   fixture.detectChanges();
  //   expect(cmpInstance.assocSummary).not.toBeNull();
  // });

  // it('should search with isbn!', async () => {
  //   let cmpInstance = fixture.debugElement.componentInstance;
  //   cmpInstance.arcReqDetails = new arcReqDetails();
  //   cmpInstance.arcReqSummary = new arcReqSummary();
  //   cmpInstance.searchedMHID = '';
  //   cmpInstance.searchedISBN = '';
  //   cmpInstance.searchByTab('test-isbn', 'isbn', false);
  //   fixture.detectChanges();
  //   expect(cmpInstance.assocSummary).not.toBeNull();
  // });

  // it('should search with task id!', async () => {
  //   let cmpInstance = fixture.debugElement.componentInstance;
  //   cmpInstance.arcReqDetails = new arcReqDetails();
  //   cmpInstance.arcReqSummary = new arcReqSummary();
  //   cmpInstance.searchedMHID = '';
  //   cmpInstance.searchedISBN = '';
  //   cmpInstance.searchByTab('1234', 'taskid', false);
  //   fixture.detectChanges();
  //   expect(cmpInstance.assocSummary).not.toBeNull();
  // });

  // it('should not search without keyword!', async () => {
  //   let cmpInstance = fixture.debugElement.componentInstance;
  //   cmpInstance.arcReqDetails = new arcReqDetails();
  //   cmpInstance.arcReqSummary = new arcReqSummary();
  //   cmpInstance.searchedMHID = '';
  //   cmpInstance.searchedISBN = '';
  //   cmpInstance.searchByTab('', '', false);
  //   fixture.detectChanges();
  //   expect(cmpInstance.assocSummary).toBe(undefined);
  // });

  // it('should not search if same isbn is there!', async () => {
  //   let cmpInstance = fixture.debugElement.componentInstance;
  //   cmpInstance.arcReqDetails = new arcReqDetails();
  //   cmpInstance.arcReqSummary = new arcReqSummary();
  //   cmpInstance.searchedMHID = '';
  //   cmpInstance.searchedISBN = 'test-isbn';
  //   cmpInstance.searchByTab('test-isbn', 'isbn', false);
  //   fixture.detectChanges();
  //   expect(cmpInstance.assocSummary).toBe(undefined);
  // });

  // it('should not search if keyword is not given!', async () => {
  //   let cmpInstance = fixture.debugElement.componentInstance;
  //   cmpInstance.arcReqDetails = new arcReqDetails();
  //   cmpInstance.arcReqSummary = new arcReqSummary();
  //   cmpInstance.searchedMHID = '';
  //   cmpInstance.searchedISBN = 'test-isbn';
  //   cmpInstance.searchByTab('test-isbn', '', false);
  //   fixture.detectChanges();
  //   expect(cmpInstance.assocSummary).toBe(undefined);
  // });

  // it('should not search if mhid and isbn both are same!', async () => {
  //   let cmpInstance = fixture.debugElement.componentInstance;
  //   cmpInstance.arcReqDetails = new arcReqDetails();
  //   cmpInstance.arcReqSummary = new arcReqSummary();
  //   cmpInstance.searchedMHID = 'test-mhid';
  //   cmpInstance.searchedISBN = 'test-isbn';
  //   cmpInstance.searchByTab('test-isbn', 'test-isbn', false);
  //   fixture.detectChanges();
  //   expect(cmpInstance.assocSummary).toBe(undefined);
  // });

  // it('should fill the form after providing the isbn/mhid', async () => {
  //   let cmpInstance = fixture.debugElement.componentInstance;
  //   cmpInstance.arcReqDetails = new arcReqDetails();
  //   cmpInstance.arcReqSummary = new arcReqSummary();
  //   const dummyData = {
  //     summary: {
  //       mhid: 'test-mhid',
  //       isbn13: 'test-isbn',
  //       recordid: 2272100,
  //       previousISBN: 'test_pd_4_123',
  //       newISBN: 'test_pd_4_000',
  //       author: 'test prax',
  //       title: 'testing api part 1',
  //       edition: 3,
  //       priority: 'test high',
  //       owningDivision: 'College',
  //       owningSubDivision: 'test own subdiv',
  //       copyrightYear: 2022,
  //       boundBookDate: '2022-12-25',
  //       permissionEndDate: '2022-11-20',
  //       projectOPDate: '2022-11-20',
  //       deliveryFormat: 'test delivery format 2',
  //       titleTypeDesc: 'test title desc 2',
  //       gradeRange: '13 - 17',
  //       specificMarket: 'testing market',
  //       ipubPublishingGroup: 'prax_grp_3',
  //       ipubProgrammingTitle: 'testing prog title - 2',
  //       noOfPages: 50,
  //       comments:
  //         'testing comment;\ntesting api update;\ntesting done by prakriti_de;\nDe, Prakriti 2023-1-2 19:37:45\nhello\n',
  //     },
  //   };
  //   cmpInstance.arcReqDetails.requestReceivedDate = '';
  //   cmpInstance.arcReqDetails.inProgress;
  //   cmpInstance.fillFormSubscription(dummyData, false);
  //   expect(cmpInstance.searchedMHID).not.toBeNull();
  // });

  // it('should fill the form after hitting the save button', async () => {
  //   let cmpInstance = fixture.debugElement.componentInstance;
  //   cmpInstance.arcReqDetails = new arcReqDetails();
  //   cmpInstance.arcReqSummary = new arcReqSummary();
  //   const dummyData = testData;
  //   cmpInstance.fillFormSubscription(dummyData, false);
  //   expect(cmpInstance.searchedMHID).not.toBeNull();
  // });
});
