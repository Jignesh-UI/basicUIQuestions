import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit, ElementRef, ViewChild, OnDestroy } from '@angular/core';
import { HttpResponseModel } from 'src/app/shared/response.model';
import { Observable } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from 'src/app/services/notification.service';
import { LovDataService } from 'src/app/services/lov-data.service';
import { CommonService } from 'src/app/services/common.service';
import { arcReqDetails, arcReqSummary, chkInterface, lovInterface } from 'src/app/models/common.model';
import { APP_Messages } from 'src/app/models/app-defaults';

@Component({
  selector: 'app-request',
  templateUrl: './request.component.html',
  styleUrls: ['./request.component.scss']
})
export class RequestComponent implements OnInit {


  @ViewChild('mhid') mhid: ElementRef | undefined;

  maxLengthofControls = {
    'mhidMaxLength': 15,
    'ISBN13MaxLength': 50,
    'previousISBNMaxLength': 15,
    'newISBNMaxLength': 15,
    'authorMaxLength': 240,
    'titleMaxLength': 1500,
    'editionMaxLength': 22,
    'priorityMaxLength': 16,
    'ODDMaxLength': 150,
    'SDDMaxLength': 150,
    'copyYearMaxLength': 22,
    'boundBookDateMaxLength': 7,
    'permissionEndDateMaxLength': 7,
    'projectOPdateMaxLength': 7,
    'deliveryFormatMaxLength': 150,
    'titleTypeMaxLength': 240,
    'gradeRangeMaxLength': 5,
    'specificMarketMaxLength': 150,
    'iPubPublishingGroupMaxLength': 20,
    'iPubProgramTitleMaxLength': 500,
    'pageCountMaxLength': 22,
    'archiveNotesMaxLength': 4000,
    'requestReceivedMaxLength': 7,
    'requestedByMaxLength': 100,
    'requestorDepartmentMaxLength': 100,
    'dueDateMaxLength': 7,
    'completedDateMaxLength': 7,
    'printingMaxLength': 22,
    'specialInstructionsMaxLength': 4000,
    'statusNotesMaxLength': 4000
  };

  recordInformation:any = {
    uniqueId: 0,
    dateCreated: null,
    createdBy: '',
    dateLastModified: null,
    lastModifiedBy: null,
    daysCompleted: 0
  }

  userName: string = '';
  commnetsRows = 5;
  notesRows = 10;
  archiveNotesRows = 8;
  repcommnetsRows = 2;

  arcReqDetails = new arcReqDetails();
  arcReqSummary = new arcReqSummary();

  private headers = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }
  defaultCompVendorOtherValue: string = '';

  archivistArray: lovInterface[] = [];
  actualArchivistArray: lovInterface[] = [];
  compVendorArray: lovInterface[] = [];
  deliveryMediumArray: lovInterface[] = [];
  PDFsArray: chkInterface[] = [];
  requestedFilesArray: chkInterface[] = [];
  showCompVendor: boolean = false;
  compVendorOther: string = '';
  requestedFilesOther: string = '';
  disabledPDHField: boolean = true;
  enablenotes: boolean = false;
  disabledReqDetailsField: boolean = true;
  disabledTextAreaField: boolean = false;
  createSimilarRecord: boolean = false;
  createNewRecord: boolean = false;
  searchedMHID: string = '';
  searchedISBN: string = '';
  isLoading: boolean = false;

  url: string = 'services/archiveWips';

  constructor(private http: HttpClient, private notify: NotificationService, private lovData: LovDataService,
    private cs: CommonService,
    private dialog: MatDialog, private router: Router, private activatedRoute: ActivatedRoute) {
    localStorage.removeItem('arcRequestoData');
    this.router.onSameUrlNavigation = 'reload';
    activatedRoute.params.subscribe(val => {
      const taskid = val['keyword'];
      if (taskid != null) {
        this.searchByTab(taskid, 'taskid');
      }
    });
  }

  async canDeactivate(): Promise<boolean | Observable<boolean>> {
    if (this.searchedMHID.length > 1 && this.searchedISBN?.length > 1) {
      const chkData = JSON.parse(localStorage.getItem('arcRequestoData') || '{}');
      const dataComparisonFlag: boolean = await this.adjustData(chkData, this.arcReqSummary, this.arcReqDetails);
      if (!dataComparisonFlag) {
        const flag = await this.cs.showModalConfirmation(true);
        if (!flag) {
          this.arcReqSummary.mhid = this.searchedMHID;
          this.arcReqSummary.isbn13 = this.searchedISBN;
          this.isLoading = false;
          return false;
        }
      }
      this.arcReqSummary.mhid = this.searchedMHID;
      this.arcReqSummary.isbn13 = this.searchedISBN;
    }
    return true;
  }

  async ngOnInit(): Promise<void> {
    this.arcReqDetails = new arcReqDetails();
    this.arcReqSummary = new arcReqSummary();
    // const promise = await this.oktaService.GetOktUserInfo();
    // const user = promise['claims']['name'];
    this.userName = "Jignesh Patel";
    await this.loadLovs();
    this.disableTextAreaCtrls();
  }

  async ngOnDestroy(): Promise<void> {
    localStorage.removeItem('arcRequestoData');
  }

  async adjustData(chkData: any, asDetails: any, asSummary: any) {
    delete chkData?.details?.mhid;
    delete chkData?.details?.isbn13;
    delete asDetails?.mhid;
    delete asDetails?.isbn13;
    let flagSummary = await this.chkSummaryValidation(asSummary);

    if (flagSummary) {
      if ((JSON.stringify(chkData.details) === JSON.stringify(asDetails)) && (JSON.stringify(chkData.summary) === JSON.stringify(asSummary))) {
        return true;
      } else {
        return false;
      }
    } else {
      if (JSON.stringify(chkData.details) === JSON.stringify(asDetails) && this.cs.getDate() == asSummary?.requestReceivedDate) {
        return true;
      } else {
        return false;
      }
    }
  }

  async chkSummaryValidation(asSummary: any): Promise<boolean> {
    let validationFlag: boolean = false;
    for (const keys in asSummary) {
      if (asSummary[keys]?.length > 0 && (asSummary.hasOwnProperty(keys) && keys !== 'requestReceivedDate' && keys !== 'recordid' && keys !== 'inProgress' && keys !== 'taskid' && keys !== 'printingVersion')) {
        validationFlag = true;
        break;
      } else if (keys === 'printingVersion' && asSummary['printingVersion'] != 0) {
        validationFlag = true;
        break;
      }
    }
    return validationFlag;
  }

  async searchByTab(input: string, filterTyle: string) {

    let dbCall: Observable<Object>;
    this.isLoading = true;
    if (input.trim().length < 1) {
      this.isLoading = false;
      return false;
    } else if (filterTyle == 'mhid' && input == this.searchedMHID) {
      this.isLoading = false;
      return false;
    } else if (filterTyle == 'isbn' && input == this.searchedISBN) {
      this.isLoading = false;
      return false;
    }

    if (this.searchedMHID.length > 1 && this.searchedISBN?.length > 1) {
      const chkData = JSON.parse(localStorage.getItem('arcRequestoData') || '{}');
      const dataComparisonFlag: boolean = await this.adjustData(chkData, this.arcReqSummary, this.arcReqDetails);
      if (!dataComparisonFlag) {
        const t = await this.cs.showModalConfirmation();
        if (!t) {
          this.arcReqSummary.mhid = this.searchedMHID;
          this.arcReqSummary.isbn13 = this.searchedISBN;
          this.isLoading = false;
          return false;
        }
      }
      this.arcReqSummary.mhid = this.searchedMHID;
      this.arcReqSummary.isbn13 = this.searchedISBN;
    }

    if (filterTyle == 'mhid' && input) {
      const url = this.url + "/mhId/" + input;
      dbCall = this.http.get<HttpResponseModel>(url, this.headers);
    } else if (filterTyle == 'isbn' && input) {
      const url = this.url + "/isbn13/" + input;
      dbCall = this.http.get<HttpResponseModel>(url, this.headers);
    } else if (filterTyle == 'taskid' && input) {
      const url = this.url + "/taskId/" + input;
      dbCall = this.http.get<HttpResponseModel>(url, this.headers);
    } else {
      this.isLoading = false;
      return false;
    }

    dbCall.subscribe((response: HttpResponseModel): void => {
      this.compVendorOther = "";
      this.requestedFilesOther = "";

      if (response['data'] && response['succeeded']) {
        this.resetArchiveModel();
        this.fillFormSubscription(response['data']);
      } else {
        this.resetArchiveModel();
        // this.resetDrpLists();
        // this.disabledReqDetailsField = true;
        this.notify.showSuccess('', response['message']);
      }
      this.isLoading = false;
    }, err => {
      this.disabledReqDetailsField = true;
      this.isLoading = false;
      this.notify.showSuccess('', APP_Messages.ServerErrorMessage);
    });
    return;
  }

  private fillFormSubscription(data: any) {
    this.arcReqSummary = data['summary'] as arcReqSummary;
    if (data['details']) {
      this.arcReqDetails = data['details'] as arcReqDetails;
      this.arcReqDetails.inProgress = data['details'].inProgress == 'Y' ? true : false;
      this.defaultCompVendorOtherValue = this.arcReqDetails?.compositorVendor?.otherValue == null ? "" : this.arcReqDetails?.compositorVendor?.otherValue;

      this.setArchivest();
      this.setCompVendor();
      this.setDeliveryMedium();
      this.fillRecordInfo(true);
      this.setPDFLists();
      this.setRequestedFiles();
      this.disablePDHControls();
      this.disableTextAreaCtrls();
    } else {
      // this.resetArchiveDetails();
      this.arcReqDetails.recordid = this.arcReqSummary.recordid;
      if (this.arcReqDetails.requestReceivedDate == null || this.arcReqDetails.requestReceivedDate == "" || this.arcReqDetails.requestReceivedDate == undefined) {
        this.arcReqDetails.requestReceivedDate = this.cs.getDate();
      }
      if (this.arcReqDetails.inProgress == null || this.arcReqDetails.inProgress == undefined) {
        this.arcReqDetails.inProgress = true;
        this.calculatedDaysComplete(this.arcReqDetails.completedDate, this.arcReqDetails.requestReceivedDate);
      }
    }
    if (this.arcReqDetails.requestorDepartment === null || this.arcReqDetails.requestorDepartment === undefined) {
      this.arcReqDetails.requestorDepartment = "";
    }
    this.searchedMHID = this.arcReqSummary.mhid;
    this.searchedISBN = this.arcReqSummary.isbn13;

    this.disabledReqDetailsField = false;
    if (data['details']) {
      localStorage.setItem('arcRequestoData', JSON.stringify({ "summary": this.arcReqDetails, "details": this.arcReqSummary }));
    } else {
      localStorage.setItem('arcRequestoData', JSON.stringify({ "details": this.arcReqSummary }));
    }
  }

  onARSNCommentAdd(comment: any) {
    this.arcReqDetails.statusNotes = this.arcReqDetails.statusNotes || '';
    if (this.arcReqDetails.statusNotes.length > 0) {
      const newLine = this.arcReqDetails.statusNotes.substr(this.arcReqDetails.statusNotes.length - 1, 2) == '\n' ? '' : '\n';
      this.arcReqDetails.statusNotes += newLine + this.userName + " " + this.cs.getDateTime() + '\n' + comment + '\n';
    } else {
      this.arcReqDetails.statusNotes += this.userName + " " + this.cs.getDateTime() + '\n' + comment + '\n';
    }
  }

  onSICommentAdd(comment: any) {
    this.arcReqDetails.specialInstructions = this.arcReqDetails.specialInstructions || '';
    if (this.arcReqDetails.specialInstructions.length > 0) {
      const newLine = this.arcReqDetails.specialInstructions.substr(this.arcReqDetails.specialInstructions.length - 1, 2) == '\n' ? '' : '\n';
      this.arcReqDetails.specialInstructions += newLine + this.userName + " " + this.cs.getDateTime() + '\n' + comment + '\n';
    } else {
      this.arcReqDetails.specialInstructions += this.userName + " " + this.cs.getDateTime() + '\n' + comment + '\n';
    }
  }

  onSubmit() {
    // changing the date format from mm-dd-yyyy to mm/dd/yyy
    // this.dateFormatChange('-', '/', 'html');

    let dataUrl = '';
    this.isLoading = true;
    this.arcReqDetails.modifiedDate = this.cs.getDate();
    this.arcReqDetails.modifiedBy = this.userName;
    delete this.arcReqDetails?.compVendorTest;

    let data: any = { "summary": this.arcReqSummary, "details": this.arcReqDetails };
    data.details.archivist = this.saveArchivist(data.details.archivist);
    data.details.deliveryMedium = this.seaveDeliveryMedium(data.details.deliveryMedium);
    data.details.compositorVendor = this.saveCompVendor(data.details.compositorVendor);

    data = this.savePdfsList(data);
    data = this.saveRequestedFilesList(data);
    data.details.inProgress = this.arcReqDetails.inProgress ? 'Y' : 'N';
    data.details.printingVersion = this.arcReqDetails.printingVersion == null ? 0 : this.arcReqDetails.printingVersion;
    data.details.recordid = data.details.recordid == '' ? data.summary.recordid : data.details.recordid;

    if (!this.recordInformation.uniqueId) {
      this.createSimilarRecord = true;
      dataUrl = this.url + '/';
      this.arcReqDetails.createdBy = this.userName;
      this.arcReqDetails.createdDate = this.cs.getDate();
      data.details.createdBy = this.userName;
      data.details.createdDate = this.cs.getDate();
      this.http.post<HttpResponseModel>(dataUrl, data).subscribe((response:any) => {
        this.resetDrpLists();
        if (response.succeeded) {
          this.fillFormSubscription(response.data);
          this.createSimilarRecord = false;
          this.createNewRecord = false;
          this.recordInformation.daysCompleted = this.calculatedDaysComplete(response.data['details'].completedDate, response.data['details'].requestReceivedDate);
        }
        this.notify.showSuccess('', response.message);
        localStorage.setItem('arcRequestoData', JSON.stringify({ "summary": this.arcReqDetails, "details": this.arcReqSummary }));
        this.isLoading = false;
      }, err => {
        this.isLoading = false;
        this.notify.showSuccess('', APP_Messages.ServerErrorMessage);
      });
    } else {
      dataUrl = this.url + '/' + this.recordInformation.uniqueId;
      this.http.put<HttpResponseModel>(dataUrl, data).subscribe((response:any) => {
        this.resetDrpLists();
        if (response.succeeded) {
          this.fillFormSubscription(response.data);
          this.recordInformation.dateLastModified = response.data['details'].modifiedDate;
          this.recordInformation.lastModifiedBy = response.data['details'].modifiedBy;
          this.recordInformation.daysCompleted = this.calculatedDaysComplete(response.data['details'].completedDate, response.data['details'].requestReceivedDate);
          this.createNewRecord = false;
          localStorage.setItem('arcRequestoData', JSON.stringify({ "summary": this.arcReqDetails, "details": this.arcReqSummary }));
        }
        this.notify.showSuccess('', response.message);
        this.isLoading = false;
      }, err => {
        this.isLoading = false;
        this.notify.showSuccess('', APP_Messages.ServerErrorMessage);
      });
    }
  }

  createSimilar() {
    this.isLoading = true;
    let dataUrl = '';
    this.arcReqDetails.modifiedDate = this.cs.getDate();
    this.arcReqDetails.modifiedBy = this.userName;
    delete this.arcReqDetails?.compVendorTest;

    let data: any = { "summary": this.arcReqSummary, "details": this.arcReqDetails };
    data.details.archivist = this.saveArchivist(data.details.archivist);
    data.details.deliveryMedium = this.seaveDeliveryMedium(data.details.deliveryMedium);
    data.details.compositorVendor = this.saveCompVendor(data.details.compositorVendor);
    data = this.savePdfsList(data);
    data = this.saveRequestedFilesList(data);
    data.details.inProgress = this.arcReqDetails.inProgress ? 'Y' : 'N';
    data.details.printingVersion = this.arcReqDetails.printingVersion == null ? 0 : this.arcReqDetails.printingVersion;
    data.details.recordid = data.details.recordid == '' ? data.summary.recordid : data.details.recordid;

    if (!this.recordInformation.uniqueId) {
      this.createSimilarRecord = true;
      dataUrl = this.url + '/';
      this.arcReqDetails.createdBy = this.userName;
      this.arcReqDetails.createdDate = this.cs.getDate();
      data.details.createdBy = this.userName;
      data.details.createdDate = this.cs.getDate();

      this.http.post<HttpResponseModel>(dataUrl, data).subscribe((response:any) => {
        this.resetDrpLists();
        if (response.succeeded) {
          this.fillFormSubscription(response.data);
          this.createSimilarRecord = true;
          this.createNewRecord = true;
          this.recordInformation.daysCompleted = this.calculatedDaysComplete(response.data['details'].completedDate, response.data['details'].requestReceivedDate);
          this.fillRecordInfo(false);
          this.arcReqDetails.taskid = 0;
        }
        this.notify.showSuccess('', response.message);
        localStorage.setItem('arcRequestoData', JSON.stringify({ "summary": this.arcReqDetails, "details": this.arcReqSummary }));
        this.isLoading = false;
      }, err => {
        this.isLoading = false;
        this.notify.showSuccess('', APP_Messages.ServerErrorMessage);
      });
    } else {
      data.details.taskid = 0; // Task Id Setted 0 instead of Null, Discussed with Prakriti
      dataUrl = this.url + '/' + this.recordInformation.uniqueId;
      this.http.put<HttpResponseModel>(dataUrl, data).subscribe((response:any) => {
        this.resetDrpLists();
        if (response.succeeded) {
          this.fillFormSubscription(response.data);
          this.recordInformation.dateLastModified = response.data['details'].modifiedDate;
          this.recordInformation.lastModifiedBy = response.data['details'].modifiedBy;
          this.recordInformation.daysCompleted = this.calculatedDaysComplete(response.data['details'].completedDate, response.data['details'].requestReceivedDate);
          this.fillRecordInfo(false);
          this.arcReqDetails.taskid = 0;
          this.createNewRecord = false;
          localStorage.setItem('arcRequestoData', JSON.stringify({ "summary": this.arcReqDetails, "details": this.arcReqSummary }));
        }
        this.notify.showSuccess('', response.message);
        this.isLoading = false;
      }, err => {
        this.isLoading = false;
        this.notify.showSuccess('', APP_Messages.ServerErrorMessage);
      });
    }
  }

  dateFormatChange(from: string, to: string, source: string) {
    this.arcReqSummary.boundBookDate = this.cs.DateFormat(this.arcReqSummary.boundBookDate, from, to, source);
    this.arcReqSummary.permissionEndDate = this.cs.DateFormat(this.arcReqSummary.permissionEndDate, from, to, source);
    this.arcReqSummary.projectOPDate = this.cs.DateFormat(this.arcReqSummary.projectOPDate, from, to, source);

    this.arcReqDetails.requestReceivedDate = this.cs.DateFormat(this.arcReqDetails.requestReceivedDate, from, to, source);
    this.arcReqDetails.dueDate = this.cs.DateFormat(this.arcReqDetails.dueDate, from, to, source);
    this.arcReqDetails.completedDate = this.cs.DateFormat(this.arcReqDetails.completedDate, from, to, source);
  }

  compVendorChange(selectedValue: any) {
    let cdata: any;
    if (selectedValue.currentTarget) {
      cdata = selectedValue.currentTarget.options[selectedValue.currentTarget.selectedIndex].text.trim().toLocaleLowerCase();
    } else {
      cdata = selectedValue.trim().toLocaleLowerCase();
    }
    this.showCompVendor = cdata == "other" ? true : false;
  }

  async loadLovs() {
    this.actualArchivistArray = this.archivistArray = this.lovData.returnArchivistLOV();
    this.compVendorArray = this.lovData.returnSingleLOV('COMPOSITOR_VENDOR');
    this.deliveryMediumArray = this.lovData.returnSingleLOV('DELIVERY_MEDIUM');
    this.PDFsArray = this.lovData.returnSingleLOV("PDFS");
    this.requestedFilesArray = this.lovData.returnSingleLOV('REQUESTEDFILES');

    this.arcReqDetails.archivist = '';
    this.arcReqDetails.compositorVendor = '';
    this.arcReqDetails.deliveryMedium = '';
  }

  private fillRecordInfo(resetField: boolean) {
    this.recordInformation.uniqueId = resetField == true ? this.arcReqDetails.taskid : null;
    this.recordInformation.createdBy = resetField == true ? this.arcReqDetails.createdBy : null;
    this.recordInformation.dateCreated = resetField == true ? this.arcReqDetails.createdDate : null;
    this.recordInformation.dateLastModified = resetField == true ? this.arcReqDetails.modifiedDate : null;
    this.recordInformation.lastModifiedBy = resetField == true ? this.arcReqDetails.modifiedBy : null;
    this.recordInformation.daysCompleted = resetField == true ? this.calculatedDaysComplete(this.arcReqDetails.completedDate, this.arcReqDetails.requestReceivedDate) : null;
  }

  calculatedDaysComplete(cDate: string, rrDate: string) {
    if (cDate == "" || cDate == undefined) {
      this.recordInformation.daysCompleted = 0;
    }
    if (cDate && rrDate) {
      this.recordInformation.daysCompleted = this.cs.calculateDays(this.cs.getDatewithParam(rrDate), this.cs.getDatewithParam(cDate));
      const d1 = this.cs.getDate();
      if (this.cs.calculateDays(d1, this.cs.getDatewithParam(cDate)) > 1) {
        this.arcReqDetails.inProgress = true;
      } else {
        this.arcReqDetails.inProgress = false;
      }
      return this.recordInformation.daysCompleted;
    }
    return null;
  }

  private disablePDHControls() {
    this.disabledPDHField = true;
    this.enablenotes = true;
  }

  private disableTextAreaCtrls() {
    this.disabledTextAreaField = true;
  }

  private setArchivest() {

    if (this.arcReqDetails.archivist?.description == null || this.arcReqDetails.archivist?.description == "") {
      this.arcReqDetails.archivist = '';
      return false;
    } else if (this.checkExistingArchiviest(this.arcReqDetails.archivist.description) != true) {
      return false;
    }

    let dbData: string;
    let flag: boolean = false;

    if (this.arcReqDetails.archivist != null) {
      this.archivistArray = this.lovData.returnArchivistLOV();
      dbData = this.arcReqDetails.archivist['description'];
    }

    this.archivistArray.filter(ary => {
      if (ary.description == dbData) {
        flag = true;
      }
    });

    if (flag) {
      this.archivistArray.push(this.arcReqDetails.archivist);
    }

    const lovId = this.archivistArray.filter((arryData) => { return arryData.description?.toLowerCase() == dbData.toLowerCase() })[0].lovid;
    this.arcReqDetails.archivist = lovId;
    return;
  }

  checkExistingArchiviest(paramData: string) {
    this.archivistArray = this.cs.removePreviousArray(this.archivistArray, this.actualArchivistArray);
    const dataLength = this.archivistArray.filter((arData) => {
      return arData.description?.toLowerCase() === paramData.toLowerCase();
    });
    if (dataLength.length >= 1) {
      this.arcReqDetails.archivist = dataLength[0].lovid;
      return false
    } else {
      return true;
    }
  }

  private setCompVendor() {
    if (this.arcReqDetails && this.arcReqDetails.compositorVendor) {
      const dbData: string = this.arcReqDetails.compositorVendor.description;
      for (const keys in this.compVendorArray) {
        if (dbData == this.compVendorArray[keys].description) {
          if (dbData.trim().toLowerCase() === 'other') {
            this.compVendorOther = this.arcReqDetails.compositorVendor.otherValue ? this.arcReqDetails.compositorVendor.otherValue.trim() : "";
          }
          this.arcReqDetails.compositorVendor = this.compVendorArray[keys].lovid;
          this.compVendorChange(dbData);
        }
      }
    } else {
      this.arcReqDetails.compositorVendor = '';
      this.compVendorChange('');
    }
  }

  private setDeliveryMedium() {
    if (this.arcReqDetails && this.arcReqDetails.deliveryMedium) {
      const dbData: string = this.arcReqDetails.deliveryMedium.description;
      for (const keys in this.deliveryMediumArray) {
        if (dbData == this.deliveryMediumArray[keys].description) {
          this.arcReqDetails.deliveryMedium = this.deliveryMediumArray[keys].lovid;
        }
      }
    } else {
      this.arcReqDetails.deliveryMedium = '';
    }
  }

  private setPDFLists() {
    if (this.arcReqDetails && this.arcReqDetails.pdfsList) {
      this.PDFsArray.forEach(arrData => {
        this.arcReqDetails.pdfsList.forEach((respData: { description: string; }) => {
          if (arrData.description?.trim().toLowerCase() == respData.description.trim().toLowerCase()) {
            arrData.checked = true;
          }
        })
      });
    }
  }

  private setRequestedFiles() {
    if (this.arcReqDetails && this.arcReqDetails.requestedFilesList) {
      this.requestedFilesArray.forEach(arrData => {
        this.arcReqDetails.requestedFilesList.forEach((respData: { description: string; otherValue: string }) => {
          if (arrData.description?.trim().toLowerCase() == respData.description.trim().toLowerCase()) {
            if (respData.description.trim().toLowerCase() === 'other') {
              this.requestedFilesOther = respData.otherValue == null ? ' ' : respData.otherValue?.trim();
            }
            arrData.checked = true;
          }
        })
      });
    }
  }

  pdfArrayChange(evt: any, dataList: chkInterface) {
    if (evt) {
      this.arcReqDetails.pdfsList?.push(dataList);
    } else {
      this.arcReqDetails.pdfsList?.forEach((objList: { description: string; }, index: any) => {
        if (objList.description.trim().toLowerCase() == dataList.description?.trim().toLowerCase()) {
          this.arcReqDetails.pdfsList.splice(index, 1)
        };
      });
    }
  }

  reqArrayChange(evt: any, dataList: chkInterface) {
    if (evt) {
      this.arcReqDetails.requestedFilesList?.push(dataList);
    } else {
      this.arcReqDetails.requestedFilesList?.forEach((objList: { description: string; }, index: any) => {
        if (objList.description.trim().toLowerCase() == dataList.description?.trim().toLowerCase()) {
          this.arcReqDetails.requestedFilesList.splice(index, 1);
        }
      });
    }
  }

  private resetArchiveModel() {
    // this.arcReqDetails = new arcReqDetails(); // need to change
    this.arcReqSummary = new arcReqSummary();
    // this.resetCheckboxes();
    this.fillRecordInfo(false);
    this.searchedMHID = '';
    this.searchedISBN = '';
  }

  resetCheckboxes() {
    this.requestedFilesArray.forEach(v => {
      v.checked = false;
      v.enabled = 'Y';
    });
    this.PDFsArray.forEach(v => {
      v.checked = false;
      v.enabled = 'Y';
    });
  }

  private resetDrpLists() {
    this.setArchivest();
    this.setCompVendor();
    this.setDeliveryMedium();
  }

  async createNewRecordClick() {

    if (this.searchedMHID.length > 1 && this.searchedISBN?.length > 1) {
      const chkData = JSON.parse(localStorage.getItem('arcRequestoData') || '{}');
      const dataComparisonFlag: boolean = await this.adjustData(chkData, this.arcReqSummary, this.arcReqDetails);
      if (!dataComparisonFlag) {
        const flag = await this.cs.showModalConfirmationNewRecord();
        if (!flag) {
          this.arcReqSummary.mhid = this.searchedMHID;
          this.arcReqSummary.isbn13 = this.searchedISBN;
          this.isLoading = false;
          return false;
        }
      }
      this.arcReqSummary.mhid = this.searchedMHID;
      this.arcReqSummary.isbn13 = this.searchedISBN;
    }

    this.createNewRecord = true;
    this.resetArchiveDetails();
    this.arcReqSummary = new arcReqSummary();
    localStorage.removeItem('arcRequestoData');
    this.searchedMHID = '';
    this.searchedISBN = '';
    this.resetCheckboxes();
    this.fillRecordInfo(false);
    this.compVendorOther = '';
    this.requestedFilesOther = '';
    this.compVendorChange('');
    // this.arcReqDetails.requestReceivedDate = this.cs.getDate();
    this.disabledReqDetailsField = true;
    if (this.router.url !== '/archiveReq') {
      this.router.navigate(['archiveReq']);
    }
    return;
  }

  private saveArchivist(data: any) {
    const fdata = this.archivistArray.filter(arr => {
      return arr.lovid === +this.arcReqDetails.archivist;
    })[0];
    data = fdata;
    return data;
  }

  private seaveDeliveryMedium(data: any) {
    const fdata = this.deliveryMediumArray.filter(arr => {
      return arr.lovid === +this.arcReqDetails.deliveryMedium;
    })[0];
    data = fdata;
    return data;
  }

  private saveCompVendor(data: any) {
    let otherField: boolean = false;
    const fdata = this.compVendorArray.filter(arr => {
      if (arr.lovid === +this.arcReqDetails.compositorVendor) {
        if (arr.description?.trim().toLowerCase() === 'other') {
          otherField = true;
        }
        return arr.lovid === +this.arcReqDetails.compositorVendor;
      }
      return;
    })[0];
    if (otherField) {
      fdata.otherValue = this.compVendorOther?.trim();
    }
    data = fdata;
    return data;
  }

  private savePdfsList(data: any) {
    const fdata: chkInterface[] = [];
    this.PDFsArray.filter(arr => {
      if (arr.checked) {
        fdata.push(arr);
      }
    });
    data.details.pdfsList = fdata
    return data;
  }

  private saveRequestedFilesList(data: any) {
    const fdata: chkInterface[] = [];
    this.requestedFilesArray.filter(arr => {
      if (arr.checked) {
        if (arr.description?.trim().toLowerCase() === 'other') {
          arr.otherValue = this.requestedFilesOther?.trim();
        }
        fdata.push(arr);
      }
    });
    data.details.requestedFilesList = fdata
    return data;
  }

  private resetArchiveDetails() {
    this.arcReqDetails.requestReceivedDate = '';
    this.arcReqDetails.dueDate = '';
    this.arcReqDetails.completedDate = '';
    this.arcReqDetails.inProgress = false;
    this.arcReqDetails.requestedBy = '';
    this.arcReqDetails.requestorDepartment = '';
    this.arcReqDetails.printingVersion = 0;
    this.arcReqDetails.taskid = 0;
    this.arcReqDetails.specialInstructions = '';
    this.arcReqDetails.statusNotes = '';
    this.arcReqDetails.archivist = '';
    this.arcReqDetails.deliveryMedium = '';
    this.arcReqDetails.compositorVendor = '';
    this.arcReqDetails.pdfsList = [];
    this.arcReqDetails.requestedFilesList = [];
    this.arcReqDetails.createdDate = '';
    this.arcReqDetails.createdBy = '';
    this.arcReqDetails.modifiedDate = '';
    this.arcReqDetails.modifiedBy = '';
    this.arcReqDetails.recordid = '';
    this.compVendorChange('');
  }

  requestedByChange(event: any) {
    if (this.arcReqDetails.requestedBy.length < 1) {
      this.arcReqDetails.requestedBy = '';
    } else {
      this.arcReqDetails.requestedBy = this.arcReqDetails.requestedBy.trim();
    }
  }

  otherFilesOtherValueChange(event: any, ofl: chkInterface) {
    this.arcReqDetails.requestedFilesList.filter((filterData: { lovid: number; otherValue: any; }) => {
      if (filterData.lovid == ofl.lovid) {
        filterData.otherValue = event.currentTarget.value;
      }
      return filterData.lovid == ofl.lovid
    });
  }

  compVendorOtherValueChange(event: any) {
    if (this.defaultCompVendorOtherValue == event.currentTarget.value) {
      delete this.arcReqDetails?.compVendorTest;
    } else {
      this.arcReqDetails.compVendorTest = event.currentTarget.value;
    }
  }

}
