
export const APP_Messages = {
    SuccessMessage: "Success",
    ServerErrorMessage: "Something went wrong, Please try again!",
    differentCriteria: "Please Select Different Criteria",
    selectPropertyName: "Please Select Property Name",
    selectContains: "Please Select Contains",
    selectOperator: "Please Select Operator",
    enterValue: "Please Enter Value",
    selectValue: "Please Select Value",
    selectPage: "Please Select Page!",
    selectColumns: "Please Select Columns!"
}

export const AppArchiveRecordMessages = {
    confirmTitle: 'Please Confirm',
    confirmMessage: 'This option will leave the page without saving your changes.',
    confirmText: 'CONTINUE',
    confirmCanceltext: 'RETURN TO PREVIOUS PAGE',
}

export const AppArchiveRequestMessages = {
    confirmTitle: AppArchiveRecordMessages.confirmTitle,
    confirmMessage: AppArchiveRecordMessages.confirmMessage,
    confirmText: AppArchiveRecordMessages.confirmText,
    confirmCanceltext: AppArchiveRecordMessages.confirmCanceltext,
}

export const appDataChangeOnListedRecordMessages = {
  confirmTitle: 'Please Confirm',
  confirmMessage: 'This option will leave the record without saving your changes',
  confirmText: 'Continue',
  confirmCanceltext: 'Return to previous record',
}

export const appDataChangeOnNavigationMessages = {
  confirmTitle: 'Please Confirm',
  confirmMessage: 'This option will leave the page without saving your changes.',
  confirmText: 'Continue',
  confirmCanceltext: 'Return to previous PAGE',
}

