export class arcReqDetails {
  requestReceivedDate!: string;
  dueDate!: string;
  completedDate!: string;
  inProgress!: boolean;
  requestedBy!: string;
  requestorDepartment!: string;
  printingVersion!: number;
  taskid!: number;
  specialInstructions!: string;
  statusNotes!: string;
  archivist: any;
  deliveryMedium: any;
  compositorVendor: any;
  pdfsList: any;
  requestedFilesList: any;
  createdDate!: string;
  createdBy!: string;
  modifiedDate!: string;
  modifiedBy!: string;
  recordid!: string;
  compVendorTest: any;
}

export class arcReqSummary {
  mhid!: string;
  isbn13!: string;
  previousISBN!: string;
  newISBN!: string;
  author!: string;
  title!: string;
  edition!: number;
  priority!: string;
  owningDivision!: string;
  owningSubDivision!: string;
  copyrightYear!: number;
  boundBookDate!: string;
  permissionEndDate!: string;
  projectOPDate!: string;
  deliveryFormat!: string;
  titleTypeDesc!: string;
  gradeRange!: string;
  specificMarket!: string;
  ipubPublishingGroup!: string;
  ipubProgrammingTitle!: string;
  noOfPages!: number;
  comments!: string;
  recordid!: string;
}

export class associatedSummary {
  mhid!: string;
  isbn13!: string;
  previousISBN!: string;
  newISBN!: string;
  author!: string;
  title!: string;
  edition!: number;
  copyrightYear!: number;
  boundBookDate!: string;
  permissionEndDate!: string;
  projectOPDate!: string;
  owningDivision!: string;
  owningSubDivision!: string;
  deliveryFormat!: string;
  titleTypeDesc!: string;
  gradeRange!: string;
  specificMarket!: string;
  ipubPublishingGroup!: string;
  ipubProgrammingTitle!: string;
  noOfPages!: number;
  comments: any;
  recordid!: number;
  priority!: string;
}

export class associatedDetails {
  productTitle: string | undefined;
  archivist: any;
  compositorVendor: any;
  downloadReceivedDate!: string;
  archivedDate!: string;
  storageLocation: any;
  libraryLocation!: string;
  printingVersion!: number;
  reprintContact: any;
  pagingFilesList: any;
  otherFilesList: any;
  pdfsList: any;

  associatedid!: number;
  recordid!: number;
  productNotes!: string;
  createdDate!: string;
  createdBy!: string;
  modifiedDate!: string;
  modifiedBy!: string;
}

export class Summary{
  recordid?: number;
  mhid: any;
  isbn13: any;
  previousISBN: string | undefined;
  newISBN: string | undefined;
  author: string | undefined;
  title: string | undefined;
  copyrightYear: number | undefined;
  boundBookDate: any;
  ipubPublishingGroup: string | undefined;
  ipubProgrammingTitle: string | undefined;
  comments: string | undefined;
}

export class Details{
  archivist: any;
  compositorVendor: any;
  downloadDueDate: string | undefined;
  downloadReceivedDate:any;
  pagingFilesList:any;
  otherFilesList:any;
  pdfsList:any;
  createdDate: Date | undefined;
  createdBy: string | undefined;
  modifiedDate: Date | undefined;
  modifiedBy: string | undefined;
}

export interface lovInterface{
  lovid?: number,
  lovType?: string,
  lovCode?: string,
  description?: string,
  valueField?: string,
  enabled?: string,
  orderSeq?: number,
  otherValue?:string
}

export interface chkInterface{
  lovid?: number,
  lovType?: string,
  lovCode?: string,
  description?: string,
  valueField?: string,
  enabled?: string,
  checked?:boolean,
  orderSeq?: number,
  otherValue?:string
}


export interface lovDataInterface{
  lovGroupType:string,
  lovItemList:lovInterface[]
}

export interface leadData{
  succeeded:string,
  data:mainData[],
  message:string
}

export interface mainData{
  summary:Summary[],
  details:Details[]
}


export class nimasSummary {
  recordid!: number;
  mhid!: string;
  isbn13!: string;
  previousISBN!: string;
  newISBN!: string;
  author!: string;
  title!: string;
  edition!: number;
  priority!: string;
  owningDivision!: string;
  owningSubDivision!: string;
  copyrightYear!: number;
  boundBookDate!: string;
  permissionEndDate!: string;
  projectOPDate!: string;
  deliveryFormat!: string;
  titleTypeDesc!: string;
  gradeRange!: string;
  specificMarket!: string;
  ipubPublishingGroup!: string;
  ipubProgrammingTitle!: string;
  noOfPages!: number;
  comments!: string;
}
export class nimasDetails {
  archivist: any;
  coordinator:any;
  nimasCertNumber!:string;
  nimasCertReceivedDate!:string;
  nimasConvVendor: any;
  nimasDescVendor: any;
  filesDescriptionVendor!: string;
  filesConversionVendor: any;
  notes: any;

  nimasCertiReceived!: string;
  nimasCertiNumber!: string;
  createdDate!: string;
  createdBy!: string;
  modifiedDate!: string;
  modifiedBy!: string;

  nimasid!: number;
  recordid!: number;
}

export interface nimasLovInterface {
  lovid?: number,
  lovType?: string,
  lovCode?: string,
  description?: string,
  valueField?: string,
  enabled?: string,
  orderSeq?: number,
  otherValue?: string,
  filesSentDate?: string
}

export interface apiModel {
  succeeded: boolean;
  data: dataModel;
  message: string;
}

export interface dataModel {
  summary: Summary;
  details: Details;
}

