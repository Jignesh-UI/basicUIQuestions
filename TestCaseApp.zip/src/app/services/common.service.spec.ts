import { HttpClient, HttpHandler } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/compiler';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialog, MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RouterTestingModule } from '@angular/router/testing';
import { ConfirmDialogComponent } from '../shared/components/confirm-dialog/confirm-dialog.component';

import { CommonService } from './common.service';

describe('CommonService', () => {
  let service: CommonService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[RouterTestingModule, MatDialogModule],
      declarations:[ConfirmDialogComponent],
      providers: [
        HttpClient,
        HttpHandler,
        { provide: MatDialogRef, useValue: {} }
      ],
      schemas:[NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
    service = TestBed.inject(CommonService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });


  it('should return todays Date and Time',()=>{
    let dt = service.getDateTime();
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ':' + today.getMinutes() + ':' + today.getSeconds();
    var dateTime = date + ' ' + time;
    expect(dt == dateTime).toBeTruthy();
  });

  // it('should return todays date',()=>{
  //   let dateFromServiceFunction = service.getDate();
  //   let today = new Date();
  //   let month = today.getMonth() < 10 ? '0' + (today.getMonth()+1) : today.getMonth()+1;
  //   let todayDate = today.getDate() <  10 ? '0' + today.getDate() : today.getDate();
  //   var todaysDate = today.getFullYear() + '-' + month + '-' + todayDate;
  //   expect(dateFromServiceFunction == todaysDate).toBeTruthy();
  // });

  // it('should adjust date in HTML Format', ()=>{
  //   let date = new Date();
  //   let month = date.getMonth() < 10 ? '0' + (date.getMonth()+1) : date.getMonth()+1;
  //   let todaysDate = date.getDate() <  10 ? '0' + date.getDate() : date.getDate();
  //   let todayDate = date.getFullYear() + '-' + month + '-' + todaysDate;
  //   const dateFromService = service.DateFormat(todayDate,'-','/','html');
  //   expect((dateFromService.match(new RegExp("/", "g")) || []).length).toBe(2);
  // });

  // it('should adjust date in SERVER Format', ()=>{
  //   let date = new Date();
  //   let month = date.getMonth() < 10 ? '0' + (date.getMonth()+1) : date.getMonth()+1;
  //   let todaysDate = date.getDate() <  10 ? '0' + date.getDate() : date.getDate();
  //   let todayDate = date.getFullYear() + '/' + month + '/' + todaysDate;
  //   const dateFromService = service.DateFormat(todayDate,'/','-','server');
  //   expect((dateFromService.match(new RegExp("-", "g")) || []).length).toBe(2);
  // });

  // it('should return empty string when date is not passed', ()=>{
  //   const dateFromService = service.DateFormat('','-','/','html');
  //   expect(dateFromService).toBe('');
  // });

  // it('should return date with parameters', ()=>{
  //   const date= new Date();
  //   let month = date.getMonth() < 10 ? '0' + (date.getMonth()+1) : date.getMonth()+1;
  //   let todaysDate = date.getDate() <  10 ? '0' + date.getDate() : date.getDate();
  //   let todayDate = date.getFullYear() + '/' + month + '/' + todaysDate;
  //   const dateFromService = service.getDatewithParam(todayDate);
  //   expect((dateFromService.match(new RegExp("/", "g")) || []).length).toBe(2);
  // });

  // it('should return number of days between two dates', ()=>{
  //   const date1 = service.getDatewithParam("2022/09/23");
  //   const date2 = service.getDatewithParam("2022/09/25");
  //   const noOfDays:any = service.calculateDays(date1,date2);
  //   expect(3).toEqual(noOfDays);
  // });

  // it('should return date in mm + / + dd + / + yy Format.', ()=>{
  //   const date1 = "2022/09/23";
  //   const noOfDays = service.getDateforSearchGrid(date1);
  //   expect(noOfDays === '09/23/2022').toBeTruthy();
  // });

  // it('should return TRUE if data is compared',()=>{
  //   let chkData = {
  //     "summary": {
  //         "recordid": 1304182,
  //         "mhid": "test-mhid",
  //         "isbn13": "test-isbn",
  //         "title": "testing api part 1",
  //     },
  //     "details": {
  //         "associatedid": 10863,
  //         "recordid": 1304182,
  //         "productTitle": "testing product title from postman - 12",
  //         "archivist": 1005,
  //         "compositorVendor": 4005,
  //       }
  //     };
  //     let assocDetails = {
  //       "associatedid": 10863,
  //       "recordid": 1304182,
  //       "productTitle": "testing product title from postman - 12",
  //       "archivist": 1005,
  //       "compositorVendor": 4005,
  //     }
  //     let assocSummary = {
  //       "recordid": 1304182,
  //       "mhid": "test-mhid",
  //       "isbn13": "test-isbn",
  //       "title": "testing api part 1",
  //     }
  //   expect(service.adjustData(chkData,assocDetails,assocSummary)).toBeTruthy();
  // });

});
