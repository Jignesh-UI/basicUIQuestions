import { Injectable } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { appDataChangeOnListedRecordMessages, appDataChangeOnNavigationMessages } from '../models/app-defaults';
import { lovInterface } from '../models/common.model';
import { ConfirmDialogComponent } from '../shared/components/confirm-dialog/confirm-dialog.component';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(private dialog: MatDialog) { }


  getDate(): any {
    var today = new Date();
    let month = today.getMonth() < 10 ? '0' + (today.getMonth()+1) : today.getMonth()+1;
    let todayDate = today.getDate() <  10 ? '0' + today.getDate() : today.getDate();
    var date = today.getFullYear() + '-' + month + '-' + todayDate;
    return date;
  }

  getDateTime(): any {
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ':' + today.getMinutes() + ':' + today.getSeconds();
    var dateTime = date + ' ' + time;
    return dateTime;
  }

  DateFormat(date: string, from: string, to: string, source: string): string {
    if (date) {
      if (source === 'html') {
        const d = new Date(date + ' 00:00:00.00');
        const dd = d.getDate();
        const mm = d.getMonth() + 1;
        const yy = d.getFullYear();
        const newdate = mm + '/' + dd + '/' + yy;
        return newdate;
      } else if (source === 'server') {
        const d = new Date(date + ' 00:00:00.00');
        const dd = d.getDate();
        const mm = d.getMonth() + 1;
        const yy = d.getFullYear();
        const newdate = mm + '-' + dd + '-' + yy;
        return newdate;
      }
    } else {
      return '';
    }
    return '';
  }

  getDatewithParam(date: string): any {
    const d = new Date(date + ' 00:00:00.00');
    const dd = d.getDate();
    const mm = d.getMonth() + 1;
    const yy = d.getFullYear();
    const newdate = mm + '/' + dd + '/' + yy;
    return newdate;
  }

  calculateDays(date1:Date, date2:Date) {
    let days = 0;
    var Time = new Date(date2).getTime() - new Date(date1).getTime();
    days = Time / (1000 * 3600 * 24); //Diference in Days
    return days >= 0 ? (days+1) : 0;
  }

  getDateforSearchGrid(date: string): any {
    const d = new Date(date);
    const dd = d.getDate() <  10 ? '0' + d.getDate() : d.getDate();
    const mm = d.getMonth() < 9 ? '0' + (d.getMonth()+1) : d.getMonth()+1;
    const yy = d.getFullYear();
    return mm + '/' + dd + '/' + yy;
  }

  removePreviousArray(objArray: lovInterface[], objActualArray: lovInterface[]) {
    const obj = objArray.filter(({ lovid: id1 }) => !objActualArray.some(({ lovid: id2 }) => id2 === id1))[0];
    if (obj) {
      objArray = objArray.filter((item) => {
        return item.lovid != obj.lovid;
      });
    }
    return objArray;
  }

  async adjustData(chkData: any, asDetails: any, asSummary: any) {
    delete chkData.summary.mhid;
    delete chkData.summary.isbn13;
    delete asSummary.mhid;
    delete asSummary.isbn13;
    if ((JSON.stringify(chkData.details) === JSON.stringify(asDetails)) && (JSON.stringify(chkData.summary) === JSON.stringify(asSummary))) {
      return true;
    } else {
      return false;
    }
  }

  async showModalConfirmation(pageMessage: boolean = false) {
    const dConfig = new MatDialogConfig();
    dConfig.data = {
      'title': !pageMessage ? appDataChangeOnListedRecordMessages.confirmTitle : appDataChangeOnNavigationMessages.confirmTitle,
      'message': !pageMessage ? appDataChangeOnListedRecordMessages.confirmMessage : appDataChangeOnNavigationMessages.confirmMessage,
      'confirmText': !pageMessage ? appDataChangeOnListedRecordMessages.confirmText : appDataChangeOnNavigationMessages.confirmText,
      'canceltext': !pageMessage ? appDataChangeOnListedRecordMessages.confirmCanceltext : appDataChangeOnNavigationMessages.confirmCanceltext,
      success: (e: any) => {
        return false;
      },
      close: (e: any) => {
        return true;
      }
    };
    const dialogRef = this.dialog.open(ConfirmDialogComponent, dConfig);
    return await dialogRef.afterClosed().toPromise();
  }

  async showModalConfirmationNewRecord(pageMessage: boolean = false) {
    const dConfig = new MatDialogConfig();
    dConfig.data = {
      'title': "Please Confirm",
      'message': "This action will clear the page and unsaved changes will be lost",
      'confirmText': "Continue",
      'canceltext': "Return to previous record",
      success: (e: any) => {
        return false;
      },
      close: (e: any) => {
        return true;
      }
    };
    const dialogRef = this.dialog.open(ConfirmDialogComponent, dConfig);
    return await dialogRef.afterClosed().toPromise();
  }

}
