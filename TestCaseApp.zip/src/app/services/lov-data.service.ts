import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NotificationService } from './notification.service';
import { map, tap } from 'rxjs/operators';
import { leadData } from '../models/common.model';
import { throwError } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class LovDataService {
  private url: string = '../../assets/localData/lovData.json';

  private lovData: any[] = [];

  constructor(private http: HttpClient, private notify: NotificationService) {}


  loadListofLovs() {
    if (this.lovData.length === 0) {
      return this.http
        .get<leadData[]>(this.url, {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
          }),
        })
        .pipe(
          map((responseData) => {
            const lovArray: any[] = [];
            for (const keys in responseData) {
              if (responseData.hasOwnProperty(keys) && keys === 'data') {
                lovArray.push(Object.values(responseData[keys]));
              }
            }
            return Object.values(lovArray[0]);
          }),
          tap((responseData) => {
            this.lovData = responseData;
          })
        );
    } else {
      return this.lovData;
    }
  }

  returnSingleLOV(param: string) {
    let singleLovArray = [];
    for (const keys in this.lovData) {
      if (this.lovData[keys].lovGroupType == param) {
      singleLovArray = this.lovData[keys].lovItemList;
      }
    }
    return singleLovArray;
  }

  returnArchivistLOV() {
    let singleLovArray = [];
    for (const keys in this.lovData) {
      if (this.lovData[keys].lovGroupType == 'ARCHIVIST') {
        singleLovArray = this.lovData[keys].lovItemList;
      }
    }
    return singleLovArray;
  }

  handleError(errorRes: HttpErrorResponse){
    console.log(errorRes.status + ' ' + errorRes.statusText);
    return throwError(errorRes.status);
  }

}
