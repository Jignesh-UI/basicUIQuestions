import { HttpClient, HttpHandler } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { ToastrModule } from 'ngx-toastr';

import { LOVResolverService } from './lovresolver.service';

describe('LOVResolverService', () => {
  let service: LOVResolverService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[ ToastrModule.forRoot()],
      providers: [
        HttpClient,
        HttpHandler
      ],
    });
    service = TestBed.inject(LOVResolverService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
