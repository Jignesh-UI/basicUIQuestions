import { TestBed } from '@angular/core/testing';

import { RolesPolicyService } from './roles-policy.service';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { ToastrModule } from 'ngx-toastr';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/compiler';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';

describe('RolesPolicyService', () => {
  let service: RolesPolicyService;

  const policyArray = [
    {
      securityPolicyName: 'SP-HigherEd',
      owningDivisions: ['COLLEGE', 'ESL/ELT', 'INTERNATIONAL'],
      role: {
        roleId: 79001,
        roleName: 'Archivist',
        permissions: ['CREATE', 'EDIT', 'VIEW', 'SEARCH', 'REPORT'],
      },
      securityPolicyRoleid: 85000,
    },
    {
      securityPolicyName: 'SP-School',
      owningDivisions: ['AGENCY/DISTRIBUTED', 'ELEMENTARY', 'SECONDARY'],
      role: {
        roleId: 79000,
        roleName: 'Read-Only User',
        permissions: ['VIEW', 'SEARCH', 'REPORT'],
      },
      securityPolicyRoleid: 85001,
    },
    {
      securityPolicyName: 'SP-LATAM',
      owningDivisions: ['LATIN AMERICA'],
      role: {
        roleId: 79000,
        roleName: 'Read-Only User',
        permissions: ['VIEW', 'SEARCH', 'REPORT'],
      },
      securityPolicyRoleid: 85002,
    },
    {
      securityPolicyName: 'SP-Open',
      owningDivisions: [],
      role: {
        roleId: 79001,
        roleName: 'Archivist',
        permissions: ['CREATE', 'EDIT', 'VIEW', 'SEARCH', 'REPORT'],
      },
      securityPolicyRoleid: 85003,
    },
  ];

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        ToastrModule.forRoot(),
        MatDialogModule,
        HttpClientTestingModule,
      ],
      providers: [
        HttpClient,
        HttpHandler,
        { provide: MatDialogRef, useValue: {} },
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
    });
    service = TestBed.inject(RolesPolicyService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return true when sp-open role is applied', () => {
    service.securityPolicyRoles = policyArray;
    const rules = service.authenticationStatus('sp-open');
    expect(rules).toBeTruthy();
  });

  it('should return true when archiviest role is applied', () => {
    service.securityPolicyRoles = policyArray;
    const rules = service.authenticationStatus('COLLEGE');
    expect(rules).toBeTruthy();
  });

  it('should return false when read only role is applied', () => {
    service.securityPolicyRoles = policyArray;
    const rules = service.authenticationStatus('SECONDARY');
    expect(rules).toBeTruthy();
  });

  it('should list all the policies in array', async () => {
    service.securityPolicyRoles = policyArray;
    await service.listPolicies();
    expect(service.securityPolicyRoles.length).not.toBe(0);
  });

  it('should list all the policies in array from API', async () => {
    const localService = TestBed.inject(RolesPolicyService);
    const httpMock = TestBed.inject(HttpTestingController);
    let lidata;

    localService.featchRolePolicies().subscribe({
      next: async (data: SecurityPolicyRole[] | any): Promise<void> => {
        lidata = data;
        expect(data).not.toBeNull()
      },
      error: (error) => {
          console.log(error);
      }
    });

    expect(lidata).not.toBeNull();

    // const req = httpMock.expectOne('https://archivedb-api-dev.aef.mh-int.dev/archivedb/services/user');
    // req.flush(expectedResponse);
    httpMock.verify();

  });

});


export interface RolesPolicyInterface {
  succeeded: boolean
  data: Data
  message: string
}

export interface Data {
  userId: number
  email: string
  userName: string
  securityPolicyRoles: SecurityPolicyRole[]
}

export interface SecurityPolicyRole {
  securityPolicyName: string
  owningDivisions: string[]
  role: Role
  securityPolicyRoleid: number
}

export interface Role {
  roleId: number
  roleName: string
  permissions: string[]
}
