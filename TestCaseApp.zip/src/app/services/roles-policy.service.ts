import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { CommonService } from './common.service';
import { map, tap } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class RolesPolicyService {

  private rolePolicyURL = environment.baseAPIUrl + 'services/user';
    private defaultOwningDivision = "sp-open";
    securityPolicyRoles:SecurityPolicyRole[]=[];

    constructor(private http: HttpClient, private cs: CommonService) { }

    featchRolePolicies(){
        const request = {
            email : "jignesh.patel@mheducation.com"
        }
        return this.http.post(this.rolePolicyURL, request)
            .pipe(map((responseData:RolesPolicyInterface[] | any) => {
              const policyArray=[];
                if(responseData.succeeded == true && responseData.data != null){
                    for(const keys in responseData){
                        for(const rkeys in responseData[keys]){
                            if (responseData.data.hasOwnProperty(rkeys) && rkeys === 'securityPolicyRoles') {
                                policyArray.push(...responseData.data[rkeys])
                            }
                        }
                    }
                  }
                  return policyArray;
            }));
    }

    async listPolicies(){
        if(this.securityPolicyRoles.length > 0){
            return;
        }

        this.featchRolePolicies().subscribe({
            next: async (response: SecurityPolicyRole[] | any): Promise<void> => {
                // console.log(response);
                this.securityPolicyRoles = response;
            },
            error: (error) => {
                console.log(error);
            }
        })
    }

    async authenticationStatus(owningDivision:string){
        if(this.securityPolicyRoles.length <= 0){
            await this.listPolicies();
        }
        const filteredData:SecurityPolicyRole = this.returnOwingDivisionsFilter(owningDivision);
        if(filteredData != undefined || filteredData != null){
            const rolesFilter = this.returnPermissionsFilter(filteredData)
            return this.authFlag(rolesFilter.length);
        }else{
            const spOpenRules = this.returnSpOpenRules();
            return this.authFlag(spOpenRules.length)
        }
    }

    private authFlag(rolesLength:number){
        if(rolesLength>0){
            return true;
        }else{
            return false;
        }
    }

    private returnOwingDivisionsFilter(owningDivision:string){
        return this.securityPolicyRoles.filter(item =>{
            return item.owningDivisions.includes(owningDivision.toUpperCase())
          })[0];
    }

    private returnPermissionsFilter(filteredData: SecurityPolicyRole){
        return filteredData.role.permissions.filter((item:any) => {
            return item.includes('CREATE') || item.includes('EDIT')
        })
    }

    private returnSpOpenRules(){
        const spName = this.securityPolicyRoles.filter(item => {
            return item.securityPolicyName.toLowerCase() === this.defaultOwningDivision ? item.securityPolicyName : [];
        })[0];

        return spName.role.permissions.filter((item:any) => {
            return item.includes('CREATE') || item.includes('EDIT')
        })
    }

}




export interface RolesPolicyInterface {
  succeeded: boolean
  data: Data
  message: string
}

export interface Data {
  userId: number
  email: string
  userName: string
  securityPolicyRoles: SecurityPolicyRole[]
}

export interface SecurityPolicyRole {
  securityPolicyName: string
  owningDivisions: string[]
  role: Role
  securityPolicyRoleid: number
}

export interface Role {
  roleId: number
  roleName: string
  permissions: string[]
}
