import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import {MatDialogModule} from '@angular/material/dialog'

@Component({
  selector: 'app-confirm-dialog',
  templateUrl: './confirm-dialog.component.html',
  styleUrls: ['./confirm-dialog.component.scss']
})
export class ConfirmDialogComponent implements OnInit {



  constructor(@Inject(MAT_DIALOG_DATA) public dialog: ConfirmDialogInterface) {
  }

  ngOnInit(): void {
  }
}

interface ConfirmDialogInterface {
  message: string;
  title: string;
  confirmText: string;
  canceltext: string;
  success: any;
  close: any;
}



