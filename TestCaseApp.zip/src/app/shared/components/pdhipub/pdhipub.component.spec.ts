import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { NO_ERRORS_SCHEMA } from '@angular/compiler';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { LovDataService } from 'src/app/services/lov-data.service';

import { PdhipubComponent } from './pdhipub.component';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule } from '@angular/forms';
import { ToastrModule } from 'ngx-toastr';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AllmatcompModule } from 'src/app/allmatcomp.module';

describe('PdhipubComponent', () => {
  let component: PdhipubComponent;
  let fixture: ComponentFixture<PdhipubComponent>;
  let matDialogService: jasmine.SpyObj<MatDialog>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports:[RouterTestingModule, MatDialogModule, FormsModule, ToastrModule.forRoot(),
        BrowserAnimationsModule, AllmatcompModule, HttpClientTestingModule],
      declarations: [ PdhipubComponent ],
      providers:[HttpClient, HttpHandler, LovDataService,
        {
          provide: MatDialog,
          useValue: matDialogService,
        }],
      schemas:[NO_ERRORS_SCHEMA],
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PdhipubComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
