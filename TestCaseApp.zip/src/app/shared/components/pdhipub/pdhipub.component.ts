import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {
  associatedDetails,
  associatedSummary,
  chkInterface,
  lovInterface,
} from 'src/app/models/common.model';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CommonService } from 'src/app/services/common.service';
import { LovDataService } from 'src/app/services/lov-data.service';
import { NotificationService } from 'src/app/services/notification.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { APP_Messages } from 'src/app/models/app-defaults';

@Component({
  selector: 'app-pdhipub',
  templateUrl: './pdhipub.component.html',
  styleUrls: ['./pdhipub.component.scss'],
})
export class PdhipubComponent implements OnInit {
  @Input('title') title: string = '';
  // @Output() disabledPDHField = new EventEmitter<boolean>(true);
  @Output() disabledDetailsField = new EventEmitter<boolean>(true);
  @Output() validationFlag = new EventEmitter<boolean>(false);
  @Output() assocDet = new EventEmitter<associatedDetails>();

  assocSummary = new associatedSummary();
  assocDetails = new associatedDetails();

  maxLengthofControls = {
    mhidMaxLength: 15,
    ISBN13MaxLength: 50,
    PREVIOUS_ISBNMaxLength: 15,
    NEW_ISBNMaxLength: 15,
    authorMaxLength: 240,
    titleMaxLength: 1500,
    editionMaxLength: 22,
    publicationstatusMaxLength: 16,
    ODDMaxLength: 150,
    SDDMaxLength: 150,
    copyYearMaxLength: 22,
    boundBookDateMaxLength: 7,
    permissionEndDateMaxLength: 7,
    projectOPdateMaxLength: 7,
    deliveryFormatMaxLength: 150,
    titleTypeMaxLength: 240,
    gradeRangeMaxLength: 5,
    specificMarketMaxLength: 150,
    iPubPublishingGroupMaxLength: 20,
    iPubProgramTitleMaxLength: 500,
    pageCountMaxLength: 22,
    archiveNotesMaxLength: 4000,
    requestedByMaxLength: 100,
    printingMaxLength: 22,
    statusNotesMaxLength: 4000,
    productTitleMaxLength: 500,
    downloadReceivedMaxLength: 7,
    dateArchivedMaxLength: 7,
    libraryLocationMaxLength: 500,
    compVendorOtherMaxLength: 22,
    reprintContactOtherMaxLength: 22,
    pagingLengthOthMaxLength: 30,
    othFilesOthMaxLength: 30,
  };

  showCompVendor: boolean = false;

  searchedMHID!: string;
  searchedISBN!: string;
  isLoading: boolean = false;
  url: string = 'services/associatedRecords/';
  private headers = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
    }),
  };

  pagingFilesOther: string = '';
  otherFilesOther: string = '';
  reprintContactOther: string = '';
  compVendorOther: string = '';

  userName: string = '';
  message: string = '';
  commnetsRows = 5;
  libLocRows = 2;
  notesRows = 8;
  archiveNotesRows = 8;
  repcommnetsRows = 2;
  showReprintInput: boolean = false;

  archivistArray: lovInterface[] = [];
  actualArchivistArray: lovInterface[] = [];
  compVendorArray: lovInterface[] = [];
  locationArray: lovInterface[] = [];
  reprintContactArray: lovInterface[] = [];

  pagingFilesArray: chkInterface[] = [];
  otherFilesArray: chkInterface[] = [];
  PDFsArray: chkInterface[] = [];

  disabledPDHField: boolean = true;

  constructor(
    private cs: CommonService,
    private http: HttpClient,
    private lovData: LovDataService,
    private notify: NotificationService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {}

  async searchByTab(
    input: string,
    filterTyle: string,
    urlSearch: boolean = false
  ) {
    let dbCall: Observable<Object>;
    this.isLoading = true;

    if (
      input == this.searchedMHID ||
      input == this.searchedISBN ||
      input.trim().length < 1
    ) {
      this.isLoading = false;
      return false;
    }

    if (this.searchedMHID?.length > 1 && this.searchedISBN?.length > 1) {
      const chkData = JSON.parse(localStorage.getItem('oData') || '{}');
      const dataComparisonFlag: boolean = await this.cs.adjustData(
        chkData,
        this.assocDetails,
        this.assocSummary
      );
      if (!dataComparisonFlag) {
        const t = await this.cs.showModalConfirmation();
        if (!t) {
          this.assocSummary.mhid = this.searchedMHID;
          this.assocSummary.isbn13 = this.searchedISBN;
          this.isLoading = false;
          return false;
        }
      }
      this.assocSummary.mhid = this.searchedMHID;
      this.assocSummary.isbn13 = this.searchedISBN;
    }

    if (filterTyle == 'mhid' && input) {
      const url = this.url + '/mhId/' + input;
      dbCall = this.http.get(url, this.headers);
    } else if (filterTyle == 'isbn' && input) {
      const url = this.url + '/isbn13/' + input;
      dbCall = this.http.get(url, this.headers);
    } else if (filterTyle == 'assocId' && input) {
      const url = this.url + '/associatedId/' + input;
      dbCall = this.http.get(url, this.headers);
    } else {
      this.isLoading = false;
      return false;
    }
    dbCall = this.http.get('../../assets/localData/associated.data.json');

    dbCall.subscribe(
      (responseData: any) => {
        console.log(responseData);
        this.compVendorOther = '';
        this.reprintContactOther = '';
        this.pagingFilesOther = '';
        this.otherFilesOther = '';

        if (responseData['data'] && responseData['succeeded']) {
          this.resetArchiveModel();
          this.fillFormSubscription(responseData['data'], urlSearch);
        } else {
          this.resetArchiveModel();
          this.resetDrpLists();
          this.disabledDetailsField.emit(true); // = true;
          this.validationFlag.emit(false);
          this.notify.showSuccess('', responseData['message']);
        }
        this.isLoading = false;
      },
      (err) => {
        this.disabledDetailsField.emit(true); // = true;
        this.isLoading = false;
        this.validationFlag.emit(false);
        this.notify.showSuccess('', APP_Messages.ServerErrorMessage);
      }
    );

    this.isLoading = false;

    return true;
  }

  fillFormSubscription(data: any, urlSearch: boolean = false) {
    this.assocSummary = data['summary'] as associatedSummary;
    if (urlSearch) {
      this.resetDetails();
    } else {
      if (data['details']) {
        this.assocDet.emit(data['details'] as associatedDetails);
        this.assocDetails = data['details'] as associatedDetails;
        this.disablePDHControls();
        this.setArchivest();
        this.setCompVendor();
        this.setLocation();
        this.setReprintContact();
        this.setPaggingFiles();
        this.setOtherFiles();
        this.setPDFLists();
      } else {
        this.resetDetails();
      }
    }
    this.adjustRecordId();
    this.searchedMHID = this.assocSummary.mhid;
    this.searchedISBN = this.assocSummary.isbn13;
    this.disabledDetailsField.emit(false); // = false;
    this.validationFlag.emit(true);

    if (data['details']) {
      localStorage.setItem(
        'oData',
        JSON.stringify({
          summary: this.assocSummary,
          details: this.assocDetails,
        })
      );
    } else {
      localStorage.setItem(
        'oData',
        JSON.stringify({ summary: this.assocSummary })
      );
    }
  }

  adjustRecordId() {
    if (
      this.assocDetails.recordid == 0 ||
      this.assocDetails.recordid == null ||
      this.assocDetails.recordid == undefined
    ) {
      this.assocDetails.recordid = this.assocSummary.recordid;
    }
  }

  private resetDrpLists() {
    this.setArchivest();
    this.setCompVendor();
    this.setLocation();
    this.setReprintContact();
  }

  private resetArchiveModel() {
    this.assocSummary = new associatedSummary();
    this.resetDetails();
    this.resetCheckboxes();
    this.searchedMHID = '';
    this.searchedISBN = '';
  }

  private resetCheckboxes() {
    this.pagingFilesArray.forEach((v: chkInterface) => {
      v.checked = false;
      v.enabled = 'Y';
    });
    this.otherFilesArray.forEach((v) => {
      v.checked = false;
      v.enabled = 'Y';
    });
    this.PDFsArray.forEach((v) => {
      v.checked = false;
      v.enabled = 'Y';
    });
  }

  private disablePDHControls() {
    this.disabledPDHField = true;
    // this.disabledPDHField.emit(true);
  }

  private resetDetails() {
    const emptyDetails = {
      productTitle: '',
      archivist: '',
      compositorVendor: '',
      downloadReceivedDate: '',
      archivedDate: '',
      storageLocation: '',
      libraryLocation: '',
      printingVersion: 0,
      reprintContact: '',
      pagingFilesList: [],
      otherFilesList: [],
      pdfsList: [],
      associatedid: 0,
      recordid: 0,
      productNotes: '',
      createdDate: '',
      createdBy: '',
      modifiedDate: '',
      modifiedBy: '',
    };
    this.assocDetails = emptyDetails;
    this.assocDet.emit(emptyDetails)
    this.compVendorChange('');
  }
  compVendorChange(selectedValue: any) {
    let cdata: any;
    if (selectedValue.currentTarget) {
      cdata = selectedValue.currentTarget.options[
        selectedValue.currentTarget.selectedIndex
      ].text
        .trim()
        .toLocaleLowerCase();
    } else {
      cdata = selectedValue;
    }

    this.showCompVendor = cdata.trim().toLowerCase() == 'other' ? true : false;
  }

  private setCompVendor() {
    if (this.assocDetails && this.assocDetails.compositorVendor) {
      const dbData: string = this.assocDetails.compositorVendor.description;
      for (const keys in this.compVendorArray) {
        if (dbData == this.compVendorArray[keys].description) {
          if (dbData.trim().toLowerCase() === 'other') {
            this.compVendorOther =
              this.assocDetails.compositorVendor.otherValue.trim();
          } else {
            this.compVendorOther = '';
          }
          this.assocDetails.compositorVendor = this.compVendorArray[keys].lovid;
          this.compVendorChange(dbData);
        }
      }
    } else {
      this.assocDetails.compositorVendor = '';
      this.compVendorChange('');
    }
  }

  private setLocation() {
    if (this.assocDetails && this.assocDetails.storageLocation) {
      const dbData: string = this.assocDetails.storageLocation.description;
      for (const keys in this.locationArray) {
        if (dbData == this.locationArray[keys].description) {
          this.assocDetails.storageLocation = this.locationArray[keys].lovid;
        }
      }
    } else {
      this.assocDetails.storageLocation = '';
    }
  }

  private setReprintContact() {
    if (this.assocDetails && this.assocDetails.reprintContact) {
      const dbData: string = this.assocDetails.reprintContact.description;
      for (const keys in this.reprintContactArray) {
        if (dbData == this.reprintContactArray[keys].description) {
          if (dbData.trim().toLowerCase() === 'other') {
            this.reprintContactOther =
              this.assocDetails.reprintContact.otherValue.trim();
          } else {
            this.reprintContactOther = '';
          }
          this.assocDetails.reprintContact =
            this.reprintContactArray[keys].lovid;
          this.reprintValueChange(dbData);
        }
      }
    } else {
      this.assocDetails.reprintContact = '';
      this.reprintValueChange('');
    }
  }

  private setPaggingFiles() {
    if (this.assocDetails && this.assocDetails.pagingFilesList) {
      let noneChecked = this.assocDetails.pagingFilesList.filter(
        (values: { description: string }) => {
          if (values.description == 'None') {
            this.pagingFilesArray.filter((arrayValues) => {
              if (arrayValues.description == 'None') {
                arrayValues.enabled = 'Y';
                arrayValues.checked = true;
              } else {
                arrayValues.enabled = 'N';
              }
            });
          }
          return values.description == 'None';
        }
      )[0];

      if (noneChecked) {
        this.pagingFilesOther = '';
        return false;
      }

      this.pagingFilesArray.forEach((arrData) => {
        this.assocDetails.pagingFilesList.forEach(
          (respData: { description: string; otherValue: string }) => {
            if (
              arrData.description?.trim().toLowerCase() ==
              respData.description.trim().toLowerCase()
            ) {
              if (respData.description.trim().toLowerCase() === 'other') {
                this.pagingFilesOther =
                  respData.otherValue == null
                    ? ' '
                    : respData.otherValue.trim();
              }
              arrData.checked = true;
            }
          }
        );
      });
    }
    return true;
  }

  private setOtherFiles() {
    if (this.assocDetails && this.assocDetails.otherFilesList) {
      let noneChecked = this.assocDetails.otherFilesList.filter(
        (values: { description: string }) => {
          if (values.description == 'None') {
            this.otherFilesArray.filter((arrayValues) => {
              if (arrayValues.description == 'None') {
                arrayValues.enabled = 'Y';
                arrayValues.checked = true;
              } else {
                arrayValues.enabled = 'N';
              }
            });
          }
          return values.description == 'None';
        }
      )[0];

      if (noneChecked) {
        this.otherFilesOther = '';
        return false;
      }

      this.otherFilesArray.forEach((arrData) => {
        this.assocDetails.otherFilesList.forEach(
          (respData: { description: string; otherValue: string }) => {
            if (
              arrData.description?.trim().toLowerCase() ==
              respData.description.trim().toLowerCase()
            ) {
              if (respData.description.trim().toLowerCase() === 'other') {
                this.otherFilesOther =
                  respData.otherValue == null
                    ? ' '
                    : respData.otherValue.trim();
              }
              arrData.checked = true;
            }
          }
        );
      });
    }
    return true;
  }

  private setPDFLists() {
    if (this.assocDetails && this.assocDetails.pdfsList) {
      this.PDFsArray.forEach((arrData) => {
        this.assocDetails.pdfsList.forEach(
          (respData: { description: string }) => {
            if (
              arrData.description?.trim().toLowerCase() ==
              respData.description.trim().toLowerCase()
            ) {
              arrData.checked = true;
            }
          }
        );
      });
    }
  }

  reprintValueChange(selectedValue: any) {
    let cdata: any;
    if (selectedValue.currentTarget) {
      cdata = selectedValue.currentTarget.options[
        selectedValue.currentTarget.selectedIndex
      ].text
        .trim()
        .toLocaleLowerCase();
    } else {
      cdata = selectedValue;
    }
    this.showReprintInput =
      cdata.trim().toLowerCase() == 'other' ? true : false;
  }

  private setArchivest() {
    if (
      this.assocDetails.archivist?.description == null ||
      this.assocDetails.archivist?.description == ''
    ) {
      this.assocDetails.archivist = '';
      return false;
    } else if (
      this.checkExistingArchiviest(this.assocDetails.archivist.description) !=
      true
    ) {
      return false;
    }

    let dbData: string;
    let flag: boolean = false;
    let lvid = this.assocDetails.archivist.lovid;

    if (this.assocDetails.archivist != null) {
      this.archivistArray = this.lovData.returnArchivistLOV();
      dbData = this.assocDetails.archivist['description'];
    }

    this.archivistArray.filter((ary: lovInterface) => {
      if (ary.description == dbData) {
        flag = true;
      }
    });

    if (flag) {
      this.archivistArray.push(this.assocDetails.archivist);
    }

    let lovId = this.archivistArray.filter((arryData) => {
      return arryData.description?.toLowerCase() == dbData.toLowerCase();
    });
    if (lovId.length > 0) {
      lvid = lovId[0].lovid;
    }
    this.assocDetails.archivist = lvid;
    return false;
  }

  checkExistingArchiviest(paramData: string = '') {
    this.archivistArray = this.cs.removePreviousArray(
      this.archivistArray,
      this.actualArchivistArray
    );
    const dataLength = this.archivistArray.filter((arData) => {
      return arData.description?.toLowerCase() === paramData.toLowerCase();
    });
    if (dataLength.length >= 1) {
      this.assocDetails.archivist = dataLength[0].lovid;
      return false;
    } else {
      return true;
    }
  }
}
