import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-record-information',
  templateUrl: './record-information.component.html',
  styleUrls: ['./record-information.component.scss']
})
export class RecordInformationComponent implements OnInit {

  @Input('recInfoData') recInfoData: any = '';
  @Input('uniqueIdTitle') uniqueIdTitle: string ='';


  constructor() { }

  ngOnInit(): void {
  }

}
