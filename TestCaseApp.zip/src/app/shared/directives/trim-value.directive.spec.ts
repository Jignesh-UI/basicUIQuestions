import { TrimValueDirective } from './trim-value.directive';

describe('TrimValueDirective', () => {
  it('should trim the value of an input when hover',()=>{
    let elRefMock = {
      nativeElement: document.createElement('input')
    };
    elRefMock.nativeElement.value="   asdf";
    const dir = new TrimValueDirective(elRefMock);
    dir.applyTrim();

    expect(elRefMock.nativeElement.value).toBe('asdf');
  })
});
