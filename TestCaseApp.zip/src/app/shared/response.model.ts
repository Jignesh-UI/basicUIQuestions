export class HttpResponseModel{
  data?: any[];
  message?: string;
  succeeded?: string;
}
