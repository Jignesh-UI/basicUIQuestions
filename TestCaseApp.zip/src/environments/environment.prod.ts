export const environment = {
  production: true,
  CLIENT_ID: '0oau7jctp9XRVKTge0x7',
  ISSUER: 'https://mhe.okta.com/oauth2/default',
  LOGIN_REDIRECT_URI: 'http://localhost:39090/archivedb',
  oktaEnaled: true,
  baseAPIUrl: 'https://archivedb-api-dev.aef.mh-int.dev/archivedb/'
};
