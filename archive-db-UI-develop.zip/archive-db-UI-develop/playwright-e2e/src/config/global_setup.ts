/* eslint-disable require-jsdoc */
import { chromium, FullConfig } from '@playwright/test';
import { Environment} from '../../tests/environments/environment';
import environment from '../../tests/environments/nonProd/testdata';

 function globalSetup () :Environment {
  var environmentName = process.env.SDLC.trim().toLowerCase() === 'prod' ? 'prod' : 'nonProd';
  const environment = require(`../../tests/environments/${environmentName}/testdata`).default;

  // if (environmentName == 'nonProd')
  // {

    // const browser = await chromium.launch();
    // const page = await browser.newPage();
    // await page.goto('https://mhe.okta.com/');
    // await page.locator('input[name="username"]').click();
    // await page.locator('input[name="username"]').fill('testshubha.puranik@mheducation.com ');
    // await page.locator('input[name="password"]').click();
    // await page.locator('input[name="password"]').fill('Wo2ZK9eQYMkR0cxGeU4McH18');
    // page.waitForTimeout(5000);
    // await Promise.all([
    //   page.waitForNavigation(/*{ url: 'https://mhe.okta.com/app/UserHome' }*/),
    //   page.locator('input:has-text("Sign In")').click()
    // ]);
  
    // const [page1] = await Promise.all([
    //   page.waitForEvent('popup'),
    //   page.waitForNavigation(/*{ url: 'https://archivedbqa.emhe.mhc:39090/#/' }*/),
    //   page.locator('text=DAL Archive Database (QA)').first().click()
    // ]);

    // await page1.locator('input[name="mhid"]').click();

  
    // const [page2] = await Promise.all([
    //   page.waitForEvent('popup'),
    //   page.locator('text=DAL Archive Database (QA)').first().click()
    // ]);

    // await page2.locator('input[name="mhid"]').click();
  // }
  // else{
  //   console.log("Please Setup Prod Data");
  // }
  return environment
}

export default globalSetup;