import { chromium, FullConfig } from '@playwright/test';
import { test, expect, Page } from '@playwright/test';

// eslint-disable-next-line require-jsdoc
async function globalTearDown (config: FullConfig) {
  console.log("Tear Down ******************************Tear Down ")
}

export default globalTearDown;