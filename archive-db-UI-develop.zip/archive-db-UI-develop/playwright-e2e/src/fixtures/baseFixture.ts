import { test as baseTest } from "@playwright/test";
import { ArchiveRecordPage } from "./../page-objects/archive-record-page";
import globalSetup from "../../src/config/global_setup";
import { ArchiveDalMainPage } from "./../page-objects/archive-dal-app";
import { LoginPage } from "./../page-objects/login_page";
import { SearchPage } from "./../page-objects/search_page";
import { AssociatedRecordPage } from "@pages/associated-record-page";
import { NimasRecordPage } from "@pages/nimas-record-page";
import { ArchiveRequestPage } from "@pages/archive-request-page";
import { SavedSearchPage } from "@pages/saved_search";
import { ReportPage } from "@pages/report_page";
import { SavedReportPage } from "@pages/saved_reports";

const environment = globalSetup();

const test = baseTest.extend<{
  loginPage: LoginPage;
  archiveRecordPage: ArchiveRecordPage;
  archiveDalMainPage: ArchiveDalMainPage;
  searchPage: SearchPage;
  associatedMainPage: AssociatedRecordPage;
  nimasRecordPage: NimasRecordPage;
  archiveRequestPage: ArchiveRequestPage;
  savedSearchPage: SavedSearchPage;
  reportPage: ReportPage;
  savedReportPage: SavedReportPage;
}>({
  loginPage: async ({ page }, use) => {
    await use(new LoginPage(page));
  },

  archiveDalMainPage: async ({ page }, use) => {
    await use(new ArchiveDalMainPage(page));
  },
  archiveRecordPage: async ({ page }, use) => {
    await use(new ArchiveRecordPage(page));
  },
  searchPage: async ({ page }, use) => {
    await use(new SearchPage(page));
  },
  associatedMainPage: async ({ page }, use) => {
    await use(new AssociatedRecordPage(page));
  },
  nimasRecordPage: async ({ page }, use) => {
    await use(new NimasRecordPage(page));
  },
  archiveRequestPage: async ({ page }, use) => {
    await use(new ArchiveRequestPage(page))
  },
  savedSearchPage: async ({ page }, use) => {
    await use(new SavedSearchPage(page))
  },
  reportPage: async ({ page }, use) => {
    await use(new ReportPage(page))
  },
  savedReportPage: async ({ page }, use) => {
    await use(new SavedReportPage(page))
  }

});

export default test;
export const expect = test.expect;
