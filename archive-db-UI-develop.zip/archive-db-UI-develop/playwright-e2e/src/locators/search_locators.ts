const search_locators = {
  searchContainer: "class=searchContainer",
  searchCriteria: "text=Search Criteria",
  page_label: "label:has-text('Page')",
  properties_label: "label:has-text('Properties')",
  contains_label: "label:has-text('Contains')",
  value_label: "label:has-text('Value')",
  search_button: "button:has-text('Search')",
  save_search_button: "button:has-text('Save Search')",
  add_property_button: "text=Add Property",
  remove_property_button: "text=Remove Property",
};

export default search_locators;
