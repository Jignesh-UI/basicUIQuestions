import { ArchiveRecordPage } from "./archive-record-page";

import { ArchiveDalMainPage } from "./archive-dal-app";
import { LoginPage } from "./login_page";
import { SearchPage } from "./search_page";
import { Page } from "@playwright/test";
import { AssociatedRecordPage } from "./associated-record-page";
import { NimasRecordPage } from "./nimas-record-page";
import { ArchiveRequestPage } from "./archive-request-page";
import { SavedSearchPage } from "./saved_search";
import { ReportPage } from "./report_page";
import { SavedReportPage } from "./saved_reports";

export class App {
  readonly page: Page;
  readonly archiveRecordPage: ArchiveRecordPage;
  readonly archiveDalMainPage: ArchiveDalMainPage;
  readonly logingPage: LoginPage;
  readonly searchPage: SearchPage;
  readonly associatedRecordPage: AssociatedRecordPage;
  readonly nimasRecordPage: NimasRecordPage;
  readonly archiveRequestPage: ArchiveRequestPage;
  readonly savedSearchPage: SavedSearchPage;
  readonly reportPage: ReportPage;
  readonly savedReportPage: SavedReportPage;

  constructor(page: Page, env: string) {
    this.page = page;
    this.logingPage = new LoginPage(page);
    this.archiveRecordPage = new ArchiveRecordPage(page);
    this.archiveDalMainPage = new ArchiveDalMainPage(page);
    this.searchPage = new SearchPage(page);
    this.associatedRecordPage = new AssociatedRecordPage(page);
    this.nimasRecordPage = new NimasRecordPage(page);
    this.archiveRequestPage = new ArchiveRequestPage(page);
    this.savedSearchPage = new SavedSearchPage(page);
    this.reportPage = new ReportPage(page);
    this.savedReportPage = new SavedReportPage(page);
  }
}
