import { test, expect, Page, Locator } from "@playwright/test";
import archiveDalAppLocators from "@locators/archive-dal-app-locators";

export class ArchiveDalMainPage {
  readonly page: Page;
  readonly archiveRecord: Locator;
  readonly associatedRecord: Locator;
  readonly archiveRequest: Locator;
  readonly nimas: Locator;
  readonly reports: Locator;
  readonly searchPage: Locator;
  readonly savedSearchPage: Locator;
  readonly savedReportPage: Locator;

  constructor(page: Page) {
    this.page = page;
    this.archiveRecord = page.locator(archiveDalAppLocators.archiveRecord);
    this.associatedRecord = page.locator(archiveDalAppLocators.associatedRecord);
    this.archiveRequest = page.locator(archiveDalAppLocators.archiveRequest);
    this.nimas = page.locator(archiveDalAppLocators.nimas);
    this.reports = page.locator(archiveDalAppLocators.reports);
    this.searchPage = page.locator(archiveDalAppLocators.search);
    this.savedSearchPage = page.locator(archiveDalAppLocators.savedSearch);
    this.savedReportPage = page.locator(archiveDalAppLocators.savedReport);
  }
}
