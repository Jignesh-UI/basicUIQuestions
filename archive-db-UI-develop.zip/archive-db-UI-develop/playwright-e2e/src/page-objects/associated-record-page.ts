import { test, expect, Page, Locator } from "@playwright/test";
import associated_record_locators from "@locators/associated_record_locators";


export class AssociatedRecordPage {
    readonly page: Page;
    readonly MHID: Locator;
    readonly ISBN13: Locator;
    readonly priorEditionISBN: Locator;
    readonly nextEditionISBN: Locator;
    readonly authors: Locator;
    readonly marketingTitle: Locator;
    readonly edition: Locator;
    readonly copyrightyear: Locator;

    readonly calculatedBBD: Locator;
    readonly permissionEndDate: Locator;
    readonly projectOPDate: Locator;
    readonly publicationStatus: Locator;
    readonly owningDivision: Locator;
    readonly owningSubDivision: Locator;
    readonly subdivisionDescription: Locator;

    readonly deliveryFormat: Locator;
    readonly titleType: Locator;
    readonly gradeRange: Locator;
    readonly specificMarket: Locator;
    readonly ipubPublishingGroup: Locator;
    readonly ipubProgrammingTitle: Locator;
    readonly pageCount: Locator;
    readonly archiveNotes: Locator;
    readonly addNote: Locator;
    readonly recordId: Locator;

    readonly associatedProductTitle: Locator;
    readonly archivist: Locator;
    readonly compVendor: Locator;
    readonly downloadReceivedDate: Locator;
    readonly dateArchivedDate: Locator;
    readonly location: Locator;
    readonly libraryLocation: Locator;
    readonly printing: Locator;
    readonly reprintContact: Locator;

    readonly pagingFilesInDesign: Locator;
    readonly pagingFilesMSWord: Locator;
    readonly pagingFilesNone: Locator;
    readonly pagingFilesQuark: Locator;
    readonly pagingFilesTex: Locator;
    readonly pagingFilesOther: Locator;
    readonly inputPagingFilesOther: Locator;

    readonly otherFilesAccessibilityFiles: Locator;
    readonly otherFilesCoverDesign: Locator;
    readonly otherFilesImages: Locator;
    readonly otherFilesNone: Locator;
    readonly otherFilesOther: Locator;
    readonly coverDesign: Locator;
    readonly inputOtherFilesOther: Locator;

    // readonly downloadDueDate: Locator;
    readonly associatedNotes: Locator;
    readonly saveAssociatedRecordButton: Locator;
    readonly deleteAssociatedRecordButton: Locator;



    constructor(page: Page) {
        this.page = page;
        this.MHID = page.locator(associated_record_locators.MHID);
        this.ISBN13 = page.locator(associated_record_locators.ISBN13);

        this.priorEditionISBN = page.locator(
            associated_record_locators.priorEditionISBN
        );
        this.nextEditionISBN = page.locator(
            associated_record_locators.nextEditionISBN
        );
        this.ipubPublishingGroup = page.locator(
            associated_record_locators.ipubPublishingGroup
        );
        this.ipubProgrammingTitle = page.locator(
            associated_record_locators.ipubProgrammingTitle
        );
        this.authors = page.locator(associated_record_locators.authors);
        this.marketingTitle = page.locator(associated_record_locators.marketingTitle);
        this.edition = page.locator(associated_record_locators.edition);
        this.copyrightyear = page.locator(associated_record_locators.copyrightyear);
        this.ISBN13 = page.locator(associated_record_locators.ISBN13);
        this.calculatedBBD = page.locator(associated_record_locators.calculatedBBD);
        this.projectOPDate = page.locator(associated_record_locators.projectOPDate);
        this.permissionEndDate = page.locator(
            associated_record_locators.permissionEndDate
        );
        this.publicationStatus = page.locator(
            associated_record_locators.publicationStatus
        );
        this.owningDivision = page.locator(associated_record_locators.owningDivision);
        this.owningSubDivision = page.locator(
            associated_record_locators.owningSubDivision
        );
        this.subdivisionDescription = page.locator(
            associated_record_locators.subdivisionDescription
        );
        this.deliveryFormat = page.locator(associated_record_locators.deliveryFormat);
        this.titleType = page.locator(associated_record_locators.titleType);
        this.gradeRange = page.locator(associated_record_locators.gradeRange);
        this.specificMarket = page.locator(associated_record_locators.specificMarket);
        this.pageCount = page.locator(associated_record_locators.pageCount);
        this.addNote = page.locator(associated_record_locators.addNote);
        this.archiveNotes = page.locator(associated_record_locators.archiveNotes);
        this.recordId = page.locator(associated_record_locators.recordId);
        this.archivist = page.locator(associated_record_locators.archivist);
        this.compVendor = page.locator(associated_record_locators.compVendor);

        this.downloadReceivedDate = page.locator(
            associated_record_locators.downloadReceivedDate
        );
        this.associatedProductTitle = page.locator(
            associated_record_locators.associatedProductTitle
        )
        this.dateArchivedDate = page.locator(
            associated_record_locators.dateArchivedDate
        );
        this.location = page.locator(associated_record_locators.location);
        this.printing = page.locator(associated_record_locators.printing);
        this.reprintContact = page.locator(associated_record_locators.reprintContact);
        this.libraryLocation = page.locator(
            associated_record_locators.libraryLocation
        );
        this.coverDesign = page.locator(associated_record_locators.coverDesign);
        this.otherFilesOther = page.locator(
            associated_record_locators.otherFilesOther
        );
        this.saveAssociatedRecordButton = page.locator( associated_record_locators.saveAssociatedRecordButton );

        this.coverDesign = page.locator(associated_record_locators.coverDesign);
        this.otherFilesOther = page.locator(
            associated_record_locators.otherFilesOther
        );
        this.deleteAssociatedRecordButton = page.locator( associated_record_locators.deleteAssociatedRecordButton);
        this.pagingFilesInDesign = page.locator(
            associated_record_locators.pagingFilesInDesign
        );
        this.pagingFilesMSWord = page.locator(
            associated_record_locators.pagingFilesMSWord
        );
        this.pagingFilesNone = page.locator(
            associated_record_locators.pagingFilesNone
        );
        this.pagingFilesQuark = page.locator(
            associated_record_locators.pagingFilesQuark
        );
        this.pagingFilesTex = page.locator(associated_record_locators.pagingFilesTex);
        this.pagingFilesOther = page.locator(
            associated_record_locators.pagingFilesOther
        );
        this.inputPagingFilesOther = page.locator(
            associated_record_locators.inputPagingFilesOther
        );
        this.inputOtherFilesOther = page.locator(
            associated_record_locators.inputOtherFilesOther
        );
        this.otherFilesCoverDesign = page.locator(
            associated_record_locators.otherFilesCoverDesign
        );
        this.otherFilesAccessibilityFiles = page.locator(
            associated_record_locators.otherFilesAccessibilityFiles
        );
        this.otherFilesImages = page.locator(associated_record_locators.otherFilesImages);
        this.otherFilesNone = page.locator(associated_record_locators.otherFilesNone);
        this.associatedNotes = page.locator(associated_record_locators.associatedNotes);
    }

    async goto(url: string) {
        await this.page.goto(url);
    }

    async enter_MHID(MHIDData: string) {
        expect(await this.MHID.isEditable()).toBeTruthy();
        expect(await this.ISBN13.isEditable()).toBeTruthy();
        await this.MHID.fill(MHIDData);
        await this.page.keyboard.press("Tab");
        expect(await this.MHID.isEditable()).toBeTruthy();
        await this.page.waitForTimeout(1000);
    }

    async enter_ISBN13(ISBN13Data: string) {
        expect(await this.MHID.isEditable()).toBeTruthy();
        expect(await this.ISBN13.isEditable()).toBeTruthy();
        await this.ISBN13.fill(ISBN13Data);
        await this.page.keyboard.press("Tab");
        expect(await this.ISBN13.isEditable()).toBeTruthy();
        await this.page.waitForTimeout(1000);
    }

    async fieldsNotEditable() {
        expect(await this.nextEditionISBN.isDisabled()).toBeTruthy();
        expect(await this.priorEditionISBN.isDisabled()).toBeTruthy();
        expect(await this.authors.isDisabled()).toBeTruthy();
        expect(await this.marketingTitle.isDisabled()).toBeTruthy();
        expect(await this.edition.isDisabled()).toBeTruthy();
        expect(await this.copyrightyear.isDisabled()).toBeTruthy();
        expect(await this.calculatedBBD.isDisabled()).toBeTruthy();
        expect(await this.permissionEndDate.isDisabled()).toBeTruthy();
        expect(await this.projectOPDate.isDisabled()).toBeTruthy();
        expect(await this.publicationStatus.isDisabled()).toBeTruthy();
        expect(await this.owningDivision.isDisabled()).toBeTruthy();
        expect(await this.owningSubDivision.isDisabled()).toBeTruthy();
        expect(await this.subdivisionDescription.isDisabled()).toBeTruthy();
        expect(await this.deliveryFormat.isDisabled()).toBeTruthy();
        expect(await this.titleType.isDisabled()).toBeTruthy();
        expect(await this.gradeRange.isDisabled()).toBeTruthy();
        expect(await this.specificMarket.isDisabled()).toBeTruthy();
        expect(await this.ipubPublishingGroup.isDisabled()).toBeTruthy();
        expect(await this.ipubProgrammingTitle.isDisabled()).toBeTruthy();
        expect(await this.pageCount.isDisabled()).toBeTruthy();
        expect(await this.archiveNotes.isDisabled()).toBeTruthy();
    }

    async fieldsEditable() {
        expect(await this.MHID.isEditable()).toBeTruthy();
        expect(await this.ISBN13.isEditable()).toBeTruthy();
        expect(await this.ipubPublishingGroup.isDisabled()).toBeTruthy();
        expect(await this.ipubProgrammingTitle.isDisabled()).toBeTruthy();
        // expect(await this.addNote.isEnabled()).toBeTruthy();
    }

    async pagingFilesOptionsEditableWhenNoneNotSelected() {
        if (await this.pagingFilesNone.isChecked()) {
            await this.pagingFilesNone.click();
            expect(await this.pagingFilesNone.isEnabled()).toBeTruthy();
            expect(await this.pagingFilesNone.isChecked()).toBeFalsy();
        }
        await this.pagingFilesNone.click();
        expect(await this.pagingFilesNone.isEnabled()).toBeTruthy();
        expect(await this.pagingFilesNone.isChecked()).toBeTruthy();

        expect(await this.pagingFilesTex.isDisabled()).toBeTruthy();
        expect(await this.pagingFilesQuark.isDisabled()).toBeTruthy();
        expect(await this.pagingFilesMSWord.isDisabled()).toBeTruthy();
        expect(await this.pagingFilesOther.isDisabled()).toBeTruthy();
        expect(await this.pagingFilesInDesign.isDisabled()).toBeTruthy();

        await this.pagingFilesNone.click();
        await this.pagingFilesInDesign.click();
        await this.pagingFilesQuark.click();
        await this.pagingFilesMSWord.click();
        await this.pagingFilesTex.click();
        await this.pagingFilesOther.click();
        expect(await this.pagingFilesNone.isEnabled()).toBeTruthy();
        expect(await this.pagingFilesNone.isChecked()).toBeFalsy();
        expect(await this.pagingFilesInDesign.isEditable()).toBeTruthy();
        expect(await this.pagingFilesInDesign.isChecked()).toBeTruthy();
        expect(await this.pagingFilesTex.isEditable()).toBeTruthy();
        expect(await this.pagingFilesTex.isChecked()).toBeTruthy();
        expect(await this.pagingFilesQuark.isEditable()).toBeTruthy();
        expect(await this.pagingFilesQuark.isChecked()).toBeTruthy();
        expect(await this.pagingFilesMSWord.isEditable()).toBeTruthy();
        expect(await this.pagingFilesMSWord.isChecked()).toBeTruthy();
        expect(await this.pagingFilesOther.isChecked()).toBeTruthy();
        expect(await this.pagingFilesOther.isEditable()).toBeTruthy();
        expect(await this.inputPagingFilesOther.isEditable()).toBeTruthy();
    }

    async otherFilesOptionsEditableWhenNoneNotSelected() {
        if (await this.otherFilesNone.isChecked()) {
            await this.otherFilesNone.click();
            expect(await this.otherFilesNone.isEnabled()).toBeTruthy();
            expect(await this.otherFilesNone.isChecked()).toBeFalsy();
        }
        await this.otherFilesNone.click();
        expect(await this.otherFilesNone.isEnabled()).toBeTruthy();
        expect(await this.otherFilesNone.isChecked()).toBeTruthy();
        expect(await this.otherFilesCoverDesign.isDisabled()).toBeTruthy();
        expect(await this.otherFilesImages.isDisabled()).toBeTruthy();
        expect(await this.otherFilesOther.isDisabled()).toBeTruthy();
        await this.otherFilesNone.click();
        await this.otherFilesCoverDesign.click();
        await this.otherFilesImages.click();
        await this.otherFilesOther.click();
        expect(await this.otherFilesNone.isEnabled()).toBeTruthy();
        expect(await this.otherFilesNone.isChecked()).toBeFalsy();
        expect(await this.otherFilesCoverDesign.isEditable()).toBeTruthy();
        expect(await this.otherFilesCoverDesign.isChecked()).toBeTruthy();
        expect(await this.otherFilesImages.isEditable()).toBeTruthy();
        expect(await this.otherFilesImages.isChecked()).toBeTruthy();
        expect(await this.otherFilesOther.isEditable()).toBeTruthy();
        expect(await this.otherFilesOther.isChecked()).toBeTruthy();
        expect(await this.inputOtherFilesOther.isEditable()).toBeTruthy();
    }

    async pageFilesInputEnabledWhenOtherCheckboxSelected() {
        await this.pagingFilesOther.click();
        if (await this.pagingFilesOther.isChecked()) {
            expect(await this.inputPagingFilesOther.isEditable()).toBeTruthy();
        } else {
            await this.pagingFilesOther.dblclick();
            expect(await this.inputPagingFilesOther.isEditable()).toBeTruthy();
        }
    }

    async otherFilesInputEnabledWhenOtherCheckboxSelected() {
        await this.otherFilesOther.click();
        if (await this.otherFilesOther.isChecked()) {
            expect(await this.inputOtherFilesOther.isEditable()).toBeTruthy();
        } else {
            await this.otherFilesOther.dblclick();
            expect(await this.inputOtherFilesOther.isEditable()).toBeTruthy();
        }
    }

    async disabledAssociatedProductNotes() {
        expect(await this.associatedNotes.isDisabled()).toBeTruthy();
    }

    async fillArchiveInformationDownloadDate(dateInput: string) {
        await this.downloadReceivedDate.fill(dateInput);
    }

    async fillAssociatedProductTitle(productVal: string) {
        await this.associatedProductTitle.fill(productVal);
    }

    async disableAssociatedButton() {
        expect(await this.saveAssociatedRecordButton.isDisabled()).toBeTruthy();
    }

    async associatedPageisLoaded(mhid: string) {
        expect(this.MHID.textContent).not.toBeNull();
        expect(this.MHID.textContent).toBe(mhid);
    }

    async saveRequestButtonEnable() {
        await this.associatedProductTitle.fill('test');
        expect(await this.saveAssociatedRecordButton.isDisabled()).toBeFalsy();
        expect(await this.page.getByRole('button', { name: 'Archive Record' }).isDisabled()).toBeFalsy();
    }

    async saveRequestButtonDisable() {
        await this.associatedProductTitle.fill('test');
        expect(await this.saveAssociatedRecordButton.isEnabled()).toBeFalsy();
        expect(await this.page.getByRole('button', { name: 'Archive Record' }).isEnabled()).toBeFalsy()
    }

    async deleteRecord(){
        await this.page.waitForTimeout(3000);
        await this.associatedProductTitle.fill('test test');
        expect(await this.saveAssociatedRecordButton.isDisabled()).toBeFalsy();
        expect(await this.page.getByRole('button', { name: 'Archive Record' }).isDisabled()).toBeFalsy();
        expect(await this.deleteAssociatedRecordButton.isDisabled()).toBeFalsy();
    }

}