import { test, expect, Page, Locator } from "@playwright/test";
import nimas_record_locators from "@locators/nimas_record_locators";


export class NimasRecordPage {
    readonly page: Page;
    readonly MHID: Locator;
    readonly ISBN13: Locator;
    readonly priorEditionISBN: Locator;
    readonly nextEditionISBN: Locator;
    readonly authors: Locator;
    readonly marketingTitle: Locator;
    readonly edition: Locator;
    readonly copyrightyear: Locator;

    readonly calculatedBBD: Locator;
    readonly permissionEndDate: Locator;
    readonly projectOPDate: Locator;
    readonly publicationStatus: Locator;
    readonly owningDivision: Locator;
    readonly owningSubDivision: Locator;
    readonly subdivisionDescription: Locator;

    readonly deliveryFormat: Locator;
    readonly titleType: Locator;
    readonly gradeRange: Locator;
    readonly specificMarket: Locator;
    readonly ipubPublishingGroup: Locator;
    readonly ipubProgrammingTitle: Locator;
    readonly pageCount: Locator;
    readonly archiveNotes: Locator;
    readonly addNote: Locator;
    readonly recordId: Locator;

    readonly archivist: Locator;
    readonly nimasCoordinator: Locator;
    readonly NIMACCertificationReceived: Locator;
    readonly NIMACCertificateNumber: Locator;
    readonly NIMASConversionVendor: Locator;
    readonly FilesSenttoConversionVendor: Locator;
    readonly NIMASConversionVendorOther: Locator;
    readonly NIMASDescriptionVendor: Locator;
    readonly FilesSenttoDescriptionVendor: Locator;
    readonly NIMASDescriptionVendorOther: Locator;
    readonly saveNimasRecordButton: Locator;
    readonly nimasArchiveNotes: Locator;


    constructor(page: Page) {
        this.page = page;
        this.MHID = page.locator(nimas_record_locators.MHID);
        this.ISBN13 = page.locator(nimas_record_locators.ISBN13);
        this.priorEditionISBN = page.locator(nimas_record_locators.priorEditionISBN);
        this.nextEditionISBN = page.locator(nimas_record_locators.nextEditionISBN);
        this.ipubPublishingGroup = page.locator(nimas_record_locators.ipubPublishingGroup);
        this.ipubProgrammingTitle = page.locator(nimas_record_locators.ipubProgrammingTitle);
        this.authors = page.locator(nimas_record_locators.authors);
        this.marketingTitle = page.locator(nimas_record_locators.marketingTitle);
        this.edition = page.locator(nimas_record_locators.edition);
        this.copyrightyear = page.locator(nimas_record_locators.copyrightyear);
        this.ISBN13 = page.locator(nimas_record_locators.ISBN13);
        this.calculatedBBD = page.locator(nimas_record_locators.calculatedBBD);
        this.projectOPDate = page.locator(nimas_record_locators.projectOPDate);
        this.permissionEndDate = page.locator(nimas_record_locators.permissionEndDate);
        this.publicationStatus = page.locator(nimas_record_locators.publicationStatus);
        this.owningDivision = page.locator(nimas_record_locators.owningDivision);
        this.owningSubDivision = page.locator(nimas_record_locators.owningSubDivision);
        this.subdivisionDescription = page.locator(nimas_record_locators.subdivisionDescription);
        this.deliveryFormat = page.locator(nimas_record_locators.deliveryFormat);
        this.titleType = page.locator(nimas_record_locators.titleType);
        this.gradeRange = page.locator(nimas_record_locators.gradeRange);
        this.specificMarket = page.locator(nimas_record_locators.specificMarket);
        this.pageCount = page.locator(nimas_record_locators.pageCount);
        this.addNote = page.locator(nimas_record_locators.addNote);
        this.archiveNotes = page.locator(nimas_record_locators.archiveNotes);

        this.recordId = page.locator(nimas_record_locators.recordId);
        this.archivist = page.locator(nimas_record_locators.archivist);
        this.nimasCoordinator = page.locator(nimas_record_locators.nimasCoordinator);
        this.NIMACCertificationReceived = page.locator(nimas_record_locators.NIMACCertificationReceived);
        this.NIMACCertificateNumber = page.locator(nimas_record_locators.NIMACCertificateNumber);
        this.NIMASConversionVendor = page.locator(nimas_record_locators.NIMASConversionVendor);
        this.FilesSenttoConversionVendor = page.locator(nimas_record_locators.FilesSenttoConversionVendor);
        this.NIMASConversionVendorOther = page.locator(nimas_record_locators.NIMASConversionVendorOther);
        this.NIMASDescriptionVendor = page.locator(nimas_record_locators.NIMASDescriptionVendor);
        this.FilesSenttoDescriptionVendor = page.locator(nimas_record_locators.FilesSenttoDescriptionVendor);
        this.NIMASDescriptionVendorOther = page.locator(nimas_record_locators.NIMASDescriptionVendorOther);
        this.saveNimasRecordButton = page.locator(nimas_record_locators.saveNimasRecordButton);
        this.nimasArchiveNotes = page.locator(nimas_record_locators.nimasArchiveNotes);
    }

    async goto(url: string) {
        await this.page.goto(url);
    }

    async enter_MHID(MHIDData: string) {
        await this.page.waitForTimeout(3000);
        expect(await this.MHID.isEditable()).toBeTruthy();
        expect(await this.ISBN13.isEditable()).toBeTruthy();
        await this.MHID.fill(MHIDData);
        await this.page.keyboard.press("Tab");
        expect(await this.MHID.isEditable()).toBeTruthy();
        await this.page.waitForTimeout(1000);
    }

    async enter_ISBN13(ISBN13Data: string) {
        await this.page.waitForTimeout(3000);
        expect(await this.MHID.isEditable()).toBeTruthy();
        expect(await this.ISBN13.isEditable()).toBeTruthy();
        await this.ISBN13.fill(ISBN13Data);
        await this.page.keyboard.press("Tab");
        expect(await this.ISBN13.isEditable()).toBeTruthy();
        await this.page.waitForTimeout(1000);
    }

    async fieldsNotEditable() {
        expect(await this.nextEditionISBN.isDisabled()).toBeTruthy();
        expect(await this.priorEditionISBN.isDisabled()).toBeTruthy();
        expect(await this.authors.isDisabled()).toBeTruthy();
        expect(await this.marketingTitle.isDisabled()).toBeTruthy();
        expect(await this.edition.isDisabled()).toBeTruthy();
        expect(await this.copyrightyear.isDisabled()).toBeTruthy();
        expect(await this.calculatedBBD.isDisabled()).toBeTruthy();
        expect(await this.permissionEndDate.isDisabled()).toBeTruthy();
        expect(await this.projectOPDate.isDisabled()).toBeTruthy();
        expect(await this.publicationStatus.isDisabled()).toBeTruthy();
        expect(await this.owningDivision.isDisabled()).toBeTruthy();
        expect(await this.owningSubDivision.isDisabled()).toBeTruthy();
        expect(await this.subdivisionDescription.isDisabled()).toBeTruthy();
        expect(await this.deliveryFormat.isDisabled()).toBeTruthy();
        expect(await this.titleType.isDisabled()).toBeTruthy();
        expect(await this.gradeRange.isDisabled()).toBeTruthy();
        expect(await this.specificMarket.isDisabled()).toBeTruthy();
        expect(await this.ipubPublishingGroup.isDisabled()).toBeTruthy();
        expect(await this.ipubProgrammingTitle.isDisabled()).toBeTruthy();
        expect(await this.pageCount.isDisabled()).toBeTruthy();
        expect(await this.archiveNotes.isDisabled()).toBeTruthy();
    }

    async fieldsEditable() {
        await this.page.waitForTimeout(3000);
        expect(await this.MHID.isEditable()).toBeTruthy();
        expect(await this.ISBN13.isEditable()).toBeTruthy();
        expect(await this.archivist.isEditable()).toBeTruthy();
        expect(await this.nimasCoordinator.isEditable()).toBeTruthy();
        expect(await this.NIMACCertificationReceived.isEditable()).toBeTruthy();
        expect(await this.NIMACCertificateNumber.isEditable()).toBeTruthy();
        expect(await this.NIMASConversionVendor.isEditable()).toBeTruthy();
        expect(await this.FilesSenttoConversionVendor.isEditable()).toBeTruthy();
        expect(await this.NIMASDescriptionVendor.isEditable()).toBeTruthy();
        expect(await this.FilesSenttoDescriptionVendor.isEditable()).toBeTruthy();
        expect(await this.saveNimasRecordButton.isEditable()).toBeTruthy();
        await this.page.waitForTimeout(1000);
    }

    async associatedPageisLoaded(mhid: string) {
        expect(this.MHID.textContent).not.toBeNull();
        expect(this.MHID.textContent).toBe(mhid);
    }

    async waitForElementAttached(locator: string): Promise<void> {
        await this.page.waitForSelector(locator);
    }

    async updateNimasRecord() {
        await this.page.waitForTimeout(3000);
        expect(await this.MHID.isEditable()).toBeTruthy();
        expect(await this.NIMACCertificateNumber.isEditable()).toBeTruthy();
        await this.nimasCoordinator.selectOption('10002');
        await this.NIMACCertificateNumber.click();
        await this.NIMACCertificateNumber.fill('test Certificate');
    }

    async disabledAssociatedProductNotes() {
        expect(await this.nimasArchiveNotes.isDisabled()).toBeTruthy();
        await this.page.locator('text=Add Note').nth(1).click();
        await this.page.locator('textarea[name="instruction"]').click();
        await this.page.locator('textarea[name="instruction"]').fill('test');
        await this.page.locator('div[role="document"] button:has-text("Add")').click();
        expect(this.page.locator('textarea[name="instruction"]')).not.toBeNull();
    }

    async disabledAssociatedProductNotesButton() {
        expect(await this.nimasArchiveNotes.isDisabled()).toBeTruthy();
        await this.page.locator('text=Add Note').nth(1).click();
        await this.page.locator('textarea[name="instruction"]').click();
        await this.page.locator('textarea[name="instruction"]').fill('   ');
        expect(await this.page.locator('div[role="document"] button:has-text("Add")').isEditable()).toBeFalsy()
        expect(this.page.locator('textarea[name="instruction"]')).not.toBeNull();
    }

    async fillNimasDetails() {
        await this.page.locator('text=Add Note').nth(1).click();
        await this.page.locator('textarea[name="instruction"]').click();
        await this.page.locator('textarea[name="instruction"]').fill('Test Archive Note');
        await this.page.locator('div[role="document"] button:has-text("Add")').click();
        await this.NIMACCertificateNumber.click();
        await this.NIMACCertificateNumber.fill('test Certificate');
    }

    async checkNimasDetails() {
        await this.nimasCoordinator.selectOption('');
        expect(await this.saveNimasRecordButton.isDisabled()).toBeTruthy();
        await this.NIMACCertificateNumber.click();
        await this.NIMACCertificateNumber.fill('test Certificate');
        await this.nimasCoordinator.selectOption('10002');
        expect(await this.saveNimasRecordButton.isEnabled()).toBeTruthy();
    }

    async saveRequestButtonEnable() {
        await this.nimasCoordinator.selectOption('10002');
        expect(await this.saveNimasRecordButton.isDisabled()).toBeFalsy();
    }

    async saveRequestButtonDisable() {
        await this.nimasCoordinator.selectOption('10002');
        expect(await this.saveNimasRecordButton.isEnabled()).toBeFalsy();
    }

}