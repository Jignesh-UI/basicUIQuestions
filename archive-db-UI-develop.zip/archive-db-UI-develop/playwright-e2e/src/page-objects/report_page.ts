import report_locators from "@locators/report_locators";
import { test, expect, Page, Locator } from "@playwright/test";
import { Report_Data, Report_Data_Params } from "tests/environments/environment";


export class ReportPage {
    readonly page: Page;

    readonly reportContainer: Locator;
    readonly reportCriteria: Locator;
    readonly page_label: Locator;
    readonly properties_label: Locator;
    readonly contains_label: Locator;
    readonly value_label: Locator;
    readonly create_report_button: Locator;
    readonly save_report_button: Locator;
    readonly move_up_button: Locator;
    readonly move_down_button: Locator;
    readonly add_property_button: Locator;
    readonly remove_property_button: Locator;
    readonly availableProperties: Locator;
    readonly addProperties: Locator;
    readonly removeProperties: Locator;
    readonly selectedProperties: Locator;



    constructor(page: Page) {
        this.page = page;
        this.reportContainer = page.locator(report_locators.reportContainer)
        this.reportCriteria = page.locator(report_locators.reportCriteria).first()
        this.page_label = page.locator(report_locators.page_label).first()
        this.properties_label = page.locator(report_locators.properties_label).first()
        this.contains_label = page.locator(report_locators.contains_label).first()
        this.value_label = page.locator(report_locators.value_label).first()
        this.create_report_button = page.locator(report_locators.create_report_button)
        this.save_report_button = page.locator(report_locators.save_report_button)
        this.move_up_button = page.locator(report_locators.move_up_button)
        this.move_down_button = page.locator(report_locators.move_down_button)
        this.add_property_button = page.locator(report_locators.add_property_button)
        this.remove_property_button = page.locator(report_locators.remove_property_button)
        this.availableProperties = page.locator(report_locators.availableProperties)
        this.addProperties = page.locator(report_locators.addProperties)
        this.removeProperties = page.locator(report_locators.removeProperties)
        this.selectedProperties = page.locator(report_locators.selectedProperties)
    }

    async goto(baseURL: string) {
        await this.page.goto(baseURL);
    }

    async searchContainerSection() {
        expect(await this.reportCriteria.isVisible()).toBeTruthy();
        // expect(await this.save_search_button.isEnabled()).toBeTruthy();
        // expect(await this.add_property_button.isEnabled()).toBeTruthy();
        // expect(await this.remove_property_button.isHidden()).toBeTruthy();
        expect(await this.page.locator("div:nth-child(1) > div:nth-child(1) > .form-control").inputValue() === '-1').toBeTruthy();
        expect(await this.page.locator("div:nth-child(1) > div:nth-child(2) > .form-control").inputValue() === '').toBeTruthy();
        expect(await this.page.locator("div:nth-child(1) > div:nth-child(3) > .form-control").inputValue() === '').toBeTruthy();
        expect(await this.page.locator("div:nth-child(1) > div:nth-child(4) > .form-control").inputValue() === '').toBeTruthy();
    }

    async fieldsVisible() {
        await this.page.waitForTimeout(3000);
        expect(await this.reportCriteria.isVisible()).toBeTruthy();
        // expect(await this.reportContainer.isVisible()).toBeTruthy();
        expect(await this.page_label.isVisible()).toBeTruthy();
        expect(await this.properties_label.isVisible()).toBeTruthy();
        expect(await this.contains_label.isVisible()).toBeTruthy();
        expect(await this.value_label.isVisible()).toBeTruthy();
        expect(await this.create_report_button.isVisible()).toBeTruthy();
        expect(await this.save_report_button.isVisible()).toBeTruthy();
        expect(await this.move_up_button.isVisible()).toBeTruthy();
        expect(await this.move_down_button.isVisible()).toBeTruthy();
        expect(await this.add_property_button.nth(0).isVisible()).toBeTruthy();
        // expect(await this.remove_property_button.isVisible()).toBeTruthy();
        expect(await this.availableProperties.isVisible()).toBeTruthy();
        expect(await this.addProperties.isVisible()).toBeTruthy();
        expect(await this.removeProperties.isVisible()).toBeTruthy();
        expect(await this.selectedProperties.isVisible()).toBeTruthy();
        expect(await this.move_up_button.isDisabled()).toBeTruthy();
        expect(await this.move_down_button.isDisabled()).toBeTruthy();
        expect(await this.addProperties.isDisabled()).toBeTruthy();
        expect(await this.removeProperties.isDisabled()).toBeTruthy();
    }

    async downloadFileMethod() {
        const fs = require('fs');
        const [download] = await Promise.all([
            this.page.waitForEvent('download'),
            await this.create_report_button.click()
        ]);

        const suggestedFileName = download.suggestedFilename();
        const filePath = 'C:/test/' + suggestedFileName
        await download.saveAs(filePath);
        expect(fs.existsSync(filePath)).toBeTruthy()
    }

    async fillFieldValues(rpt_data: Report_Data_Params[], lengthRec: number = 0) {
        const dataLength = lengthRec == 0 ? rpt_data.length : lengthRec;
        for (let i = 0; i < dataLength; i++) {
            await this.page.locator(".reportsContainer > .adjustment:nth-child(" + (i + 2) + ") > div:nth-child(1) > .form-control").selectOption({ label: rpt_data[i].search_page_type });
            await this.page.locator(".reportsContainer > .adjustment:nth-child(" + (i + 2) + ") > div:nth-child(2) > .form-control").selectOption({ label: rpt_data[i].properties });
            await this.page.locator(".reportsContainer > .adjustment:nth-child(" + (i + 2) + ") > div:nth-child(3) > .form-control").selectOption({ label: rpt_data[i].contains });
            await this.page.locator(".reportsContainer > .adjustment:nth-child(" + (i + 2) + ") > div:nth-child(4) > .form-control").fill(rpt_data[i].value);
            if (i < dataLength - 1) {
                await this.add_property_button.nth(0).click();
            }
        }
        await this.page.waitForTimeout(3000);
    }

    async loadReportsArchiveRecord() {
        expect(await this.availableProperties.count()).not.toBe(null);
        await this.availableProperties.selectOption([{ label: 'MHID' }, { label: 'ISBN-13' }, { label: 'Author(s)' }, { label: 'Copyright Year' }, { label: 'Delivery Format' }, { label: 'Edition' }]);
        await this.addProperties.click();
        await this.page.waitForTimeout(3000);
        await this.downloadFileMethod();
    }

    async addReportPropertiesRequest() {
        expect(await this.availableProperties.count()).not.toBe(null);
        await this.availableProperties.selectOption([{ label: 'Task ID' }, { label: 'MHID' }, { label: 'ISBN-13' }, { label: 'Author(s)' }, { label: 'Copyright Year' }, { label: 'Delivery Format' }, { label: 'Edition' }]);
        await this.addProperties.click();
        await this.downloadFileMethod();
    }

    async addAdditionalParam(reqData: Report_Data_Params) {
        await this.add_property_button.nth(0).click();
        await this.page.locator(".reportsContainer > .adjustment:nth-child(3) > div:nth-child(1) > .form-control").selectOption({ label: reqData.search_page_type });
        await this.page.locator(".reportsContainer > .adjustment:nth-child(3) > div:nth-child(2) > .form-control").selectOption({ label: reqData.properties });
        await this.page.locator(".reportsContainer > .adjustment:nth-child(3) > div:nth-child(3) > .form-control").selectOption({ label: reqData.contains });
        await this.page.locator(".reportsContainer > .adjustment:nth-child(3) > div:nth-child(4) > .form-control").fill(reqData.value);
        await this.availableProperties.selectOption([{ label: 'Owning Division' }]);
        await this.addProperties.click();
        await this.downloadFileMethod();
        await this.remove_property_button.nth(0).click();
        await this.downloadFileMethod();
    }

    async addQueryWithLOV(reqData: Report_Data_Params) {
        await this.add_property_button.nth(0).click();
        await this.page.locator(".reportsContainer > .adjustment:nth-child(3) > div:nth-child(1) > .form-control").selectOption({ label: reqData.search_page_type });
        await this.page.locator(".reportsContainer > .adjustment:nth-child(3) > div:nth-child(2) > .form-control").selectOption({ label: reqData.properties });
        await this.page.locator(".reportsContainer > .adjustment:nth-child(3) > div:nth-child(3) > .form-control").selectOption({ label: reqData.contains });
        await this.page.locator(".reportsContainer > .adjustment:nth-child(3) > div:nth-child(4) > .form-control").selectOption({ label: reqData.value });
        await this.availableProperties.selectOption([{ label: 'Archivist' }]);
        await this.addProperties.click();
        await this.downloadFileMethod();
    }

    async additionalCriteria(rpt_data: Report_Data_Params[]) {
        const dataLength = rpt_data.length;
        await this.add_property_button.nth(0).click();

        for (let i = 0; i < dataLength; i++) {
            await this.page.locator(".reportsContainer > .adjustment:nth-child(" + (i + 4) + ") > div:nth-child(1) > .form-control").selectOption({ label: rpt_data[i].search_page_type });
            await this.page.locator(".reportsContainer > .adjustment:nth-child(" + (i + 4) + ") > div:nth-child(2) > .form-control").selectOption({ label: rpt_data[i].properties });
            await this.page.locator(".reportsContainer > .adjustment:nth-child(" + (i + 4) + ") > div:nth-child(3) > .form-control").selectOption({ label: rpt_data[i].contains });
            if (rpt_data[i].contains != 'Is Not Null' && rpt_data[i].contains != 'Is Null') {
                await this.page.locator(".reportsContainer > .adjustment:nth-child(" + (i + 4) + ") > div:nth-child(4) > .form-control").fill(rpt_data[i].value);
            }
            if (i < dataLength - 1) {
                await this.add_property_button.nth(0).click();
            }
        }
        await this.downloadFileMethod();
    }

    async rptWithIsNull() {
        await this.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(1) > .form-control").selectOption({ label: 'Archive Record' });
        await this.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(2) > .form-control").selectOption({ label: 'Edition' });
        await this.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(3) > .form-control").selectOption({ label: 'Is Null' });
        await this.loadReportsArchiveRecord();
    }

    async rptWithIsNotNull() {
        await this.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(1) > .form-control").selectOption({ label: 'Archive Record' });
        await this.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(2) > .form-control").selectOption({ label: 'Edition' });
        await this.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(3) > .form-control").selectOption({ label: 'Is Not Null' });
        await this.loadReportsArchiveRecord();
    }

    async searchSectionExpcol() {
        await this.page.locator(".arrow").click();
        expect(await this.page.locator(".reportsContainer").nth(1).isVisible()).toBeFalsy();
        await this.page.locator(".arrow").click();
        expect(await this.page.locator(".reportsContainer").nth(1).isVisible()).toBeTruthy();
    }

    async changeAvailableProperties() {
        expect(await this.selectedProperties.textContent()).toBe("");

        await this.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(1) > .form-control").selectOption({ label: 'Archive Record' });
        expect(await this.availableProperties.textContent()).not.toBeNull();

        const fistProperties = await this.availableProperties.textContent();
        await this.availableProperties.selectOption([{ label: 'Archivist' }, { label: 'Delivery Format' }, { label: 'MHID' }, { label: 'Edition' }, { label: 'ISBN-13' }, { label: 'Author(s)' },]);
        await this.addProperties.click();

        await this.selectedProperties.selectOption([{ label: 'Archivist' }]);
        await this.move_up_button.click();
        await this.selectedProperties.selectOption([{ label: 'Delivery Format' }]);
        await this.move_down_button.click();

        await this.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(1) > .form-control").selectOption({ label: 'Archive Request' });
        const secProperties = await this.availableProperties.textContent();

        expect(await this.selectedProperties.textContent()).toBe("");
        expect(await this.availableProperties.textContent()).not.toBeNull();

        expect(fistProperties != secProperties).toBeTruthy();
    }

    async removeSelectedProperties() {
        expect(await this.selectedProperties.textContent()).toBe("");

        await this.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(1) > .form-control").selectOption({ label: 'Archive Record' });
        expect(await this.availableProperties.textContent()).not.toBeNull();

        await this.availableProperties.selectOption([{ label: 'Archivist' }, { label: 'Delivery Format' }, { label: 'MHID' }, { label: 'Edition' }, { label: 'ISBN-13' }, { label: 'Author(s)' },]);
        await this.addProperties.click();

        await this.selectedProperties.selectOption([{ label: 'Archivist' }]);
        await this.move_up_button.click();
        await this.move_up_button.click();
        await this.selectedProperties.selectOption([{ label: 'Delivery Format' }]);
        await this.move_down_button.click();
        await this.selectedProperties.selectOption([{ label: 'Edition' }]);
        await this.remove_property_button.click();

        const aProperties = await this.availableProperties.textContent();
        const sProperties = await this.selectedProperties.textContent();
        expect(sProperties.search("Edition")).toBe(-1);
        expect(aProperties.search("Edition")).not.toBe(-1);
        expect(aProperties.search("Edition")).toBeGreaterThan(0);

        expect(await this.selectedProperties.textContent()).not.toBeNull();
        expect(await this.availableProperties.textContent()).not.toBeNull();
    }

    async clearAllFields() {
        await this.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(1) > .form-control").selectOption({ label: 'Archive Record' });
        await this.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(2) > .form-control").selectOption({ label: 'Edition' });
        await this.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(3) > .form-control").selectOption({ label: 'Contains' });
        await this.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(4) > .form-control").fill("2022");
        await this.availableProperties.selectOption([{ label: 'Archivist' }, { label: 'Delivery Format' }, { label: 'MHID' }, { label: 'Edition' }, { label: 'ISBN-13' }, { label: 'Author(s)' },]);
        await this.addProperties.click();
        await this.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(1) > .form-control").selectOption({ label: 'NIMAS' });
        expect(await this.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(2) > .form-control").inputValue()).toBe('');
        expect(await this.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(3) > .form-control").inputValue()).toBe('');
        expect(await this.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(4) > .form-control").inputValue()).toBe('');
        expect(await this.selectedProperties.textContent()).toBe('');
    }



}