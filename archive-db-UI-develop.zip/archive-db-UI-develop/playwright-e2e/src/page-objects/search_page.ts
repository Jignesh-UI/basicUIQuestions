import { test, expect, Page, Locator } from "@playwright/test";
import search_locators from "@locators/search_locators";
import { Search_Data } from "../../tests/environments/environment";

export class SearchPage {
  readonly searchContainer: Locator;
  readonly searchCriteria: Locator;
  readonly page_label: Locator;
  readonly properties_label: Locator;
  readonly contains_label: Locator;
  readonly value_label: Locator;
  readonly search_button: Locator;
  readonly save_search_button: Locator;
  readonly add_property_button: Locator;
  readonly remove_property_button: Locator;
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
    this.searchContainer = page.locator(search_locators.searchContainer);
    this.searchCriteria = page.locator(search_locators.searchCriteria).first();
    this.page_label = page.locator(search_locators.page_label).first();
    this.properties_label = page.locator(search_locators.properties_label).first();
    this.contains_label = page.locator(search_locators.contains_label).first();
    this.value_label = page.locator(search_locators.value_label).first();
    this.search_button = page.locator(search_locators.search_button).first();
    this.save_search_button = page.locator(search_locators.save_search_button);
    this.add_property_button = page.locator(search_locators.add_property_button);
    this.remove_property_button = page.locator(search_locators.remove_property_button);
  }

  async goto(baseURL: string) {
    await this.page.goto(baseURL);
  }

  async fieldsVisible() {
    await this.page.waitForTimeout(3000)
    expect(await this.searchCriteria.isVisible()).toBeTruthy();
    expect(await this.page_label.isVisible()).toBeTruthy();
    expect(await this.properties_label.isVisible()).toBeTruthy();
    expect(await this.value_label.isVisible()).toBeTruthy();
    expect(await this.contains_label.isVisible()).toBeTruthy();
    expect(await this.save_search_button.isEnabled()).toBeTruthy();
    expect(await this.add_property_button.isEnabled()).toBeTruthy();
    expect(await this.remove_property_button.isHidden()).toBeTruthy();
    // expect(await this.search_button.isEnabled()).toBeTruthy();
  }

  async addAndRemovePropertyButtonValidation() {
    await this.add_property_button.nth(0).click();
    await this.add_property_button.nth(0).click();
    await this.add_property_button.nth(0).click();
    await this.add_property_button.nth(0).click();
    // await this.add_property_button.nth(0).click();

    expect(await this.add_property_button.nth(0).isEnabled()).toBeTruthy();
    expect(await this.add_property_button.nth(1).isEnabled()).toBeTruthy();
    expect(await this.add_property_button.nth(2).isEnabled()).toBeTruthy();
    expect(await this.add_property_button.nth(3).isEnabled()).toBeTruthy();
    expect(await this.add_property_button.nth(4).isEnabled()).toBeTruthy();
    expect(await this.add_property_button.nth(5).isHidden()).toBeTruthy();

    expect(await this.remove_property_button.nth(0).isEnabled()).toBeTruthy();
    expect(await this.remove_property_button.nth(1).isEnabled()).toBeTruthy();
    expect(await this.remove_property_button.nth(2).isEnabled()).toBeTruthy();
    expect(await this.remove_property_button.nth(3).isEnabled()).toBeTruthy();
    expect(await this.remove_property_button.nth(4).isHidden()).toBeTruthy();

    await this.remove_property_button.nth(0).click();
    await this.remove_property_button.nth(0).click();
    await this.remove_property_button.nth(0).click();
    await this.remove_property_button.nth(0).click();

    expect(await this.add_property_button.nth(0).isEnabled()).toBeTruthy();
    expect(await this.remove_property_button.nth(0).isHidden()).toBeTruthy();
  }

  async searchContainerTable(search_data: Search_Data[], data_entries_returned: number) {
    for (let i = 0; i < search_data.length; i++) {
      // console.log("*****", search_data[i].contains);
      await this.page.locator("div:nth-child(" + (i + 1) + ") > div:nth-child(1) > .form-control").selectOption({ label: search_data[i].search_page_type });
      await this.page.locator("div:nth-child(" + (i + 1) + ") > div:nth-child(2) > .form-control").selectOption({ label: search_data[i].properties });
      await this.page.locator("div:nth-child(" + (i + 1) + ") > div:nth-child(3) > .form-control").selectOption({ label: search_data[i].contains });

      // console.log("Value of I right now", i);
      // console.log(search_data[i].value);
      await this.page.locator('input[type="text"]').nth(i + 1).click();
      await this.page.locator('input[type="text"]').nth(i + 1).fill(search_data[i].value);
      await this.page.locator('input[type="text"]').nth(i + 1).press("Tab");

      if (i < search_data.length - 1) {
        // console.log("i", i);
        await this.add_property_button.nth(0).click();
      }
    }

    await this.page.locator('button:has-text("Search")').nth(1).click();
    for (let i = 0; i < data_entries_returned; i++) {
      (await this.page.waitForSelector("td:nth-child(1) > span >> nth=0")).isVisible();
      // console.log("***** td:nth-child(1) > span >> nth=" + i);
      expect(await this.page.locator("td:nth-child(1) > span >> nth=" + i).isVisible()).toBeTruthy();
      const row = this.page.locator("td:nth-child(2) > span >> nth=" + i);
      // console.log("Print " + i);
      expect(await this.page.locator("td:nth-child(2) > span >> nth=" + i).evaluate<string, HTMLTableRowElement>((node) => node.textContent)).toContain(search_data[0].value);
      expect(await this.page.locator("td:nth-child(7) > span >> nth=" + i).evaluate<string, HTMLTableRowElement>((node) => node.textContent)).toContain(search_data[1].value);
    }
    expect(await this.page.locator("td:nth-child(1) > span >> nth=" + data_entries_returned).isHidden()).toBeFalsy();
  }

  async searchContainerSection() {
    expect(await this.searchCriteria.isVisible()).toBeTruthy();
    expect(await this.save_search_button.isEnabled()).toBeTruthy();
    expect(await this.add_property_button.isEnabled()).toBeTruthy();
    expect(await this.remove_property_button.isHidden()).toBeTruthy();
    expect(await this.page.locator("div:nth-child(1) > div:nth-child(1) > .form-control").inputValue() === '-1').toBeTruthy();
    expect(await this.page.locator("div:nth-child(1) > div:nth-child(2) > .form-control").inputValue() === '').toBeTruthy();
    expect(await this.page.locator("div:nth-child(1) > div:nth-child(3) > .form-control").inputValue() === '').toBeTruthy();
    expect(await this.page.locator("div:nth-child(1) > div:nth-child(4) > .form-control").inputValue() === '').toBeTruthy();
  }

  async searchWithAR(search_data: Search_Data[]) {
    await this.page.locator("div:nth-child(1) > div:nth-child(1) > .form-control").selectOption({ label: search_data[0].search_page_type });
    await this.page.locator("div:nth-child(1) > div:nth-child(2) > .form-control").selectOption({ label: search_data[0].properties });
    await this.page.locator("div:nth-child(1) > div:nth-child(3) > .form-control").selectOption({ label: search_data[0].contains });

    await this.page.locator('input[type="text"]').nth(1).click();
    await this.page.locator('input[type="text"]').nth(1).fill(search_data[0].value);
    await this.page.locator('input[type="text"]').nth(1).press("Tab");
    await this.page.locator('button:has-text("Search")').nth(1).click();
    await this.page.waitForTimeout(3000);
    await (await this.page.waitForSelector("td:nth-child(1) > span >> nth=0")).isVisible();
    expect(await (this.page.locator("td:nth-child(1) > span >> nth=0")).isVisible()).toBeTruthy();
    expect(await (this.page.locator("td:nth-child(1) > span >> nth=1")).isVisible()).toBeTruthy();
  }

  async searchWithARWithProperty(search_data: Search_Data[]) {

    await this.page.locator("div:nth-child(1) > div:nth-child(1) > .form-control").selectOption({ label: search_data[0].search_page_type });
    await this.page.locator("div:nth-child(1) > div:nth-child(2) > .form-control").selectOption({ label: search_data[0].properties });
    await this.page.locator("div:nth-child(1) > div:nth-child(3) > .form-control").selectOption({ label: search_data[0].contains });
    await this.page.locator('input[type="text"]').nth(1).fill(search_data[0].value);

    await this.page.locator('button:has-text("Search")').nth(1).click();
    await this.page.waitForSelector(".dataTable > tbody > .dataTableRow");
    const lenghtRecords = await this.page.locator(".dataTable > tbody > .dataTableRow").count();
    expect(lenghtRecords).toBeGreaterThanOrEqual(1);
  }

  async addPropertiestoExistingSearch(search_data: Search_Data[]) {
    await this.add_property_button.nth(0).click();
    (await this.page.waitForSelector("div:nth-child(2) > div:nth-child(1) > .form-control")).isVisible();

    await this.page.locator("div:nth-child(2) > div:nth-child(1) > .form-control").selectOption({ label: search_data[1].search_page_type });
    await this.page.locator("div:nth-child(2) > div:nth-child(2) > .form-control").selectOption({ label: search_data[1].properties });
    await this.page.locator("div:nth-child(2) > div:nth-child(3) > .form-control").selectOption({ label: search_data[1].contains });
    await this.page.locator('input[type="text"]').nth(2).fill("2022");

    await this.page.locator('button:has-text("Search")').nth(1).click();
    (await this.page.waitForSelector("td:nth-child(1) > span >> nth=0")).isVisible();

    await this.page.waitForSelector(".dataTable > tbody > .dataTableRow");
    const lenghtRecords = await this.page.locator(".dataTable > tbody > .dataTableRow").count();
    expect(lenghtRecords).toBeGreaterThanOrEqual(2);

    expect(await (this.page.locator("td:nth-child(1) > span >> nth=0")).isVisible()).toBeTruthy()
    expect(await (this.page.locator("td:nth-child(1) > span >> nth=1")).isVisible()).toBeTruthy()
  }

  async removePropertyfromSearch() {
    await this.page.locator('button:has-text("Remove Property")').click();
    await this.page.locator('button:has-text("Search")').nth(1).click();
    (await this.page.waitForSelector(".dataTable tbody tr:nth-child(3)")).isVisible();
    await this.page.waitForSelector(".dataTable > tbody > .dataTableRow");
    const lenghtRecords = await this.page.locator(".dataTable > tbody > .dataTableRow").count();
    expect(lenghtRecords).not.toBeNull();
    expect(lenghtRecords).toBeGreaterThanOrEqual(4);
  }

  async searchArchivist() {
    await this.page.waitForTimeout(3000);
    await this.page.locator("div:nth-child(1) > div:nth-child(1) > .form-control").selectOption({ label: 'Archive Record' });
    await this.page.locator("div:nth-child(1) > div:nth-child(2) > .form-control").selectOption({ label: 'Archivist' });
    await this.page.locator("div:nth-child(1) > div:nth-child(3) > .form-control").selectOption({ label: 'Equals' });
    await (await this.page.waitForSelector("div:nth-child(1) > div:nth-child(4) > .form-control")).isVisible();
    await this.page.locator("div:nth-child(1) > div:nth-child(4) > .form-control").selectOption({ label: 'Tina Flanagan' });

    await this.page.locator('button:has-text("Search")').nth(1).click();
    await (await this.page.waitForSelector("td:nth-child(1) > span >> nth=0")).isVisible();
    expect(await (this.page.locator("td:nth-child(1) > span >> nth=0")).isVisible()).toBeTruthy();
    expect(await (this.page.locator("td:nth-child(1) > span >> nth=1")).isVisible()).toBeTruthy();
  }

  async adjustCriteria(search_data_request: any) {
    for (let i = 0; i < search_data_request.length; i++) {
      await this.page.locator("div:nth-child(" + (i + 1) + ") > div:nth-child(1) > .form-control").selectOption({ label: search_data_request[i].search_page_type });
      await this.page.locator("div:nth-child(" + (i + 1) + ") > div:nth-child(2) > .form-control").selectOption({ label: search_data_request[i].properties });
      await this.page.locator("div:nth-child(" + (i + 1) + ") > div:nth-child(3) > .form-control").selectOption({ label: search_data_request[i].contains });
      if (search_data_request[i].contains != 'Is Not Null' && search_data_request[i].contains != 'Is Null') {
        await this.page.locator("div:nth-child(" + (i + 1) + ") > div:nth-child(4) > .form-control").fill(search_data_request[i].value);
      }
      if (i < search_data_request.length - 1) {
        await this.add_property_button.nth(0).click();
        (await this.page.waitForSelector("div:nth-child(" + (i + 1) + ") > div:nth-child(1) > .form-control")).isVisible();
      }
    }
  }

  async searchWithMultipleContains() {
    const search_data_request = [{
      search_page_type: 'Archive Record',
      properties: "Copyright Year",
      contains: 'Equals',
      value: "2022",
    }, {
      search_page_type: "AND",
      properties: "Marketing Title",
      contains: 'Starts with',
      value: "t",
    }, {
      search_page_type: "AND",
      properties: "Edition",
      contains: 'Ends with',
      value: "2",
    }, {
      search_page_type: "AND",
      properties: "Marketing Title",
      contains: 'Does not contain',
      value: 'z'
    }, {
      search_page_type: "AND",
      properties: "Edition",
      contains: 'Does not equal',
      value: "2010",
    }];
    await this.adjustCriteria(search_data_request);
    await this.page.locator('button:has-text("Search")').nth(1).click();
    await this.page.waitForSelector(".dataTable > tbody > .dataTableRow");
    const lenghtRecords = await this.page.locator(".dataTable > tbody > .dataTableRow").count();
    expect(lenghtRecords).not.toBeNull();
    expect(lenghtRecords).toBeGreaterThanOrEqual(1);
  }

  async searchWithisNull() {
    const search_data_request = [{
      search_page_type: 'Archive Record',
      properties: "Edition",
      contains: 'Equals',
      value: '2'
    }];
    await this.adjustCriteria(search_data_request);
    await this.page.locator('button:has-text("Search")').nth(1).click();
    const search_data_request2 = [{
      search_page_type: 'Archive Record',
      properties: "Edition",
      contains: 'Is Null',
      value: ''
    }];
    await this.adjustCriteria(search_data_request2);
    await this.page.locator('button:has-text("Search")').nth(1).click();
    // (await this.page.waitForSelector(".paginationBox")).isVisible();
    await this.page.waitForSelector(".dataTable > tbody > .dataTableRow");

    const lenghtRecords = await this.page.locator(".dataTable > tbody > .dataTableRow").count();
    expect(lenghtRecords).not.toBeNull();
    expect(lenghtRecords).toBeGreaterThanOrEqual(50);
  }

  async searchWithisNotNull() {
    const search_data_request = [{
      search_page_type: 'Archive Record',
      properties: "Edition",
      contains: 'Equals',
      value: '2'
    }];
    await this.adjustCriteria(search_data_request);
    await this.page.locator('button:has-text("Search")').nth(1).click();
    const search_data_request2 = [{
      search_page_type: 'Archive Record',
      properties: "Next Edition ISBN",
      contains: 'Is Not Null',
      value: ''
    }];
    await this.adjustCriteria(search_data_request2);
    await this.page.locator('button:has-text("Search")').nth(1).click();
    // (await this.page.waitForSelector(".paginationBox")).isVisible();
    await this.page.waitForSelector(".dataTable > tbody > .dataTableRow");

    const lenghtRecords = await this.page.locator(".dataTable > tbody > .dataTableRow").count();
    expect(lenghtRecords).not.toBeNull();
    expect(lenghtRecords).toBeGreaterThanOrEqual(50);
  }

  async searchSectionExpcol() {
    await this.page.locator(".arrow").click();
    expect(await this.page.locator(".searchContainer").isVisible()).toBeFalsy();
    await this.page.locator(".arrow").click();
    await this.page.waitForSelector(".searchContainer");
    expect(await this.page.locator(".searchContainer").isVisible()).toBeTruthy();
  }

  async searchResultNavigation() {
    await this.searchWithisNull();
    await this.page.waitForSelector(".pagination .page-item");
    expect(await this.page.locator(".dataTable > tbody > .dataTableRow").count()).toBe(50)
    let pageCount = await this.page.locator(".pagination .page-item").count();
    pageCount = pageCount - 2;
    if (pageCount > 2) {
      await this.page.locator(".pagination .page-item").nth(3).click();
      await this.page.waitForSelector(".dataTable > tbody > .dataTableRow");
      const currentPage = await this.page.locator(".pagination .page-item.active").innerText();
      expect(currentPage).toBe("3");
    } else {
      const currentPage = await this.page.locator(".pagination .page-item.active").innerText();
      expect(currentPage).toBe("1");
    }
  }

  async searchResultSortOrder() {
    const search_data_request = [{
      search_page_type: 'Archive Record',
      properties: "Edition",
      contains: 'Equals',
      value: '2'
    }];
    await this.adjustCriteria(search_data_request);
    await this.page.locator('button:has-text("Search")').nth(1).click();

    await this.page.locator(".dataTable .dataTableHRow th:nth-child(4) .titleSpan").click();
    await this.page.waitForTimeout(3000);
    await (await this.page.waitForSelector(".dataTable .dataTableHRow th:nth-child(4) .sortOrder")).isVisible();
    const sortorderPosition = (await this.page.locator(".dataTable .dataTableHRow th:nth-child(4)").innerHTML()).search("sortOrder");
    expect(sortorderPosition).toBeGreaterThan(2);
  }

  async searchResultNavigate(search_data: any) {
    await this.adjustCriteria(search_data);
    await this.page.locator('button:has-text("Search")').nth(1).click();
    await this.page.waitForSelector(".dataTable > tbody > .dataTableRow");
    await (await this.page.waitForSelector('.dataTable tbody .dataTableRow:nth-child(1)')).isVisible();
    await this.page.locator('.dataTable tbody .dataTableRow').nth(1).click();
  }



}
