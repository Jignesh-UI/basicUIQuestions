export interface Environment {
  OKTAURL: string;
  ApplicationURL: string;
  MHID: string;
  MHIDInvalid: string;
  ISBN13: string;
  ISBN13Invalid: string;
  legacyArchiviestMHID:string;
  legacyArchiviestISBN:string;
  selectArchiviest:string;
  search_data: Search_Data[];
  search_data_request: Search_Data[],
  report_data_record: Report_Data_Params[],
  report_data_request: Report_Data_Params[],
  report_additional: Report_Data_Params[],

  expected_archive_data: {
    MHID: string;
    ISBN13: string;
    Prior_Edition: string;
    RecordId: string;
  };

  expected_assoc_data: {
    MHID: string;
    ISBN13: string;
    associatedId: string;
    productTitle: string;
  };

  expected_nimas_data: {
    MHID: string;
    ISBN13: string;
    nimasId: string;
  };

  expected_archive_request_data:{
    MHID: string,
    ISBN13: string,
    Prior_Edition: string,
    TaskId: string,
  };

}

export enum Search_Page_Type {
  "Archive Record" = "Archive Record",
  "Archive Request" = "Archive Request",
  "Associated" = "Associated",
  "NIMAS" = "NIMAS",
}

export type Search_Data = {
  search_page_type: Search_Page_Type | And_Or_Type;
  properties: string;
  contains: Contains;
  value: string;
};

export type Report_Data = {
  search_page_type: Search_Page_Type | And_Or_Type;
  properties: string;
  contains: Contains;
  value: string;
};

export type Report_Data_Params = {
  search_page_type: Search_Page_Type | And_Or_Type;
  properties: string;
  contains: string;
  value: string;
};

export enum And_Or_Type {
  "and" = "AND",
  "or" = "OR",
}

export enum Contains {
  "Contains" = "Contains",
  "Does not contain" = " Does not contain",
  "Does not equal" = " Does not equal",
  "Ends with" = " Ends with",
  "equals" = "Equals",
  "Is Not Null" = " Is Not Null",
  "Is Null" = " Is Null",
  "Starts with" = " Starts with",
}
