import { Environment } from "../environment";
import { Search_Page_Type, And_Or_Type, Contains } from "../environment";

const environment: Environment = {
  OKTAURL: "https://mhe.okta.com",
  ApplicationURL: "https://archivedb-ui-dev.aef.mh-int.dev/",
  MHID: "mhe-qa-test",
  ISBN13: "mhe-qa-test",
  MHIDInvalid: "mhe-qa-test-unknown",
  ISBN13Invalid: "mhe-qa-test-unknown",
  legacyArchiviestMHID: "test-mhid2",
  legacyArchiviestISBN: "test-isbn2",
  selectArchiviest: '1011',
  search_data: [
    {
      search_page_type: Search_Page_Type["Archive Record"],
      properties: "MHID",
      contains: Contains["Contains"],
      value: "11",
    },
    {
      search_page_type: And_Or_Type.and,
      properties: "Copyright Year",
      contains: Contains["equals"],
      value: "2022",
    },
  ],

  search_data_request: [
    {
      search_page_type: Search_Page_Type["Archive Request"],
      properties: "MHID",
      contains: Contains["Contains"],
      value: "11",
    },
    {
      search_page_type: And_Or_Type.and,
      properties: "Copyright Year",
      contains: Contains["equals"],
      value: "2022",
    },
  ],

  expected_archive_data: {
    MHID: "mhe-qa-test",
    ISBN13: "mhe-qa-test",
    Prior_Edition: "mhe-qa-test",
    RecordId: "3036702",
  },
  expected_assoc_data: {
    MHID: "mhe-qa-test",
    ISBN13: "mhe-qa-test",
    associatedId: "3036702",
    productTitle: "Test Product Title QA"
  },
  expected_nimas_data: {
    MHID: "mhe-qa-test",
    ISBN13: "mhe-qa-test",
    nimasId: "3036702"
  },
  expected_archive_request_data: {
    MHID: "mhe-qa-test",
    ISBN13: "mhe-qa-test",
    Prior_Edition: "mhe-qa-test",
    TaskId: "258290",
  },


  report_data_record: [
    {
      search_page_type: Search_Page_Type["Archive Record"],
      properties: "Copyright Year",
      contains: "Equals",
      value: "2022",
    },
    {
      search_page_type: And_Or_Type.and,
      properties: "MHID",
      contains: "Starts with",
      value: "0",
    },
    {
      search_page_type: And_Or_Type.and,
      properties: "Owning Division",
      contains: "Contains",
      value: "College",
    },
  ],

  report_data_request: [
    {
      search_page_type: Search_Page_Type["Archive Request"],
      properties: "Copyright Year",
      contains: "Equals",
      value: "2021",
    },
    {
      search_page_type: And_Or_Type.and,
      properties: "MHID",
      contains: "Starts with",
      value: "0",
    },
    {
      search_page_type: And_Or_Type.and,
      properties: "Owning Division",
      contains: "Contains",
      value: "College",
    }, {
      search_page_type: And_Or_Type.and,
      properties: "Archivist",
      contains: "Equals",
      value: "Tina Flanagan",
    },
  ],

  report_additional: [
    {
      search_page_type: And_Or_Type.and,
      properties: "MHID",
      contains: "Starts with",
      value: "0",
    },
    {
      search_page_type: And_Or_Type.and,
      properties: "Edition",
      contains: "Does not contain",
      value: "10",
    },
    {
      search_page_type: And_Or_Type.and,
      properties: "ISBN-13",
      contains: "Ends with",
      value: "0",
    },
    {
      search_page_type: And_Or_Type.and,
      properties: "Edition",
      contains: "Is Not Null",
      value: "",
    }
  ]


};

export default environment;
