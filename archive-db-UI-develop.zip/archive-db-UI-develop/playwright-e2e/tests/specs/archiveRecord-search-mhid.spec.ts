import { test, expect, Page, chromium } from "@playwright/test";
import globalSetup from "@globalSetup/global_setup";
import { App } from "@pages/app";
const environment = globalSetup();

test.describe("Validate Archive Record by providing MHID", () => {
    let page: Page;

    test.beforeAll(async ({ browser }) => {
        page = await browser.newPage();
        console.log("Before tests");
        const app = new App(page, process.env.SDLC);
        app.logingPage.goto(environment.OKTAURL);
        app.logingPage.logintoOkta(
            process.env.OKTA_USERNAME,
            process.env.OKTA_PASSWORD
        );
        const app1 = new App(await launchApp(), process.env.SDLC);
        await app1.archiveRecordPage.enter_MHID(environment.MHID);
        await app1.page.close();
    });

    test.afterAll(async({browser})=>{
        page = await browser.newPage();
        await page.close();
    });

    async function launchApp(): Promise<Page> {
        const app = new App(page, process.env.SDLC);
        const [page2] = await Promise.all([
            page.waitForEvent("popup"),
            app.logingPage.launchArchiveDALapp(),
        ]);
        return page2;
    }

    test("Validate non editable fields", async () => {
        const app2 = new App(await launchApp(), process.env.SDLC);
        await app2.archiveRecordPage.enter_MHID(environment.MHID);
        await app2.archiveRecordPage.fieldsNotEditable();
    });

    test("Validate editable fields", async () => {
        const app2 = new App(await launchApp(), process.env.SDLC);
        await app2.archiveRecordPage.enter_MHID(environment.MHID);
        await app2.archiveRecordPage.fieldsEditable();
    });

    test("Update the details for archive record that already exists", async () => {
        const page2 = await launchApp();
        const app2 = new App(page2, process.env.SDLC);
        await app2.archiveDalMainPage.archiveRecord.click();
        await app2.archiveRecordPage.enter_MHID(environment.MHID);
        var archiveRecordInformationID: string =
            "text=Record ID: " + environment.expected_archive_data.RecordId;
        await expect(page2.locator(archiveRecordInformationID)).toBeVisible();
    });

    test("Validate confirmation message is displayed when user updates the archive record information.", async () => {
        const page2 = await launchApp();
        const app2 = new App(page2, process.env.SDLC);
        await app2.archiveDalMainPage.archiveRecord.click();
        await app2.archiveRecordPage.enter_MHID(environment.MHID);
        await app2.archiveRecordPage.fillArchiveInformationDownloadDate(
            "2022-05-16"
        );
        await app2.archiveRecordPage.saveArchiveRecordButton.click();
        var archiveRecordMessage: string =
            "text=Record Updated Successfully with Record Id==>" +
            environment.expected_archive_data.RecordId;
        expect(await page2.locator(archiveRecordMessage).isVisible());
        await page2.locator(archiveRecordMessage).click();
        page2.on("dialog", (dialog) => dialog.accept());
        await app2.archiveRecordPage.enter_MHID(environment.MHID);
        await app2.archiveRecordPage.fillArchiveInformationDownloadDate(
            "2022-05-20"
        );
        await app2.archiveRecordPage.saveArchiveRecordButton.click();

        expect(await page2.locator(archiveRecordMessage).isVisible());
        await page2.locator(archiveRecordMessage).click();
        page2.on("dialog", (dialog) => dialog.accept());
    });

    test("Validate Warning message is displayed when user navigates away from screen without saving changes after editing.", async () => {
        const url: String = environment.ApplicationURL + "#/associatedRecord/";
        const page2 = await launchApp();
        const app2 = new App(page2, process.env.SDLC);
        await app2.archiveRecordPage.enter_MHID(environment.MHID);
        await app2.archiveRecordPage.fillArchiveInformationDownloadReceived();
        await app2.archiveDalMainPage.associatedRecord.click();
        await page2.locator("text=RETURN TO PREVIOUS PAGE").click();
        await page2.waitForNavigation(/* { url: ${url} } */),
            page2.on("dialog", (dialog) => dialog.dismiss());
        // Testing the same above scenario second time since there was defect(19320) wherein this worked correctly only on first attempt.
        await app2.archiveDalMainPage.archiveRequest.click();
        await Promise.all([
            page2.waitForNavigation(/* { url: ${url} } */),
            page2.locator("text=RETURN TO PREVIOUS PAGE").click(),
        ]);
        page2.on("dialog", (dialog) => dialog.dismiss());
    });

    test("Validate 'No Data found for the given ID' message is displayed when user provides invalid ID.", async () => {
        const page2 = await launchApp();
        const app2 = new App(page2, process.env.SDLC);
        await app2.archiveRecordPage.enter_MHID(environment.MHIDInvalid);
        await expect(
            page2.locator("text=No Data found for the given ID")
        ).toBeVisible();
        await page2.locator("text=No Data found for the given ID").click();
    });

    test('should add legacy arhivist name in archivist list', async () => {
        const page2 = await launchApp();
        const app2 = new App(page2, process.env.SDLC);
        await app2.archiveRecordPage.enter_MHID(environment.legacyArchiviestMHID);
        expect(await app2.page.locator('select[name="archivist"]').selectOption(environment.selectArchiviest)).toBeTruthy();
    });

    test("Validate checking the None option clears and disables all other options in Paging Files. ", async () => {
        const page2 = await launchApp();
        const app2 = new App(page2, process.env.SDLC);
        await app2.archiveDalMainPage.archiveRecord.click();
        await app2.archiveRecordPage.enter_MHID(environment.MHID);
        await app2.archiveRecordPage.pagingFilesOptionsEditableWhenNoneNotSelected();
    });

    test("Validate checking the None option clears and disables all other options in Other Files. ", async () => {
        const page2 = await launchApp();
        const app2 = new App(page2, process.env.SDLC);
        await app2.archiveDalMainPage.archiveRecord.click();
        await app2.archiveRecordPage.enter_MHID(environment.MHID);
        await app2.archiveRecordPage.otherFilesOptionsEditableWhenNoneNotSelected();
    });

    test("Validate text input field is enabled when other option is selected in Paging Files.", async () => {
        const page2 = await launchApp();
        const app2 = new App(page2, process.env.SDLC);
        await app2.archiveRecordPage.enter_MHID(environment.MHID);
        await app2.archiveRecordPage.pageFilesInputEnabledWhenOtherCheckboxSelected();
    });

    test("Validate text input field is enabled when other option is selected in Other Files. ", async () => {
        const page2 = await launchApp();
        const app2 = new App(page2, process.env.SDLC);
        await app2.archiveRecordPage.enter_MHID(environment.MHID);
        await app2.archiveRecordPage.otherFilesInputEnabledWhenOtherCheckboxSelected();
    });

    test('shoule load archive record with Disabled all the associated records list.', async () => {
        const page2 = await launchApp();
        const app2 = new App(page2, process.env.SDLC);
        await app2.archiveDalMainPage.archiveRecord.click();
        await app2.archiveRecordPage.enter_MHID(environment.MHID);
        await app2.page.waitForTimeout(1000);
        await app2.archiveRecordPage.disabledAssociatedcontrols();
    });

    test('should load archive record on click of view record button click', async () => {
        const page2 = await launchApp();
        const appAr = new App(page2, process.env.SDLC);
        await appAr.archiveDalMainPage.archiveRecord.click();
        await appAr.archiveRecordPage.enter_MHID(environment.MHID);
        await appAr.archiveRecordPage.checkassociatedrecordValue();
    });

    test('should save new associated record loaded from archive request page', async () => {
        const page2 = await launchApp();
        const appAr = new App(page2, process.env.SDLC);
        await appAr.archiveDalMainPage.archiveRecord.click();
        await appAr.archiveRecordPage.enter_MHID(environment.MHID);
        await appAr.archiveRecordPage.clickAddAssocRecord(environment.expected_assoc_data.productTitle);
    });

    test('should load associated record page from view record link and add notes', async () => {
        const page2 = await launchApp();
        const appAr = new App(page2, process.env.SDLC);
        await appAr.archiveDalMainPage.archiveRecord.click();
        await appAr.archiveRecordPage.enter_MHID(environment.MHID);
        await appAr.archiveRecordPage.clickViewProductIcon();
    });

    test('shoule show tooltip on hover of all textboxes', async () => {
        const page2 = await launchApp();
        const app2 = new App(page2, process.env.SDLC);
        await app2.archiveDalMainPage.archiveRecord.click();
        await app2.archiveRecordPage.enter_MHID(environment.MHID);
        await app2.page.locator('input[name="ipubPublishingGroup"]').fill('This is the test.');
        await app2.page.locator('input[name="ipubPublishingGroup"]').hover();
        expect(await app2.page.getByText('This is the test.').isVisible()).toBeTruthy();
    });

    test('should add note once product is loaded and user can add note when click on add note button', async () => {
        const page2 = await launchApp();
        const app2 = new App(page2, process.env.SDLC);
        await app2.archiveDalMainPage.archiveRecord.click();
        await app2.archiveRecordPage.enter_MHID(environment.MHID);
        await app2.archiveRecordPage.checkNotes();
    });

    test('should not select legacy archivist once new archivist is updated.', async () => {
        const page2 = await launchApp();
        const app2 = new App(page2, process.env.SDLC);
        await app2.archiveDalMainPage.archiveRecord.click();
        await app2.archiveRecordPage.enter_MHID(environment.legacyArchiviestMHID);
        await app2.archiveRecordPage.updateLegacyArchivist();
        await app2.archiveRecordPage.saveArchiveRecordButton.click();
        await app2.archiveRecordPage.checkLegacyArchivist();
    });

    test('should enable Save Archive, AddAssociatedRecord Link record button if role policy is not read only.', async () =>{
        const page2 = await launchApp();
        const app2 = new App(page2, process.env.SDLC);
        await app2.archiveDalMainPage.archiveRecord.click();
        await app2.archiveRecordPage.enter_MHID(environment.MHID);
        await app2.archiveRecordPage.saveArchiveRecordButtonEnable();
    });

    test('should disable Save Archive, AddAssociatedRecord Link record button if role policy is read only.', async () =>{
        const page2 = await launchApp();
        const app2 = new App(page2, process.env.SDLC);
        await app2.archiveDalMainPage.archiveRecord.click();
        await app2.archiveRecordPage.enter_MHID('test-mhid3');
        await app2.archiveRecordPage.saveArchiveRecordButtonDisable();
    });

    test("should enable production specialist field after search", async () => {
        const app2 = new App(await launchApp(), process.env.SDLC);
        await app2.archiveRecordPage.enter_MHID(environment.MHID);
        await app2.archiveRecordPage.checkProdSpecialityField();
    });


});
