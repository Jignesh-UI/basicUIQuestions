import { test, expect, Page, chromium } from "@playwright/test";
import { App } from "@pages/app";
import globalSetup from "@globalSetup/global_setup";
const environment = globalSetup();

test.describe("Validate Archive Request by providing MHID", () => {
    let page: Page;


    test.beforeAll(async ({ browser }) => {
        page = await browser.newPage();
        console.log("Before tests");
        const app = new App(page, process.env.SDLC);
        app.logingPage.goto(environment.OKTAURL);
        app.logingPage.logintoOkta(
            process.env.OKTA_USERNAME,
            process.env.OKTA_PASSWORD
        );
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.archiveRequest.click();
        await appPage.archiveRequestPage.enter_MHID(environment.MHID);
        await appPage.page.close();
    });

    test.afterAll(async({browser})=>{
        page = await browser.newPage();
        await page.close();
    });

    async function launchApp(): Promise<Page> {
        const app = new App(page, process.env.SDLC);
        const [page2] = await Promise.all([
            page.waitForEvent("popup"),
            app.logingPage.launchArchiveRequestDALapp(),
        ]);
        return page2;
    }

    test('should open archive request page and disable all fields except few', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.archiveRequest.click();
        await appPage.archiveRequestPage.pageLoadFieldsCheck();
    });

    test("Validate non editable fields", async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.archiveRequest.click();
        await appPage.archiveRequestPage.enter_MHID(environment.MHID);
        await appPage.archiveRequestPage.fieldsNotEditable();
    });

    test("Validate Editable Fields", async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.archiveRequest.click();
        await appPage.archiveRequestPage.enter_MHID(environment.MHID);
        await appPage.archiveRequestPage.fieldsEditable();
    });

    test('should update data on click of Save Record button with confirmation message', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.archiveRequest.click();
        await appPage.archiveRequestPage.enter_MHID(environment.MHID);
        await appPage.archiveRequestPage.updateData();
        await appPage.archiveRequestPage.saveRecordButton.click();
        var assocRecordMessage: string =
            "text=Record Created Successfully with Task Id==>" +
            environment.expected_archive_request_data.TaskId;
        expect(await appPage.page.locator(assocRecordMessage).isVisible());
    });

    test('should clone the record on clicking of "clone" Button', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.archiveRequest.click();
        await appPage.archiveRequestPage.enter_MHID(environment.MHID);
        await appPage.archiveRequestPage.updateData();
        await appPage.archiveRequestPage.cloneButton.click();
        var assocRecordMessage: string =
            "text=Record Created Successfully with Task Id==>" +
            environment.expected_archive_request_data.TaskId;
        expect(await appPage.page.locator(assocRecordMessage).isVisible());
    });

    test('should be clear the page and disable all the non editable fields', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.archiveRequest.click();
        await appPage.archiveRequestPage.enter_MHID(environment.MHID);
        await appPage.archiveRequestPage.updateData();
        await appPage.archiveRequestPage.clearButton.click();
        await Promise.all([
            appPage.page.locator("text=Continue").click(),
        ]);
        appPage.page.on("dialog", (dialog) => dialog.dismiss());
        await appPage.archiveRequestPage.pageLoadFieldsCheck();
    });

    test('should save archive request', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.archiveRequest.click();
        await appPage.archiveRequestPage.enter_MHID(environment.MHID);
        await appPage.archiveRequestPage.checkRequestReceivedDate();
        await appPage.archiveRequestPage.updateData();
        const taskid = appPage.page.locator("text=Task ID:");
        await appPage.archiveRequestPage.saveRecordButton.click();
        await appPage.page.waitForTimeout(3000);
        var assocRecordMessage: string =
            "text=Record Created Successfully with Task Id==>" +
            environment.expected_archive_request_data.TaskId;
        expect(await appPage.page.locator(assocRecordMessage).isVisible());
        expect((await taskid.innerText()).length > 10).toBeTruthy();
    });

    test('should add legacy arhivist name in archivist list', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.archiveRequest.click();
        await appPage.archiveRequestPage.enter_MHID(environment.legacyArchiviestMHID);
        // if throws error, Check provided MHID/ISBN contain legacy Archivist or not.
        if (!await appPage.archiveRequestPage.archivist.selectOption('')) {
            expect(await appPage.archiveRequestPage.archivist.selectOption('')).toBeFalsy();
        }
    });

    test('should not display legacy arhivist in archivist list once record is updated with new archivist', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.archiveRequest.click();
        await appPage.archiveRequestPage.enter_MHID(environment.MHID);
        await appPage.archiveRequestPage.updateData();
        await appPage.archiveRequestPage.updateLegacyArchivist();
        await appPage.archiveRequestPage.saveRecordButton.click();
        await appPage.archiveRequestPage.checkLegacyArchivist();
    });

    test('should save archive request and display record information in bottom', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.archiveRequest.click();
        await appPage.archiveRequestPage.enter_MHID(environment.MHID);
        await appPage.archiveRequestPage.checkRequestReceivedDate();
        await appPage.archiveRequestPage.updateData();
        await appPage.archiveRequestPage.checkRecordInformation();
        const taskid = appPage.page.locator("text=Task ID:");
        const dateCreated = appPage.page.locator("text=Date Created:");
        const createdBy = appPage.page.locator("text=Created By:");
        const dateLastModified = appPage.page.locator("text=Date Last Modified:");
        const lastModifiedBy = appPage.page.locator("text=Last Modified By:");
        const daysTakenToComplete = appPage.page.locator("text=Days Taken To Complete:");

        await appPage.archiveRequestPage.saveRecordButton.click();
        await appPage.page.waitForTimeout(3000);
        var assocRecordMessage: string =
            "text=Record Created Successfully with Task Id==>" +
            environment.expected_archive_request_data.TaskId;

        expect(await appPage.page.locator(assocRecordMessage).isVisible());
        expect((await taskid.innerText()).length > 10).toBeTruthy();
        expect((await dateCreated.innerText()).length > 15).toBeTruthy();
        expect((await createdBy.innerText()).length > 12).toBeTruthy();
        expect((await dateLastModified.innerText()).length > 20).toBeTruthy();
        expect((await lastModifiedBy.innerText()).length > 16).toBeTruthy();
        expect((await daysTakenToComplete.innerText()).length > 22).toBeTruthy();
    });

    test('should display days taken field', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.archiveRequest.click();
        await appPage.archiveRequestPage.enter_MHID(environment.MHID);
        await appPage.archiveRequestPage.updateData();
        await appPage.archiveRequestPage.checkDaysTakenField();
    });

    test('should add archive request status note', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.archiveRequest.click();
        await appPage.archiveRequestPage.enter_MHID(environment.MHID);
        await appPage.archiveRequestPage.addStatusNotes();
    });

    test('should add archive request special instruction note', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.archiveRequest.click();
        await appPage.archiveRequestPage.enter_MHID(environment.MHID);
        await appPage.archiveRequestPage.addInstructionNotes();
    });

    test('should enable Save Record, Clone button if role policy is not read only.', async () =>{
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.archiveRequest.click();
        await appPage.archiveRequestPage.enter_MHID(environment.MHID);
        await appPage.archiveRequestPage.saveRequestButtonEnable();
    });

    test('should disable Save Record, clone button if role policy is read only.', async () =>{
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.archiveRequest.click();
        await appPage.archiveRequestPage.enter_MHID('test-mhid3')
        await appPage.archiveRequestPage.saveRequestButtonDisable();
    });

});