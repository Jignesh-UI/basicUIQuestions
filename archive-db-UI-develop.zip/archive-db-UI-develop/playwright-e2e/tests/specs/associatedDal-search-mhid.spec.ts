import { test, expect, Page, chromium } from "@playwright/test";
import { App } from "@pages/app";
import globalSetup from "@globalSetup/global_setup";
const environment = globalSetup();

test.describe("Validate Associated Record by providing MHID", () => {
    let page: Page;


    test.beforeAll(async ({ browser }) => {
        page = await browser.newPage();
        console.log("Before tests");
        const app = new App(page, process.env.SDLC);
        await app.logingPage.goto(environment.OKTAURL);
        await app.logingPage.logintoOkta(
            process.env.OKTA_USERNAME,
            process.env.OKTA_PASSWORD
        );
        const app1 = new App(await launchApp(), process.env.SDLC);
        await app1.archiveDalMainPage.associatedRecord.click();
        await app1.associatedRecordPage.enter_MHID(environment.MHID);
        // await app1.page.close();
    });

    test.afterAll(async({browser})=>{
        page = await browser.newPage();
        await page.close();
    });

    async function launchApp(): Promise<Page> {
        const app = new App(page, process.env.SDLC);
        const [page2] = await Promise.all([
            page.waitForEvent("popup"),
            await app.logingPage.launchAssociatedDALapp(),
        ]);
        return page2;
    }

    test("Validate non editable fields", async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.associatedRecord.click();
        await appPage.associatedRecordPage.enter_MHID(environment.MHID);
        await appPage.associatedRecordPage.fieldsNotEditable();
    });

    test("Validate Editable Fields", async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.associatedRecord.click();
        await appPage.associatedRecordPage.enter_MHID(environment.MHID);
        await appPage.associatedRecordPage.fieldsEditable();
    });

    test("Validate 'No Data found for the given ID' message is displayed when user provides invalid ID.", async () => {
        const appPage = await launchApp();
        const appInstance = new App(appPage, process.env.SDLC);
        await appInstance.associatedRecordPage.enter_MHID(environment.MHIDInvalid);
        await expect(appPage.locator("text=No Data found for the given ID")).toBeVisible();
        await appPage.locator("text=No Data found for the given ID").click();
    });

    test("Validate checking the None option clears and disables all other options in Paging Files. ", async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.associatedRecord.click();
        await appPage.associatedRecordPage.enter_MHID(environment.MHID);
        await appPage.associatedRecordPage.pagingFilesOptionsEditableWhenNoneNotSelected();
    });

    test("Validate checking the None option clears and disables all other options in Other Files. ", async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.associatedRecord.click();
        await appPage.associatedRecordPage.enter_MHID(environment.MHID);
        await appPage.associatedRecordPage.otherFilesOptionsEditableWhenNoneNotSelected();
    });

    test("Validate text input field is enabled when other option is selected in Paging Files.", async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.associatedRecord.click();
        await appPage.associatedRecordPage.enter_MHID(environment.MHID);
        await appPage.associatedRecordPage.pageFilesInputEnabledWhenOtherCheckboxSelected();
    });

    test("Validate text input field is enabled when other option is selected in Other Files. ", async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.associatedRecord.click();
        await appPage.associatedRecordPage.enter_MHID(environment.MHID);
        await appPage.associatedRecordPage.otherFilesInputEnabledWhenOtherCheckboxSelected();
    });

    test("Disable Associated Product Notes", async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.associatedRecord.click();
        await appPage.associatedRecordPage.enter_MHID(environment.MHID);
        await appPage.associatedRecordPage.disabledAssociatedProductNotes();
    });

    test("should disable 'Save Associated Record' button if 'Associated Product Title' is empty or contains just whitespace", async () => {
        const page2 = await launchApp();
        const app2 = new App(page2, process.env.SDLC);
        await app2.archiveDalMainPage.associatedRecord.click();
        await app2.associatedRecordPage.enter_MHID(environment.MHID);
        await app2.associatedRecordPage.fillAssociatedProductTitle("");
        await app2.associatedRecordPage.disableAssociatedButton();
    });

    test("should save 'Associated Record' if all validation is passed", async () => {
        const page2 = await launchApp();
        const app2 = new App(page2, process.env.SDLC);
        await app2.archiveDalMainPage.associatedRecord.click();
        await app2.associatedRecordPage.enter_MHID(environment.MHID);
        await app2.associatedRecordPage.fillAssociatedProductTitle("test");
        await app2.associatedRecordPage.saveAssociatedRecordButton.click();
        var assocRecordMessage: string =
            "text=Associated Record Updated Successfully for Associated ID==>" +
            environment.expected_assoc_data.associatedId;
        expect(await page2.locator(assocRecordMessage).isVisible());
    });

    test("it should Validate warning message is displayed when user navigates away from screen without saving changes after editing", async () => {
        const page2 = await launchApp();
        const app2 = new App(page2, process.env.SDLC);
        await app2.archiveDalMainPage.associatedRecord.click();
        await app2.associatedRecordPage.enter_MHID(environment.MHID);
        await app2.associatedRecordPage.fillAssociatedProductTitle("test");
        await page2.locator('text=Archive Record (current)').click()

        await page2.locator("text=Return to previous PAGE").click();
        await page2.waitForNavigation(/*{ url: ${environment.ApplicationURL} + '#/archiveRec' }*/),
            page2.on("dialog", (dialog) => dialog.dismiss());
    });

    test("it should Redirect user after clicking Continue from warning message is displayed when user navigates away from screen without saving changes after editing", async () => {
        const page2 = await launchApp();
        const app2 = new App(page2, process.env.SDLC);
        await app2.archiveDalMainPage.associatedRecord.click();
        await app2.associatedRecordPage.enter_MHID(environment.MHID);
        await app2.associatedRecordPage.fillAssociatedProductTitle("test");
        await page2.locator('text=Archive Record (current)').click()

        await page2.locator("text=Continue").click();
        await page2.waitForNavigation(/*{ url:  ${environment.ApplicationURL} + '#/archiveRec' }*/),
            page2.on("dialog", (dialog) => dialog.dismiss());
    });

    test("Validate Warning message is displayed when user navigates away from screen without saving changes after editing.", async () => {
        const page2 = await launchApp();
        const app2 = new App(page2, process.env.SDLC);
        await app2.archiveRecordPage.enter_MHID(environment.MHID);
        await app2.archiveRecordPage.fillArchiveInformationDownloadReceived();
        await app2.archiveDalMainPage.associatedRecord.click();
        await page2.locator("text=RETURN TO PREVIOUS PAGE").click();
        await page2.waitForNavigation(/*{ url:  ${environment.ApplicationURL} + '#/associatedRecord' }*/),
            page2.on("dialog", (dialog) => dialog.dismiss());
        // Testing the same above scenario second time since there was defect(19320) wherein this worked correctly only on first attempt.
        await app2.archiveDalMainPage.archiveRequest.click();
        await Promise.all([
            page2.waitForNavigation(/*{ url:  ${environment.ApplicationURL} + '#/associatedRecord' }*/),
            page2.locator("text=RETURN TO PREVIOUS PAGE").click(),
        ]);
        page2.on("dialog", (dialog) => dialog.dismiss());
    });

    test('should list associated record in the archive record page', async () => {
        const page2 = await launchApp();
        const app2 = new App(page2, process.env.SDLC);
        await app2.archiveDalMainPage.archiveRecord.click();
        await app2.archiveRecordPage.enter_MHID(environment.MHID);
        await app2.archiveRecordPage.searchArchiveRecord(environment.expected_assoc_data.productTitle);
    });

    test('should enable Save Record if role policy is not read only.', async () =>{
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.associatedRecord.click();
        await appPage.associatedRecordPage.enter_MHID(environment.MHID);
        await appPage.associatedRecordPage.saveRequestButtonEnable();
    });

    test('should disable Save Record if role policy is read only.', async () =>{
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.associatedRecord.click();
        await appPage.associatedRecordPage.enter_MHID('test-mhid3');
        await appPage.associatedRecordPage.saveRequestButtonDisable();
    });

    test('should delete associated record on clicking on delete', async () => {
        const page2 = await launchApp();
        const app2 = new App(page2, process.env.SDLC);
        await app2.archiveDalMainPage.associatedRecord.click();
        await app2.associatedRecordPage.enter_MHID(environment.MHID);
        await app2.associatedRecordPage.fillAssociatedProductTitle("test");
        await app2.associatedRecordPage.saveAssociatedRecordButton.click();
        var assocRecordMessage: string =
            "text=Associated Record Updated Successfully for Associated ID==>" +
            environment.expected_assoc_data.associatedId;
        expect(await page2.locator(assocRecordMessage).isVisible());
        app2.page.waitForTimeout(2000);
        await app2.associatedRecordPage.deleteRecord();
        await app2.associatedRecordPage.deleteAssociatedRecordButton.click();

        await Promise.all([
            app2.page.locator("text=Continue").click(),
        ]);
        app2.page.on("dialog", (dialog) => dialog.dismiss());

        app2.page.waitForTimeout(2000);
        var assocDeleteMessage: string = "text=Associated Record deleted Successfully for Associated ID==>11558" + 
            app2.associatedRecordPage.recordId;
        expect(await page2.locator(assocDeleteMessage).isVisible());
    });

});