import { test, Page, expect } from "@playwright/test";
import globalSetup from "@globalSetup/global_setup";
import { App } from "@pages/app";
const environment = globalSetup();

test.describe("Validate Reports Functionality", () => {
    let page: Page;

    test.beforeAll(async ({ browser }) => {
        page = await browser.newPage();
        console.log("Before tests");
        const loginAppInstance = new App(page, process.env.SDLC);
        loginAppInstance.logingPage.goto(environment.OKTAURL);
        loginAppInstance.logingPage.logintoOkta(
            process.env.OKTA_USERNAME,
            process.env.OKTA_PASSWORD
        );
        const reportAppInstance = new App(await launchApp(), process.env.SDLC);
        await reportAppInstance.archiveDalMainPage.reports.first().click();
        await reportAppInstance.page.close();
    });

    test.afterAll(async({browser})=>{
        page = await browser.newPage();
        await page.close();
    });

    async function launchApp(): Promise<Page> {
        const app = new App(page, process.env.SDLC);
        const [page2] = await Promise.all([
            page.waitForEvent("popup"),
            app.logingPage.launchArchiveDALapp(),
        ]);
        return page2;
    }

    test('reports page sould load!', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.reports.first().click();
        await appPage.reportPage.fieldsVisible();
    });

    test('should generate report on archive record!', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.reports.first().click();
        await appPage.reportPage.fillFieldValues(environment.report_data_record);
        await appPage.reportPage.loadReportsArchiveRecord();
    });

    test('should generate report on archive request!', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.reports.first().click();
        await appPage.reportPage.fillFieldValues(environment.report_data_request, 1);
        await appPage.reportPage.addReportPropertiesRequest();
        await appPage.reportPage.addAdditionalParam(environment.report_data_request[2]);
        await appPage.reportPage.addQueryWithLOV(environment.report_data_request[3]);
        await appPage.reportPage.additionalCriteria(environment.report_additional)
    });

    test('should generate report with is NULL Criteria!', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.reports.first().click();
        await appPage.reportPage.rptWithIsNull();
    });

    test('should generate report with is NOT NULL Criteria!', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.reports.first().click();
        await appPage.reportPage.rptWithIsNotNull();
    });

    test('should expand/collapse report section', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.reports.first().click();
        await appPage.reportPage.searchSectionExpcol();
    });

    test('should change available properties on page change!', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.reports.first().click();
        await appPage.reportPage.changeAvailableProperties();
    });

    test('should remove the selected properties', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.reports.first().click();
        await appPage.reportPage.removeSelectedProperties();
    });

    test('should display error message if page is not selected ', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.reports.first().click();
        await Promise.all([
            page.on('dialog', dialog => console.log(dialog.message())),
            await appPage.reportPage.create_report_button.click(),
            expect(appPage.page.locator('text=Please Select Page!')).toBeVisible(),
        ]);
    });


    test('should display error message if Property is not selected ', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.reports.first().click();
        await appPage.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(1) > .form-control").selectOption({ label: 'Archive Record' });
        await Promise.all([
            // page.on('dialog', dialog => console.log(dialog.message())),
            page.on('dialog', dialog => dialog.accept()),
            await appPage.reportPage.create_report_button.click(),
            expect(appPage.page.locator('text=Please Select Property Name!')).toBeVisible(),
        ]);
    });

    test('should display error message if Contains is not selected ', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.reports.first().click();
        await appPage.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(1) > .form-control").selectOption({ label: 'Archive Record' });
        await appPage.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(2) > .form-control").selectOption({ label: 'Edition' });
        await Promise.all([
            // page.on('dialog', dialog => console.log(dialog.message())),
            page.on('dialog', dialog => dialog.accept()),
            await appPage.reportPage.create_report_button.click(),
            expect(appPage.page.locator('text=Please Select Contains!')).toBeVisible(),
        ]);
    });

    test('should display error message if Values is not Entered/Selected ', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.reports.first().click();
        await appPage.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(1) > .form-control").selectOption({ label: 'Archive Record' });
        await appPage.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(2) > .form-control").selectOption({ label: 'Edition' });
        await appPage.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(3) > .form-control").selectOption({ label: 'Contains' });
        await Promise.all([
            // page.on('dialog', dialog => console.log(dialog.message())),
            page.on('dialog', dialog => dialog.accept()),
            await appPage.reportPage.create_report_button.click(),
            expect(appPage.page.locator('text=Please Enter Value!')).toBeVisible(),
        ]);
    });

    test('should display error message if Columns are not Selected ', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.reports.first().click();
        await appPage.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(1) > .form-control").selectOption({ label: 'Archive Record' });
        await appPage.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(2) > .form-control").selectOption({ label: 'Edition' });
        await appPage.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(3) > .form-control").selectOption({ label: 'Contains' });
        await appPage.page.locator(".reportsContainer > .adjustment:nth-child(2) > div:nth-child(4) > .form-control").fill("2022");
        await Promise.all([
            // page.on('dialog', dialog => console.log(dialog.message())),
            page.on('dialog', dialog => dialog.accept()),
            await appPage.reportPage.create_report_button.click(),
            expect(appPage.page.locator('text=Please Select Columns!')).toBeVisible(),
        ]);
    });

    test('should change all selected values if page selection is changed! ', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.reports.first().click();
        await appPage.reportPage.clearAllFields();
    });

})