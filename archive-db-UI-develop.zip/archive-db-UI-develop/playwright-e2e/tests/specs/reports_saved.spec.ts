import { test, expect, Page, chromium } from "@playwright/test";
import globalSetup from "@globalSetup/global_setup";
import { App } from "@pages/app";
import { createPublicKey } from "crypto";
const environment = globalSetup();

test.describe("Validate Saved Report Functionality", () => {
    let page: Page;

    test.beforeAll(async ({ browser }) => {
        page = await browser.newPage();
        console.log("Before tests");
        const app = new App(page, process.env.SDLC);
        app.logingPage.goto(environment.OKTAURL);
        app.logingPage.logintoOkta(
            process.env.OKTA_USERNAME,
            process.env.OKTA_PASSWORD
        );
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.reports.first().hover();
        await appPage.archiveDalMainPage.savedReportPage.click();
        await appPage.page.close();
    });
    
    test.afterAll(async({browser})=>{
        page = await browser.newPage();
        await page.close();
    });

    async function launchApp(): Promise<Page> {
        const app = new App(page, process.env.SDLC);
        const [page2] = await Promise.all([
            page.waitForEvent("popup"),
            app.logingPage.launchArchiveDALapp(),
        ]);
        return page2;
    }

    test('should load saved report page!', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.reports.first().hover();
        await appPage.archiveDalMainPage.savedReportPage.click();
        await appPage.page.waitForTimeout(1000);
        await appPage.savedReportPage.gridVisible();
    });

    test('should save the report with Archive Record!', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.reports.first().click();
        await appPage.savedReportPage.fillFieldValues(environment.report_data_record);
        await appPage.savedReportPage.loadReportsArchiveRecord();
        await appPage.savedReportPage.saveReportWithMessage('Archive Rec SR: CP = 2021, College');
        await appPage.savedReportPage.saveReportWithMessage('Archive Rec SR: CP = 2021, College - V2');
        await appPage.savedReportPage.addAdditionalParam(environment.report_additional[2], 5);
        await appPage.savedReportPage.addAdditionalParam(environment.report_additional[3], 6);
        await appPage.savedReportPage.addAdditionalColumn();
        await appPage.savedReportPage.saveReportWithMessage('Archive Rec Saved Report: V3');
    });

    test('should save the report with Archive Request!', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.reports.first().click();
        await appPage.savedReportPage.fillFieldValues(environment.report_data_request);
        await appPage.savedReportPage.loadReportsArchiveRequest();
        await appPage.savedReportPage.saveReportWithMessage('Archive Req SR: CP = 2021, College');
    });

    test('should validate saved reports are completed with above steps!', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.page.waitForTimeout(3000);
        await appPage.archiveDalMainPage.reports.first().hover();
        await appPage.archiveDalMainPage.savedReportPage.click();
        await appPage.page.waitForTimeout(3000);
        await appPage.savedReportPage.gridVisible();
        const rows = await appPage.page.locator("ag-grid-angular .ag-body-viewport .ag-center-cols-viewport .ag-center-cols-container .ag-row").count()
        expect(rows).not.toBeNull();
        expect(rows).toBeGreaterThan(1);
    });

    test('should download report on clicking of run button!', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.reports.first().hover();
        await appPage.archiveDalMainPage.savedReportPage.click();
        await appPage.page.waitForTimeout(1000);
        await appPage.savedReportPage.gridVisible();
        const rows = await appPage.page.locator("ag-grid-angular .ag-body-viewport .ag-center-cols-viewport .ag-center-cols-container .ag-row").count();
        const flg = rows == 0 ? false : true;
        if (flg) {
            await appPage.savedReportPage.runReport();
            expect(rows).not.toBeNull();
            expect(rows).not.toBe(0);
        } else {
            expect(rows).toBe(0);
        }
    });

    test('should delete report on clicking of delete button!', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.reports.first().hover();
        await appPage.archiveDalMainPage.savedReportPage.click();
        await appPage.page.waitForTimeout(1000);
        await appPage.savedReportPage.gridVisible();
        await appPage.page.waitForTimeout(5000);
        const rows = await appPage.page.locator("ag-grid-angular .ag-body-viewport .ag-center-cols-viewport .ag-center-cols-container .ag-row").count();
        // await appPage.page.pause();
        const flg = rows == 0 ? false : true;
        if (flg) {
            await appPage.savedReportPage.deleteReport(rows);
            expect(rows).not.toBeNull();
            expect(rows).not.toBe(0);
        } else {
            expect(rows).toBe(0);
        }
    });

    test('should create and save reports and download from both page!', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        const rptName = 'Sample Report 2';
        await appPage.archiveDalMainPage.reports.first().click();
        await appPage.savedReportPage.fillFieldValues(environment.report_data_record);
        await appPage.savedReportPage.loadReportsArchiveRecord();
        await appPage.savedReportPage.downloadReport();
        await appPage.savedReportPage.saveReportWithMessage(rptName);

        await appPage.archiveDalMainPage.reports.first().hover();
        await appPage.archiveDalMainPage.savedReportPage.click();
        await appPage.page.waitForTimeout(1000);
        await appPage.savedReportPage.gridVisible();
        await appPage.savedReportPage.downloadSavedReport(rptName);
    });

    test('should not enter more than 100 characters in save report name field!', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        const rptName = 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum.';
        await appPage.archiveDalMainPage.reports.first().click();
        await appPage.savedReportPage.fillFieldValues(environment.report_data_record);
        await appPage.savedReportPage.loadReportsArchiveRecord();
        await appPage.savedReportPage.saveReportWithLongMessage(rptName);
    });

    test('should change the sort order of the column!', async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.reports.first().hover();
        await appPage.archiveDalMainPage.savedReportPage.click();
        await appPage.page.waitForTimeout(1000);
        await appPage.savedReportPage.changeSortOrder();
    });

    test('should delete all saved report ', async()=>{
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.page.waitForTimeout(3000);
        await appPage.archiveDalMainPage.reports.first().hover();
        await appPage.archiveDalMainPage.savedReportPage.click();
        await appPage.page.waitForTimeout(3000);
        await appPage.savedReportPage.deleteAllSavedReport();
      });
});
