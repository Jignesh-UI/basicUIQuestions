import { test, expect, Page, chromium } from "@playwright/test";
import globalSetup from "@globalSetup/global_setup";
import { App } from "@pages/app";
import { createPublicKey } from "crypto";
const environment = globalSetup();

test.describe("Validate Saved Search Functionality", () => {
  let page: Page;

  test.beforeAll(async ({ browser }) => {
    page = await browser.newPage();
    console.log("Before tests");
    const app = new App(page, process.env.SDLC);
    app.logingPage.goto(environment.OKTAURL);
    app.logingPage.logintoOkta(
      process.env.OKTA_USERNAME,
      process.env.OKTA_PASSWORD
    );
    const appPage = new App(await launchApp(), process.env.SDLC);
    await appPage.archiveDalMainPage.searchPage.first().hover();
    await appPage.archiveDalMainPage.savedSearchPage.click();
    await appPage.page.close();
  });

  test.afterAll(async({browser})=>{
      page = await browser.newPage();
      await page.close();
  });

  async function launchApp(): Promise<Page> {
    const app = new App(page, process.env.SDLC);
    const [page2] = await Promise.all([
      page.waitForEvent("popup"),
      app.logingPage.launchArchiveDALapp(),
    ]);
    return page2;
  }

  test('should load saved search page!', async () => {
    const appPage = new App(await launchApp(), process.env.SDLC);
    await appPage.archiveDalMainPage.searchPage.first().hover();
    await appPage.archiveDalMainPage.savedSearchPage.click();
    await appPage.page.waitForTimeout(1000);
    await appPage.savedSearchPage.gridVisible();
  });

  test('should save the search!', async () => {
    const appPage = new App(await launchApp(), process.env.SDLC);
    await appPage.archiveDalMainPage.searchPage.first().click();
    // await appPage.archiveDalMainPage.searchPage.first().hover();
    // await appPage.archiveDalMainPage.savedSearchPage.click();
    await appPage.page.waitForTimeout(1000);
    await appPage.savedSearchPage.searchForReport();
  });

  test('should save the search with additional search criteria!', async () => {
    const appPage = new App(await launchApp(), process.env.SDLC);
    await appPage.archiveDalMainPage.searchPage.first().click();
    await appPage.page.waitForTimeout(1000);
    await appPage.savedSearchPage.additionalSearchCriteria();
  });

  test('should save the search with additional search criteria on archive request!', async () => {
    const appPage = new App(await launchApp(), process.env.SDLC);
    await appPage.archiveDalMainPage.searchPage.first().click();
    await appPage.page.waitForTimeout(1000);
    await appPage.savedSearchPage.searchArchiveRequestReport();
  });

  test('should load saved report on clicking of RUN Button!', async () => {
    const appPage = new App(await launchApp(), process.env.SDLC);
    await appPage.page.waitForTimeout(3000);
    await appPage.archiveDalMainPage.searchPage.first().hover();
    await appPage.archiveDalMainPage.savedSearchPage.click();
    await appPage.page.waitForTimeout(3000);
    await appPage.savedSearchPage.runSavedReport();
  });

  test('should delete saved report on clicking of Delete Button!', async () => {
    const appPage = new App(await launchApp(), process.env.SDLC);
    await appPage.page.waitForTimeout(3000);
    await appPage.archiveDalMainPage.searchPage.first().hover();
    await appPage.archiveDalMainPage.savedSearchPage.click();
    await appPage.page.waitForTimeout(3000);
    await appPage.savedSearchPage.deleteSavedReport();
  });

  test('should delete all saved Search ', async()=>{
    const appPage = new App(await launchApp(), process.env.SDLC);
    await appPage.page.waitForTimeout(3000);
    await appPage.archiveDalMainPage.searchPage.first().hover();
    await appPage.archiveDalMainPage.savedSearchPage.click();
    await appPage.page.waitForTimeout(3000);
    await appPage.savedSearchPage.deleteAllSavedSearches();
  });

});
