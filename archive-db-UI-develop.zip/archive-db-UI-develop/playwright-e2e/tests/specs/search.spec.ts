import { test, expect, Page, chromium } from "@playwright/test";
import globalSetup from "@globalSetup/global_setup";
import { App } from "@pages/app";
import { createPublicKey } from "crypto";
const environment = globalSetup();

test.describe("Validate Search Page", () => {
  let page: Page;

  test.beforeAll(async ({ browser }) => {
    page = await browser.newPage();
    console.log("Before tests");
    const app = new App(page, process.env.SDLC);
    app.logingPage.goto(environment.OKTAURL);
    app.logingPage.logintoOkta(
      process.env.OKTA_USERNAME,
      process.env.OKTA_PASSWORD
    );
    const app1 = new App(await launchApp(), process.env.SDLC);
    await app1.archiveDalMainPage.searchPage.first().click();
    await app1.page.close();
  });

  test.afterAll(async({browser})=>{
      page = await browser.newPage();
      await page.close();
  });

  async function launchApp(): Promise<Page> {
    const app = new App(page, process.env.SDLC);
    const [page2] = await Promise.all([
      page.waitForEvent("popup"),
      app.logingPage.launchArchiveDALapp(),
    ]);
    return page2;
  }

  test('should load search page and search criteria should be visible', async () => {
    const appPage = new App(await launchApp(), process.env.SDLC);
    await appPage.page.waitForTimeout(3000);
    await appPage.archiveDalMainPage.searchPage.first().click();
    await appPage.page.waitForTimeout(3000);
    await appPage.searchPage.searchContainerSection();
  });

  test('should search with archive record', async () => {
    const appPage = new App(await launchApp(), process.env.SDLC);
    await appPage.archiveDalMainPage.searchPage.first().click();
    await appPage.page.waitForTimeout(3000);
    await appPage.searchPage.searchWithAR(environment.search_data);
  });

  test('should search with archive request', async () => {
    const appPage = new App(await launchApp(), process.env.SDLC);
    await appPage.archiveDalMainPage.searchPage.first().click();
    await appPage.page.waitForTimeout(3000);
    await appPage.searchPage.searchWithAR(environment.search_data_request);
  });

  test('should search with archive record with additional properties', async () => {
    const appPage = new App(await launchApp(), process.env.SDLC);
    await appPage.archiveDalMainPage.searchPage.first().click();
    await appPage.page.waitForTimeout(1000);
    await appPage.searchPage.searchWithARWithProperty(environment.search_data);
    await appPage.searchPage.addPropertiestoExistingSearch(environment.search_data);
    await appPage.searchPage.removePropertyfromSearch();
  });

  test("Validate Search Page and Add Remove Property Buttons", async () => {
    const page2 = await launchApp();
    await page2.waitForTimeout(1000);
    const app2 = new App(page2, process.env.SDLC);
    await page2.waitForTimeout(2000);
    await app2.archiveDalMainPage.searchPage.first().click();
    await page2.waitForTimeout(3000);
    // await Promise.all([
    //   page2.waitForNavigation(/*{ url: ${environment.ApplicationURL} + '#/search' }*/),
    // ]);

    await app2.searchPage.fieldsVisible();
    await app2.searchPage.addAndRemovePropertyButtonValidation();
    await app2.searchPage.searchContainerTable(environment.search_data, 2);
  });

  test('should search with archive record with archivist', async () => {
    const appPage = new App(await launchApp(), process.env.SDLC);
    await appPage.archiveDalMainPage.searchPage.first().click();
    await appPage.page.waitForTimeout(3000);
    await appPage.searchPage.searchArchivist();
  });

  test('should search with multiple contains values', async () => {
    const appPage = new App(await launchApp(), process.env.SDLC);
    await appPage.archiveDalMainPage.searchPage.first().click();
    await appPage.page.waitForTimeout(1000);
    await appPage.searchPage.searchWithMultipleContains();
  });

  test('should search with IS NULL contains values', async () => {
    const appPage = new App(await launchApp(), process.env.SDLC);
    await appPage.archiveDalMainPage.searchPage.first().click();
    await appPage.page.waitForTimeout(1000);
    await appPage.searchPage.searchWithisNull();
  });

  test('should search with IS NOT NULL contains values', async () => {
    const appPage = new App(await launchApp(), process.env.SDLC);
    await appPage.archiveDalMainPage.searchPage.first().click();
    await appPage.page.waitForTimeout(1000);
    await appPage.searchPage.searchWithisNotNull();
  });

  test('should collapse/expand search criteria section', async () => {
    const appPage = new App(await launchApp(), process.env.SDLC);
    await appPage.archiveDalMainPage.searchPage.first().click();
    await appPage.page.waitForTimeout(1000);
    await appPage.searchPage.searchSectionExpcol();
  });

  test('should load new next searched page data on page change', async () => {
    const appPage = new App(await launchApp(), process.env.SDLC);
    await appPage.archiveDalMainPage.searchPage.first().click();
    await appPage.page.waitForTimeout(1000);
    await appPage.searchPage.searchResultNavigation();
  });

  test('should load data in different sorting order', async () => {
    const appPage = new App(await launchApp(), process.env.SDLC);
    await appPage.archiveDalMainPage.searchPage.first().click();
    await appPage.page.waitForTimeout(1000);
    await appPage.searchPage.searchResultSortOrder();
  });

  test('should load data, click on search record to navigate to respective page', async () => {
    const appPage = new App(await launchApp(), process.env.SDLC);
    await appPage.page.waitForTimeout(2000);
    await appPage.archiveDalMainPage.searchPage.first().click();
    await appPage.page.waitForTimeout(3000);
    await appPage.searchPage.searchResultNavigate(environment.search_data);
    await appPage.page.waitForTimeout(2000);
    await Promise.all([
      appPage.page.waitForNavigation(/*{ url: ${environment.ApplicationURL} + '?iss=https%3A%2F%2Fmhe.okta.com#/archiveRec/2452968' }*/),
      await appPage.page.locator('textarea[name="libraryLocation"]').fill('test'),
      expect(await appPage.page.locator('input[name="isbn13"]').inputValue() != "").toBeTruthy(),
      expect(await appPage.page.locator('input[name="mhid"]').inputValue() != "").toBeTruthy(),
      await appPage.page.goBack(),
      await appPage.page.locator("text=Continue").click(),
    ]);
  });


});
