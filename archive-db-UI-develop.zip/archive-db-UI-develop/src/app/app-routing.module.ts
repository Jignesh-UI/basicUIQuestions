import { NgModule } from '@angular/core';
import { Routes, RouterModule, ExtraOptions } from '@angular/router';
import { LogoutComponent } from './components/logout/logout.component';
import { SearchComponent } from './components/search/search.component';
import { ReportsComponent } from './components/reports/reports.component';
import { SearchHistoryComponent } from './components/search-history/search-history.component';
import { SearchResultComponent } from './components/search-result/search-result.component';
import { ReportHistoryComponent } from './components/report-history/report-history.component';
import { OktaAuthService } from './service/okta-auth.service';
import { MenuComponent } from './components/menu/menu.component';
import { HeaderComponent } from './components/header/header.component';
import { ArcRecordComponent } from './components/archive-record/arc-record.component';
import { ArchiveRequestComponent } from './components/archive-request/archive-request.component';
import { AssociatedRecordComponent } from './components/associated-record/associated-record.component';
import { LOVResolverService } from './service/commonClasses/Lov-Resolver.Service';
import { CanDeactivateGuardService } from './shared/can-deactivate-guard.service';
import { NimasComponent } from './components/nimas/nimas.component';



const routes: Routes = [
  { path: 'logout', component: LogoutComponent },
  { path: 'archiveRec/:keyword', component: ArcRecordComponent, canDeactivate: [CanDeactivateGuardService], canActivate: [OktaAuthService], resolve: [LOVResolverService] },
  { path: 'archiveRec', component: ArcRecordComponent, canDeactivate: [CanDeactivateGuardService], canActivate: [OktaAuthService], resolve: [LOVResolverService] },
  { path: 'archiveReq/:keyword', component: ArchiveRequestComponent, canDeactivate: [CanDeactivateGuardService], canActivate: [OktaAuthService], resolve: [LOVResolverService] },
  { path: 'archiveReq', component: ArchiveRequestComponent, canDeactivate: [CanDeactivateGuardService], canActivate: [OktaAuthService], resolve: [LOVResolverService] },
  { path: 'associatedRecord/:keyword', component: AssociatedRecordComponent, canDeactivate: [CanDeactivateGuardService], canActivate: [OktaAuthService], resolve: [LOVResolverService] },
  { path: 'associatedRecord', component: AssociatedRecordComponent, canDeactivate: [CanDeactivateGuardService], canActivate: [OktaAuthService], resolve: [LOVResolverService] },
  { path: 'search', component: SearchComponent, canActivate: [OktaAuthService], resolve: [LOVResolverService] },
  { path: 'search/:keyword', component: SearchComponent, canActivate: [OktaAuthService], resolve: [LOVResolverService] },
  { path: 'searchresult/:keyword', component: SearchResultComponent, canActivate: [OktaAuthService] },
  { path: 'searchresult', component: SearchResultComponent, canActivate: [OktaAuthService] },
  { path: 'reports', component: ReportsComponent, canActivate: [OktaAuthService], resolve: [LOVResolverService] },
  { path: 'searchhistory', component: SearchHistoryComponent, canActivate: [OktaAuthService], resolve: [LOVResolverService] },
  { path: 'reporthistory', component: ReportHistoryComponent, canActivate: [OktaAuthService], resolve: [LOVResolverService] },
  { path: 'nimas/:keyword', component: NimasComponent, canDeactivate: [CanDeactivateGuardService], canActivate: [OktaAuthService], resolve: [LOVResolverService] },
  { path: 'nimas', component: NimasComponent, canDeactivate: [CanDeactivateGuardService], canActivate: [OktaAuthService], resolve: [LOVResolverService] },
  { path: 'menu', component: MenuComponent, canActivate: [OktaAuthService] },
  { path: 'header', component: HeaderComponent, canActivate: [OktaAuthService] },
  { path: '', redirectTo: 'archiveRec', pathMatch: 'full' },
  { path: '**', pathMatch: 'full', redirectTo: 'archiveRec' },
];

const routerOption: ExtraOptions = {
  onSameUrlNavigation: 'reload',
  useHash: true
}

@NgModule({
  imports: [RouterModule.forRoot(routes, routerOption)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
