import { TestBed, waitForAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { By } from '@angular/platform-browser';
import { RouterOutlet } from '@angular/router';
import { OktaInfoService } from './shared/okta/okta-info.service';
import { OktaAuthService } from './service/okta-auth.service';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { ComponentFixture, fakeAsync, tick } from '@angular/core/testing';

describe('AppComponent', () => {

  let iservice : OktaInfoService;
  let matDialogService: jasmine.SpyObj<MatDialog>;
  matDialogService = jasmine.createSpyObj<MatDialog>('MatDialog', ['open']);


  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      providers:[OktaInfoService, OktaAuthService, HttpClient, HttpHandler,
        {
          provide: MatDialog,
          useValue: matDialogService,
        }],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA ],
      imports: [
        RouterTestingModule.withRoutes([])
      ],
      declarations: [
        AppComponent
      ],
    }).compileComponents();
    iservice = TestBed.inject(OktaInfoService);

  }));

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

  it('should have router outlet',()=>{
    const fixture = TestBed.createComponent(AppComponent);
    const de = fixture.debugElement.query(By.directive(RouterOutlet));
    expect(de).not.toBeNull();
    fixture.debugElement.componentInstance.ngOnInit();
  });

  // it('should set user Email on ngOnInit method', fakeAsync (() => {
  //   const fixture = TestBed.createComponent(AppComponent);
  //   const app = fixture.debugElement.componentInstance;
  //   app.ngOnInit();
  //   tick();
  //   expect(app.userEmail).not.toBeNull();
  // }))
  
});
