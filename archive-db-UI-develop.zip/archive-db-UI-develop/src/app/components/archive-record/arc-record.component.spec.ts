import { HttpClient, HttpHandler } from "@angular/common/http";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import {
  ComponentFixture,
  fakeAsync,
  TestBed,
  tick,
} from "@angular/core/testing";
import { FormsModule } from "@angular/forms";
import { MatDialog } from "@angular/material/dialog";
import { Router } from "@angular/router";
import { RouterTestingModule } from "@angular/router/testing";
import { ToastrModule } from "ngx-toastr";
import { OktaAuthService } from "src/app/service/okta-auth.service";
import { OktaInfoService } from "src/app/shared/okta/okta-info.service";
import { PopupComponent } from "../popup/popup.component";
import { By } from "@angular/platform-browser";

import { ArcRecordComponent } from "./arc-record.component";
import { Details, Summary } from "./arc-record.model";

describe("ArcRecordComponent", () => {
  let component: ArcRecordComponent;
  let fixture: ComponentFixture<ArcRecordComponent>;
  let matDialogService: jasmine.SpyObj<MatDialog>;
  matDialogService = jasmine.createSpyObj<MatDialog>("MatDialog", ["open"]);
  const allCompVendor = [
    {
      lovid: 4000,
      lovType: "COMPOSITOR_VENDOR",
      lovCode: "COMPOSITOR_VENDOR-ALL",
      description: "Aptara",
      valueField: null,
      enabled: "Y",
      orderSeq: 1,
    },
    {
      lovid: 4001,
      lovType: "COMPOSITOR_VENDOR",
      lovCode: "COMPOSITOR_VENDOR-MHSE",
      description: "Editec",
      valueField: null,
      enabled: "Y",
      orderSeq: 2,
    },
    {
      lovid: 4002,
      lovType: "COMPOSITOR_VENDOR",
      lovCode: "COMPOSITOR_VENDOR-MHHE",
      description: "Hurix",
      valueField: null,
      enabled: "Y",
      orderSeq: 3,
    },
    {
      lovid: 4003,
      lovType: "COMPOSITOR_VENDOR",
      lovCode: "COMPOSITOR_VENDOR-ALL",
      description: "MPS",
      valueField: null,
      enabled: "Y",
      orderSeq: 4,
    },
    {
      lovid: 4004,
      lovType: "COMPOSITOR_VENDOR",
      lovCode: "COMPOSITOR_VENDOR-MHSE",
      description: "SeBue",
      valueField: null,
      enabled: "Y",
      orderSeq: 5,
    },
    {
      lovid: 4005,
      lovType: "COMPOSITOR_VENDOR",
      lovCode: "COMPOSITOR_VENDOR-ALL",
      description: "Other",
      valueField: null,
      enabled: "Y",
      orderSeq: 6,
    },
    {
      lovid: 4006,
      lovType: "COMPOSITOR_VENDOR",
      lovCode: "COMPOSITOR_VENDOR-ALL",
      description: "Straive",
      valueField: null,
      enabled: "Y",
      orderSeq: 7,
    },
    {
      lovid: 4007,
      lovType: "COMPOSITOR_VENDOR",
      lovCode: "COMPOSITOR_VENDOR-ALL",
      description: "Intertext",
      valueField: null,
      enabled: "Y",
      orderSeq: 8,
    },
    {
      lovid: 4008,
      lovType: "COMPOSITOR_VENDOR",
      lovCode: "COMPOSITOR_VENDOR-ALL",
      description: "Magic EdTech",
      valueField: null,
      enabled: "Y",
      orderSeq: 9,
    },
  ];

  const testData = {
    recordid: 2272100,
    mhid: "test-mhid",
    isbn13: "test-isbn",
    previousISBN: "test_pd_4_123",
    newISBN: "test_pd_4_000",
    author: "test prax",
    title: "testing api part 1",
    edition: 3.0,
    priority: "test high",
    owningDivision: "test owndiv",
    owningSubDivision: "test own subdiv",
    copyrightYear: 2022,
    boundBookDate: "2022-12-25",
    permissionEndDate: "2022-11-20",
    projectOPDate: "2022-11-20",
    deliveryFormat: "test delivery format 2",
    titleTypeDesc: "test title desc 2",
    gradeRange: "13 - 17",
    specificMarket: "testing market",
    ipubPublishingGroup: "prax_grp_3",
    ipubProgrammingTitle: "testing prog title - 2",
    noOfPages: 50.0,
    comments: "testing",
  };
  const testSummary = {
    archivist: 1013,
    compositorVendor: 4006,
    downloadDueDate: "2022-11-21",
    downloadReceivedDate: "2022-02-11",
    archivedDate: "2023-01-11",
    storageLocation: 49006,
    libraryLocation: "testing lib loc 2",
    printingVersion: 53.39,
    reprintContact: 40000,
    inserts: 22001,
    productionSpecialist: 91013,
    endsheets: 19001,
    pagingFilesList: [],
    otherFilesList: [],
    pdfsList: [],
    setOfDiscs: 37.0,
    discsInSet: 68.0,
    discSize: 51.98,
    mbgb: "GB",
    associatedList: [],
    createdDate: "2022-12-28",
    createdBy: "ARCHOWNER",
    modifiedDate: "2023-01-03",
    modifiedBy: "Pusti, Shuvendu",
  };

  const dummyData = {
    summary: {
      recordid: 2533201,
      mhid: "test-mhid",
      isbn13: "test-isbn",
      previousISBN: "test_pd_4_123",
      newISBN: "test_pd_4_000",
      author: "test prax",
      title: "testing api part 1",
      edition: 3,
      priority: "test high",
      owningDivision: "test owndiv",
      owningSubDivision: "test own subdiv",
      copyrightYear: 2022,
      boundBookDate: "2023-01-06",
      permissionEndDate: "2022-11-19",
      projectOPDate: "2022-11-19",
      deliveryFormat: "test delivery format 2",
      titleTypeDesc: "test title desc 2",
      gradeRange: "13 - 17",
      specificMarket: "testing market",
      ipubPublishingGroup: "prax_grp_3",
      ipubProgrammingTitle: "testing prog title - 2",
      noOfPages: 50,
      comments:
        "testing comment;\ntesting api update;\ntesting done by prakriti_de;",
    },
    details: {
      archivist: 1017,
      compositorVendor: 4005,
      downloadDueDate: "2022-11-20",
      downloadReceivedDate: "2022-02-10",
      archivedDate: "2022-08-16",
      storageLocation: 49010,
      libraryLocation: "testing lib loc 2 asdf",
      printingVersion: 53.39,
      reprintContact: 40004,
      productionSpecialist: "",
      inserts: 22002,
      endsheets: 19000,
      pagingFilesList: [
        {
          lovid: 31000,
          lovType: "PAGINGFILES",
          lovCode: "PAGINGFILES-MHHE",
          description: "InDesign",
          valueField: null,
          enabled: "Y",
          orderSeq: 1,
          otherValue: null,
        },
        {
          lovid: 31001,
          lovType: "PAGINGFILES",
          lovCode: "PAGINGFILES-ALL",
          description: "MSWord",
          valueField: null,
          enabled: "Y",
          orderSeq: 2,
          otherValue: null,
        },
        {
          lovid: 31003,
          lovType: "PAGINGFILES",
          lovCode: "PAGINGFILES-MHHE",
          description: "Quark",
          valueField: null,
          enabled: "Y",
          orderSeq: 4,
          otherValue: null,
        },
        {
          lovid: 31004,
          lovType: "PAGINGFILES",
          lovCode: "PAGINGFILES-MHHE",
          description: "Tex",
          valueField: null,
          enabled: "Y",
          orderSeq: 5,
          otherValue: null,
        },
        {
          lovid: 31005,
          lovType: "PAGINGFILES",
          lovCode: "PAGINGFILES-ALL",
          description: "Other",
          valueField: null,
          enabled: "Y",
          orderSeq: 6,
          otherValue: "testing",
        },
      ],
      otherFilesList: [
        {
          lovid: 25003,
          lovType: "OTHERFILES",
          lovCode: "OTHERFILES-ALL",
          description: "None",
          valueField: null,
          enabled: "Y",
          orderSeq: 4,
          otherValue: null,
        },
      ],
      pdfsList: [
        {
          lovid: 34000,
          lovType: "PDFS",
          lovCode: "PDFS-ALL",
          description: "PDF: Media (Low-Res)",
          valueField: null,
          enabled: "Y",
          orderSeq: 1,
        },
        {
          lovid: 34001,
          lovType: "PDFS",
          lovCode: "PDFS-ALL",
          description: "PDF: Printer (High-Res)",
          valueField: null,
          enabled: "Y",
          orderSeq: 2,
        },
      ],
      setOfDiscs: 37,
      discsInSet: 68,
      discSize: 8.97,
      mbgb: "MB",
      associatedList: [
        {
          summary: null,
          details: {
            associatedid: 11570,
            recordid: 2533201,
            productTitle: "test",
            archivist: null,
            compositorVendor: null,
            downloadReceivedDate: null,
            archivedDate: null,
            storageLocation: null,
            libraryLocation: null,
            printingVersion: 0,
            reprintContact: null,
            pagingFilesList: [],
            otherFilesList: [],
            pdfsList: [],
            productNotes: null,
            createdDate: null,
            createdBy: null,
            modifiedDate: null,
            modifiedBy: null,
          },
        },
        {
          summary: null,
          details: {
            associatedid: 11558,
            recordid: 2533201,
            productTitle: "test1",
            archivist: null,
            compositorVendor: null,
            downloadReceivedDate: null,
            archivedDate: null,
            storageLocation: null,
            libraryLocation: null,
            printingVersion: 0,
            reprintContact: null,
            pagingFilesList: [],
            otherFilesList: [],
            pdfsList: [],
            productNotes: null,
            createdDate: null,
            createdBy: null,
            modifiedDate: null,
            modifiedBy: null,
          },
        },
        {
          summary: null,
          details: {
            associatedid: 11559,
            recordid: 2533201,
            productTitle: "test2",
            archivist: null,
            compositorVendor: null,
            downloadReceivedDate: null,
            archivedDate: null,
            storageLocation: null,
            libraryLocation: null,
            printingVersion: 0,
            reprintContact: null,
            pagingFilesList: [],
            otherFilesList: [],
            pdfsList: [],
            productNotes: null,
            createdDate: null,
            createdBy: null,
            modifiedDate: null,
            modifiedBy: null,
          },
        },
      ],
      createdDate: "2023-02-10",
      createdBy: "ARCHUSER",
      modifiedDate: "2023-07-18",
      modifiedBy: "Patel, Jignesh",
    },
  };

  const reprintArray = [
    {
      lovid: 40003,
      lovType: "REPRINT_CONTACT",
      lovCode: "REPRINT_CONTACT-MHSE",
      description: "Kim Cotter",
      valueField: null,
      enabled: "N",
      orderSeq: 6,
      otherValue: null,
    },
  ];

  const archivistArray1 = [
    {
      lovid: 1005,
      lovType: "ARCHIVIST",
      lovCode: "ARCHIVIST-MHSE",
      description: "April Cleland",
      valueField: null,
      enabled: "N",
      orderSeq: 6,
    },
  ];

  const allArchivist = [
    {
      lovid: 1003,
      lovType: "ARCHIVIST",
      lovCode: "ARCHIVIST-MHSE",
      description: "Andy Backs",
      valueField: null,
      enabled: "Y",
      orderSeq: 4,
    },
    {
      lovid: 1011,
      lovType: "ARCHIVIST",
      lovCode: "ARCHIVIST-MHSE",
      description: "Jeff Kemeter",
      valueField: null,
      enabled: "Y",
      orderSeq: 12,
    },
    {
      lovid: 1012,
      lovType: "ARCHIVIST",
      lovCode: "ARCHIVIST-MHSE",
      description: "Jessica Solomon",
      valueField: null,
      enabled: "Y",
      orderSeq: 13,
    },
    {
      lovid: 1013,
      lovType: "ARCHIVIST",
      lovCode: "ARCHIVIST-MHHE",
      description: "Jodi Gaherty",
      valueField: null,
      enabled: "Y",
      orderSeq: 14,
    },
    {
      lovid: 1014,
      lovType: "ARCHIVIST",
      lovCode: "ARCHIVIST-MHHE",
      description: "Kara Kudronowicz",
      valueField: null,
      enabled: "Y",
      orderSeq: 15,
    },
    {
      lovid: 1017,
      lovType: "ARCHIVIST",
      lovCode: "ARCHIVIST-MHHE",
      description: "Laurie Lenstra",
      valueField: null,
      enabled: "Y",
      orderSeq: 18,
    },
    {
      lovid: 1032,
      lovType: "ARCHIVIST",
      lovCode: "ARCHIVIST-MHHE",
      description: "Tina Flanagan",
      valueField: null,
      enabled: "Y",
      orderSeq: 33,
    },
  ];

  const otherFilesArray = [
    {
      lovid: 25000,
      lovType: "OTHERFILES",
      lovCode: "OTHERFILES-ALL",
      description: "Accessibility Files",
      valueField: null,
      enabled: "Y",
      orderSeq: 1,
    },
    {
      lovid: 25001,
      lovType: "OTHERFILES",
      lovCode: "OTHERFILES-ALL",
      description: "Cover/Design",
      valueField: null,
      enabled: "Y",
      orderSeq: 2,
    },
    {
      lovid: 25002,
      lovType: "OTHERFILES",
      lovCode: "OTHERFILES-ALL",
      description: "Images",
      valueField: null,
      enabled: "Y",
      orderSeq: 3,
    },
  ];

  const prodSpecialistArray = [
    {
      lovid: 91000,
      lovType: "PRODUCTION_SPECIALIST",
      lovCode: "PRODUCTION_SPECIALIST",
      description: "Abby Harshbarger",
      valueField: null,
      enabled: "Y",
      orderSeq: 1,
    },
    {
      lovid: 91001,
      lovType: "PRODUCTION_SPECIALIST",
      lovCode: "PRODUCTION_SPECIALIST",
      description: "Abby Pickering",
      valueField: null,
      enabled: "Y",
      orderSeq: 2,
    },
    {
      lovid: 91002,
      lovType: "PRODUCTION_SPECIALIST",
      lovCode: "PRODUCTION_SPECIALIST",
      description: "Adrianne Searcy",
      valueField: null,
      enabled: "Y",
      orderSeq: 3,
    },
    {
      lovid: 91003,
      lovType: "PRODUCTION_SPECIALIST",
      lovCode: "PRODUCTION_SPECIALIST",
      description: "Alli Fehlman",
      valueField: null,
      enabled: "Y",
      orderSeq: 4,
    },
    {
      lovid: 91004,
      lovType: "PRODUCTION_SPECIALIST",
      lovCode: "PRODUCTION_SPECIALIST",
      description: "Becky Wardlaw",
      valueField: null,
      enabled: "Y",
      orderSeq: 5,
    },
    {
      lovid: 91005,
      lovType: "PRODUCTION_SPECIALIST",
      lovCode: "PRODUCTION_SPECIALIST",
      description: "Bethany Norman",
      valueField: null,
      enabled: "Y",
      orderSeq: 6,
    },
    {
      lovid: 91006,
      lovType: "PRODUCTION_SPECIALIST",
      lovCode: "PRODUCTION_SPECIALIST",
      description: "Chelsea Romer",
      valueField: null,
      enabled: "Y",
      orderSeq: 7,
    },
    {
      lovid: 91007,
      lovType: "PRODUCTION_SPECIALIST",
      lovCode: "PRODUCTION_SPECIALIST",
      description: "Darrell Harley",
      valueField: null,
      enabled: "Y",
      orderSeq: 8,
    },
    {
      lovid: 91008,
      lovType: "PRODUCTION_SPECIALIST",
      lovCode: "PRODUCTION_SPECIALIST",
      description: "Desiree Robinson",
      valueField: null,
      enabled: "Y",
      orderSeq: 9,
    },
    {
      lovid: 91009,
      lovType: "PRODUCTION_SPECIALIST",
      lovCode: "PRODUCTION_SPECIALIST",
      description: "Divina West",
      valueField: null,
      enabled: "Y",
      orderSeq: 10,
    },
    {
      lovid: 91010,
      lovType: "PRODUCTION_SPECIALIST",
      lovCode: "PRODUCTION_SPECIALIST",
      description: "Jaclyn Hamilton",
      valueField: null,
      enabled: "Y",
      orderSeq: 11,
    },
    {
      lovid: 91011,
      lovType: "PRODUCTION_SPECIALIST",
      lovCode: "PRODUCTION_SPECIALIST",
      description: "Jeremiah Catalano-Reilly",
      valueField: null,
      enabled: "Y",
      orderSeq: 12,
    },
    {
      lovid: 91012,
      lovType: "PRODUCTION_SPECIALIST",
      lovCode: "PRODUCTION_SPECIALIST",
      description: "Julian Rose",
      valueField: null,
      enabled: "Y",
      orderSeq: 13,
    },
    {
      lovid: 91013,
      lovType: "PRODUCTION_SPECIALIST",
      lovCode: "PRODUCTION_SPECIALIST",
      description: "Julie Perry",
      valueField: null,
      enabled: "Y",
      orderSeq: 14,
    },
  ];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule, FormsModule, ToastrModule.forRoot()],
      declarations: [ArcRecordComponent, PopupComponent],
      providers: [
        OktaAuthService,
        HttpClient,
        HttpHandler,
        OktaInfoService,
        {
          provide: MatDialog,
          useValue: matDialogService,
        },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ArcRecordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(async () => {
    fixture.destroy();
  });

  it("should create the Component", () => {
    expect(component).toBeTruthy();
  });

  it("should disable when MHID and ISBN is empty", () => {
    const component = fixture.debugElement.componentInstance;
    component.searchedMHID = "";
    component.searchedISBN = "";
    fixture.detectChanges();
    expect(
      fixture.debugElement.nativeElement.querySelector(".btn.btn-primary")
        .disabled
    ).toBeTruthy();
  });

  it("should return true when record Id is not available", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    const flagNavigate = cmpInstance.canDeactivate();
    expect(flagNavigate).toBeTruthy();
  });

  it("should return true when record Id is not available!", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    localStorage.setItem(
      "arcRecoData",
      JSON.stringify({ summary: testData, details: testSummary })
    );
    // cmpInstance.archiveData = testData;
    const flagNavigate = cmpInstance.canDeactivate();
    expect(flagNavigate).toBeTruthy();
  });

  it("should add NIMAS Archive Notes when comment is already added", () => {
    const component = fixture.debugElement.componentInstance;
    component.archiveData = new Details();
    component.archiveInfo = new Summary();
    component.archiveData.comment = "";
    component.onCommentAdd("test comment");
    expect(component.archiveData.comment).not.toBeNull();
    const message = "Test Message\n";
    component.archiveData.comment = message;
    component.onCommentAdd(message);
    expect(component.archiveData.comment).not.toBeNull();
  });

  it("should fill Record Information in bottom", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    component.archiveData = new Details();
    component.archiveInfo = new Summary();

    cmpInstance.archiveData.recordid = "test-mhid";
    cmpInstance.fillRecordInfo(true);
    fixture.detectChanges();
    expect(cmpInstance.recordInformation.uniqueId).not.toBeNull();
    cmpInstance.fillRecordInfo(false);
    fixture.detectChanges();
    expect(cmpInstance.recordInformation.uniqueId).toBeNull();
  });

  it("should show others input when Other Comp Vendor is selected", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.compVendorArray = allCompVendor;
    component.archiveData = new Details();
    component.archiveInfo = new Summary();

    cmpInstance.archiveData = testData;
    cmpInstance.archiveInfo = testSummary;

    fixture.detectChanges();
    const selectElement: HTMLSelectElement = fixture.debugElement.query(
      By.css("#compositorVendor")
    ).nativeElement;
    selectElement.value = selectElement.options[5].value;
    selectElement.dispatchEvent(new Event("change"));
    expect(cmpInstance.showCompVendor).toBeFalsy();
  });

  it("should load all LOVs on Page Load", async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    await cmpInstance.loadLovs();
    fixture.autoDetectChanges();
    expect(cmpInstance.archivistArray).not.toBeNull();
    expect(cmpInstance.compVendorArray).not.toBeNull();
    expect(cmpInstance.locationArray).not.toBeNull();
    expect(cmpInstance.reprintContactArray).not.toBeNull();
    expect(cmpInstance.insertsArray).not.toBeNull();
    expect(cmpInstance.endSheetsArray).not.toBeNull();
    expect(cmpInstance.pagingFilesArray).not.toBeNull();
    expect(cmpInstance.otherFilesArray).not.toBeNull();
    expect(cmpInstance.PDFsArray).not.toBeNull();
  });

  it("should fill all the required data in objects", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    component.archiveData = new Details();
    component.archiveInfo = new Summary();

    cmpInstance.fillFormSubscription(dummyData, false);
    expect(cmpInstance.searchedMHID).not.toBeNull();
  });

  it("should check archiviest if already exists in array", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.archiveData = new Details();
    cmpInstance.actualArchivistArray = [
      {
        lovid: 1005,
        lovType: "ARCHIVIST",
        lovCode: "ARCHIVIST-MHSE",
        description: "April Cleland",
        valueField: null,
        enabled: "N",
        orderSeq: 6,
      },
    ];
    cmpInstance.archivistArray = [
      {
        lovid: 1005,
        lovType: "ARCHIVIST",
        lovCode: "ARCHIVIST-MHSE",
        description: "April Cleland",
        valueField: null,
        enabled: "N",
        orderSeq: 6,
      },
    ];

    const j = cmpInstance.checkExistingArchiviest("April Cleland");
    fixture.detectChanges();
    expect(j).toBeFalsy();
  });

  it("should check existing reprint contact", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.archiveData = new Details();
    cmpInstance.reprintContactArray = reprintArray;
    cmpInstance.actualReprintArray = reprintArray;

    const j = cmpInstance.checkExistingReprintContact("Kim Cotter");
    fixture.detectChanges();
    expect(j).toBeFalsy();
  });

  it("should check existing reprint contact return false if not found", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.archiveData = new Details();
    cmpInstance.actualReprintArray = reprintArray;
    cmpInstance.reprintContactArray = reprintArray;

    cmpInstance.archiveInfo.reprintContact = {
      lovid: 40006,
      lovType: "REPRINT_CONTACT",
      lovCode: "REPRINT_CONTACT-MHSE",
      description: "Tim Heppner",
      valueField: null,
      enabled: "N",
      orderSeq: 11,
      otherValue: null,
    };

    const j = cmpInstance.checkExistingReprintContact("Tim Heppner");
    fixture.detectChanges();
    expect(j).toBeTruthy();
  });

  it("should adjust reprint contact other value in input!", async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.archiveData = new Details();
    component.archiveInfo = new Summary();
    cmpInstance.archiveData = testData;
    cmpInstance.archiveInfo = testSummary;

    cmpInstance.reprintContactArray = [
      {
        lovid: 40007,
        lovType: "REPRINT_CONTACT",
        lovCode: "REPRINT_CONTACT-MHSE",
        description: "Other",
        valueField: "test",
        enabled: "Y",
        orderSeq: 12,
      },
    ];

    const j = cmpInstance.adjustReprintContactOther("other");
    fixture.detectChanges();
    expect(cmpInstance.reprintContactOther).not.toBeNull();
  });

  it("should adjust archiviest", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    component.archiveData = new Details();
    component.archiveInfo = new Summary();

    cmpInstance.archiveData = testData;
    cmpInstance.archiveInfo = testSummary;
    cmpInstance.actualArchivistArray = [
      {
        lovid: 1005,
        lovType: "ARCHIVIST",
        lovCode: "ARCHIVIST-MHSE",
        description: "April Cleland",
        valueField: null,
        enabled: "N",
        orderSeq: 6,
      },
    ];
    cmpInstance.archivistArray = allArchivist;
    cmpInstance.archiveInfo.archivist = archivistArray1[0];
    const j = cmpInstance.setArchivest();
    fixture.detectChanges();
    expect(j).toBeFalsy();
  });

  it("should adjust archiviest if there is legacy", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    component.archiveData = new Details();
    component.archiveInfo = new Summary();

    cmpInstance.archiveData = testData;
    cmpInstance.archiveInfo = testSummary;
    cmpInstance.archivistArray = allArchivist;
    const j = cmpInstance.setArchivest();
    fixture.detectChanges();
    expect(j).toBeFalsy();
  });

  it("should adjust compvendor when search", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.archiveInfo = new Summary();
    cmpInstance.compVendorArray = [
      {
        lovid: 4000,
        lovType: "COMPOSITOR_VENDOR",
        lovCode: "COMPOSITOR_VENDOR-ALL",
        description: "Aptara",
        valueField: null,
        enabled: "Y",
        orderSeq: 1,
      },
      {
        lovid: 4001,
        lovType: "COMPOSITOR_VENDOR",
        lovCode: "COMPOSITOR_VENDOR-MHSE",
        description: "Editec",
        valueField: null,
        enabled: "Y",
        orderSeq: 2,
      },
      {
        lovid: 4002,
        lovType: "COMPOSITOR_VENDOR",
        lovCode: "COMPOSITOR_VENDOR-MHHE",
        description: "Hurix",
        valueField: null,
        enabled: "Y",
        orderSeq: 3,
      },
    ];
    cmpInstance.archiveInfo.compositorVendor = [
      {
        lovid: 4002,
        lovType: "COMPOSITOR_VENDOR",
        lovCode: "COMPOSITOR_VENDOR-MHHE",
        description: "Hurix",
        valueField: null,
        enabled: "Y",
        orderSeq: 3,
        otherValue: null,
      },
    ];

    cmpInstance.setCompVendor();
    fixture.detectChanges();
    expect(cmpInstance.archiveInfo.compositorVendor).not.toBeNull();
  });

  it("should adjust compvendor empty when search", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.archiveInfo = new Summary();
    cmpInstance.compVendorArray = [
      {
        lovid: 4000,
        lovType: "COMPOSITOR_VENDOR",
        lovCode: "COMPOSITOR_VENDOR-ALL",
        description: "Aptara",
        valueField: null,
        enabled: "Y",
        orderSeq: 1,
      },
      {
        lovid: 4001,
        lovType: "COMPOSITOR_VENDOR",
        lovCode: "COMPOSITOR_VENDOR-MHSE",
        description: "Editec",
        valueField: null,
        enabled: "Y",
        orderSeq: 2,
      },
      {
        lovid: 4002,
        lovType: "COMPOSITOR_VENDOR",
        lovCode: "COMPOSITOR_VENDOR-MHHE",
        description: "Hurix",
        valueField: null,
        enabled: "Y",
        orderSeq: 3,
      },
    ];
    cmpInstance.archiveInfo.compositorVendor = "";
    cmpInstance.setCompVendor();
    fixture.detectChanges();
    expect(cmpInstance.archiveInfo.compositorVendor).toBe("");
  });

  it("should adjust compvendor Other Field when search", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.archiveInfo = new Summary();
    cmpInstance.compVendorArray = [
      {
        lovid: 4004,
        lovType: "COMPOSITOR_VENDOR",
        lovCode: "COMPOSITOR_VENDOR-MHSE",
        description: "SeBue",
        valueField: null,
        enabled: "Y",
        orderSeq: 5,
      },
      {
        lovid: 4005,
        lovType: "COMPOSITOR_VENDOR",
        lovCode: "COMPOSITOR_VENDOR-ALL",
        description: "Other",
        valueField: null,
        otherValue: "test",
        enabled: "Y",
        orderSeq: 6,
      },
      {
        lovid: 4006,
        lovType: "COMPOSITOR_VENDOR",
        lovCode: "COMPOSITOR_VENDOR-ALL",
        description: "Straive",
        valueField: null,
        enabled: "Y",
        orderSeq: 7,
      },
    ];

    cmpInstance.archiveInfo.compositorVendor = {
      lovid: 4005,
      lovType: "COMPOSITOR_VENDOR",
      lovCode: "COMPOSITOR_VENDOR-ALL",
      description: "Other",
      valueField: null,
      otherValue: "test",
      enabled: "Y",
      orderSeq: 6,
    };
    fixture.autoDetectChanges();
    cmpInstance.setCompVendor();
    expect(cmpInstance.archiveInfo.compositorVendor).not.toBeNull();
  });

  it("should adjust location value", async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.archiveInfo = new Summary();
    cmpInstance.locationArray = [
      {
        lovid: 49011,
        lovType: "STORAGE_LOCATION",
        lovCode: "STORAGE_LOCATION-ALL",
        description: "VideoTape",
        valueField: null,
        enabled: "Y",
        orderSeq: 12,
      },
      {
        lovid: 49012,
        lovType: "STORAGE_LOCATION",
        lovCode: "STORAGE_LOCATION-ALL",
        description: "Warehouse",
        valueField: null,
        enabled: "Y",
        orderSeq: 13,
      },
    ];

    cmpInstance.archiveInfo.storageLocation = {
      lovid: 49012,
      lovType: "STORAGE_LOCATION",
      lovCode: "STORAGE_LOCATION-ALL",
      description: "Warehouse",
      valueField: null,
      enabled: "Y",
      orderSeq: 13,
    };
    fixture.autoDetectChanges();
    cmpInstance.setLocation();
    expect(cmpInstance.archiveInfo.storageLocation).not.toBeNull();
  });

  it("should adjust reprint Contact value", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.archiveInfo = new Summary();
    cmpInstance.reprintContactArray = [
      {
        lovid: 40000,
        lovType: "REPRINT_CONTACT",
        lovCode: "REPRINT_CONTACT-MHSE",
        description: "Adrienne Searcy",
        valueField: null,
        enabled: "Y",
        orderSeq: 1,
      },
      {
        lovid: 40001,
        lovType: "REPRINT_CONTACT",
        lovCode: "REPRINT_CONTACT-MHSE",
        description: "Angela Warner",
        valueField: null,
        enabled: "Y",
        orderSeq: 2,
      },
      {
        lovid: 40007,
        lovType: "REPRINT_CONTACT",
        lovCode: "REPRINT_CONTACT-MHSE",
        description: "Other",
        valueField: null,
        enabled: "Y",
        orderSeq: 8,
      },
    ];
    cmpInstance.archiveInfo.reprintContact = {
      lovid: 40007,
      lovType: "REPRINT_CONTACT",
      lovCode: "REPRINT_CONTACT-MHSE",
      description: "Other",
      valueField: null,
      otherValue: "",
      enabled: "Y",
      orderSeq: 8,
    };
    fixture.autoDetectChanges();
    cmpInstance.setReprintContact();
    expect(cmpInstance.archiveInfo.reprintContact).not.toBeNull();
  });

  it("should adjust reprint Contact value null", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.archiveInfo = new Summary();
    cmpInstance.actualReprintArray = cmpInstance.reprintContactArray = [
      {
        lovid: 40000,
        lovType: "REPRINT_CONTACT",
        lovCode: "REPRINT_CONTACT-MHSE",
        description: "Adrienne Searcy",
        valueField: null,
        enabled: "Y",
        orderSeq: 1,
      },
      {
        lovid: 40001,
        lovType: "REPRINT_CONTACT",
        lovCode: "REPRINT_CONTACT-MHSE",
        description: "Angela Warner",
        valueField: null,
        enabled: "Y",
        orderSeq: 2,
      },
      {
        lovid: 40007,
        lovType: "REPRINT_CONTACT",
        lovCode: "REPRINT_CONTACT-MHSE",
        description: "Other",
        valueField: null,
        enabled: "Y",
        orderSeq: 8,
      },
    ];
    cmpInstance.archiveInfo.reprintContact = {
      lovid: 40006,
      lovType: "REPRINT_CONTACT",
      lovCode: "REPRINT_CONTACT-MHSE",
      description: "Tim Heppner",
      valueField: null,
      enabled: "N",
      orderSeq: 11,
      otherValue: null,
    };
    fixture.autoDetectChanges();
    cmpInstance.setReprintContact();
    expect(cmpInstance.archiveInfo.reprintContact).not.toBeNull();
  });

  it("should adjust Production Speciality field value!", async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    component.archiveInfo = new Summary();

    cmpInstance.archiveInfo = testSummary;
    cmpInstance.prodSpecialistArray = prodSpecialistArray;
    cmpInstance.archiveInfo.productionSpecialist = {
      lovid: 91013,
      lovType: "PRODUCTION_SPECIALIST",
      lovCode: "PRODUCTION_SPECIALIST",
      description: "Julie Perry",
      valueField: null,
      enabled: "Y",
      orderSeq: 14,
      otherValue: null,
    };

    cmpInstance.setProdSpeciality();
    fixture.detectChanges();
    expect(cmpInstance.archiveInfo.productionSpecialist).toBe(91013);
  });

  it("should set other value of comp vendor field!", async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.archiveInfo = new Summary();
    cmpInstance.defaultCompVendorOtherValue = "example value";
    cmpInstance.archiveInfo = {
      compositorVendor: "initial value",
    };

    const event = {
      currentTarget: {
        value: "example value",
      },
    };
    cmpInstance.compVendorOtherValueChange(event);
    expect(cmpInstance.archiveInfo?.compositorVendor).not.toBeUndefined();
  });

  it("should set other value of comp vendor not field!", async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.archiveInfo = new Summary();
    cmpInstance.defaultCompVendorOtherValue = "example value";
    cmpInstance.archiveInfo = {
      compositorVendor: "initial value",
    };

    const event = {
      currentTarget: {
        value: "",
      },
    };
    cmpInstance.compVendorOtherValueChange(event);
    expect(cmpInstance.archiveInfo?.compositorVendor).not.toBeUndefined();
  });

  it("should set other value of production specialist field!", async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.archiveInfo = new Summary();
    cmpInstance.defaultproductionSpecialist = "example value";
    cmpInstance.archiveInfo = { defaultproductionSpecialist: "initial value" };
    const event = { currentTarget: { value: "example value" } };
    cmpInstance.productionSpecialistOtherValueChange(event);
    expect(
      cmpInstance.archiveInfo?.defaultproductionSpecialist
    ).not.toBeUndefined();
  });

  it("should set other value of production specialist not field!", async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.archiveInfo = new Summary();
    cmpInstance.defaultproductionSpecialist = "example value";
    cmpInstance.archiveInfo = { defaultproductionSpecialist: "initial value" };
    const event = { currentTarget: { value: "" } };
    cmpInstance.productionSpecialistOtherValueChange(event);
    expect(
      cmpInstance.archiveInfo?.defaultproductionSpecialist
    ).not.toBeUndefined();
  });

  it("should set other value of reprint contact field!", async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.archiveInfo = new Summary();
    cmpInstance.reprintContactOther = "example value";
    cmpInstance.archiveInfo = { defaultproductionSpecialist: "initial value" };
    const event = { currentTarget: { value: "example value" } };
    cmpInstance.reprintContactOtherValueChange(event);
    expect(
      cmpInstance.archiveInfo?.defaultproductionSpecialist
    ).not.toBeUndefined();
  });

  it("should set other value of reprint contact not field!", async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.archiveInfo = new Summary();
    cmpInstance.reprintContactOther = "example value";
    cmpInstance.archiveInfo = { defaultproductionSpecialist: "initial value" };
    const event = { currentTarget: { value: "" } };
    cmpInstance.reprintContactOtherValueChange(event);
    expect(
      cmpInstance.archiveInfo?.defaultproductionSpecialist
    ).not.toBeUndefined();
  });

  it("should call and return other files other checkbox", async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.archiveInfo = new Summary();

    cmpInstance.otherFilesArray = otherFilesArray;
    cmpInstance.archiveInfo.otherFilesList = [
      {
        lovid: 25001,
        lovType: "OTHERFILES",
        lovCode: "OTHERFILES-ALL",
        description: "Cover/Design",
        valueField: null,
        enabled: "Y",
        orderSeq: 2,
      },
    ];
    const event = { currentTarget: { lovid: 25001 } };
    const j = cmpInstance.otherFilesOtherValueChange(
      event,
      cmpInstance.archiveInfo.otherFilesList
    );
    expect(j).not.toBeNull();
  });
});
