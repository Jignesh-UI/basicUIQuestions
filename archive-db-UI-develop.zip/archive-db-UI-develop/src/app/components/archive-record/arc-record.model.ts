export class Details {
    recordid: number;
    mhid: string;
    isbn13: string;
    previousISBN: string;
    newISBN: string;
    author: string;
    title: string;
    edition: number;
    priority: string;
    owningDivision: string;
    owningSubDivision: string;
    copyrightYear: number;
    boundBookDate: string;
    permissionEndDate: string;
    projectOPDate: string;
    deliveryFormat: string;
    titleTypeDesc: string;
    gradeRange: string;
    specificMarket: string;
    ipubPublishingGroup: string;
    ipubProgrammingTitle: string;
    noOfPages: number;
    comments: string;
}
export class Summary {
    archivist: any;
    compositorVendor: any;
    downloadDueDate: string;
    downloadReceivedDate: string;
    archivedDate: string;
    storageLocation: any;
    libraryLocation: string;
    printingVersion: number;
    reprintContact: any;
    productionSpecialist: any;
    inserts: any;
    endsheets: any;
    pagingFilesList: any;
    otherFilesList: any;
    pdfsList: any;
    setOfDiscs: number;
    discsInSet: number;
    discSize: any;
    mbgb: string;
    createdDate: string;
    createdBy: string;
    modifiedDate: string;
    modifiedBy: string;
    associatedList: allAssocProductInterface[];
    reprintContactTest:any;
    compVendorTest:any;
    productionSpecialistTest:any;
}

export interface assocProductsInterface {
    associatedid?: string;
    productTitle?: string;
    printingVersion?: number;
    archivedDate?: string;
}

export interface allAssocProductInterface{
    sumary?:any,
    details?: assocProductsInterface
}