export class arcReqDetails {
    requestReceivedDate: string;
    dueDate: string;
    completedDate: string;
    inProgress: boolean;
    requestedBy: string;
    requestorDepartment: string;
    printingVersion: number;
    taskid: number;
    specialInstructions: string;
    statusNotes: string;
    archivist: any;
    deliveryMedium: any;
    compositorVendor: any;
    pdfsList: any;
    requestedFilesList: any;
    createdDate: string;
    createdBy: string;
    modifiedDate: string;
    modifiedBy: string;
    recordid: string;
    compVendorTest: any;
}

export class arcReqSummary {
    mhid: string;
    isbn13: string;
    previousISBN: string;
    newISBN: string;
    author: string;
    title: string;
    edition: number;
    priority: string;
    owningDivision: string;
    owningSubDivision: string;
    copyrightYear: number;
    boundBookDate: string;
    permissionEndDate: string;
    projectOPDate: string;
    deliveryFormat: string;
    titleTypeDesc: string;
    gradeRange: string;
    specificMarket: string;
    ipubPublishingGroup: string;
    ipubProgrammingTitle: string;
    noOfPages: number;
    comments: string;
    recordid: string;
}
