import { chkInterface } from "src/app/service/models/common.model";

export class associatedSummary {
    mhid: string;
    isbn13: string;
    previousISBN: string;
    newISBN: string;
    author: string;
    title: string;
    edition: number;
    copyrightYear: number;
    boundBookDate: string;
    permissionEndDate: string;
    projectOPDate: string;
    owningDivision: string;
    owningSubDivision: string;
    deliveryFormat: string;
    titleTypeDesc: string;
    gradeRange: string;
    specificMarket: string;
    ipubPublishingGroup: string;
    ipubProgrammingTitle: string;
    noOfPages: number;
    comments: any;
    recordid: number;
    priority: string;
}

export class associatedDetails {
    productTitle: string;
    archivist: any;
    compositorVendor: any;
    downloadReceivedDate: string;
    archivedDate: string;
    storageLocation: any;
    libraryLocation: string;
    printingVersion: number;
    reprintContact: any;
    pagingFilesList: chkInterface[];
    otherFilesList: chkInterface[];
    pdfsList: chkInterface[];

    associatedid: number;
    recordid: number;
    productNotes: string;
    createdDate: string;
    createdBy: string;
    modifiedDate: string;
    modifiedBy: string;

    reprintContactTest:any;
    compVendorTest:any;
}

