import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as OktaAuth from '@okta/okta-auth-js';
import { ComponentService } from 'src/app/service/component.service';
import { OktaAuthService } from 'src/app/service/okta-auth.service';

const VERSION = require("../../../../package.json").version;

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  isAuthenticated: boolean;
  appVersion: string = VERSION;
  title = "McGraw Hill Archive Database";

  ngOnInit() {
    this.comm.isAuthenticated.subscribe(isAuth => this.isAuthenticated = isAuth)
  }
  
  constructor(public oktaAuthService: OktaAuthService, private comm: ComponentService, private router: Router) { }

  logout() {
    // this.oktaAuthService.oktaAuth.signOut({ });
    this.comm.changeIsAuthenticate(false);
    this.router.navigate(['/logout']);
  }

  login() {
    this.router.navigate(['/']);
  }
}
