import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { Router, RouterLink } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

import { MenuComponent } from './menu.component';

describe('MenuComponent', () => {
  let component: MenuComponent;
  let fixture: ComponentFixture<MenuComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule, FormsModule],
      declarations: [MenuComponent]
    })
      .compileComponents();

  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate to Archive Record Page', () => {
      const router = TestBed.get(Router);
      const spy = spyOn(router,'navigate');
      component.onKeywordSearch();
      expect(spy).toHaveBeenCalledWith(['archiveRec',''])
  })

  it('keyword is required', () => {
    const component = fixture.debugElement.componentInstance;
    component.keyword = "";
    fixture.detectChanges();
    expect(fixture.debugElement.nativeElement.querySelector("button").disabled).toBeTruthy();
  });

  it('button should enabled when keyword is not empty', () => {
    const component = fixture.debugElement.componentInstance;
    component.keyword = "test";
    fixture.detectChanges();
    expect(fixture.debugElement.nativeElement.querySelector("button").disabled).toBeFalsy();
  });

  it('should have link to Archive Record page', () => {
    const debugElements = fixture.debugElement.queryAll(By.directive(RouterLink));
    const index = debugElements.findIndex(de => de.attributes['routerLink'] === '/archiveRec')
    expect(index).toBeGreaterThan(-1)
  });

  it('should have link to Archive Request page', () => {
    const debugElements = fixture.debugElement.queryAll(By.directive(RouterLink));
    const index = debugElements.findIndex(de => de.attributes['routerLink'] === '/archiveReq')
    expect(index).toBeGreaterThan(-1)
  });

  it('should have link to Associated Record page', () => {
    const debugElements = fixture.debugElement.queryAll(By.directive(RouterLink));
    const index = debugElements.findIndex(de => de.attributes['routerLink'] === '/associatedRecord')
    expect(index).toBeGreaterThan(-1)
  });


  it('should have link to nimas page', () => {
    const debugElements = fixture.debugElement.queryAll(By.directive(RouterLink));
    const index = debugElements.findIndex(de => de.attributes['routerLink'] === '/nimas')
    expect(index).toBeGreaterThan(-1)
  });

  it('should have link to search page', () => {
    const debugElements = fixture.debugElement.queryAll(By.directive(RouterLink));
    const index = debugElements.findIndex(de => de.attributes['routerLink'] === '/search')
    expect(index).toBeGreaterThan(-1)
  });

  it('should have link to searchhistory page', () => {
    const debugElements = fixture.debugElement.queryAll(By.directive(RouterLink));
    const index = debugElements.findIndex(de => de.attributes['routerLink'] === '/searchhistory')
    expect(index).toBeGreaterThan(-1)
  });

  it('should have link to reports page', () => {
    const debugElements = fixture.debugElement.queryAll(By.directive(RouterLink));
    const index = debugElements.findIndex(de => de.attributes['routerLink'] === '/reports')
    expect(index).toBeGreaterThan(-1)
  });

  it('should have link to reporthistory page', () => {
    const debugElements = fixture.debugElement.queryAll(By.directive(RouterLink));
    const index = debugElements.findIndex(de => de.attributes['routerLink'] === '/reporthistory')
    expect(index).toBeGreaterThan(-1)
  });

});
