import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ComponentService } from 'src/app/service/component.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})

export class MenuComponent {
  keyword = '';

  constructor(private router: Router, private commuincationService: ComponentService) { }

  onKeywordSearch() {
    this.router.navigate(['archiveRec', this.keyword.trim().replaceAll(".", "%2525252E")]);
    this.keyword = '';
  }

  onSearchNavigate() {
    this.commuincationService.unSubscribeMessage();
  }

}
