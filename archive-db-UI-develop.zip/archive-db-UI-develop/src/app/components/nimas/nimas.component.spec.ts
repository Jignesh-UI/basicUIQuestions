import { HttpClient, HttpHandler } from '@angular/common/http';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { By } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';
import { ToastrModule } from 'ngx-toastr';
import { LovDataService } from 'src/app/service/commonClasses/lov-data.service';
import { OktaAuthService } from 'src/app/service/okta-auth.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { NimasComponent } from './nimas.component';
import { nimasDetails, nimasSummary } from './nimas.model';

describe('NimasComponent', () => {
  let component: NimasComponent;
  let fixture: ComponentFixture<NimasComponent>;
  let dataService: LovDataService;
  let matDialogService: jasmine.SpyObj<MatDialog>;
  matDialogService = jasmine.createSpyObj<MatDialog>('MatDialog', ['open']);

  const testArchivistArray = [{
    lovid: 1003,
    lovType: "ARCHIVIST",
    lovCode: "ARCHIVIST-MHSE",
    description: "Andy Backs",
    valueField: '',
    enabled: "Y",
    orderSeq: 4
  }, {
    lovid: 1011,
    lovType: "ARCHIVIST",
    lovCode: "ARCHIVIST-MHSE",
    description: "Jeff Kemeter",
    valueField: '',
    enabled: "Y",
    orderSeq: 12
  }, {
    lovid: 1012,
    lovType: "ARCHIVIST",
    lovCode: "ARCHIVIST-MHSE",
    description: "Jessica Solomon",
    valueField: '',
    enabled: "Y",
    orderSeq: 13
  }, {
    lovid: 1013,
    lovType: "ARCHIVIST",
    lovCode: "ARCHIVIST-MHHE",
    description: "Jodi Gaherty",
    valueField: '',
    enabled: "Y",
    orderSeq: 14
  }, {
    lovid: 1014,
    lovType: "ARCHIVIST",
    lovCode: "ARCHIVIST-MHHE",
    description: "Kara Kudronowicz",
    valueField: '',
    enabled: "Y",
    orderSeq: 15
  }, {
    lovid: 1017,
    lovType: "ARCHIVIST",
    lovCode: "ARCHIVIST-MHHE",
    description: "Laurie Lenstra",
    valueField: '',
    enabled: "Y",
    orderSeq: 18
  }, {
    lovid: 1032,
    lovType: "ARCHIVIST",
    lovCode: "ARCHIVIST-MHHE",
    description: "Tina Flanagan",
    valueField: '',
    enabled: "Y",
    orderSeq: 33
  }];


  const testNimasCoordinatorArray = [{
    lovid: 10000,
    lovType: "COORDINATOR",
    lovCode: "COORDINATOR-MHSE",
    description: "Andy Backs",
    valueField: '',
    enabled: "Y",
    orderSeq: 1
  }, {
    lovid: 10001,
    lovType: "COORDINATOR",
    lovCode: "COORDINATOR-MHSE",
    description: "April Cleland",
    valueField: '',
    enabled: "Y",
    orderSeq: 2
  }, {
    lovid: 10002,
    lovType: "COORDINATOR",
    lovCode: "COORDINATOR-MHSE",
    description: "Jeff Kemeter",
    valueField: '',
    enabled: "Y",
    orderSeq: 3
  }, {
    lovid: 10003,
    lovType: "COORDINATOR",
    lovCode: "COORDINATOR-MHSE",
    description: "Jessica Solomon",
    valueField: '',
    enabled: "Y",
    orderSeq: 4
  }, {
    lovid: 10004,
    lovType: "COORDINATOR",
    lovCode: "COORDINATOR-MHSE",
    description: "Kristen Silver",
    valueField: '',
    enabled: "Y",
    orderSeq: 5
  }, {
    lovid: 10014,
    lovType: "DESC_VENDOR",
    lovCode: "DESC_VENDOR-MHSE",
    description: "Other",
    valueField: '',
    enabled: "Y",
    orderSeq: 14,
    otherValue: "test",
  }, {
    lovid: 10005,
    lovType: "COORDINATOR",
    lovCode: "COORDINATOR-MHSE",
    description: "Larry Marotta",
    valueField: '',
    enabled: "Y",
    orderSeq: 6
  }];

  const testNimasConvVendorArray = [{
    lovid: 7000,
    lovType: "CONV_VENDOR",
    lovCode: "CONV_VENDOR-MHSE",
    description: "Aptara",
    valueField: '',
    enabled: "Y",
    orderSeq: 1,
    otherValue: "test",
    filesSentDate: "2022-06-19"
  },
  {
    lovid: 7001,
    lovType: "CONV_VENDOR",
    lovCode: "CONV_VENDOR-MHSE",
    description: "Laserwords",
    valueField: '',
    enabled: "Y",
    orderSeq: 2,
    otherValue: "test",
    filesSentDate: "2022-06-19"
  },
  {
    lovid: 7002,
    lovType: "CONV_VENDOR",
    lovCode: "CONV_VENDOR-MHSE",
    description: "MPS",
    valueField: '',
    enabled: "Y",
    orderSeq: 3,
    otherValue: "test",
    filesSentDate: "2022-06-19"
  },
  {
    lovid: 7003,
    lovType: "CONV_VENDOR",
    lovCode: "CONV_VENDOR-MHSE",
    description: "Quad Graphics",
    valueField: '',
    enabled: "Y",
    orderSeq: 4,
    otherValue: "test",
    filesSentDate: "2022-06-19"
  },
  {
    lovid: 7004,
    lovType: "CONV_VENDOR",
    lovCode: "CONV_VENDOR-MHSE",
    description: "Other",
    valueField: '',
    enabled: "Y",
    orderSeq: 5,
    otherValue: "test",
    filesSentDate: "2022-06-19"
  }
  ];

  const testNimasDescVendorArray = [{
    lovid: 16000,
    lovType: "DESC_VENDOR",
    lovCode: "DESC_VENDOR-MHSE",
    description: "Aptara",
    valueField: '',
    enabled: "Y",
    orderSeq: 1,
    otherValue: "test",
    filesSentDate: "2022-06-19"
  },
  {
    lovid: 16001,
    lovType: "DESC_VENDOR",
    lovCode: "DESC_VENDOR-MHSE",
    description: "Laserwords",
    valueField: '',
    enabled: "Y",
    orderSeq: 2,
    otherValue: "test",
    filesSentDate: "2022-06-19"
  },
  {
    lovid: 16002,
    lovType: "DESC_VENDOR",
    lovCode: "DESC_VENDOR-MHSE",
    description: "MPS",
    valueField: '',
    enabled: "Y",
    orderSeq: 3,
    otherValue: "test",
    filesSentDate: "2022-06-19"
  },
  {
    lovid: 16003,
    lovType: "DESC_VENDOR",
    lovCode: "DESC_VENDOR-MHSE",
    description: "Quad Graphics",
    valueField: '',
    enabled: "Y",
    orderSeq: 4,
    otherValue: "test",
    filesSentDate: "2022-06-19"
  },
  {
    lovid: 16004,
    lovType: "DESC_VENDOR",
    lovCode: "DESC_VENDOR-MHSE",
    description: "Other",
    valueField: '',
    enabled: "Y",
    orderSeq: 5,
    otherValue: "test",
    filesSentDate: "2022-06-19"
  }
  ];

  const testNimasDetailsData = {
    "nimasid": 19700,
    "recordid": 1304182,
    "archivist": 1003,
    "coordinator": 10003,
    "nimasCertNumber": "Testing NimasCertNumber part4",
    "nimasCertReceivedDate": "2022-06-19",
    "nimasConvVendor": 7003,
    "nimasDescVendor": 16000,
    "notes": "Testing Nimas creation on 09-June-2022",
    "createdDate": "2022-08-17",
    "createdBy": "De, Prakriti",
    "modifiedDate": "2022-08-17",
    "modifiedBy": "De, Prakriti"
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule, MatDialogModule, FormsModule, ToastrModule.forRoot(), BrowserAnimationsModule],
      declarations: [NimasComponent],
      providers: [OktaAuthService, HttpClient, HttpHandler, LovDataService,
        {
          provide: MatDialog,
          useValue: matDialogService,
        }],
      schemas: [NO_ERRORS_SCHEMA]
    })
      .compileComponents();
    dataService = TestBed.inject(LovDataService);

  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NimasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    fixture.destroy();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should adjust record ID is it is empty', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.nimasSummary = new nimasSummary();
    cmpInstance.nimasDetails.nimasid = null;
    cmpInstance.nimasSummary.recordid = '1234';
    cmpInstance.adjustNimasId();
    fixture.detectChanges();
    expect(cmpInstance.nimasDetails.recordid).not.toBeNull();
  });

  it('should add NIMAS Archive Notes when comment is already added', () => {
    component.nimasDetails = new nimasDetails();
    const message = 'Test Message\n';
    component.nimasDetails.notes = message;
    component.onNIMASCommentAdd(message);
    expect(component.nimasDetails.notes).not.toBeNull();
  });

  it('should add NIMAS Archive Notes when comment is blank ', () => {
    component.onNIMASCommentAdd('new Test Message');
    expect(component.nimasDetails.notes.length).toBeGreaterThan(16);
  });

  it('should fill Record Information in bottom', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.nimasDetails.nimasid = 'test-mhid';
    cmpInstance.fillRecordInfo(true);
    fixture.detectChanges();
    expect(cmpInstance.recordInformation.uniqueId).not.toBeNull();
  });

  it('should NOT fill Record Information in bottom if there are not information in Details', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.nimasDetails.nimasid = 'test-mhid';
    cmpInstance.fillRecordInfo(false);
    fixture.detectChanges();
    expect(cmpInstance.recordInformation.uniqueId).toBeNull();
  });


  it('should show others input when Other NIMAS Conversion Vendor is selected', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasconvVendorArray = testNimasConvVendorArray;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.nimasDetails = testNimasDetailsData;
    fixture.detectChanges();
    const selectElement: HTMLSelectElement = fixture.debugElement.query(By.css('#nimasConvVendor')).nativeElement;
    selectElement.value = selectElement.options[5].value;
    selectElement.dispatchEvent(new Event('change'));
    expect(cmpInstance.showConvVendor).toBeTruthy();
  });

  it('should not show others input when NIMAS Conversion Vendor is selected with value that is not Other', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasconvVendorArray = testNimasConvVendorArray;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.nimasDetails = testNimasDetailsData;
    cmpInstance.convVendorChange('7003');
    fixture.detectChanges();
    expect(cmpInstance.showConvVendor).toBeFalsy();
  });

  it('should show others input when Other NIMAS Description Vendor is selected', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDescVendorArray = testNimasDescVendorArray;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.nimasDetails = testNimasDetailsData;
    fixture.detectChanges();
    const selectElement: HTMLSelectElement = fixture.debugElement.query(By.css('#nimasDescVendor')).nativeElement;
    selectElement.value = selectElement.options[5].value;
    selectElement.dispatchEvent(new Event('change'));
    expect(cmpInstance.showDescVendor).toBeTruthy();
  });

  it('should not show others input when NIMAS Description Vendor is selected with value that is not Other', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDescVendorArray = testNimasDescVendorArray;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.nimasDetails = testNimasDetailsData;
    cmpInstance.descVendorChange('16001');
    fixture.detectChanges();
    expect(cmpInstance.showDescVendor).toBeFalsy();
  });

  it('should reset the reset Summary array and others', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.resetDataModel();
    expect((cmpInstance.nimasDetails = {})).toBeTruthy();
  });

  it('should reset the all Dropdown Lists', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.resetDrpLists();
    expect(cmpInstance.nimasDetails.archivist).not.toBeNull();
  });

  it('should adjust archivist from the list', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.actualArchivistArray = testArchivistArray;
    cmpInstance.archivistArray = testArchivistArray;
    cmpInstance.nimasDetails.archivist = {
      lovid: 1003,
      lovType: "ARCHIVIST",
      lovCode: "ARCHIVIST-MHSE",
      description: "Andy Backs",
      valueField: '',
      enabled: "Y",
      orderSeq: 4
    };
    fixture.detectChanges();
    const j = cmpInstance.setArchivest();
    fixture.detectChanges();
    expect(j).toBeFalsy();
  });

  it('should adjust archivist to the list if it is not selected', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.archivistArray = testArchivistArray;
    cmpInstance.nimasDetails.archivist = {};
    const j = cmpInstance.setArchivest();
    fixture.detectChanges();
    expect(j).toBeFalsy();
  });

  it('should set NIMAS Coordinator based on search by MHID/ISBN', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.nimasCoordinatorArray = testNimasCoordinatorArray;
    cmpInstance.nimasDetails.coordinator = {
      lovid: 10001,
      lovType: "COORDINATOR",
      lovCode: "COORDINATOR-MHSE",
      description: "April Cleland",
      valueField: '',
      enabled: "Y",
      orderSeq: 2
    };
    cmpInstance.setCoordinator();
    fixture.detectChanges();
    expect(cmpInstance.nimasDetails.coordinator == 10001).toBeTruthy();
  });


  it('should set NIMAS Conversion Vendor based on search by MHID/ISBN', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.nimasconvVendorArray = testNimasConvVendorArray;
    cmpInstance.nimasDetails.nimasConvVendor = {
      lovid: 7001,
      lovType: "CONV_VENDOR",
      lovCode: "CONV_VENDOR-MHSE",
      description: "Laserwords",
      valueField: '',
      enabled: "Y",
      orderSeq: 2
    };
    cmpInstance.setConversionVendor();
    fixture.detectChanges();
    expect(cmpInstance.nimasDetails.nimasConvVendor == 7001).toBeTruthy();
  });


  it('should set "Other" in NIMAS Conversion Vendor based on search by MHID/ISBN', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.nimasconvVendorArray = testNimasConvVendorArray;
    cmpInstance.nimasDetails.nimasConvVendor = {
      lovid: 7004,
      lovType: "CONV_VENDOR",
      lovCode: "CONV_VENDOR-MHSE",
      description: "Other",
      valueField: '',
      enabled: "Y",
      orderSeq: 5,
      otherValue: 'test value'
    };
    cmpInstance.setConversionVendor();
    fixture.detectChanges();
    expect(cmpInstance.nimasDetails.nimasConvVendor == 7004).toBeTruthy();
    expect(cmpInstance.convVendorOther).toBeTruthy();
  });

  it('should set NIMAS Description Vendor based on search by MHID/ISBN', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.nimasDescVendorArray = testNimasDescVendorArray;
    cmpInstance.nimasDetails.nimasDescVendor = {
      lovid: 16003,
      lovType: "DESC_VENDOR",
      lovCode: "DESC_VENDOR-MHSE",
      description: "Quad Graphics",
      valueField: '',
      enabled: "Y",
      orderSeq: 4
    };
    cmpInstance.setDescriptionVendor();
    fixture.detectChanges();
    expect(cmpInstance.nimasDetails.nimasDescVendor == 16003).toBeTruthy();
  });


  it('should set "Other" in NIMAS Description Vendor based on search by MHID/ISBN', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.nimasDescVendorArray = testNimasDescVendorArray;
    cmpInstance.nimasDetails.nimasDescVendor = {
      lovid: 16004,
      lovType: "DESC_VENDOR",
      lovCode: "DESC_VENDOR-MHSE",
      description: "Other",
      valueField: '',
      enabled: "Y",
      orderSeq: 5,
      otherValue: 'test value'
    };
    cmpInstance.setDescriptionVendor();
    fixture.detectChanges();
    expect(cmpInstance.nimasDetails.nimasDescVendor == 16004).toBeTruthy();
    expect(cmpInstance.descVendorOther).toBeTruthy();
  });


  it('should fill all the required data in objects not in details', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.actualArchivistArray = testArchivistArray;
    cmpInstance.archivistArray = testArchivistArray;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.nimasSummary = new nimasSummary();
    const dummyData = {
      summary: {
        "recordid": 1304182,
        "mhid": "test-mhid",
        "isbn13": "test-isbn",
        "previousISBN": "test_pd_4_123",
        "newISBN": "test_pd_4_000",
        "author": "test prax",
        "title": "testing api part 1",
        "edition": 3,
        "priority": "test high",
        "owningDivision": "test owndiv",
        "owningSubDivision": "test own subdiv",
        "copyrightYear": 2022,
        "boundBookDate": "2022-11-20",
        "permissionEndDate": "2022-11-20",
        "projectOPDate": "2022-11-20",
        "deliveryFormat": "test delivery format 2",
        "titleTypeDesc": "test title desc 2",
        "gradeRange": "13 - 17",
        "specificMarket": "testing market",
        "ipubPublishingGroup": "test",
        "ipubProgrammingTitle": "t e s t",
        "noOfPages": 50,
        "comments": "\nfgdhyfh\ntesting comment;fdg\ntesting api update;\ntesting done by prakriti_de;\nPusti, Shuvendu 2022-9-2 15:20:47\ntestdfgdfg\ntest123dfgdfg\nkhfuhsjkdhf\nPusti, Shuvendu 2022-9-2 19:57:17\ntest123\nDe, Prakriti 2022-9-13 20:59:10\ntest\ntest2"
      },
      details: {
        "nimasid": 19700,
        "recordid": 1304182,
        "archivist": {
          lovid: 1003,
          lovType: "ARCHIVIST",
          lovCode: "ARCHIVIST-MHSE",
          description: "Andy Backs",
          valueField: '',
          enabled: "Y",
          orderSeq: 4
        },
        "coordinator": {
          lovid: 10001,
          lovType: "COORDINATOR",
          lovCode: "COORDINATOR-MHSE",
          description: "April Cleland",
          valueField: '',
          enabled: "Y",
          orderSeq: 2
        },
        "nimasCertNumber": "Testing NimasCertNumber part4",
        "nimasCertReceivedDate": "2022-06-19",
        "nimasConvVendor": {
          lovid: 7003,
          lovType: "CONV_VENDOR",
          lovCode: "CONV_VENDOR-MHSE",
          description: "Quad Graphics",
          valueField: '',
          enabled: "Y",
          orderSeq: 4,
          otherValue: 'test value',
          filesSentDate: "2022-06-19"
        },
        "nimasDescVendor": {
          lovid: 16004,
          lovType: "DESC_VENDOR",
          lovCode: "DESC_VENDOR-MHSE",
          description: "Other",
          valueField: '',
          enabled: "Y",
          orderSeq: 5,
          otherValue: "Testing Desc Vendor Other",
          filesSentDate: "2022-06-17"
        },
        "notes": "Testing Nimas creation on 09-June-2022",
        "createdDate": "2022-08-17",
        "createdBy": "De, Prakriti",
        "modifiedDate": "2022-08-17",
        "modifiedBy": "De, Prakriti"
      }
    };
    cmpInstance.fillFormSubscription(dummyData, false);
    expect(cmpInstance.searchedMHID).not.toBeNull();
  });

  it('should search using mhid', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.nimasSummary = new nimasSummary();
    cmpInstance.searchedMHID = '';
    cmpInstance.searchedISBN = '';

    cmpInstance.searchByTab('test-mhid', 'mhid', false);
    cmpInstance.searchByTab('test-isbn', 'isbn', false);
    cmpInstance.searchByTab('test-isbn', 'isbn123', false);
    // cmpInstance.searchByTab('test-mhid', 'assocId', false);
    fixture.detectChanges();
    expect(cmpInstance.nimasSummary).not.toBeNull();
  });

  it('should not search if MHID/ISBN13 are same ', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.nimasSummary = new nimasSummary();
    cmpInstance.searchedMHID = 'test-mhid';
    cmpInstance.searchedISBN = 'test-isbn';
    cmpInstance.searchByTab('test-mhid', 'mhid', false);
    fixture.detectChanges();
    expect(cmpInstance.nimasSummary).not.toBeNull();
  });

  it('should not search if MHID/ISBN13 are same and should not fetched', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.nimasSummary = new nimasSummary();
    cmpInstance.searchedMHID = 'test-mhid';
    cmpInstance.searchedISBN = 'test-isbn';
    cmpInstance.searchByTab('test-mhid', 'mhid', false);
    fixture.detectChanges();
    expect(cmpInstance.nimasSummary).not.toBeNull();
  });

  it('should load all LOVs on Page Load', async () => {
    // await dataService.loadListofLovs();
    const cmpInstance = fixture.debugElement.componentInstance;
    await cmpInstance.loadLovs();
    fixture.autoDetectChanges();
    expect(cmpInstance.archivistArray).not.toBeNull();
  });

  it('should return object of nimas Conversion Vendor from nimas Conversion Vendor is selected', async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.nimasconvVendorArray = testNimasConvVendorArray;
    cmpInstance.nimasDetails.nimasConvVendor = 7004;
    const fdata = await cmpInstance.saveConvVendor();
    fixture.detectChanges();
    expect(fdata == testNimasConvVendorArray[4]).toBeTruthy();
    expect(fdata.description == "Other").toBeTruthy();
  });

  it('should return object of nimas Conversion Vendor if nimas Conversion Vendor is selected with other value is empty', async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.nimasconvVendorArray = testNimasConvVendorArray;
    cmpInstance.nimasDetails.nimasConvVendor = 7001;
    const fdata = await cmpInstance.saveConvVendor();
    fixture.detectChanges();
    expect(fdata == testNimasConvVendorArray[1]).toBeTruthy();
    expect(fdata.description == "Laserwords").toBeTruthy();
  });

  it('should return null of nimas Conversion Vendor from nimas Conversion Vendor is empty', async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.nimasconvVendorArray = testNimasConvVendorArray;
    cmpInstance.nimasDetails.nimasConvVendor = '';
    const fdata = await cmpInstance.saveConvVendor();
    fixture.detectChanges();
    expect(fdata == null).toBeTruthy();
  });

  it('should return object of nimas Description Vendor from nimas Description Vendor is selected', async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.nimasDescVendorArray = testNimasDescVendorArray;
    cmpInstance.nimasDetails.nimasDescVendor = 16004;
    const fdata = await cmpInstance.saveDescVendor();
    fixture.detectChanges();
    expect(fdata == testNimasDescVendorArray[4]).toBeTruthy();
    expect(fdata.description == "Other").toBeTruthy();
  });

  it('should return null of nimas Conversion Vendor from nimas Conversion Vendor is empty', async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.nimasDescVendorArray = testNimasDescVendorArray;
    cmpInstance.nimasDetails.nimasDescVendor = '';
    const fdata = await cmpInstance.saveDescVendor();
    fixture.detectChanges();
    expect(fdata == null).toBeTruthy();
  });

  it('should validate MHID the required fields', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasSummary = new nimasSummary();
    cmpInstance.nimasSummary.mhid = null;
    const flag = cmpInstance.validation();
    expect(flag).toBeTruthy();
  });

  // it('should validate ISBN13 as required fields', () => {
  //   const cmpInstance = fixture.debugElement.componentInstance;
  //   cmpInstance.nimasSummary = new nimasSummary();
  //   cmpInstance.nimasSummary.mhid = 'test-mhid';
  //   cmpInstance.nimasSummary.isbn13 = null;
  //   const flag = cmpInstance.validation();
  //   expect(flag).toBeTruthy();
  // });

  it('should validate MHID/ISBN13 as required fields and return false if both are validated', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasSummary = new nimasSummary();
    cmpInstance.nimasSummary.mhid = 'test-mhid';
    cmpInstance.nimasSummary.isbn13 = 'test-isbn';
    const flag = cmpInstance.validation();
    expect(flag).toBeFalsy();
  });

  it('should return true when record Id is not available', async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails.nimasid = null;
    cmpInstance.nimasDetails.recordid = null;
    const flagNavigate = await cmpInstance.canDeactivate();
    expect(flagNavigate).toBeTruthy();
  });

  it('should save archivist object from archivist description', async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails.archivist = "1011";
    cmpInstance.archivistArray = testArchivistArray;
    const data = await cmpInstance.saveArchivist();
    const testData = {
      lovid: 1011,
      lovType: "ARCHIVIST",
      lovCode: "ARCHIVIST-MHSE",
      description: "Jeff Kemeter",
      valueField: '',
      enabled: "Y",
      orderSeq: 12
    };
    expect(JSON.stringify(data) == JSON.stringify(testData)).toBeTruthy();
  });

  it('should return Empty archivist object from archivist description if no Archivist is selected', async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails.archivist = "";
    cmpInstance.archivistArray = testArchivistArray;
    const data = await cmpInstance.saveArchivist();
    expect(data).toBeNull();
  });

  it('should save Coordinator object from Coordinator description', async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails.coordinator = "10014";
    cmpInstance.nimasCoordinatorArray = testNimasCoordinatorArray;

    const data = await cmpInstance.saveCoordinatorVendor();
    const testData = {
      lovid: 10014,
      lovType: "DESC_VENDOR",
      lovCode: "DESC_VENDOR-MHSE",
      description: "Other",
      valueField: '',
      enabled: "Y",
      orderSeq: 14,
      otherValue: "test",
    };
    expect(JSON.stringify(data) == JSON.stringify(testData)).toBeTruthy();
  });

  it('should return Empty Coordinator object from Coordinator description if no Coordinator is selected', async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails.coordinator = "";
    cmpInstance.archivistArray = testNimasCoordinatorArray;
    const data = await cmpInstance.saveCoordinatorVendor();
    expect(data).toBeNull();
  });


  it('should call submit method if all data are validated using NIMAS ID', async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasSummary = new nimasSummary();
    cmpInstance.nimasDetails = new nimasDetails();

    cmpInstance.nimasSummary = {
      "recordid": 1304182,
      "mhid": "test-mhid",
      "isbn13": "test-isbn",
      "previousISBN": "test_pd_4_123",
      "newISBN": "test_pd_4_000",
      "author": "test prax",
      "title": "testing api part 1",
      "edition": 3,
      "priority": "test high",
      "owningDivision": "test owndiv",
      "owningSubDivision": "test own subdiv",
      "copyrightYear": 2022,
      "boundBookDate": "2022-11-20",
      "permissionEndDate": "2022-11-20",
      "projectOPDate": "2022-11-20",
      "deliveryFormat": "test delivery format 2",
      "titleTypeDesc": "test title desc 2",
      "gradeRange": "13 - 17",
      "specificMarket": "testing market",
      "ipubPublishingGroup": "test",
      "ipubProgrammingTitle": "t e s t",
      "noOfPages": 50,
      "comments": "\nfgdhyfh\ntesting comment;fdg\ntesting api update;\ntesting done by prakriti_de;\nPusti, Shuvendu 2022-9-2 15:20:47\ntestdfgdfg\ntest123dfgdfg\nkhfuhsjkdhf\nPusti, Shuvendu 2022-9-2 19:57:17\ntest123\nDe, Prakriti 2022-9-13 20:59:10\ntest\ntest2"
    }

    cmpInstance.nimasDetails = {
      "nimasid": 19700,
      "recordid": 1304182,
      "archivist": 1011,
      "coordinator": 10002,
      "nimasCertNumber": "Testing NimasCertNumber part4",
      "nimasCertReceivedDate": "2022-06-19",
      "nimasConvVendor": 7004,
      "nimasDescVendor": 16004,
      "notes": "Testing Nimas creation on 09-June-2022",
      "createdDate": "2022-08-17",
      "createdBy": "De, Prakriti",
      "modifiedDate": "2022-010-21",
      "modifiedBy": "Patel, Jignesh",
      "filesConversionVendor": "2022-06-19",
      "filesDescriptionVendor": "2022-06-17"
    }

    cmpInstance.actualArchivistArray = cmpInstance.archivistArray = testArchivistArray
    cmpInstance.nimasCoordinatorArray = testNimasCoordinatorArray
    cmpInstance.nimasconvVendorArray = testNimasConvVendorArray
    cmpInstance.nimasDescVendorArray = testNimasDescVendorArray;

    const data = await cmpInstance.onSubmit();
    fixture.detectChanges();
    expect(data).not.toBeNull();
  });

  it('should return false when validation is true', async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasSummary = new nimasSummary();
    cmpInstance.nimasDetails = new nimasDetails();
    const validationFlag = await cmpInstance.onSubmit();
    expect(validationFlag).toBeFalsy();
  });

  it('should call submit method if all data are validated Without NIMAS ID', async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasSummary = new nimasSummary();
    cmpInstance.nimasDetails = new nimasDetails();

    cmpInstance.nimasSummary = {
      "recordid": 1304182,
      "mhid": "test-mhid",
      "isbn13": "test-isbn",
      "previousISBN": "test_pd_4_123",
      "newISBN": "test_pd_4_000",
      "author": "test prax",
      "title": "testing api part 1",
      "edition": 3,
      "priority": "test high",
      "owningDivision": "test owndiv",
      "owningSubDivision": "test own subdiv",
      "copyrightYear": 2022,
      "boundBookDate": "2022-11-20",
      "permissionEndDate": "2022-11-20",
      "projectOPDate": "2022-11-20",
      "deliveryFormat": "test delivery format 2",
      "titleTypeDesc": "test title desc 2",
      "gradeRange": "13 - 17",
      "specificMarket": "testing market",
      "ipubPublishingGroup": "test",
      "ipubProgrammingTitle": "t e s t",
      "noOfPages": 50,
      "comments": "\nfgdhyfh\ntesting comment;fdg\ntesting api update;\ntesting done by prakriti_de;\nPusti, Shuvendu 2022-9-2 15:20:47\ntestdfgdfg\ntest123dfgdfg\nkhfuhsjkdhf\nPusti, Shuvendu 2022-9-2 19:57:17\ntest123\nDe, Prakriti 2022-9-13 20:59:10\ntest\ntest2"
    }

    cmpInstance.actualArchivistArray = cmpInstance.archivistArray = testArchivistArray
    cmpInstance.nimasCoordinatorArray = testNimasCoordinatorArray
    cmpInstance.nimasconvVendorArray = testNimasConvVendorArray
    cmpInstance.nimasDescVendorArray = testNimasDescVendorArray;

    const data = await cmpInstance.onSubmit();
    fixture.detectChanges();
    expect(data).not.toBeNull();
  });

  it('should reset or empty nimas details', async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.nimasDetails = new nimasDetails();
    cmpInstance.nimasDetails = {
      "nimasid": 19700,
      "recordid": 1304182,
      "archivist": 1011,
      "coordinator": 10002,
      "nimasCertNumber": "Testing NimasCertNumber part4",
      "nimasCertReceivedDate": "2022-06-19",
      "nimasConvVendor": 7004,
      "nimasDescVendor": 16004,
      "notes": "Testing Nimas creation on 09-June-2022",
      "createdDate": "2022-08-17",
      "createdBy": "De, Prakriti",
      "modifiedDate": "2022-010-21",
      "modifiedBy": "Patel, Jignesh",
      "filesConversionVendor": "2022-06-19",
      "filesDescriptionVendor": "2022-06-17"
    }

    cmpInstance.resetDetails();
    fixture.detectChanges();
    expect(cmpInstance.nimasDetails.archivist).toBe('');
    expect(cmpInstance.nimasDetails.productNotes).toBe('');
    expect(cmpInstance.nimasDetails.nimasid).toBe(0);
    expect(cmpInstance.nimasDetails.nimasCertiReceived).toBe('');
    expect(cmpInstance.nimasDetails.nimasCertiReceived).toBe('');
  })


});


