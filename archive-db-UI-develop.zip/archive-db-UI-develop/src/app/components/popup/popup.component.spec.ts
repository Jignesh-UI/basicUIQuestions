import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { NgbModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { PopupComponent } from './popup.component';

export class MockNgbModalRef {
  result: Promise<any> = new Promise((resolve, reject) => resolve('x'));
}

describe('PopupComponent', () => {
  let component: PopupComponent;
  let fixture: ComponentFixture<PopupComponent>;
  const mockModalRef: MockNgbModalRef = new MockNgbModalRef();
  let modalService: NgbModal;
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [PopupComponent],
      imports: [NgbModule],
      schemas: [NO_ERRORS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    modalService = TestBed.get(NgbModal);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should clear and close', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.clearAndClosePopUp();
    expect(cmpInstance.instruction == "").toBeTruthy();
  });

  it('should prevent default when entering space first character!', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    const event = new KeyboardEvent("keydown", {
      "key": "space"
    });
    cmpInstance.instructionChange(event);
    expect(cmpInstance.instruction == "").toBeTruthy();
  });

  it('should add content to the instruction', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.onAdd("this is the sample text!");
    expect(cmpInstance.instruction == "").toBeTruthy();
  });

  it('should open modal!', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.open("this is the sample text!");
    cmpInstance.disabledInitially = true;
    expect(cmpInstance.instruction == "").toBeTruthy();
  });

});
