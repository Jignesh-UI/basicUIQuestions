import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-record-information',
  templateUrl: './record-information.component.html',
  styleUrls: ['./record-information.component.css']
})
export class RecordInformationComponent{

  @Input() recInfoData: any = ''; //Data will received from Parent Component
  @Input() uniqueIdTitle ='';

}
