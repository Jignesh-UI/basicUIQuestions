import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { saveAs as importedSaveAs } from 'file-saver';
import { ReportService } from 'src/app/service/reports.service';
import { ComponentService } from 'src/app/service/component.service';
import { OktaInfoService } from 'src/app/shared/okta/okta-info.service';
import { LovDataService } from 'src/app/service/commonClasses/lov-data.service';
import { NotificationService } from 'src/app/service/notification.service';
import { APP_Messages } from 'src/app/service/commonClasses/app-defaults';
import { colProperties, DisplayColumns } from 'src/app/service/models/reports.model';
import { reportParamsInterface } from 'src/app/service/models/common.model';


@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {


  isLoading = false;
  showSearch = false;

  selecteTableDrp = '';

  columns = [];
  selectedColumns = [];
  displayColumns = [];
  properties: reportParamsInterface[] = [
    { order: 1, propertyName: '', condition: '', operator: '', value: '', properties: [], condtions: [], drpvalues: [] }
  ];
  displaySelected: any[];
  message = "";
  isError: boolean;
  today: string;
  referenceProp = [];
  userName: string;
  dropDownOptions = ['ARCHIVIST', 'STORAGE_LOCATION', 'IN_PROCESS', 'REQUESTEDFILES'];
  searchPageArray: any[] = [];
  searchPropertiesArray: any[] = [];


  constructor(private oktaService: OktaInfoService, private activatedRoute: ActivatedRoute, private http: HttpClient,
    private reportService: ReportService,
    private communicationService: ComponentService,
    private lovData: LovDataService,
    private notify: NotificationService) {

    const today = new Date();
    const date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    const time = today.getHours() + ':' + today.getMinutes() + ':' + today.getSeconds();
    const dateTime = date + ' ' + time;
    this.today = dateTime;
  }

  async ngOnInit() {
    const promise = await this.oktaService.GetOktUserInfo();
    const user = promise['claims']['name'];
    this.userName = user;
    this.properties = [
      { order: 1, propertyName: '', condition: '', operator: '', value: '', properties: [], condtions: [], drpvalues: [] }];
    await this.loadLovs();
  }

  onAddProperty() {
    if (this.properties.length <= 14) {
      this.properties.push({
        order: this.properties.length + 1,
        propertyName: '',
        condition: '',
        operator: '',
        value: '',
        properties: { text: '', value: '' },
        drpvalues: []
      });
    }
  }


  onTableChange(ctrl: any, obj: any) {
    const filterValue = ctrl.currentTarget.options[ctrl.currentTarget.selectedIndex].value.trim().replace("_", " ");
    obj.isDropdown = false;
    obj.isDateProperty = false;
    this.columns = [];
    this.displayColumns = [];
    this.selectedColumns = [];
    this.displaySelected = [];
    if (filterValue == "-1") {
      this.searchPropertiesArray = [];
      this.properties = [{ order: 1, propertyName: '', condition: '', operator: '', value: '', properties: [], condtions: [], drpvalues: [] }];
      this.notify.showSuccess('', APP_Messages.selectPage);
      return false;
    }
    this.isLoading = true;
    let getPropertyArray: any;
    if (filterValue === 'Archive Record') {
      getPropertyArray = [...this.lovData.returnSingleLOV('COMMON_CRITERIA'), ...this.lovData.returnSingleLOV('ARCHIVE_RECORD_CRITERIA')];
      this.adjustProperties(getPropertyArray);
    } else if (filterValue === 'Archive Request') {
      getPropertyArray = [...this.lovData.returnSingleLOV('COMMON_CRITERIA'), ...this.lovData.returnSingleLOV('ARCHIVE_REQUEST_CRITERIA')];
      this.adjustProperties(getPropertyArray);
    } else if (filterValue === 'Associated') {
      getPropertyArray = [...this.lovData.returnSingleLOV('COMMON_CRITERIA'), ...this.lovData.returnSingleLOV('ASSOCIATED_CRITERIA')];
      this.adjustProperties(getPropertyArray);
    } else if (filterValue === 'NIMAS') {
      getPropertyArray = [...this.lovData.returnSingleLOV('COMMON_CRITERIA'), ...this.lovData.returnSingleLOV('NIMAS_CRITERIA')];
      this.adjustProperties(getPropertyArray);
    } else {
      this.columns = [];
      this.searchPropertiesArray = [];
      this.properties = [{ order: 1, propertyName: '', condition: '', operator: '', value: '', properties: [], condtions: [], drpvalues: [] }];
    }

    this.columns = getPropertyArray;
    this.sortAvailableColumns()
    this.searchPropertiesArray = getPropertyArray;
    this.isLoading = false;
  }

  adjustProperties(paramdata: any[]) {
    this.properties = [{
      order: 1, propertyName: '', condition: '', operator: '',
      value: '', properties: paramdata,
      conditions: [], isDateProperty: false
    }];
  }

  onPropertyChange(obj: any) {
    obj.condition = '';
    obj.conditions = [];
    if (obj.propertyName == null || obj.propertyName == '') {
      this.notify.showSuccess('', APP_Messages.selectPropertyName);
      return false;
    }
    this.isLoading = true;

    const filterConditionType = this.searchPropertiesArray.filter(svalue => {
      if (svalue.valueField == obj.propertyName) {
        return svalue.valueField;
      }
    })[0].lovCode;

    if (filterConditionType.search('NUMBER') > 0) {
      obj.conditions = this.lovData.returnSingleLOV('CONTAINS_VALUES_NUMBER');
      obj.isDateProperty = false;
    } else if (filterConditionType.search('STRING') > 0) {
      obj.conditions = this.lovData.returnSingleLOV('CONTAINS_VALUES_STRING');
      obj.isDateProperty = false;
    } else if (filterConditionType.search('DATE') > 0) {
      obj.conditions = this.lovData.returnSingleLOV('CONTAINS_VALUES_DATE');
      obj.isDateProperty = true;
    } else {
      this.notify.showSuccess('', APP_Messages.differentCriteria);
    }
    obj.isDropdown = false;
    obj.condition = obj.conditions[0].value;
    this.isLoading = false;
  }

  onConditionChange(obj: any) {
    if (this.dropDownOptions.indexOf(obj.propertyName) >= 0 && obj.condition.trim().toLowerCase() == "equals") {
      this.isLoading = true;
      this.drpDataFilled(obj);
      obj.isDropdown = true;
      this.isLoading = false;
    } else {
      obj.isDropdown = false;
    }
  }

  drpDataFilled(propObj: any) {
    if (propObj.propertyName == "ARCHIVIST") {
      const newDataArray = this.lovData.returnSingleLOV(propObj.propertyName);
      propObj.drpvalues = newDataArray.map(v => {
        return { text: v.description, value: v.description }
      });
    } else if (propObj.propertyName == "STORAGE_LOCATION") {
      const newDataArray = this.lovData.returnSingleLOV(propObj.propertyName);
      propObj.drpvalues = newDataArray.map(v => {
        return { text: v.description, value: v.description }
      });
    } else if (propObj.propertyName == "IN_PROCESS") {
      propObj.drpvalues = [{ text: 'Yes', value: 'Y' }, { text: 'No', value: 'N' }];
    } else if (propObj.propertyName == 'REQUESTEDFILES') {
      const newDataArray = [...this.lovData.returnSingleLOV('PDFS'), ...this.lovData.returnSingleLOV('REQUESTEDFILES')];
      propObj.drpvalues = newDataArray.map(v => {
        return { text: v.description, value: v.description }
      });
    }
  }

  onClear() {
    this.selecteTableDrp = '-1';
    this.properties = [{ order: 1, propertyName: '', condition: '', operator: '', value: '', properties: [], condtions: [] }];
    this.columns = [];
    this.selectedColumns = [];
    this.displayColumns = [];
    this.displaySelected = [];
    this.message = '';
    this.isError = false;
  }

  onRemoveProperty(obj: any) {
    if (obj.order !== 1) {
      this.properties = this.properties.filter((prop: any) => prop !== obj);
    }
  }

  moveToSelected() {
    const selectedObjs = this.columns.filter(col => this.selectedColumns.indexOf(col.valueField) >= 0);
    this.columns = this.columns.filter(col => this.selectedColumns.indexOf(col.valueField) < 0);
    this.displayColumns = this.displayColumns.concat(selectedObjs);
    this.selectedColumns = this.displayColumns.map(dc => dc.valueField);
  }

  moveToAvailable() {
    if (!this.displaySelected) {
      return false;
    }
    for (let i = 0; i < this.displaySelected.length; i++) {
      const element = this.displayColumns.filter(col => this.displaySelected.indexOf(col.valueField) >= 0);
      this.columns.splice(2, 0, element[i]);
    }
    // this.columns.sort(col => col.description);
    this.displayColumns = this.displayColumns.filter(col => this.displaySelected.indexOf(col.valueField) < 0);
    this.displaySelected = undefined;
    this.selectedColumns = undefined;
    this.sortAvailableColumns();
  }

  sortAvailableColumns() {
    const data0: colProperties[] = [];
    const data1: colProperties[] = [];
    const data2: colProperties[] = [];

    this.columns.forEach((v: colProperties) => {
      if (v.description == "MHID" || v.description == "ISBN-13") {
        data0.push(v);
      } else {
        if (v.lovType == "COMMON_CRITERIA") {
          data1.push(v);
        } else {
          data2.push(v);
        }
      }
    });

    data0.sort((a, b) => {
      return b.description.localeCompare(a.description)
    });

    data1.sort((a, b) => {
      return a.description.localeCompare(b.description)
    });

    data2.sort((a, b) => {
      return a.description.localeCompare(b.description)
    });

    this.columns = [];
    this.columns.push(...data0, ...data1, ...data2);

  }

  createReport() {
    this.isLoading = true;
    const cloneColumns = this.adjustDisplayedColumns();
    if (!this.searchStringErrorHandler(this.selecteTableDrp, cloneColumns, this.properties)) {
      this.isLoading = false;
      return false;
    }

    this.reportService.createReport(this.selecteTableDrp, cloneColumns, this.properties)
      .subscribe(response => {
        importedSaveAs(response, `Report_${this.today}.xlsx`);
        this.isLoading = false;
      }, error => {
        this.isLoading = false;
        this.notify.showSuccess('', APP_Messages.ServerErrorMessage);
      });
  }

  adjustDisplayedColumns() {
    return this.displayColumns.map((dc, index) => [{
      "order": index, "propertyName": dc.valueField, "displayName": dc.description
    }][0]);
  }

  saveReport(reportName: any) {
    const cloneColumns = this.adjustDisplayedColumns();
    if (!this.searchStringErrorHandler(this.selecteTableDrp, cloneColumns, this.properties, true)) {
      this.isLoading = false;
      return false;
    }
    this.isLoading = true;
    this.reportService.saveReport(this.userName, this.selecteTableDrp, cloneColumns, this.properties, reportName)
      .subscribe(response => {
        this.notify.showSuccess('', response['message']);
        this.isLoading = false;
      }, err => {
        this.isLoading = false;
        this.notify.showSuccess('', APP_Messages.ServerErrorMessage);
      });
  }

  moveUp() {
    let isUndefined: any;
    if (this.displaySelected.length === this.displayColumns.length) {
      return;
    } else {
      for (let i = 0; i < this.displaySelected.length; i++) {
        for (let j = 0; j < this.displayColumns.length; j++) {
          if (this.displaySelected[i] === this.displayColumns[j].valueField) {
            const temp = this.displayColumns[j - 1];
            isUndefined = temp;
            if (isUndefined !== undefined) {
              this.displayColumns[j - 1] = this.displayColumns[j];
              this.displayColumns[j] = temp;
            } else {
              break;
            }
          }
        }
        if (isUndefined === undefined) {
          break;
        }
      }
      this.selectedColumns = this.displayColumns.map(dc => dc.valueField);
    }
  }

  moveDown() {
    let isUndefined: any;
    if (this.displaySelected.length === this.displayColumns.length) {
      return;
    } else {
      for (let j = this.displaySelected.length - 1; j >= 0; j--) {
        for (let i = this.displayColumns.length - 1; i >= 0; i--) {
          if (this.displayColumns[i].valueField === this.displaySelected[j]) {
            const temp = this.displayColumns[i + 1];
            isUndefined = temp;
            if (isUndefined !== undefined) {
              this.displayColumns[i + 1] = this.displayColumns[i];
              this.displayColumns[i] = temp;
            } else {
              break;
            }

          }
        }
        if (isUndefined === undefined) {
          break;
        }
      }
      this.selectedColumns = this.displayColumns.map(dc => dc.valueField);
    }
  }

  async loadLovs() {
    this.searchPageArray = this.lovData.returnSingleLOV('SEARCH_TYPE');
    this.selecteTableDrp = '-1';
  }

  searchStringErrorHandler(selecteTable: string, selectedColumns: DisplayColumns[], properties: object[], fromSaveReport = false) {
    let searchFlag = false;

    if (selecteTable == '-1' || selecteTable == null || selecteTable == undefined) {
      searchFlag = true;
      this.notify.showSuccess('', fromSaveReport ? APP_Messages.selectSaveRptPage : APP_Messages.selectPage);
      return false;
    }

    properties.forEach((element: { propertyName: string; condition: string; value: string; order: number; operator: string; }) => {
      if (element.propertyName == null || element.propertyName == undefined || element.propertyName == '') {
        searchFlag = true;
        this.notify.showSuccess('', fromSaveReport ? APP_Messages.selectSaveRptPropertyName : APP_Messages.selectPropertyName);
        return false;
      } else if (element.condition == null || element.condition == undefined || element.condition == '') {
        searchFlag = true;
        this.notify.showSuccess('', fromSaveReport ? APP_Messages.selectSaveRptContains : APP_Messages.selectContains);
        return false;
      } else if ((element.condition != 'isNotNull' && element.condition != 'isNull') && (element.value == null || element.value == undefined || element.value == '' || element.value.trim().length < 1)) {
        searchFlag = true;
        this.notify.showSuccess('', fromSaveReport ? APP_Messages.enterSaveRptValue : APP_Messages.enterValue);
        return false;
      } else if (element.order > 1) {
        if (element.operator == null || element.operator == undefined || element.operator == '') {
          searchFlag = true;
          this.notify.showSuccess('', fromSaveReport ? APP_Messages.selectSaveRptOperator : APP_Messages.selectOperator);
          return false;
        }
      }
    })

    if (!searchFlag) {
      if (selectedColumns == null || selectedColumns == undefined || selectedColumns.length < 1) {
        searchFlag = true;
        this.notify.showSuccess('', fromSaveReport ? APP_Messages.selectSaveRptColumns : APP_Messages.selectColumns);
        return false;
      }
    }

    if (searchFlag) {
      return false;
    }
    return true;

  }

}
