import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { ComponentService } from 'src/app/service/component.service';
import { OktaInfoService } from 'src/app/shared/okta/okta-info.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-search-result',
  templateUrl: './search-result.component.html',
  styleUrls: ['./search-result.component.css']
})
export class SearchResultComponent implements OnInit {
  searchCriteria = [];
  searchType = '';
  message = '';
  iserror = false;
  userName: string;
  email: string;
  requsetjson = {
    pageNumber: 1,
    totalCount: 0,
    totalPages: 0,
    fields: ''
  };


  // ArchiveDB

  columnDefs;

  // rowData: any[];

  rowData;
  gridOptions: any;
  constructor(
    private http: HttpClient,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private oktaService: OktaInfoService,
    private communicationService: ComponentService) {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
  }

  async ngOnInit() {
    const promise = await this.oktaService.GetOktUserInfo();
    const user = promise['claims']['email'];
    this.userName = user;

    const keyword = this.activatedRoute.snapshot.paramMap.get('keyword');
    if (keyword != null) {
      const url = environment.baseAPIUrl + 'services/search/keyword/' + keyword;
      this.http.get(url).subscribe(response => {
        this.columnDefs = [
          { headerName: 'System ID', field: 'recordID', width: 100, sortable: true },
          { headerName: 'MHID', field: 'isbn', width: 100, sortable: true },
          { headerName: 'Author Name', field: 'authorLastname', width: 200, sortable: true },
          { headerName: 'Copyright Year', field: 'copyrightyear', width: 150, sortable: true },
          { headerName: 'Title', field: 'maintitle', width: 300, sortable: true },
          // {headerName: 'Sub-Title', field: 'subtitle' , width: 200, sortable: true},
          { headerName: 'Edition', field: 'edition', width: 200, sortable: true },
          { headerName: 'Check In Name', field: 'checkinname', width: 200, sortable: true },
        ];
        this.rowData = response['data'];
      });

    }
    if (!keyword) {
      this.communicationService.searchCriteria.subscribe((search) => {
        if (Object.keys(search).length === 0) {
          this.router.navigate(['/searchhistory']);
        }
        this.requsetjson.fields = search['fields'];

        this.searchType = search['searchType'];
        if (this.searchType === 'ARCHIVEWIP') {
          this.columnDefs = [

            { headerName: 'Task ID', field: 'taskid', width: 100, sortable: true },
            { headerName: 'MHID', field: 'isbn', width: 100, sortable: true },
            { headerName: 'Request Received', field: 'archWIPDate', sortable: true },
            { headerName: 'Author Name', field: 'authors', sortable: true },
            { headerName: 'Title', field: 'title', width: 450, sortable: true },
            { headerName: 'Copyright Year', field: 'copyright', width: 125, sortable: true },
            { headerName: 'Due Date', field: 'dueDate', width: 100, sortable: true },
            { headerName: 'Task Type', field: 'task', sortable: true },
            { headerName: 'Requestor', field: 'requestor', sortable: true }
          ];
          const url:string = environment.baseAPIUrl + 'services/search/wip';
          this.http.post(url, this.requsetjson).subscribe(response => {
            if (response['data'] != null) {
              console.log(response);
              this.rowData = response['data']['searchResults'];
            } else {
              this.rowData = [];
            }
          });
        } else if ((this.searchType === 'ARCHIVERECORD')) {
          this.columnDefs = [
            { headerName: 'System ID', field: 'recordID', width: 100, sortable: true },
            { headerName: 'MHID', field: 'isbn', width: 100, sortable: true },
            { headerName: 'Request Received', field: 'archWIPDate', width: 150, sortable: true },
            { headerName: 'Author Name', field: 'authorLastname', width: 120, sortable: true },
            { headerName: 'Title', field: 'maintitle', width: 450, sortable: true },
            // {headerName: 'Sub-Title', field: 'subtitle' , width: 230, sortable: true},
            { headerName: 'Copyright Year', field: 'copyrightyear', width: 125, sortable: true },
            { headerName: 'Edition', field: 'edition', sortable: true },
            { headerName: 'Requestor', field: 'checkinname', sortable: true }
          ];
          const url:string = environment.baseAPIUrl + 'services/search/archiverecord';
          this.http.post(url, this.requsetjson).subscribe(response => {
            if (response['data'] != null) {
              console.log(response);
              this.rowData = response['data']['searchResults'];
            } else {

              this.rowData = [];
            }
          });
        }
      })
    }
  }
  onRowClicked(params: any) {
    if (this.searchType == 'ARCHIVEWIP') {
      this.router.navigate(['/wip/' + params.data['taskid']]);
    } else {
      this.router.navigate(['/archiverecord/' + params.data['recordID']]);
    }
  }

  onSave(searchName: any) {
    const url = environment.baseAPIUrl + 'services/savedsearches/create';
    const request = {
      id: 0,
      searchName: searchName,
      createdBy: this.userName,
      createdDate: null,
      searchType: this.searchType,
      fields: this.requsetjson.fields
    };
    this.http.post(url, request).subscribe(response => {
      this.message = response['message'];
      this.iserror = !response['succeeded'];

    });
  }


}
