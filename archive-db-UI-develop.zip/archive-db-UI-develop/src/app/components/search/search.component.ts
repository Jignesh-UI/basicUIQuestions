import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ComponentService } from 'src/app/service/component.service';
import { OktaAuthService } from 'src/app/service/okta-auth.service';
import { CommonService } from 'src/app/service/commonClasses/common.service';
import { OktaInfoService } from 'src/app/shared/okta/okta-info.service';
import { LovDataService } from 'src/app/service/commonClasses/lov-data.service';
import { NotificationService } from 'src/app/service/notification.service';
import { FluidHeightDirective } from '../../service/directives/fluid-height.directive';
import { APP_Messages } from 'src/app/service/commonClasses/app-defaults';
import { HttpResponse } from 'src/app/shared/response.model';
import { columnInterface, pageSizeProperties } from 'src/app/service/models/search.model';
import { searchParamsInterface } from 'src/app/service/models/common.model';
import { environment } from 'src/environments/environment';


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  @ViewChild(FluidHeightDirective) setHeight: FluidHeightDirective;

  isLoading = false;
  searchPageArray: any[] = [];
  searchPropertiesArray: any[] = [];

  showSearch = false;
  showSearchResultContainer = false;

  selecteTableDrp = '';

  userName = '';
  isDropdown = false;
  dropDownOptions = ['ARCHIVIST', 'STORAGE_LOCATION', 'IN_PROCESS', 'REQUESTEDFILES'];
  properties: searchParamsInterface[] = this.resetProperties();

  searchType = '';
  message = '';
  iserror = false;
  userNameSR: string;
  email: string;

  columnDefs: columnInterface[] = [
    { headerName: 'System ID', field: 'SYSTEMID', width: 100, order: '' },
    { headerName: 'MHID', field: 'MHID', width: 130, order: 'asc' },
    { headerName: 'ISBN-13', field: 'ISBN13', width: 130, order: '' },
    { headerName: 'Author', field: 'AUTHOR', width: 170, order: '' },
    { headerName: 'Marketing Title', field: 'TITLE', width: 200, order: '' },
    { headerName: 'Edition', field: 'EDITION', width: 80, order: '' },
    { headerName: 'Copyright', field: 'COPYRIGHTYEAR', width: 80, order: '' },
    { headerName: 'Date Received', field: 'REQUEST_RECEIVED_DATE', width: 120, order: '' },
    { headerName: 'Due Date', field: 'DUE_DATE', width: 120, order: '' },
    { headerName: 'Files Requested', field: 'AGG_PAGINGFILES||AGG_OTHERFILES||AGG_PDFFILES||AGG_REQUESTEDFILES', width: 150, order: '' },
    { headerName: 'Requestor', field: 'REQUESTED_BY', width: 150, order: '' },
    { headerName: 'Archivist', field: 'ARCHIVIST', width: 150, order: '' },
    { headerName: 'Owning Division', field: 'OWNDIV', width: 120, order: '' },
    { headerName: 'Publication Status', field: 'PRIORITY', width: 130, order: '' },
    { headerName: 'Grade Range', field: 'GRADE_RANGE', width: 100, order: '' },
    { headerName: 'Specific Market', field: 'SPECIFIC_MARKET', width: 110, order: '' },
    { headerName: 'Title Type', field: 'TITLE_TYPE_DESC', width: 200, order: '' }
  ];

  rowData?: any[] | null;
  sortOrderType = "";
  sortField = "";

  pageSize: pageSizeProperties[] = [];
  pageSizeSelect: pageSizeProperties[] = [];
  totalPagesCount = 0;
  featchedRecords = 0;

  paginationSelect: any;

  url = environment.baseAPIUrl + 'services/searches';

  constructor(private http: HttpClient,
    private router: Router,
    private commuincationService: ComponentService,
    public oktaAuth: OktaAuthService,
    private cs: CommonService,
    private oktaService: OktaInfoService,
    private lovData: LovDataService,
    private notify: NotificationService,
    private activatedRoute: ActivatedRoute) {

    // this.isLoading = true;
    this.commuincationService.searchCriteria.subscribe((search) => {

      if (search['searchSummary'] && search['searchFields']) {
        if (!this.searchPropertiesChecking(search)) {
          return false;
        }

        if (this.selecteTableDrp == null || this.selecteTableDrp == undefined || this.selecteTableDrp == "") {
          this.onTableChange(null, search['searchSummary'].searchType, search['searchFields']);
          this.selecteTableDrp = search['searchSummary'].searchType
        }

        search['searchFields'].forEach((v) => {
          if (v.isDropdown) {
            this.drpDataFilled(v);
          }
        });

        this.searchType = search['searchSummary'].searchType;
        this.properties = search['searchFields'];

        this.sortField = search['searchSummary'].sortBy;
        this.totalPagesCount = search['searchSummary'].totalCount;
        this.sortOrderType = search['searchSummary'].sortOrder;
        this.searchResultClicked(search);
      }

    });
    // this.isLoading = false;
  }

  async ngOnInit() {
    // this.isLoading = true;
    const promise = this.oktaService.GetOktUserInfo();
    const info = await promise;
    this.userNameSR = info['claims']['name'];
    this.userName = sessionStorage.getItem('userName');
    await this.loadLovs();
    const keyword = this.activatedRoute.snapshot.paramMap.get('keyword');
    if (keyword != null || keyword) {
      this.properties = this.resetProperties();
      this.showSearchResultContainer = false;
      this.rowData = [];
      const url = environment.baseAPIUrl + 'services//savedSearches/savedSearchId/' + keyword;
      this.http.get<HttpResponse>(url).subscribe(response => {
        const clone: {} = {};

        clone['searchSummary'] = response.data['searchSummary'];
        clone['searchFields'] = JSON.parse(JSON.stringify(response.data['searchFields']));

        this.selecteTableDrp = clone['searchSummary'].searchType;
        this.onTableChange(null, clone['searchSummary'].searchType, clone['searchFields']);
        clone['searchFields'].forEach(element => {
          this.onPropertyChange(element)
        });
        this.commuincationService.changeMessage(clone);
      });
    }
    // this.isLoading = false;
  }

  onAddProperty() {
    if (this.properties.length <= 14) {
      this.properties.push({
        order: this.properties.length + 1,
        propertyName: '',
        condition: '',
        operator: '',
        value: '',
        properties: '', //this.selecteTableDrp === 'ARCHIVEWIP' ? SearchOptions.wipProperties : SearchOptions.archiveProperties
        drpvalues: []
      });
    }
  }

  onTableChange(ctrl: any, dtvalue: string = null, obj: any = null) {
    let filterValue = '';

    if (dtvalue != null) {
      filterValue = dtvalue.replace("_", " ");
    } else {
      filterValue = ctrl.currentTarget.options[ctrl.currentTarget.selectedIndex].value.trim().replace("_", " ");
    }

    if (filterValue == "-1") {
      this.searchPropertiesArray = [];
      this.properties = this.resetProperties();
      this.notify.showSuccess('', APP_Messages.selectPage);
      return false;
    }

    this.isLoading = true;
    obj.isDropdown = false;
    obj.isDateProperty = false;

    let getPropertyArray: any;
    if (filterValue === 'Archive Record') {
      getPropertyArray = [...this.lovData.returnSingleLOV('COMMON_CRITERIA'), ...this.lovData.returnSingleLOV('ARCHIVE_RECORD_CRITERIA')];
      this.adjustProperties(getPropertyArray);
    } else if (filterValue === 'Archive Request') {
      getPropertyArray = [...this.lovData.returnSingleLOV('COMMON_CRITERIA'), ...this.lovData.returnSingleLOV('ARCHIVE_REQUEST_CRITERIA')];
      this.adjustProperties(getPropertyArray);
    } else if (filterValue === 'Associated') {
      getPropertyArray = [...this.lovData.returnSingleLOV('COMMON_CRITERIA'), ...this.lovData.returnSingleLOV('ASSOCIATED_CRITERIA')];
      this.adjustProperties(getPropertyArray);
    } else if (filterValue === 'NIMAS') {
      getPropertyArray = [...this.lovData.returnSingleLOV('COMMON_CRITERIA'), ...this.lovData.returnSingleLOV('NIMAS_CRITERIA')];
      this.adjustProperties(getPropertyArray);
    } else {
      this.searchPropertiesArray = [];
      this.properties = this.resetProperties();
    }
    this.searchPropertiesArray = getPropertyArray;
    this.isLoading = false;
    this.searchType = this.selecteTableDrp;
  }

  resetProperties() {
    return [{ order: 1, propertyName: '', condition: '', operator: '', value: '', properties: [], condtions: [], drpvalues: [] }];
  }

  adjustProperties(paramdata: any[]) {
    this.properties = [{
      order: 1, propertyName: '', condition: '', operator: '',
      value: '', properties: paramdata,
      conditions: [], isDateProperty: false
    }];
  }

  onPropertyChange(obj: any) {
    // obj.condition = '';
    obj.conditions = [];
    if (obj.propertyName == null || obj.propertyName == '') {
      this.notify.showSuccess('', APP_Messages.selectPropertyName);
      return false;
    }

    this.isLoading = true;

    const filterConditionType = this.searchPropertiesArray.filter(svalue => {
      if (svalue.valueField == obj.propertyName) {
        return svalue.valueField;
      }
    })[0].lovCode;

    if (filterConditionType.search('NUMBER') > 0) {
      obj.conditions = this.lovData.returnSingleLOV('CONTAINS_VALUES_NUMBER');
      obj.isDateProperty = false;
    } else if (filterConditionType.search('STRING') > 0) {
      obj.conditions = this.lovData.returnSingleLOV('CONTAINS_VALUES_STRING');
      obj.isDateProperty = false;
    } else if (filterConditionType.search('DATE') > 0) {
      obj.conditions = this.lovData.returnSingleLOV('CONTAINS_VALUES_DATE');
      obj.isDateProperty = true;
    } else {
      this.notify.showSuccess('', APP_Messages.differentCriteria);
    }

    obj.isDropdown = false;
    if (obj.conditions[0].value) {
      obj.condition = obj.conditions[0].value;
    }
    this.isLoading = false;
  }

  onConditionChange(obj: any) {
    if (this.dropDownOptions.indexOf(obj.propertyName) >= 0 && obj.condition.trim().toLowerCase() == "equals") {
      this.isLoading = true;
      this.drpDataFilled(obj);
      obj.isDropdown = true;
      this.isLoading = false;
    } else {
      obj.isDropdown = false;
    }
  }

  drpDataFilled(propObj: any) {
    if (propObj.propertyName == "ARCHIVIST") {
      const newDataArray = this.lovData.returnSingleLOV(propObj.propertyName);
      propObj.drpvalues = newDataArray.map(v => {
        return { text: v.description, value: v.description }
      });
    } else if (propObj.propertyName == "STORAGE_LOCATION") {
      const newDataArray = this.lovData.returnSingleLOV(propObj.propertyName);
      propObj.drpvalues = newDataArray.map(v => {
        return { text: v.description, value: v.description }
      });
    } else if (propObj.propertyName == "IN_PROCESS") {
      propObj.drpvalues = [{ text: 'Yes', value: 'Y' }, { text: 'No', value: 'N' }];
    } else if (propObj.propertyName == 'REQUESTEDFILES') {
      const newDataArray = [...this.lovData.returnSingleLOV('REQUESTEDFILES')];
      propObj.drpvalues = newDataArray.map(v => {
        return { text: v.description, value: v.description }
      });
    }
  }

  onClear() {
    this.selecteTableDrp = '';
    this.properties = [{ order: 1, propertyName: '', condition: '', operator: '', value: '', properties: [], condtions: [] }];
  }

  onRemoveProperty(obj: any) {
    if (obj.order !== 1) {
      this.properties = this.properties.filter(prop => prop !== obj);
    }
  }

  onSearch() {
    this.sortOrderType = "";
    this.sortField = "";
    const clone: {} = this.searchQuery();
    if (!this.searchStringErrorHandler(clone)) {
      return false;
    } else {
      this.commuincationService.changeMessage(clone);
    }

  }

  showSearchSection() {
    this.showSearch = !this.showSearch;
    this.setHeight.setHeight();
  }

  searchResultClicked(requestedData: any) {
    this.isLoading = true;
    this.showSearchResultContainer = true;
    this.http.post(this.url, requestedData).subscribe(response => {

      if (response['data']) {
        if (response['data']['searchResults'].length > 0) {
          this.featchedRecords = response['data'].searchSummary.totalCount;
          this.rowData = response['data']['searchResults'];
          this.adjustSorting(response['data'].searchSummary.sortBy, response['data'].searchSummary.sortOrder);
          this.adjustPagination(response['data']['searchSummary'].pageNumber, response['data']['searchSummary'].pageSize, response['data']['searchSummary'].totalCount);
          this.setHeight?.setHeight();
        } else {
          this.resetRowsWithMessage(response['message']);
          this.pageSize = [];
          this.pageSizeSelect = [];
          this.featchedRecords = 0;
        }
      } else {
        this.resetRowsWithMessage(response['message']);
        this.pageSize = [];
        this.pageSizeSelect = [];
        this.featchedRecords = 0;
      }
      this.isLoading = false;
    }, err => {
      this.isLoading = false;
      this.notify.showSuccess('', APP_Messages.ServerErrorMessage);
    });

  }

  resetRowsWithMessage(msgResponse: string) {
    this.rowData = [];
    this.notify.showSuccess('', msgResponse)
  }

  onRowClicked(params: any) {
    if (this.searchType == 'Archive_Record') {
      this.router.navigate(['archiveRec', params.systemid]);
    } else if (this.searchType == 'Archive_Request') {
      this.router.navigate(['archiveReq', params.systemid]);
    } else if (this.searchType == 'Associated') {
      this.router.navigate(['associatedRecord', `associatedid&${params.systemid}`]);
    } else if (this.searchType == 'NIMAS') {
      this.router.navigate(['nimas', params.systemid]);
    }
  }

  onHeaderClicked(params: columnInterface) {
    this.sortField = params.field;
    if (params.order == "asc") {
      this.sortOrderType = "desc"
    } else if (params.order == "desc") {
      this.sortOrderType = "asc"
    } else {
      this.sortOrderType = "asc"
    }

    const clone: {} = this.searchQuery();
    this.commuincationService.changeMessage(clone);
    // this.searchResultClicked(clone);
  }

  onSave(searchName: any) {
    this.isLoading = true;
    const clone: {} = this.searchQuery();
    if (!this.searchStringErrorHandler(clone, true)) {
      this.isLoading = false;
      return false;
    }
    const url = environment.baseAPIUrl + 'services/savedSearches';
    const request = {
      "savedSearchSummary": {
        id: 0,
        searchName: searchName,
        searchType: this.searchType,
        createdBy: this.userNameSR,
        createdDate: this.cs.getDate(),
        modifiedDate: this.cs.getDate(),
        modifiedBy: this.userNameSR
      },
      "searchSummary": clone['searchSummary'],
      "searchFields": clone['searchFields']
    };

    this.http.post(url, request).subscribe(response => {
      this.notify.showSuccess('', response['message']);
      this.isLoading = false;
    }, err => {
      this.isLoading = false;
      this.notify.showSuccess('', APP_Messages.ServerErrorMessage);
    });
  }

  async loadLovs() {
    this.searchPageArray = this.lovData.returnSingleLOV('SEARCH_TYPE');
    if (this.searchType == '') {
      this.selecteTableDrp = '-1';
    }
  }

  searchQuery() {
    const clone: {} = {};
    clone['searchSummary'] = {
      "searchType": this.selecteTableDrp,
      "pageNumber": 1,
      "pageSize": 50,
      "totalCount": 0,
      "sortBy": this.sortField == "" ? "mhid" : this.sortField,
      "sortOrder": this.sortOrderType == "" ? "asc" : this.sortOrderType
    };
    clone['searchFields'] = JSON.parse(JSON.stringify(this.properties));
    clone['searchFields'].forEach(element => {
      // delete element.properties;
      // delete element.conditions;
      delete element.isDateProperty;
      // delete element.isDropdown;
      element.value = (element.value.split('-').length === 3 ? this.cs.getDatewithParam(element.value) : element.value);
    });
    // this.commuincationService.changeMessage(clone);
    return clone;
  }

  adjustPagination(pageNumber: number, pSize: number, totalCount: number) {
    this.pageSize = [];
    this.pageSizeSelect = [];
    const pageCount = Math.ceil(totalCount / pSize);
    this.totalPagesCount = pageCount;
    const actPageNo = pageNumber;
    if (pageNumber >= 5) {
      pageNumber = pageNumber - 2;
    } else {
      pageNumber = 1;
    }

    for (let i = 1; i <= pageCount; i++) {
      this.pageSizeSelect.push({ 'pageNumber': i, 'activePage': false });
    }

    for (let i: number = pageNumber; i <= pageCount; i++) {
      if (i > (pageNumber + 4)) {
        this.pageSize.push({ 'pageNumber': -1, 'activePage': false });
        this.pageSize.push({ 'pageNumber': pageCount, 'activePage': false });
        break;
      }

      if (i == actPageNo) {
        this.pageSize.push({ 'pageNumber': i, 'activePage': true });
        this.paginationSelect = i;
      } else {
        this.pageSize.push({ 'pageNumber': i, 'activePage': false });
      }
    }

  }

  paginationFunc(param: any) {
    let nextPageNo = 0;
    if (param == 'p') {
      param = this.pageSize.filter(pgObj => {
        return pgObj.activePage == true;
      })[0].pageNumber - 1;
    } else if (param == 'n') {
      param = this.pageSize.filter(pgObj => {
        return pgObj.activePage == true;
      })[0].pageNumber + 1;
    } else if (param == '-1') { 
      /* empty */
    }
    nextPageNo = param;

    if (param < 1 || param > this.totalPagesCount) {
      return false;
    }

    const clone: {} = this.searchQuery();
    this.commuincationService.changeMessage(clone);
    clone['searchSummary'].pageNumber = nextPageNo;

    this.pageSize.forEach(pgObj => {
      if (pgObj.pageNumber == param) {
        pgObj.activePage = true;
      } else {
        pgObj.activePage = false
      }
    });
    // this.showSearchResultContainer = true;
    // this.searchResultClicked(clone);
  }

  searchStringErrorHandler(clone: any, fromSaveSearch = false) {
    let searchFlag = false;

    if (clone.searchSummary.searchType == null || clone.searchSummary.searchType == "" || clone.searchSummary.searchType == -1) {
      searchFlag = true;
      this.notify.showSuccess('', fromSaveSearch ? APP_Messages.selectSaveSrhPage : APP_Messages.selectPage);
      return false;
    }

    clone.searchFields.forEach((element: { propertyName: string; condition: string; value: string; order: number; operator: string; }) => {
      if (element.propertyName == null || element.propertyName == undefined || element.propertyName == '') {
        searchFlag = true;
        this.notify.showSuccess('', fromSaveSearch ? APP_Messages.selectSaveSrhPropertyName : APP_Messages.selectPropertyName);
        return false;
      } else if (element.condition == null || element.condition == undefined || element.condition == '') {
        searchFlag = true;
        this.notify.showSuccess('', fromSaveSearch ? APP_Messages.selectSaveSrhContains : APP_Messages.selectContains);
        return false;
      } else if ((element.condition != 'isNotNull' && element.condition != 'isNull') && (element.value == null || element.value == undefined || element.value == '' || element.value.trim().length < 1)) {
        searchFlag = true;
        this.notify.showSuccess('', fromSaveSearch ? APP_Messages.enterSaveSrhValue : APP_Messages.enterValue);
        return false;
      } else if (element.order > 1) {
        if (element.operator == null || element.operator == undefined || element.operator == '') {
          searchFlag = true;
          this.notify.showSuccess('', fromSaveSearch ? APP_Messages.selectSaveSrhOperator : APP_Messages.selectOperator);
          return false;
        }
      }
    });

    if (searchFlag) {
      return false;
    }
    return true;
  }

  adjustSorting(sortBy: string, sortOrder: string) {
    this.columnDefs.forEach(cl => {
      if (cl.field.toLowerCase().trim() == sortBy.toLowerCase().trim()) {
        cl.order = sortOrder;
      } else {
        cl.order = '';
      }
    })
  }

  searchPropertiesChecking(clone: any) {
    let searchFlag = false;
    if (clone.searchSummary.searchType == null || clone.searchSummary.searchType == "" || clone.searchSummary.searchType == -1) {
      return false;
    }

    clone.searchFields.forEach((element: { propertyName: string; condition: string; value: string; order: number; operator: string; }) => {
      if (element.propertyName == null || element.propertyName == undefined || element.propertyName == '') {
        searchFlag = true;
        return false;
      } else if (element.condition == null || element.condition == undefined || element.condition == '') {
        searchFlag = true;
        return false;
      } else if ((element.condition != 'isNotNull' && element.condition != 'isNull') && (element.value == null || element.value == undefined || element.value == '' || element.value.trim().length < 1)) {
        searchFlag = true;
        return false;
      } else if (element.order > 1) {
        if (element.operator == null || element.operator == undefined || element.operator == '') {
          searchFlag = true;
          return false;
        }
      }
    });
    if (searchFlag) {
      return false;
    }
    return true;
  }

}


