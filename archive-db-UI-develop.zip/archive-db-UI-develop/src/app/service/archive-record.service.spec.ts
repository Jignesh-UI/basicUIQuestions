import { TestBed } from '@angular/core/testing';

import { ArchiveRecordService } from './archive-record.service';

describe('ArchiveRecordService', () => {
  let service: ArchiveRecordService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ArchiveRecordService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
