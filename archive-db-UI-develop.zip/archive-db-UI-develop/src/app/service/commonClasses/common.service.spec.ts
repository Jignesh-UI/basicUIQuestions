import { NO_ERRORS_SCHEMA } from '@angular/compiler';
import { TestBed } from '@angular/core/testing';
import { MatDialogModule } from '@angular/material/dialog';

import { CommonService } from './common.service';

describe('CommonService', () => {
  let service: CommonService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports:[MatDialogModule],
      schemas:[NO_ERRORS_SCHEMA]
    });
    service = TestBed.inject(CommonService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return todays Date and Time',()=>{
    const dt = service.getDateTime();
    const today = new Date();
    const date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    const time = today.getHours() + ':' + today.getMinutes() + ':' + today.getSeconds();
    const dateTime = date + ' ' + time;
    expect(dt == dateTime).toBeTruthy();
  });

  it('should return todays date',()=>{
    const dateFromServiceFunction = service.getDate();
    const today = new Date();
    const month = today.getMonth() < 10 ? '0' + (today.getMonth()+1) : today.getMonth()+1;
    const todayDate = today.getDate() <  10 ? '0' + today.getDate() : today.getDate();
    const todaysDate = today.getFullYear() + '-' + month + '-' + todayDate;
    expect(dateFromServiceFunction == todaysDate).toBeTruthy;
  });

  it('should adjust date in HTML Format', ()=>{
    const date = new Date();
    const month = date.getMonth() < 10 ? '0' + (date.getMonth()+1) : date.getMonth()+1;
    const todaysDate = date.getDate() <  10 ? '0' + date.getDate() : date.getDate();
    const todayDate = date.getFullYear() + '-' + month + '-' + todaysDate;
    const dateFromService = service.DateFormat(todayDate,'-','/','html');
    expect((dateFromService.match(new RegExp("/", "g")) || []).length).toBe(2);
  });

  it('should adjust date in SERVER Format', ()=>{
    const date = new Date();
    const month = date.getMonth() < 10 ? '0' + (date.getMonth()+1) : date.getMonth()+1;
    const todaysDate = date.getDate() <  10 ? '0' + date.getDate() : date.getDate();
    const todayDate = date.getFullYear() + '/' + month + '/' + todaysDate;
    const dateFromService = service.DateFormat(todayDate,'/','-','server');
    expect((dateFromService.match(new RegExp("-", "g")) || []).length).toBe(2);
  });

  it('should return empty string when date is not passed', ()=>{
    const dateFromService = service.DateFormat('','-','/','html');
    expect(dateFromService).toBe('');
  });

  it('should return date with parameters', ()=>{
    const date= new Date();
    const month = date.getMonth() < 10 ? '0' + (date.getMonth()+1) : date.getMonth()+1;
    const todaysDate = date.getDate() <  10 ? '0' + date.getDate() : date.getDate();
    const todayDate = date.getFullYear() + '/' + month + '/' + todaysDate;
    const dateFromService = service.getDatewithParam(todayDate);
    expect((dateFromService.match(new RegExp("/", "g")) || []).length).toBe(2);
  });

  // it('should return number of days between two dates', ()=>{
  //   const date1 = service.getDatewithParam("2022/09/23");
  //   const date2 = service.getDatewithParam("2022/09/25");
  //   const noOfDays:any = service.calculateDays(date1,date2);
  //   expect(3).toEqual(noOfDays);
  // });

  it('should return date in mm + / + dd + / + yy Format.', ()=>{
    const date1 = "2022/09/23";
    const noOfDays = service.getDateforSearchGrid(date1);
    expect(noOfDays === '09/23/2022').toBeTruthy();
  });

  it('should return TRUE if data is compared',()=>{
    const chkData = {
      "summary": {
          "recordid": 1304182,
          "mhid": "test-mhid",
          "isbn13": "test-isbn",
          "title": "testing api part 1",
      },
      "details": {
          "associatedid": 10863,
          "recordid": 1304182,
          "productTitle": "testing product title from postman - 12",
          "archivist": 1005,
          "compositorVendor": 4005,
        }
      };
      const assocDetails = {
        "associatedid": 10863,
        "recordid": 1304182,
        "productTitle": "testing product title from postman - 12",
        "archivist": 1005,
        "compositorVendor": 4005,
      }
      const assocSummary = {
        "recordid": 1304182,
        "mhid": "test-mhid",
        "isbn13": "test-isbn",
        "title": "testing api part 1",
      }
    expect(service.adjustData(chkData,assocDetails,assocSummary)).toBeTruthy();
  });

});
