import { Injectable } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { ConfirmDialogComponent } from 'src/app/shared/confirm-dialog/confirm-dialog.component';
import { lovInterface } from '../models/common.model';
import { appDataChangeOnListedRecordMessages, appDataChangeOnNavigationMessages, deleteAssociatedConfirmationMessages } from './app-defaults';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(private dialog: MatDialog) { }


  getDate(): any {
    const today = new Date();
    const month = today.getMonth() < 10 ? '0' + (today.getMonth() + 1) : today.getMonth() + 1;
    const todayDate = today.getDate() < 10 ? '0' + today.getDate() : today.getDate();
    const date = today.getFullYear() + '-' + month + '-' + todayDate;
    return date;
  }

  getDateTime(): any {
    const today = new Date();
    const date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    const time = today.getHours() + ':' + today.getMinutes() + ':' + today.getSeconds();
    const dateTime = date + ' ' + time;
    return dateTime;
  }

  DateFormat(date: string, from: string, to: string, source: string): string {
    if (date) {
      if (source === 'html') {
        const d = new Date(date + ' 00:00:00.00');
        const dd = d.getDate();
        const mm = d.getMonth() + 1;
        const yy = d.getFullYear();
        const newdate = mm + '/' + dd + '/' + yy;
        return newdate;
      } else if (source === 'server') {
        const d = new Date(date + ' 00:00:00.00');
        const dd = d.getDate();
        const mm = d.getMonth() + 1;
        const yy = d.getFullYear();
        const newdate = mm + '-' + dd + '-' + yy;
        return newdate;
      }
    } else {
      return '';
    }
  }

  getDatewithParam(date: string): any {
    const d = new Date(date + ' 00:00:00.00');
    const dd = d.getDate();
    const mm = d.getMonth() + 1;
    const yy = d.getFullYear();
    const newdate = mm + '/' + dd + '/' + yy;
    return newdate;
  }

  calculateDays(date2: Date) {
    const oneDay = 24*60*60*1000;
    let days = 0;
    const date1 = new Date();
    const utc2Date = date2 + ' ' + '00:00:00 UTC-5';
    date2 = new Date(new Date(utc2Date).toUTCString());

    let diffTime = new Date(date2).getTime() - new Date(date1).getTime();
    days = diffTime / oneDay; //Diference in Days
    return Math.ceil(days) >= 0 ? Math.ceil(days) : null;
  }

  calculateDaysForDay(date1: Date, date2: Date) {
    let days = 0;
    const Time = new Date(date2).getTime() - new Date(date1).getTime();
    days = Time / (1000 * 3600 * 24); //Diference in Days
    return days >= 0 ? (days + 1) : null;
  }

  getDateforSearchGrid(date: string): any {
    const d = new Date(date);
    const dd = d.getDate() < 10 ? '0' + d.getDate() : d.getDate();
    const mm = d.getMonth() < 9 ? '0' + (d.getMonth() + 1) : d.getMonth() + 1;
    const yy = d.getFullYear();
    return mm + '/' + dd + '/' + yy;
  }

  removePreviousArray(objArray: lovInterface[], objActualArray: lovInterface[]) {
    const obj = objArray.filter(({ lovid: id1 }) => !objActualArray.some(({ lovid: id2 }) => id2 === id1))[0];
    if (obj) {
      objArray = objArray.filter((item) => {
        return item.lovid != obj.lovid;
      });
    }
    return objArray;
  }

  async adjustData(chkData: any, asDetails: any, asSummary: any) {
    delete chkData?.summary?.mhid;
    delete chkData?.summary?.isbn13;
    delete asSummary.mhid;
    delete asSummary.isbn13;
    if ((JSON.stringify(chkData.details) === JSON.stringify(asDetails)) && (JSON.stringify(chkData.summary) === JSON.stringify(asSummary))) {
      return true;
    } else {
      return false;
    }
  }

  async showModalConfirmation(pageMessage = false) {
    const dConfig = new MatDialogConfig();
    dConfig.data = {
      'title': !pageMessage ? appDataChangeOnListedRecordMessages.confirmTitle : appDataChangeOnNavigationMessages.confirmTitle,
      'message': !pageMessage ? appDataChangeOnListedRecordMessages.confirmMessage : appDataChangeOnNavigationMessages.confirmMessage,
      'confirmText': !pageMessage ? appDataChangeOnListedRecordMessages.confirmText : appDataChangeOnNavigationMessages.confirmText,
      'canceltext': !pageMessage ? appDataChangeOnListedRecordMessages.confirmCanceltext : appDataChangeOnNavigationMessages.confirmCanceltext,
      success: () => {
        return false;
      },
      close: () => {
        return true;
      }
    };
    const dialogRef = this.dialog.open(ConfirmDialogComponent, dConfig);
    return await dialogRef.afterClosed().toPromise();
  }

  async showModalConfirmationNewRecord(pageMessage = false) {
    const dConfig = new MatDialogConfig();
    dConfig.data = {
      'title': "Please Confirm",
      'message': "This action will clear the page and unsaved changes will be lost",
      'confirmText': "Continue",
      'canceltext': "Return to previous record",
      success: (e: any) => {
        return false;
      },
      close: (e: any) => {
        return true;
      }
    };
    const dialogRef = this.dialog.open(ConfirmDialogComponent, dConfig);
    return await dialogRef.afterClosed().toPromise();
  }

  async adjustAssociatedData(chkData: any, asDetails: any) {
    delete chkData?.details?.mhid;
    delete chkData?.details?.isbn13;
    const flagSummary = await this.chkAssociatedDataValidation(asDetails);

    if (!flagSummary || (JSON.stringify(chkData.details) === JSON.stringify(asDetails))) {
      return true;
    }
    return false;
  }

  async chkAssociatedDataValidation(asSummary: any): Promise<boolean> {
    let validationFlag = false;
    for (const keys in asSummary) {
      if (asSummary[keys].length > 0 && (asSummary.hasOwnProperty(keys) && keys !== 'recordid' && keys !== 'printingVersion' && keys !== 'associatedid' && keys !== 'createdBy' && keys !== 'createdDate' && keys !== 'modifiedBy' && keys !== 'modifiedDate')) {
        validationFlag = true;
        break;
      } else if (keys === 'printingVersion' && asSummary['printingVersion'] != 0) {
        validationFlag = true;
        break;
      }
    }
    return validationFlag;
  }

  async showDeleteModal() {
    const dConfig = new MatDialogConfig();
    dConfig.data = {
      'title': deleteAssociatedConfirmationMessages.confirmTitle,
      'message': deleteAssociatedConfirmationMessages.confirmMessage,
      'confirmText': deleteAssociatedConfirmationMessages.confirmText,
      'canceltext': deleteAssociatedConfirmationMessages.confirmCanceltext,
      success: () => {
        return false;
      },
      close: () => {
        return true;
      }
    };
    const dialogRef = this.dialog.open(ConfirmDialogComponent, dConfig);
    return await dialogRef.afterClosed().toPromise();
  }

}
