import { HttpClient, HttpHeaders, HttpParams, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NotificationService } from '../notification.service';
import { throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LovDataService {

  private url = environment.baseAPIUrl + 'services/lov';
  private lovData: any[] = [];

  constructor(private http: HttpClient, private notify: NotificationService) { }

  loadListofLovs() {
    if (this.lovData.length === 0) {
      return this.http.get(this.url, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        }),
        params: new HttpParams().set('enabled', 'Y')
      })
        .pipe(map(responseData => {
          const lovArray = [];
          for (const keys in responseData) {
            if (responseData.hasOwnProperty(keys) && keys === 'data') {
              lovArray.push(Object.values(responseData[keys]));
            }
          }
          return Object.values(lovArray[0]);
        }),
          tap(responseData => {
            sessionStorage.setItem('lovData', JSON.stringify(responseData));
            this.lovData = responseData;
          })
        )
        .pipe(catchError(this.handleError));
    } else {
      return this.lovData;
    }
  }

  returnSingleLOV(param: string) {
    let singleLovArray = [];
    if (this.lovData?.length === 0) {
      this.lovData = JSON.parse(sessionStorage.getItem('lovData'));
    }
    for (const keys in this.lovData) {
      if (this.lovData[keys].lovGroupType == param) {
        singleLovArray = this.lovData[keys].lovItemList;
      }
    }
    return singleLovArray;
  }

  returnArchivistLOV() {
    let singleLovArray = [];
    this.lovData = JSON.parse(sessionStorage.getItem('lovData'));
    for (const keys in this.lovData) {
      if (this.lovData[keys].lovGroupType == 'ARCHIVIST') {
        singleLovArray = this.lovData[keys].lovItemList;
      }
    }
    return singleLovArray;
  }

  returnReprintContactLOV() {
    let singleLovArray = [];
    this.lovData = JSON.parse(sessionStorage.getItem('lovData'));
    for (const keys in this.lovData) {
      if (this.lovData[keys].lovGroupType == 'REPRINT_CONTACT') {
        singleLovArray = this.lovData[keys].lovItemList;
      }
    }
    return singleLovArray;
  }

  private handleError(errorRes: HttpErrorResponse) {
    console.log(errorRes.status + ' ' + errorRes.statusText);
    return throwError(errorRes.status);
  }

}
