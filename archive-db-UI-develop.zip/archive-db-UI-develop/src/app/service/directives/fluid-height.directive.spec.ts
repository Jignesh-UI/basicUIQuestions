import { FluidHeightDirective } from './fluid-height.directive';

describe('FluidHeightDirective', () => {
  it('should create an instance', () => {
    const directive = new FluidHeightDirective();
    expect(directive).toBeTruthy();
  });

  it('should adjust height acording to the content', () => {
    const dir = new FluidHeightDirective();
    const elRefMock = {
      nativeElement: document.createElement('div')
    };
    elRefMock.nativeElement.innerHTML = "this is the test html paragraph.";
    dir.minHeight = 350;
    dir.topOffset = 100;
    dir.ngAfterViewInit();
    expect(elRefMock).toBeTruthy();
  });

  it('should not display Content on Hover when content is small', () => {
    const dir = new FluidHeightDirective();
    const elRefMock = {
      nativeElement: document.createElement('div')
    };
    elRefMock.nativeElement.innerHTML = "test delivery format 2";
    dir.minHeight = 350;
    dir.topOffset = 500;
    dir.ngAfterViewInit();
    expect(elRefMock).toBeTruthy();
  });

  it('should calculate Offset of the element', () => {
    const dir = new FluidHeightDirective();
    const elRefMock = {
      nativeElement: document.createElement('div')
    };
    elRefMock.nativeElement.innerHTML = "test delivery format 2";
    dir.minHeight = 800;
    dir.topOffset = 300;
    const testData = dir.calcTopOffset();
    expect(testData).not.toBeNull();
  });

});
