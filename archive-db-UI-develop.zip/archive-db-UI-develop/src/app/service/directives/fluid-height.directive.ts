import { AfterViewInit, Directive, ElementRef, Input, Renderer2 } from "@angular/core";
import { fromEvent } from "rxjs";
import { debounceTime, throttleTime } from "rxjs/operators";

@Directive({
  selector: '[appFluidHeight]'
})
export class FluidHeightDirective implements AfterViewInit {

  @Input() minHeight: number | string | undefined;
  @Input("appFluidHeight") topOffset: number | undefined;

  private domElement: HTMLElement;

  constructor(private renderer?: Renderer2, private elementRef?: ElementRef) {
    this.domElement = this.elementRef?.nativeElement as HTMLElement;

    // register on window resize event
    fromEvent(window, "resize")
      .pipe(throttleTime(500), debounceTime(500))
      .subscribe(() => this.setHeight());
  }

  ngAfterViewInit() {
    this.setHeight();
  }

  setHeight() {
    const windowHeight = window?.innerHeight;
    const topOffset = this.topOffset || this.calcTopOffset();
    let height = Math.ceil(windowHeight - topOffset);

    if (typeof (this.minHeight) == 'string') {
      this.minHeight = +this.minHeight;
    }
    // set min height instead of the calculated
    if (this.minHeight && height < this.minHeight) {
      height = Math.ceil(this.minHeight);
    } else if (height > 1500) {
      height = 1800;
    }

    height = height < 350 ? this.minHeight : height;

    this.renderer?.setStyle(this.domElement, "height", `${height}px`);
  }

  calcTopOffset(): number {
    try {
      const rect = this.domElement.getBoundingClientRect();
      const scrollTop =
        window.pageYOffset || document.documentElement.scrollTop;

      return rect.top + scrollTop;
    } catch (e) {
      return 0;
    }
  }

}