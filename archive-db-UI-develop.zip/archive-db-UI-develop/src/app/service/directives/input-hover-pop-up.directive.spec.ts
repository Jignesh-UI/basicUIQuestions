import { InputHoverPopUpDirective } from './input-hover-pop-up.directive';

describe('InputHoverPopUpDirective', () => {
  it('should create an instance', () => {

    const elRefMock = {
      nativeElement: document.createElement('div')
    };

    const directive = new InputHoverPopUpDirective(elRefMock);
    expect(directive).toBeTruthy();
  });
});
