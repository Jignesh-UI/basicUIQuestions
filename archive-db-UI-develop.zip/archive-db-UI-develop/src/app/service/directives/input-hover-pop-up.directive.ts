import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appInputHoverPopUp]'
})
export class InputHoverPopUpDirective {
  @Input() appInputHoverPopUp = 0;
  
  constructor(private el: ElementRef) { 
  }
  
  @HostListener('mouseenter') OnMouseEnter(){
    const childList = this.el.nativeElement.childNodes;
    for (const keys in childList) {
      if(childList[keys].classList != undefined && childList[keys].classList.contains('form-control') && childList[keys].selectedIndex == null){
        const inputValue = childList[keys].value.trim();
        if(inputValue.length > this.appInputHoverPopUp){
          const div: HTMLLabelElement = document.createElement('label');
          div.innerHTML = '<label class="popUphover"> '+ inputValue +' </label>';
          const insert: HTMLElement = div.firstChild as HTMLElement;
          const before: HTMLElement = this.el.nativeElement;
          before.appendChild(insert);
        }
        break;
      }
    }
  }

  @HostListener('mouseleave') OnMouseLeave(){
    if(this.el.nativeElement.lastChild.className == "popUphover"){
      this.el.nativeElement.lastChild.remove()
    }
  }
}
