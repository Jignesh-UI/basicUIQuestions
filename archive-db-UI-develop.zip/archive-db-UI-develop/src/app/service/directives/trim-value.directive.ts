import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: 'input [type="text"],input [type="email"], textarea'
})
export class TrimValueDirective {

  constructor(private el: ElementRef) { }

  // @HostListener('blur') applyTrim() {
  //   let ele = this.el.nativeElement as HTMLInputElement;
  //     if (typeof ele.value === 'string') {
  //         ele.value = ele.value.trim();
  //     }
  // }

  // @HostListener('mouseover') applyTrimonHover() {
  //   let ele = this.el.nativeElement as HTMLInputElement;
  //     if (typeof ele.value === 'string') {
  //         ele.value = ele.value.trim();
  //     }
  // }


  @HostListener('blur', ['$event'])
  @HostListener('mouseover', ['$event'])
  applyTrim() {
    const ele = this.el.nativeElement as HTMLInputElement;
    if (typeof ele.value === 'string') {
      ele.value = ele.value.trim();
    }
  }

}
