
export interface lovInterface {
    lovid?: number,
    lovType?: string,
    lovCode?: string,
    description?: string,
    valueField?: string,
    enabled?: string,
    orderSeq?: number,
    otherValue?: string
}

export interface chkInterface {
    lovid?: number,
    lovType?: string,
    lovCode?: string,
    description?: string,
    valueField?: string,
    enabled?: string,
    checked?: boolean,
    orderSeq?: number,
    otherValue?: string
}

export interface searchParamsInterface{
    order?: number,
    propertyName?: string,
    condition?: string,
    operator?: string,
    value?: string,
    properties?: any,
    condtions?: any,
    drpvalues?: any,
    conditions?: any,
    isDateProperty?:any,
    isDropdown?:any
}

export interface reportParamsInterface{
    order?: number,
    propertyName?: string,
    condition?: string,
    operator?: string,
    value?: string,
    properties?: any,
    condtions?: any,
    drpvalues?: any,
    conditions?: any,
    isDateProperty?:any,
    isDropdown?:any
}