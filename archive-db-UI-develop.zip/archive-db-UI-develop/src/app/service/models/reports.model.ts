export class DisplayColumns {
    order: number;
    propertyName: string;
    displayName: string;
}

export interface colProperties {
    lovid: number;
    lovType: string;
    lovCode: string;
    description: string;
    valueField: string;
    enabled: string;
    orderSeq?: number;
}