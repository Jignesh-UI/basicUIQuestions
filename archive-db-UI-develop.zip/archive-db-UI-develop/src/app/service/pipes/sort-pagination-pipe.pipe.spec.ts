import { SortPaginationPipePipe } from './sort-pagination-pipe.pipe';

describe('SortPaginationPipePipe', () => {
  it('create an instance', () => {
    const pipe = new SortPaginationPipePipe();
    expect(pipe).toBeTruthy();
  });

  it(`should return '...'`, () =>{
    const pipe = new SortPaginationPipePipe();
    expect(pipe.transform(-1)).toEqual('...')
  })

});
