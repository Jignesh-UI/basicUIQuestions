import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sortPaginationPipe'
})
export class SortPaginationPipePipe implements PipeTransform {

  transform(value: number): string | number {
    if (!value) {
      return null;
    }
    const actuallimit = value == -1 ? '...' : value;
    return actuallimit;
  }

}
