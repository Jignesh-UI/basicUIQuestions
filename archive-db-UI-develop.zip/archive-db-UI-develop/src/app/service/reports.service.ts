import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CommonService } from './commonClasses/common.service';
import { DisplayColumns } from './models/reports.model';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ReportService {

  private reportSaveURL = environment.baseAPIUrl + 'services/savedReports';
  reportRequest = { reportSummary: {}, displayFields: [], searchFields: [] };
  private ReportsFetchURL = environment.baseAPIUrl + 'services/savedReports/list?createdBy=';

  constructor(private http: HttpClient, private cs: CommonService) { }

  getReports(userName: any) {
    return this.http.get<{ data: [] }>(this.ReportsFetchURL + userName);

  }
  createReport(selecteTable: string, selectedColumns: DisplayColumns[], properties: object[]): Observable<Blob> {
    this.reportRequest = { reportSummary: {}, displayFields: [], searchFields: [] };
    const payload = this.buildPayload(selecteTable, selectedColumns, properties);
    const url = environment.baseAPIUrl + 'services/reports';
    return this.http.post(url, payload, { responseType: 'blob' });
  }

  createReportFromSearch(reportId: number): Observable<Blob> {
    const url = this.reportSaveURL + '/run/' + reportId;
    return this.http.get(url, { responseType: 'blob' });
  }

  saveReport(userName: string, selecteTable: string, selectedColumns: DisplayColumns[], properties: object[], reportName: any) {
    this.buildPayload(selecteTable, selectedColumns, properties);
    const request = {
      "savedReportSummary": {
        'id': 0,
        'reportName': reportName,
        'reportType': selecteTable,
        'createdBy': userName,
        'createdDate': this.cs.getDate(),
        'modifiedDate': this.cs.getDate(),
        'modifiedBy': userName
      },
      "reportSummary": {
        "reportType": selecteTable
      },
      "displayFields": this.reportRequest.displayFields,
      "searchFields": this.reportRequest.searchFields

    };
    return this.http.post(this.reportSaveURL, request);
  }

  deleteReport(reportId: number) {
    const deleteUrl = environment.baseAPIUrl + `services/savedReports/${reportId}`;
    return this.http.delete(deleteUrl, { headers: { 'Content-Type': 'application/json' } });
  }

  buildPayload(selecteTable: string, selectedColumns: DisplayColumns[], properties: object[]) {
    this.reportRequest.displayFields = [];
    const clone: {} = {};
    clone['reportSummary'] = { "reportType": selecteTable };
    clone['searchFields'] = JSON.parse(JSON.stringify(properties));
    clone['searchFields'].forEach(element => {
      delete element.properties;
      delete element.conditions;
      delete element.isDateProperty;
      delete element.isDropdown;
      // element.value = (Date.parse(element.value) ? this.cs.getDatewithParam(element.value) : element.value);
      element.value = (element.value.split('-').length === 3 ? this.cs.getDatewithParam(element.value) : element.value);
    });

    this.reportRequest.reportSummary = clone['reportSummary'];
    this.reportRequest.searchFields = clone['searchFields'];

    selectedColumns.forEach((element) => {
      this.reportRequest.displayFields.push(element);
    });

    return this.reportRequest;
  }
}
