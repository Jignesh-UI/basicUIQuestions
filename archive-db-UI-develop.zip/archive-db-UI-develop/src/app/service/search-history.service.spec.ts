import { HttpClient, HttpHandler } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { OktaAuthService } from './okta-auth.service';

import { SearchHistoryService } from './search-history.service';

describe('SearchHistoryService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    providers:[OktaAuthService, HttpClient, HttpHandler]
  }));

  it('should be created', () => {
    const service: SearchHistoryService = TestBed.get(SearchHistoryService);
    expect(service).toBeTruthy();
  });
});
