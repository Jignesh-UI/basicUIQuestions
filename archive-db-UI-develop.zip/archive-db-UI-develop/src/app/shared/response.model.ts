export class HttpResponse {
  data: any[];
  message: string;
  succeeded: string;
}

export interface DeleteResponseModel {
  succeeded: boolean;
  data: any;
  message: string;
}
