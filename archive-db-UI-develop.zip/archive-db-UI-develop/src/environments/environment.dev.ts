export const environment = {
  production: true,
  CLIENT_ID: '0oaobkb7bjQ8DCgGl0x7',
  ISSUER: 'https://mhe.okta.com/oauth2/default',
  LOGIN_REDIRECT_URI: 'https://archivedbdev.emhe.mhc:39090',
  baseAPIUrl: ''
};
