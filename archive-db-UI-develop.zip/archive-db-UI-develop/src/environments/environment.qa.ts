export const environment = {
  production: true,
  CLIENT_ID: '0oaobkpb7vQDbcClk0x7',
  ISSUER: 'https://mhe.okta.com/oauth2/default',
  LOGIN_REDIRECT_URI: 'https://archivedbqa.emhe.mhc:39090',
  oktaEnaled: true,
  baseAPIUrl: ''
};
