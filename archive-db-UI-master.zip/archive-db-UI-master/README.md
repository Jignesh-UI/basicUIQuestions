# archivedbDEV-UI
`Steps TO build archivedb angular aplication`

The all environment based config can be found in environment folder

QA - environment.qa.ts
DEV - environment.cloudfront.ts
PROD - environment.prod.ts
LOCAL - environment.ts

No need to update the <Base href="/archivedb/">. It will be automatically added with the build.

Any environment specific data now will be in the related environment file. 

New Build Command: 

DEV - npm run build:cl
PROD - npm run build:prod
QA - npm run build:qa

The build files will be in the dist folder. Make a Zip file and just upload it to the server's specific area and unzip the file. 

`OLD STEPS`

PROD Deployment
1. Update target value on proxy.conf.json to point DEV server "target": "http://ew1dpbl7136.emhe.mhc:19090/archivedb/",
2. Update CLIENT_ID and LOGIN_REDIRECT_URI value on okta-auth-service.ts to point DEV server
              CLIENT_ID = '0oaobkb7bjQ8DCgGl0x7';
          ISSUER = 'https://mhe.okta.com/oauth2/default';
          LOGIN_REDIRECT_URI = 'https://archivedbdev.emhe.mhc:39090';
          oktaAuth = new OktaAuth({
            clientId: this.CLIENT_ID,
            issuer: this.ISSUER,
            redirectUri: this.LOGIN_REDIRECT_URI,
            pkce: true
          });
  3. run ng build --prod
  4. Deploy to server

PROD Deployment
1. Update target value on proxy.conf.json to point DEV server "target": "http://ew1dpbl7137.emhe.mhc:19090/archivedb/",
2. Update CLIENT_ID and LOGIN_REDIRECT_URI value on okta-auth-service.ts to point DEV server
             CLIENT_ID = '0oaobkpb7vQDbcClk0x7';
  ISSUER = 'https://mhe.okta.com/oauth2/default';
  LOGIN_REDIRECT_URI = 'https://archivedbqa.emhe.mhc:39090';
  oktaAuth = new OktaAuth({
    clientId: this.CLIENT_ID,
    issuer: this.ISSUER,
    redirectUri: this.LOGIN_REDIRECT_URI,
    pkce: true
  });
  3. run ng build --prod
  4. Deploy to server

PROD Deployment
1. Update target value on proxy.conf.json to point DEV server "target": "http://ew1dpbl7137.emhe.mhc:19090/archivedb/",
2. Update CLIENT_ID and LOGIN_REDIRECT_URI value on okta-auth-service.ts to point DEV server
               CLIENT_ID = '0oao6qx17vGEKbKC10x7';
  ISSUER = 'https://mhe.okta.com/oauth2/default';
  LOGIN_REDIRECT_URI = 'https://archivedb.emhe.mhc:39090';
  oktaAuth = new OktaAuth({
    clientId: this.CLIENT_ID,
    issuer: this.ISSUER,
    redirectUri: this.LOGIN_REDIRECT_URI,
    pkce: true
  });
  3. run ng build --prod
  4. Deploy to server

