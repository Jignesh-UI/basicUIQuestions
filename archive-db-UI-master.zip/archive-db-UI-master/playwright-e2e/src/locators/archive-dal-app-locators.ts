const archiveDalAppLocators = {
  archiveRecord: "text=Archive Record",
  associatedRecord: "text=Associated Record",
  archiveRequest: "text=Archive Request",
  nimas: "text=NIMAS",
  reports: "text=Reports",
  search: "text=Search ",
  savedSearch: "text=Saved Searches",
  savedReport: "text=Saved Reports"
};

export default archiveDalAppLocators;
