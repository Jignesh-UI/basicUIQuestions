const login_locators = {
    username: 'input[name="username"]',
    password: 'input[name="password"]',
    archiveDalApp: 'text=DAL Archive Database Cloud SPA (DEV)',
    archiveDalProdApp: 'text=DAL Archive Database Cloud (PROD)',
    signInButton: 'input:has-text("Sign In")',
  }
  
  export default login_locators

