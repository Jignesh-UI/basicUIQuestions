const nimas_record_locators = {
  MHID: 'input[name="mhid"]',
  ISBN13: 'input[name="isbn13"]',
  priorEditionISBN: 'input[name="previousISBN"]',
  nextEditionISBN: 'input[name="newISBN"]',
  authors: 'input[name="author"]',
  marketingTitle: 'input[name="title"]',
  edition: 'input[name="edition"]',
  copyrightyear: 'input[name="copyrightYear"]',
  calculatedBBD: 'input[name="boundBookDate"]',
  permissionEndDate: 'input[name="permissionEndDate"]',
  projectOPDate: 'input[name="projectOPDate"]',
  publicationStatus: 'input[name="priority"]',
  owningDivision: 'input[name="owningDivision"]',
  owningSubDivision: 'input[name="owningSubDivision"]',
  subdivisionDescription: 'input[name="owningSubDivision"]',
  deliveryFormat: 'input[name="deliveryFormat"]',
  titleType: 'input[name="titleTypeDesc"]',
  gradeRange: 'input[name="gradeRange"]',
  specificMarket: 'input[name="specificMarket"]',
  ipubPublishingGroup: 'input[name="ipubPublishingGroup"]',
  ipubProgrammingTitle: 'input[name="ipubProgrammingTitle"]',
  pageCount: 'input[name="noOfPages"]',
  addNote: "text=Add note",
  archiveNotes: 'textarea[name="comments"]',



  recordId: "class=recId",
  archivist: 'select[name="archivist"]',
  nimasCoordinator: 'select[name="coordinator"]',

  NIMACCertificationReceived: 'input[name="nimasCertReceivedDate"]',
  NIMACCertificateNumber: 'input[name="nimasCertNumber"]',

  NIMASConversionVendor: 'select[name="nimasConvVendor"]',
  FilesSenttoConversionVendor: 'input[name="filesConversionVendor"]',
  NIMASConversionVendorOther: 'input[name="convVendorOther"]',

  NIMASDescriptionVendor: 'select[name="nimasDescVendor"]',
  FilesSenttoDescriptionVendor: ' input[name="filesDescriptionVendor"]',
  NIMASDescriptionVendorOther: 'input[name="descVendorOther"]',

  saveNimasRecordButton: "text=Save NIMAS Record",
  nimasArchiveNotes: 'textarea[name="notes"]'

};

export default nimas_record_locators;
