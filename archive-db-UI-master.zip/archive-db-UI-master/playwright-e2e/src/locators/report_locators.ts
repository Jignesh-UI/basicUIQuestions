const report_locators = {
    reportContainer: "class=reportsContainer",
    reportCriteria: "text=Reports Criteria ",
    page_label: "label:has-text('Page')",
    properties_label: "label:has-text('Properties')",
    contains_label: "label:has-text('Contains')",
    value_label: "label:has-text('Value')",

    create_report_button: "button:has-text('Create Report')",
    save_report_button: "button:has-text('Save Report')",

    move_up_button: "button:has-text('Move Up')",
    move_down_button: "button:has-text('Move Down')",

    add_property_button: "text=Add Property",
    remove_property_button: "text=Remove Property",

    availableProperties: 'select[name="availableProperties"]',
    addProperties: 'button[name="addProperties"]',
    removeProperties: 'button[name="removeProperties"]',
    selectedProperties: 'select[name="selectedProperties"]',

};

export default report_locators;
