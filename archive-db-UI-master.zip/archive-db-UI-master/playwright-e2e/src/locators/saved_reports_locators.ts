const saved_report_locators = {
  savedReportsLabel: "text=Saved Reports"
};

export default saved_report_locators;
