const saved_search_locators = {
    savedSearchesLabel: "text=Saved Searches"
  };
  
  export default saved_search_locators;
  