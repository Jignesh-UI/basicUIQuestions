import { test, expect, Page, Locator } from "@playwright/test";
import globalSetup from "@globalSetup/global_setup";
import archive_record_locators from "@locators/archive_record_locators";
const environment = globalSetup();

export class ArchiveRecordPage {
  readonly page: Page;
  readonly ISBN13: Locator;
  readonly MHID: Locator;
  readonly priorEditionISBN: Locator;
  readonly nextEditionISBN: Locator;
  readonly authors: Locator;
  readonly marketingTitle: Locator;
  readonly edition: Locator;
  readonly copyrightYear: Locator;
  readonly calculatedBBD: Locator;
  readonly permissionEndDate: Locator;
  readonly projectOPDate: Locator;
  readonly publicationStatus: Locator;
  readonly owningDivision: Locator;
  readonly owningSubDivision: Locator;
  readonly subdivisionDescription: Locator;
  readonly deliveryFormat: Locator;
  readonly titleType: Locator;
  readonly gradeRange: Locator;
  readonly specificMarket: Locator;
  readonly ipubPublishingGroup: Locator;
  readonly ipubProgrammingTitle: Locator;
  readonly pageCount: Locator;
  readonly addNote: Locator;
  readonly archiveNotes: Locator;
  readonly recordId: Locator;
  readonly archivist: Locator;
  readonly compVendor: Locator;
  readonly downloadDueDate: Locator;
  readonly downloadReceivedDate: Locator;
  readonly dateArchivedDate: Locator;
  readonly location: Locator;
  readonly printing: Locator;
  readonly reprintContact: Locator;
  readonly productionSpecialist: Locator;
  readonly libraryLocation: Locator;
  readonly insert: Locator;
  readonly endsheets: Locator;
  readonly setOfDiscs: Locator;
  readonly discsInSet: Locator;
  readonly discSize: Locator;
  readonly mbgb: Locator;
  readonly coverDesign: Locator;
  readonly otherFilesOther: Locator;
  readonly saveArchiveRecordButton: Locator;
  readonly pagingFilesInDesign: Locator;
  readonly pagingFilesMSWord: Locator;
  readonly pagingFilesNone: Locator;
  readonly pagingFilesQuark: Locator;
  readonly pagingFilesTex: Locator;
  readonly pagingFilesOther: Locator;
  readonly inputPagingFilesOther: Locator;
  readonly inputOtherFilesOther: Locator;
  readonly otherFilesCoverDesign: Locator;
  readonly otherFilesImages: Locator;
  readonly otherFilesNone: Locator;
  readonly associatedList: Locator;
  readonly gotoNewAddAssociatedProduct: Locator;
  readonly productionSpecialistOther: Locator;

  constructor(page: Page) {
    this.page = page;
    this.MHID = page.locator(archive_record_locators.MHID);
    this.ISBN13 = page.locator(archive_record_locators.ISBN13);
    this.associatedList = page.locator(archive_record_locators.associatedList);

    this.priorEditionISBN = page.locator(
      archive_record_locators.priorEditionISBN
    );
    this.nextEditionISBN = page.locator(
      archive_record_locators.nextEditionISBN
    );
    this.ipubPublishingGroup = page.locator(
      archive_record_locators.ipubPublishingGroup
    );
    this.ipubProgrammingTitle = page.locator(
      archive_record_locators.ipubProgrammingTitle
    );
    this.authors = page.locator(archive_record_locators.authors);
    this.marketingTitle = page.locator(archive_record_locators.marketingTitle);
    this.edition = page.locator(archive_record_locators.edition);
    this.copyrightYear = page.locator(archive_record_locators.copyrightYear);
    this.ISBN13 = page.locator(archive_record_locators.ISBN13);
    this.calculatedBBD = page.locator(archive_record_locators.calculatedBBD);
    this.projectOPDate = page.locator(archive_record_locators.projectOPDate);
    this.permissionEndDate = page.locator(
      archive_record_locators.permissionEndDate
    );
    this.publicationStatus = page.locator(
      archive_record_locators.publicationStatus
    );
    this.owningDivision = page.locator(archive_record_locators.owningDivision);
    this.owningSubDivision = page.locator(
      archive_record_locators.owningSubDivision
    );
    this.subdivisionDescription = page.locator(
      archive_record_locators.subdivisionDescription
    );
    this.deliveryFormat = page.locator(archive_record_locators.deliveryFormat);
    this.titleType = page.locator(archive_record_locators.titleType);
    this.gradeRange = page.locator(archive_record_locators.gradeRange);
    this.specificMarket = page.locator(archive_record_locators.specificMarket);
    this.pageCount = page.locator(archive_record_locators.pageCount);
    this.addNote = page.locator(archive_record_locators.addNote);
    this.archiveNotes = page.locator(archive_record_locators.archiveNotes);
    this.recordId = page.locator(archive_record_locators.recordId);
    this.archivist = page.locator(archive_record_locators.archivist);
    this.compVendor = page.locator(archive_record_locators.compVendor);
    this.downloadDueDate = page.locator(
      archive_record_locators.downloadDueDate
    );
    this.downloadReceivedDate = page.locator(
      archive_record_locators.downloadReceivedDate
    );
    this.dateArchivedDate = page.locator(
      archive_record_locators.dateArchivedDate
    );
    this.location = page.locator(archive_record_locators.location);
    this.printing = page.locator(archive_record_locators.printing);
    this.reprintContact = page.locator(archive_record_locators.reprintContact);
    this.productionSpecialist = page.locator(archive_record_locators.productionSpecialist);
    this.libraryLocation = page.locator(
      archive_record_locators.libraryLocation
    );
    this.insert = page.locator(archive_record_locators.insert);
    this.endsheets = page.locator(archive_record_locators.endsheets);
    this.setOfDiscs = page.locator(archive_record_locators.setOfDiscs);
    this.discsInSet = page.locator(archive_record_locators.discsInSet);
    this.discSize = page.locator(archive_record_locators.discSize);
    this.mbgb = page.locator(archive_record_locators.mbgb);
    this.coverDesign = page.locator(archive_record_locators.coverDesign);
    this.otherFilesOther = page.locator(
      archive_record_locators.otherFilesOther
    );
    this.saveArchiveRecordButton = page.locator(
      archive_record_locators.saveArchiveRecordButton
    );

    this.coverDesign = page.locator(archive_record_locators.coverDesign);
    this.otherFilesOther = page.locator(
      archive_record_locators.otherFilesOther
    );
    this.saveArchiveRecordButton = page.locator(
      archive_record_locators.saveArchiveRecordButton
    );
    this.gotoNewAddAssociatedProduct = page.locator(
      archive_record_locators.gotoNewAddAssociatedProduct
    );
    this.pagingFilesInDesign = page.locator(
      archive_record_locators.pagingFilesInDesign
    );
    this.pagingFilesMSWord = page.locator(
      archive_record_locators.pagingFilesMSWord
    );
    this.pagingFilesNone = page.locator(
      archive_record_locators.pagingFilesNone
    );
    this.pagingFilesQuark = page.locator(
      archive_record_locators.pagingFilesQuark
    );
    this.pagingFilesTex = page.locator(archive_record_locators.pagingFilesTex);
    this.pagingFilesOther = page.locator(
      archive_record_locators.pagingFilesOther
    );
    this.inputPagingFilesOther = page.locator(
      archive_record_locators.inputPagingFilesOther
    );
    this.inputOtherFilesOther = page.locator(
      archive_record_locators.inputOtherFilesOther
    );
    this.otherFilesCoverDesign = page.locator(
      archive_record_locators.otherFilesCoverDesign
    );
    this.otherFilesImages = page.locator(
      archive_record_locators.otherFilesImages
    );
    this.otherFilesNone = page.locator(archive_record_locators.otherFilesNone);
    this.productionSpecialistOther = page.locator(archive_record_locators.productionSpecialistOther);
  }

  async goto(url: string) {
    await this.page.goto(url);
  }

  async enter_MHID(MHIDData: string) {
    expect(await this.MHID.isEditable()).toBeTruthy();
    expect(await this.ISBN13.isEditable()).toBeTruthy();
    await this.MHID.fill(MHIDData);
    await this.page.keyboard.press("Tab");
    expect(await this.MHID.isEditable()).toBeTruthy();
    await this.page.waitForTimeout(1000);
  }

  async enter_ISBN13(ISBN13Data: string) {
    expect(await this.MHID.isEditable()).toBeTruthy();
    expect(await this.ISBN13.isEditable()).toBeTruthy();
    await this.ISBN13.fill(ISBN13Data);
    await this.page.keyboard.press("Tab");
    expect(await this.ISBN13.isEditable()).toBeTruthy();
    await this.page.waitForTimeout(1000);
  }

  async fieldsNotEditable() {
    expect(await this.nextEditionISBN.isDisabled()).toBeTruthy();
    expect(await this.priorEditionISBN.isDisabled()).toBeTruthy();
    expect(await this.authors.isDisabled()).toBeTruthy();
    expect(await this.marketingTitle.isDisabled()).toBeTruthy();
    expect(await this.edition.isDisabled()).toBeTruthy();
    expect(await this.copyrightYear.isDisabled()).toBeTruthy();
    expect(await this.calculatedBBD.isDisabled()).toBeTruthy();
    expect(await this.permissionEndDate.isDisabled()).toBeTruthy();
    expect(await this.projectOPDate.isDisabled()).toBeTruthy();
    expect(await this.publicationStatus.isDisabled()).toBeTruthy();
    expect(await this.owningDivision.isDisabled()).toBeTruthy();
    expect(await this.owningSubDivision.isDisabled()).toBeTruthy();
    expect(await this.subdivisionDescription.isDisabled()).toBeTruthy();
    expect(await this.deliveryFormat.isDisabled()).toBeTruthy();
    expect(await this.titleType.isDisabled()).toBeTruthy();
    expect(await this.gradeRange.isDisabled()).toBeTruthy();
    expect(await this.specificMarket.isDisabled()).toBeTruthy();
    expect(await this.pageCount.isDisabled()).toBeTruthy();
  }
  async fieldsEditable() {
    expect(await this.MHID.isEditable()).toBeTruthy();
    expect(await this.ISBN13.isEditable()).toBeTruthy();
    expect(await this.ipubPublishingGroup.isEditable()).toBeTruthy();
    expect(await this.ipubProgrammingTitle.isEditable()).toBeTruthy();
    expect(await this.addNote.isEnabled()).toBeTruthy();
    expect(await this.archiveNotes.isEnabled()).toBeTruthy();
  }

  async fillArchiveInformationDownloadDate(dateInput: string) {
    await this.downloadDueDate.fill(dateInput);
  }

  async fillArchiveInformationDownloadReceived() {
    await this.downloadReceivedDate.fill("2022-05-18");
  }

  async pagingFilesOptionsEditableWhenNoneNotSelected() {
    await this.page.waitForTimeout(3000);
    if (await this.pagingFilesNone.isChecked()) {
      await this.pagingFilesNone.click();
      expect(await this.pagingFilesNone.isEnabled()).toBeTruthy();
      expect(await this.pagingFilesNone.isChecked()).toBeFalsy();
    }
    await this.pagingFilesNone.click();
    expect(await this.pagingFilesNone.isEnabled()).toBeTruthy();
    expect(await this.pagingFilesNone.isChecked()).toBeTruthy();

    expect(await this.pagingFilesTex.isDisabled()).toBeTruthy();
    expect(await this.pagingFilesQuark.isDisabled()).toBeTruthy();
    expect(await this.pagingFilesMSWord.isDisabled()).toBeTruthy();
    expect(await this.page.locator('label').filter({ hasText: 'Other' }).first().isDisabled()).toBeTruthy();
    expect(await this.pagingFilesInDesign.isDisabled()).toBeTruthy();

    await this.pagingFilesNone.click();
    await this.pagingFilesInDesign.click();
    await this.pagingFilesQuark.click();
    await this.pagingFilesMSWord.click();
    await this.pagingFilesTex.click();
    await this.page.locator('label').filter({ hasText: 'Other' }).first().click();
    expect(await this.pagingFilesNone.isEnabled()).toBeTruthy();
    expect(await this.pagingFilesNone.isChecked()).toBeFalsy();
    expect(await this.pagingFilesInDesign.isEditable()).toBeTruthy();
    expect(await this.pagingFilesInDesign.isChecked()).toBeTruthy();
    expect(await this.pagingFilesTex.isEditable()).toBeTruthy();
    expect(await this.pagingFilesTex.isChecked()).toBeTruthy();
    expect(await this.pagingFilesQuark.isEditable()).toBeTruthy();
    expect(await this.pagingFilesQuark.isChecked()).toBeTruthy();
    expect(await this.pagingFilesMSWord.isEditable()).toBeTruthy();
    expect(await this.pagingFilesMSWord.isChecked()).toBeTruthy();
    // expect(await this.page.locator('label').filter({ hasText: 'Other' }).first().isChecked()).toBeTruthy();
    expect(await this.page.locator('label').filter({ hasText: 'Other' }).first().isEditable()).toBeTruthy();
    expect(await this.inputPagingFilesOther.isEditable()).toBeTruthy();
  }

  async otherFilesOptionsEditableWhenNoneNotSelected() {
    if (await this.otherFilesNone.isChecked()) {
      await this.otherFilesNone.click();
      expect(await this.otherFilesNone.isEnabled()).toBeTruthy();
      expect(await this.otherFilesNone.isChecked()).toBeFalsy();
    }
    await this.otherFilesNone.click();
    expect(await this.otherFilesNone.isEnabled()).toBeTruthy();
    expect(await this.otherFilesNone.isChecked()).toBeTruthy();
    expect(await this.otherFilesCoverDesign.isDisabled()).toBeTruthy();
    expect(await this.otherFilesImages.isDisabled()).toBeTruthy();
    expect(await this.page.locator('label').filter({ hasText: 'Other' }).nth(2).isDisabled()).toBeTruthy();
    await this.otherFilesNone.click();
    await this.otherFilesCoverDesign.click();
    await this.otherFilesImages.click();
    await this.page.locator('label').filter({ hasText: 'Other' }).nth(2).dblclick();
    expect(await this.otherFilesNone.isEnabled()).toBeTruthy();
    expect(await this.otherFilesNone.isChecked()).toBeFalsy();
    expect(await this.otherFilesCoverDesign.isEditable()).toBeTruthy();
    expect(await this.otherFilesCoverDesign.isChecked()).toBeTruthy();
    expect(await this.otherFilesImages.isEditable()).toBeTruthy();
    expect(await this.otherFilesImages.isChecked()).toBeTruthy();
    expect(await this.page.locator('label').filter({ hasText: 'Other' }).nth(2).isEditable()).toBeTruthy();
    expect(await this.page.locator('label').filter({ hasText: 'Other' }).nth(2).isChecked()).toBeTruthy();
    expect(await this.inputOtherFilesOther.isEditable()).toBeTruthy();
  }

  async otherFilesInputEnabledWhenOtherCheckboxSelected() {
    if (await this.page.locator('label').filter({ hasText: 'Other' }).nth(2).isChecked()) {
      expect(await this.inputOtherFilesOther.isEditable()).toBeTruthy();
    } else {
      await this.page.locator('label').filter({ hasText: 'Other' }).nth(2).click();
      expect(await this.inputOtherFilesOther.isEditable()).toBeTruthy();
    }
  }

  async pageFilesInputEnabledWhenOtherCheckboxSelected() {
    if (await this.page.locator('label').filter({ hasText: 'Other' }).first().isChecked()) {
      expect(await this.page.locator('label').filter({ hasText: 'Other' }).first().isEditable()).toBeTruthy();
    } else {
      await this.page.locator('label').filter({ hasText: 'Other' }).first().click();
      expect(await this.inputPagingFilesOther.isEditable()).toBeTruthy();
    }
  }

  async pagingFilesOptionsNotEditableWhenOtherSelected() {
    expect(await this.MHID.isEditable()).toBeTruthy();
    expect(await this.ISBN13.isEditable()).toBeTruthy();
    expect(await this.ipubPublishingGroup.isEditable()).toBeTruthy();
    expect(await this.ipubProgrammingTitle.isEditable()).toBeTruthy();
    expect(await this.addNote.isEnabled()).toBeTruthy();
  }

  async verifyElementText(locator: string, text: string): Promise<void> {
    await this.waitForElementAttached(locator);
    const textValue = await this.page.textContent(locator);
    expect(textValue.trim()).toBe(text);
  }
  async waitForElementAttached(locator: string): Promise<void> {
    await this.page.waitForSelector(locator);
  }

  async clickedViewIcon(element: any) { // this is to redirect using product id
    this.page.locator("listProductsBody > div:nth-child(" + element + ") > div:nth-child(4)").click();
  }

  async disabledAssociatedcontrols() {
    await this.page.locator('.listProductsBody > div:nth-child(2) > div:nth-child(1) > .form-control').scrollIntoViewIfNeeded();
    for (let i = 1; i < 3; i++) {
      for (let j = 1; j < 4; j++) {
        expect(await this.page.locator('.listProductsBody > div:nth-child(' + i + ') > div:nth-child(' + j + ') > .form-control').isVisible()).toBeTruthy();
        expect(await this.page.locator('.listProductsBody > div:nth-child(' + i + ') > div:nth-child(' + j + ') > .form-control').isEditable()).toBeFalsy();
      }
    }
  }

  async checkassociatedrecordValue() {
    await this.page.locator('.listProductsBody > div:nth-child(2) > div:nth-child(1) > .form-control').scrollIntoViewIfNeeded();
    await this.page.locator('.listProductsBody > div:nth-child(' + 1 + ') > div:nth-child(' + 4 + ') > .viewRecord').first().click();
    expect(await this.page.locator('.listProductsBody > div:nth-child(' + 1 + ') > div:nth-child(' + 1 + ') > .form-control').first().textContent == await this.page.locator('input[name="productTitle"]').textContent).toBeTruthy();
    expect(await this.page.locator('.listProductsBody > div:nth-child(' + 1 + ') > div:nth-child(' + 2 + ') > .form-control').first().textContent == await this.page.locator('input[name="printingVersion"]').textContent).toBeTruthy();
    expect(await this.page.locator('.listProductsBody > div:nth-child(' + 1 + ') > div:nth-child(' + 3 + ') > .form-control').first().textContent == await this.page.locator('input[name="archivedDate"]').textContent).toBeTruthy();
  }

  async clickAddAssocRecord(productTitle: string) {
    let url="";
    const [page2] = await Promise.all([
      this.page.waitForEvent('popup'),
      this.page.locator('text=Add Associated Product').click()
    ]);
    if( page2.url().search("/archivedb/") > 1) {
      url = page2.url().replace("/archivedb/","/");
      await page2.goto(url);
    }
    await page2.locator('input[name="productTitle"]').fill(productTitle);
    await page2.locator('text=Save Associated Record').click();

    var archiveRecordMessage: string =
      "text=Associated Record Updated Successfully for Associated ID==>" +
      environment.expected_assoc_data.associatedId;
    expect(await page2.locator(archiveRecordMessage).isVisible());
    await page2.close();
  }

  async searchArchiveRecord(productVal: string) {
    await this.page.locator('.listProductsBody > div:nth-child(2) > div:nth-child(1) > .form-control').scrollIntoViewIfNeeded();
    const fstDiv = await this.page.locator('.listProductsBody > .listProductsBodyRow');
    for (let i = 0; i < await fstDiv.count(); i++) {
      const txtval: boolean = this.page.locator('.listProductsBody > .listProductsBodyRow:nth-child(' + i + ') > .colLarge:nth-child(1) > .form-control').first().textContent != null ? true : false;
      expect(txtval).toBeTruthy();
    }
  }

  async clickViewProductIcon() {
    let url = "";
    const [page2] = await Promise.all([
      this.page.waitForEvent('popup'),
      this.page.locator('.viewRecord').first().click()
    ]);

    if( page2.url().search("/archivedb/") > 1) {
      url = page2.url().replace("/archivedb/","/");
      await page2.goto(url);
    }
    
    await this.page.waitForTimeout(1000);
    await page2.locator('text=Add Note').nth(1).click();
    await page2.locator('textarea[name="instruction"]').click();
    await page2.locator('textarea[name="instruction"]').fill('text');
    await page2.locator('div[role="document"] button:has-text("Add")').click();
    await this.page.waitForTimeout(1000);
    expect(page2.locator('textarea[name="instruction"]')).not.toBeNull();
    await page2.close();
  }

  async checkNotes() {
    expect(await this.archiveNotes.isEnabled()).toBeTruthy();
    await this.addNote.click();
    await this.page.locator('#specialinstruction').click();
    await this.page.locator('#specialinstruction').fill('test record');
    await this.page.getByRole('button', { name: 'Add' }).click();
    expect(await this.archiveNotes.textContent()).not.toBeNull();
  }

  async updateLegacyArchivist(){
    expect(await this.archivist.isEnabled()).toBeTruthy();
    await this.archivist.selectOption('1014');
  }

  async checkLegacyArchivist(){
    expect(await this.archivist.isEnabled()).toBeTruthy();
    expect(await this.archivist.selectOption('1014')).toBeTruthy();
  }

  async saveArchiveRecordButtonEnable(){
    expect(await this.saveArchiveRecordButton.isDisabled()).toBeFalsy();
    expect(await this.addNote.isDisabled()).toBeFalsy();
    expect(await this.gotoNewAddAssociatedProduct.isDisabled()).toBeFalsy();
  }

  async saveArchiveRecordButtonDisable(){
    expect(await this.saveArchiveRecordButton.isDisabled()).toBeTruthy();
    expect(await this.gotoNewAddAssociatedProduct.isDisabled()).toBeTruthy();
  }

  async checkProdSpecialityField() {
    expect(await this.archivist.isEnabled()).toBeTruthy();
    expect(await this.page.locator('select[name="productionSpecialist"]').isEnabled()).toBeTruthy();
    await this.page.locator('select[name="productionSpecialist"]').selectOption({ label: 'Other' });
    expect(await this.productionSpecialistOther.isEnabled()).toBeTruthy();
  }


}
