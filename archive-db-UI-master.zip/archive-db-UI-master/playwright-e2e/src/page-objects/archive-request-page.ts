import { test, expect, Page, Locator } from "@playwright/test";
import archive_request_locators from "@locators/archive-request-locators";



export class ArchiveRequestPage {
    readonly page: Page;
    readonly MHID: Locator;
    readonly ISBN13: Locator;
    readonly priorEditionISBN: Locator;
    readonly nextEditionISBN: Locator;
    readonly authors: Locator;
    readonly marketingTitle: Locator;
    readonly edition: Locator;
    readonly copyrightyear: Locator;
    readonly calculatedBBD: Locator;
    readonly permissionEndDate: Locator;
    readonly projectOPDate: Locator;
    readonly publicationStatus: Locator;
    readonly owningDivision: Locator;
    readonly owningSubDivision: Locator;
    readonly subdivisionDescription: Locator;
    readonly deliveryFormat: Locator;
    readonly titleType: Locator;
    readonly gradeRange: Locator;
    readonly specificMarket: Locator;
    readonly ipubPublishingGroup: Locator;
    readonly ipubProgrammingTitle: Locator;
    readonly pageCount: Locator;
    readonly addNote: Locator;
    readonly archiveNotes: Locator;

    readonly requestReceivedDate: Locator;
    readonly dueDate: Locator;
    readonly completedDate: Locator;
    readonly inProgress: Locator;
    readonly archivist: Locator;
    readonly requestedBy: Locator;
    readonly requestorDepartment: Locator;
    readonly deliveryMedium: Locator;
    readonly compositorVendor: Locator;
    readonly compVendorOther: Locator;
    readonly printingVersion: Locator;

    readonly ReqFilesArtPhoto: Locator;
    readonly ReqFilesApplication: Locator;
    readonly ReqFilesCoverDesign: Locator;
    readonly ReqFilesDisabledStudent: Locator;
    readonly ReqFileseBook: Locator;
    readonly ReqFilesInternationalRights: Locator;
    readonly ReqFilesPDFMediaLowRes: Locator;
    readonly ReqFilesPDFPrinterHighRes: Locator;
    readonly ReqFilesPostProduction: Locator;
    readonly ReqFilesReprint: Locator;
    readonly ReqFilesTroubleshooting: Locator;
    readonly ReqFilesOther: Locator;
    readonly ReqFilesOtherInput: Locator;
    readonly statusNotes: Locator;
    readonly statusNotesButton: Locator;
    readonly specialInstructions: Locator;
    readonly specialInstructionsButton: Locator;
    readonly clearButton: Locator;
    readonly cloneButton: Locator;
    readonly saveRecordButton: Locator;

    constructor(page: Page) {
        this.page = page;
        this.MHID = page.locator(archive_request_locators.MHID);
        this.ISBN13 = page.locator(archive_request_locators.ISBN13);
        this.priorEditionISBN = page.locator(archive_request_locators.priorEditionISBN);
        this.nextEditionISBN = page.locator(archive_request_locators.nextEditionISBN);
        this.authors = page.locator(archive_request_locators.authors);
        this.marketingTitle = page.locator(archive_request_locators.marketingTitle);
        this.edition = page.locator(archive_request_locators.edition);
        this.copyrightyear = page.locator(archive_request_locators.copyrightyear);
        this.calculatedBBD = page.locator(archive_request_locators.calculatedBBD);
        this.permissionEndDate = page.locator(archive_request_locators.permissionEndDate);
        this.projectOPDate = page.locator(archive_request_locators.projectOPDate);
        this.publicationStatus = page.locator(archive_request_locators.publicationStatus);
        this.owningDivision = page.locator(archive_request_locators.owningDivision);
        this.owningSubDivision = page.locator(archive_request_locators.owningSubDivision);
        this.subdivisionDescription = page.locator(archive_request_locators.subdivisionDescription);
        this.deliveryFormat = page.locator(archive_request_locators.deliveryFormat);
        this.titleType = page.locator(archive_request_locators.titleType);
        this.gradeRange = page.locator(archive_request_locators.gradeRange);
        this.specificMarket = page.locator(archive_request_locators.specificMarket);
        this.ipubPublishingGroup = page.locator(archive_request_locators.ipubPublishingGroup);
        this.ipubProgrammingTitle = page.locator(archive_request_locators.ipubProgrammingTitle);
        this.pageCount = page.locator(archive_request_locators.pageCount);
        this.addNote = page.locator(archive_request_locators.addNote);
        this.archiveNotes = page.locator(archive_request_locators.archiveNotes);
        this.requestReceivedDate = page.locator(archive_request_locators.requestReceivedDate);
        this.dueDate = page.locator(archive_request_locators.dueDate);
        this.completedDate = page.locator(archive_request_locators.completedDate);
        this.inProgress = page.locator(archive_request_locators.inProgress);
        this.archivist = page.locator(archive_request_locators.archivist);
        this.requestedBy = page.locator(archive_request_locators.requestedBy);
        this.requestorDepartment = page.locator(archive_request_locators.requestorDepartment);
        this.deliveryMedium = page.locator(archive_request_locators.deliveryMedium);
        this.compositorVendor = page.locator(archive_request_locators.compositorVendor);
        this.compVendorOther = page.locator(archive_request_locators.compVendorOther);
        this.printingVersion = page.locator(archive_request_locators.printingVersion);
        this.ReqFilesArtPhoto = page.locator(archive_request_locators.ReqFilesArtPhoto);
        this.ReqFilesApplication = page.locator(archive_request_locators.ReqFilesApplication);
        this.ReqFilesCoverDesign = page.locator(archive_request_locators.ReqFilesCoverDesign);
        this.ReqFilesDisabledStudent = page.locator(archive_request_locators.ReqFilesDisabledStudent);
        this.ReqFileseBook = page.locator(archive_request_locators.ReqFileseBook);
        this.ReqFilesInternationalRights = page.locator(archive_request_locators.ReqFilesInternationalRights);
        this.ReqFilesPDFMediaLowRes = page.locator(archive_request_locators.ReqFilesPDFMediaLowRes);
        this.ReqFilesPDFPrinterHighRes = page.locator(archive_request_locators.ReqFilesPDFPrinterHighRes);
        this.ReqFilesPostProduction = page.locator(archive_request_locators.ReqFilesPostProduction);
        this.ReqFilesReprint = page.locator(archive_request_locators.ReqFilesReprint);
        this.ReqFilesTroubleshooting = page.locator(archive_request_locators.ReqFilesTroubleshooting);
        this.ReqFilesOther = page.locator(archive_request_locators.ReqFilesOther);
        this.ReqFilesOtherInput = page.locator(archive_request_locators.ReqFilesOtherInput);
        this.statusNotes = page.locator(archive_request_locators.statusNotes);
        this.statusNotesButton = page.locator(archive_request_locators.statusNotesButton);
        this.specialInstructions = page.locator(archive_request_locators.specialInstructions);
        this.specialInstructionsButton = page.locator(archive_request_locators.specialInstructionsButton);
        this.clearButton = page.locator(archive_request_locators.clearButton);
        this.cloneButton = page.locator(archive_request_locators.cloneButton);
        this.saveRecordButton = page.locator(archive_request_locators.saveRecordButton);
    }

    async goto(url: string) {
        await this.page.goto(url);
    }

    async enter_MHID(MHIDData: string) {
        expect(await this.MHID.isEditable()).toBeTruthy();
        expect(await this.ISBN13.isEditable()).toBeTruthy();
        await this.MHID.fill(MHIDData);
        await this.page.keyboard.press("Tab");
        expect(await this.MHID.isEditable()).toBeTruthy();
        await this.page.waitForTimeout(1000);
    }

    async enter_ISBN13(ISBN13Data: string) {
        expect(await this.MHID.isEditable()).toBeTruthy();
        expect(await this.ISBN13.isEditable()).toBeTruthy();
        await this.ISBN13.fill(ISBN13Data);
        await this.page.keyboard.press("Tab");
        expect(await this.ISBN13.isEditable()).toBeTruthy();
        await this.page.waitForTimeout(1000);
    }

    async pageLoadFieldsCheck() {
        await this.fieldsNotEditable();
        expect(await this.requestReceivedDate.isDisabled()).toBeTruthy();
        expect(await this.dueDate.isDisabled()).toBeTruthy();
        expect(await this.completedDate.isDisabled()).toBeTruthy();
        expect(await this.inProgress.isDisabled()).toBeTruthy();
        expect(await this.archivist.isDisabled()).toBeTruthy();
        expect(await this.requestedBy.isDisabled()).toBeTruthy();
        expect(await this.requestorDepartment.isDisabled()).toBeTruthy();
        expect(await this.deliveryMedium.isDisabled()).toBeTruthy();
        expect(await this.compositorVendor.isDisabled()).toBeTruthy();
        expect(await this.printingVersion.isDisabled()).toBeTruthy();
        expect(await this.ReqFilesArtPhoto.isDisabled()).toBeTruthy();
        expect(await this.ReqFilesApplication.isDisabled()).toBeTruthy();
        expect(await this.ReqFilesCoverDesign.isDisabled()).toBeTruthy();
        expect(await this.ReqFilesDisabledStudent.isDisabled()).toBeTruthy();
        expect(await this.ReqFileseBook.isDisabled()).toBeTruthy();
        expect(await this.ReqFilesInternationalRights.isDisabled()).toBeTruthy();
        expect(await this.ReqFilesPDFMediaLowRes.isDisabled()).toBeTruthy();
        expect(await this.ReqFilesPDFPrinterHighRes.isDisabled()).toBeTruthy();
        expect(await this.ReqFilesPostProduction.isDisabled()).toBeTruthy();
        expect(await this.ReqFilesReprint.isDisabled()).toBeTruthy();
        expect(await this.ReqFilesTroubleshooting.isDisabled()).toBeTruthy();
        expect(await this.ReqFilesOther.isDisabled()).toBeTruthy();
        expect(await this.statusNotes.isDisabled()).toBeTruthy();
        expect(await this.specialInstructions.isDisabled()).toBeTruthy();
    }

    async fieldsNotEditable() {
        await this.page.waitForTimeout(1000);
        expect(await this.nextEditionISBN.isDisabled()).toBeTruthy();
        expect(await this.priorEditionISBN.isDisabled()).toBeTruthy();
        expect(await this.authors.isDisabled()).toBeTruthy();
        expect(await this.marketingTitle.isDisabled()).toBeTruthy();
        expect(await this.edition.isDisabled()).toBeTruthy();
        expect(await this.copyrightyear.isDisabled()).toBeTruthy();
        expect(await this.calculatedBBD.isDisabled()).toBeTruthy();
        expect(await this.permissionEndDate.isDisabled()).toBeTruthy();
        expect(await this.projectOPDate.isDisabled()).toBeTruthy();
        expect(await this.publicationStatus.isDisabled()).toBeTruthy();
        expect(await this.owningDivision.isDisabled()).toBeTruthy();
        expect(await this.owningSubDivision.isDisabled()).toBeTruthy();
        expect(await this.subdivisionDescription.isDisabled()).toBeTruthy();
        expect(await this.deliveryFormat.isDisabled()).toBeTruthy();
        expect(await this.titleType.isDisabled()).toBeTruthy();
        expect(await this.gradeRange.isDisabled()).toBeTruthy();
        expect(await this.specificMarket.isDisabled()).toBeTruthy();
        expect(await this.ipubPublishingGroup.isDisabled()).toBeTruthy();
        expect(await this.ipubProgrammingTitle.isDisabled()).toBeTruthy();
        expect(await this.pageCount.isDisabled()).toBeTruthy();
        expect(await this.archiveNotes.isDisabled()).toBeTruthy();
    }

    async fieldsEditable() {
        await this.page.waitForTimeout(1000);
        expect(await this.MHID.isEditable()).toBeTruthy();
        expect(await this.ISBN13.isEditable()).toBeTruthy();
        expect(await this.requestReceivedDate.isEditable()).toBeTruthy();
        expect(await this.dueDate.isEditable()).toBeTruthy();
        expect(await this.completedDate.isEditable()).toBeTruthy();
        expect(await this.inProgress.isEditable()).toBeTruthy();
        expect(await this.archivist.isEditable()).toBeTruthy();
        expect(await this.requestedBy.isEditable()).toBeTruthy();
        expect(await this.requestorDepartment.isEditable()).toBeTruthy();
        expect(await this.deliveryMedium.isEditable()).toBeTruthy();
        expect(await this.compositorVendor.isEditable()).toBeTruthy();
        expect(await this.printingVersion.isEditable()).toBeTruthy();
        expect(await this.ReqFilesArtPhoto.isEditable()).toBeTruthy();
        expect(await this.ReqFilesApplication.isEditable()).toBeTruthy();
        expect(await this.ReqFilesCoverDesign.isEditable()).toBeTruthy();
        expect(await this.ReqFilesDisabledStudent.isEditable()).toBeTruthy();
        expect(await this.ReqFileseBook.isEditable()).toBeTruthy();
        expect(await this.ReqFilesInternationalRights.isEditable()).toBeTruthy();
        expect(await this.ReqFilesPDFMediaLowRes.isEditable()).toBeTruthy();
        expect(await this.ReqFilesPDFPrinterHighRes.isEditable()).toBeTruthy();
        expect(await this.ReqFilesPostProduction.isEditable()).toBeTruthy();
        expect(await this.ReqFilesReprint.isEditable()).toBeTruthy();
        expect(await this.ReqFilesTroubleshooting.isEditable()).toBeTruthy();
        expect(await this.ReqFilesOther.isEditable()).toBeTruthy();
        await this.ReqFilesOther.click();
        if (await this.ReqFilesOther.isChecked()) {
            expect(await this.ReqFilesOtherInput.isEditable()).toBeTruthy();
        }
        await this.ReqFilesOther.click();
        expect(await this.statusNotes.isEditable()).toBeFalsy();
        expect(await this.statusNotesButton.isEditable()).toBeTruthy();
        expect(await this.specialInstructions.isEditable()).toBeFalsy();
        expect(await this.specialInstructionsButton.isEditable()).toBeTruthy();
    }

    async updateData() {
        await this.page.waitForTimeout(1000);
        await this.archivist.selectOption('1014');
        await this.requestedBy.fill("Test Request");
        await this.dueDate.fill(await this.getDate());
        expect(await this.saveRecordButton.isEditable()).toBeTruthy();
        expect(await this.cloneButton.isEditable()).toBeTruthy();
        expect(await this.clearButton.isEditable()).toBeTruthy();
    }

    async checkRequestReceivedDate() {
        await this.page.waitForTimeout(1000);
        const today = await this.getDate();
        expect(await this.getDate() === await this.requestReceivedDate.inputValue()).toBeTruthy();
    }

    async getDate(): Promise<string> {
        var today = new Date();
        let month = today.getMonth() < 10 ? '0' + (today.getMonth() + 1) : today.getMonth() + 1;
        let todayDate = today.getDate() < 10 ? '0' + today.getDate() : today.getDate();
        var date = today.getFullYear() + '-' + month + '-' + todayDate;
        return date;
    }

    async updateLegacyArchivist() {
        expect(await this.archivist.isEnabled()).toBeTruthy();
        await this.archivist.selectOption('1014');
    }

    async checkLegacyArchivist() {
        expect(await this.archivist.isEnabled()).toBeTruthy();
        expect(await this.archivist.selectOption('1014')).toBeTruthy();
    }

    async checkRecordInformation() {
        await this.completedDate.fill(await this.getDate());
    }

    async checkDaysTakenField() {
        const daysTakenToComplete = await this.page.locator("text=Days Taken To Complete:")
        await this.completedDate.fill(await this.getDate());
        expect(await daysTakenToComplete.innerText() == "Days Taken To Complete: 1").toBeTruthy();
    }

    async addStatusNotes() {
        expect(this.statusNotes.isDisabled()).toBeTruthy()
        expect(await this.statusNotesButton.isEditable()).toBeTruthy();
        await this.statusNotesButton.click();
        const testNote = "This is the test note.";
        await this.page.locator("#specialinstruction").fill(testNote)
        await this.page.getByRole('button', { name: 'Add' }).click();
        const j = await this.statusNotes.inputValue();
        expect(j.search(testNote) > 0).toBeTruthy();
    }

    async addInstructionNotes() {
        expect(this.specialInstructions.isDisabled()).toBeTruthy()
        expect(await this.specialInstructionsButton.isEditable()).toBeTruthy();
        await this.specialInstructionsButton.click();
        const testNote = "This is the test note.";
        await this.page.locator("#specialinstruction").fill(testNote)
        await this.page.getByRole('button', { name: 'Add' }).click();
        const j = await this.specialInstructions.inputValue();
        expect(j.search(testNote) > 0).toBeTruthy();
    }

    async fillRequiredData(){
        await this.page.waitForTimeout(1000);
        await this.archivist.selectOption('1014');
        await this.requestedBy.fill("Test Request");
        await this.dueDate.fill(await this.getDate());
    }

    async saveRequestButtonEnable() {
        await this.fillRequiredData();
        expect(await this.saveRecordButton.isDisabled()).toBeFalsy();
        expect(await this.statusNotesButton.isDisabled()).toBeFalsy();
        expect(await this.specialInstructionsButton.isDisabled()).toBeFalsy();
        expect(await this.cloneButton.isDisabled()).toBeFalsy();
    }

    async saveRequestButtonDisable() {
        await this.fillRequiredData();
        expect(await this.saveRecordButton.isEnabled()).toBeFalsy();
        expect(await this.cloneButton.isEnabled()).toBeFalsy();
    }

}