import { test, expect, Page, Locator } from "@playwright/test";
import login_locators from "@locators/login_locators";

export class LoginPage {
  readonly username: Locator;
  readonly password: Locator;
  readonly signInButton: Locator;
  readonly archiveDalApp: Locator;
  readonly associatedDalApp: Locator;
  readonly archiveRequestDalApp: Locator;
  readonly nimasDalApp: Locator;
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;

    this.username = page.locator(login_locators.username).first();
    this.password = page.locator(login_locators.password).first();
    this.signInButton = page.locator(login_locators.signInButton).first();

    if(process.env.SDLC.trim().toLowerCase() === 'prod') {
      this.archiveDalApp = page.locator(login_locators.archiveDalProdApp).first();
      this.associatedDalApp = page.locator(login_locators.archiveDalProdApp).first();
      this.archiveRequestDalApp = page.locator(login_locators.archiveDalProdApp).first();
      this.nimasDalApp = page.locator(login_locators.archiveDalProdApp).first();
    }else{
      this.archiveDalApp = page.locator(login_locators.archiveDalApp).first();
      this.associatedDalApp = page.locator(login_locators.archiveDalApp).first();
      this.archiveRequestDalApp = page.locator(login_locators.archiveDalApp).first();
      this.nimasDalApp = page.locator(login_locators.archiveDalApp).first();
    }
  }

  async goto(baseURL) {
      await this.page.goto(baseURL);
  }
  
  async logintoOkta(username, password) {
    await this.username.fill(username);
    await this.username.press("Tab");
    await this.password.fill(password);
    await this.signInButton.click();
  }

  async launchArchiveDALapp() {
    await this.archiveDalApp.click();
  }

  async launchAssociatedDALapp(){
    await this.associatedDalApp.click();
  }

  async launchArchiveRequestDALapp(){
    await this.archiveRequestDalApp.click();
  }

  async launchNimasDALapp(){
    await this.nimasDalApp.click();
  }

  async verifyElementText(locator: string, text: string): Promise<void> {
    await this.waitForElementAttached(locator);
    const textValue = await this.page.textContent(locator);
    expect(textValue.trim()).toBe(text);
  }
  async waitForElementAttached(locator: string): Promise<void> {
    await this.page.waitForSelector(locator);
  }
}
