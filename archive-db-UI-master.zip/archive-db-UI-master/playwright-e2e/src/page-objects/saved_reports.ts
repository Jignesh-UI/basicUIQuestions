import { test, expect, Page, Locator } from "@playwright/test";
import saved_search_locators from "@locators/saved_search_locators";
import search_locators from "@locators/search_locators";
import saved_report_locators from "@locators/saved_reports_locators";
import report_locators from "@locators/report_locators";
import { Report_Data, Report_Data_Params } from "tests/environments/environment";

export class SavedReportPage {
    readonly savedReportsLabel: Locator;
    readonly page: Page;

    readonly reportContainer: Locator;
    readonly reportCriteria: Locator;
    readonly page_label: Locator;
    readonly properties_label: Locator;
    readonly contains_label: Locator;
    readonly value_label: Locator;
    readonly create_report_button: Locator;
    readonly save_report_button: Locator;
    readonly move_up_button: Locator;
    readonly move_down_button: Locator;
    readonly add_property_button: Locator;
    readonly remove_property_button: Locator;
    readonly availableProperties: Locator;
    readonly addProperties: Locator;
    readonly removeProperties: Locator;
    readonly selectedProperties: Locator;

    readonly testData = [{
        search_page_type: "Archive Record",
        properties: "Copyright Year",
        contains: "Equals",
        value: "2022",
    },
    {
        search_page_type: "AND",
        properties: "MHID",
        contains: "Starts with",
        value: "0",
    },
    {
        search_page_type: "AND",
        properties: "Owning Division",
        contains: "Contains",
        value: "College",
    }]


    constructor(page: Page) {
        this.page = page;
        this.savedReportsLabel = page.locator(saved_report_locators.savedReportsLabel);

        this.reportContainer = page.locator(report_locators.reportContainer)
        this.reportCriteria = page.locator(report_locators.reportCriteria).first()
        this.page_label = page.locator(report_locators.page_label).first()
        this.properties_label = page.locator(report_locators.properties_label).first()
        this.contains_label = page.locator(report_locators.contains_label).first()
        this.value_label = page.locator(report_locators.value_label).first()
        this.create_report_button = page.locator(report_locators.create_report_button)
        this.save_report_button = page.locator(report_locators.save_report_button)
        this.move_up_button = page.locator(report_locators.move_up_button)
        this.move_down_button = page.locator(report_locators.move_down_button)
        this.add_property_button = page.locator(report_locators.add_property_button)
        this.remove_property_button = page.locator(report_locators.remove_property_button)
        this.availableProperties = page.locator(report_locators.availableProperties)
        this.addProperties = page.locator(report_locators.addProperties)
        this.removeProperties = page.locator(report_locators.removeProperties)
        this.selectedProperties = page.locator(report_locators.selectedProperties)
    }

    async goto(baseURL: string) {
        await this.page.goto(baseURL);
    }

    async gridVisible() {
        expect(await this.page.locator("ag-grid-angular").isVisible()).toBeTruthy();
    }

    async fillFieldValues(rpt_data: Report_Data_Params[], lengthRec = 0) {
        const dataLength = lengthRec == 0 ? rpt_data.length : lengthRec;
        for (let i = 0; i < dataLength; i++) {
            await this.page.locator(".reportsContainer > .adjustment:nth-child(" + (i + 2) + ") > div:nth-child(1) > .form-control").selectOption({ label: rpt_data[i].search_page_type });
            await this.page.locator(".reportsContainer > .adjustment:nth-child(" + (i + 2) + ") > div:nth-child(2) > .form-control").selectOption({ label: rpt_data[i].properties });
            await this.page.locator(".reportsContainer > .adjustment:nth-child(" + (i + 2) + ") > div:nth-child(3) > .form-control").selectOption({ label: rpt_data[i].contains });
            if (rpt_data[i].contains == 'Equals' && rpt_data[i].properties == 'Archivist') {
                await this.page.locator(".reportsContainer > .adjustment:nth-child(" + (i + 2) + ") > div:nth-child(4) > .form-control").selectOption({ label: rpt_data[i].value });
            } else if (rpt_data[i].contains != 'Is Not Null' && rpt_data[i].contains != 'Is Null') {
                await this.page.locator(".reportsContainer > .adjustment:nth-child(" + (i + 2) + ") > div:nth-child(4) > .form-control").fill(rpt_data[i].value);
            }
            if (i < dataLength - 1) {
                await this.add_property_button.nth(0).click();
            }
        }
        await this.page.waitForTimeout(1000);
    }

    async loadReportsArchiveRecord() {
        expect(await this.availableProperties.count()).not.toBe(null);
        await this.availableProperties.selectOption([{ label: 'MHID' }, { label: 'ISBN-13' }, { label: 'Author(s)' }, { label: 'Copyright Year' }, { label: 'Delivery Format' }, { label: 'Edition' }]);
        await this.addProperties.click();
        await this.page.waitForTimeout(1000);
    }

    async saveReportWithMessage(message: string) {
        await Promise.all([
            await this.page.getByRole('button', { name: 'Save Report' }).click(),
            expect(await this.page.getByRole('button', { name: 'Save' }).isDisabled()).toBeTruthy(),
            expect(await this.page.getByRole('button', { name: 'Cancel' }).isDisabled()).toBeFalsy(),
            await this.page.locator('#specialinstruction').fill(message),
            await this.page.getByRole('button', { name: 'Save' }).click(),
        ]);
    }

    async addAdditionalParam(reqData: Report_Data_Params, pointer: number) {
        await this.add_property_button.nth(0).click();
        await this.page.locator(".reportsContainer > .adjustment:nth-child(" + pointer + ") > div:nth-child(1) > .form-control").selectOption({ label: reqData.search_page_type });
        await this.page.locator(".reportsContainer > .adjustment:nth-child(" + pointer + ") > div:nth-child(2) > .form-control").selectOption({ label: reqData.properties });
        await this.page.locator(".reportsContainer > .adjustment:nth-child(" + pointer + ") > div:nth-child(3) > .form-control").selectOption({ label: reqData.contains });
        if (reqData.contains != 'Is Not Null' && reqData.contains != 'Is Null') {
            await this.page.locator(".reportsContainer > .adjustment:nth-child(" + pointer + ") > div:nth-child(4) > .form-control").fill(reqData.value);
        }
    }

    async addAdditionalColumn() {
        await this.availableProperties.selectOption([{ label: 'Owning Division' }]);
        await this.addProperties.click();
    }

    async loadReportsArchiveRequest() {
        expect(await this.availableProperties.count()).not.toBe(null);
        await this.availableProperties.selectOption([{ label: 'MHID' }, { label: 'ISBN-13' }, { label: 'Owning Division' }, { label: 'Copyright Year' }, { label: 'Task ID' }, { label: 'Edition' }]);
        await this.addProperties.click();
        await this.page.waitForTimeout(1000);
    }

    async runReport(dlRptNumber = 1) {
        const fs = require('fs');
        const [download] = await Promise.all([
            this.page.waitForEvent('download'),
            await this.page.locator("ag-grid-angular .ag-body-viewport .ag-center-cols-viewport .ag-center-cols-container .ag-row:nth-child(" + dlRptNumber + ") .text-primary").click()
        ]);
        const filePath = 'C:/test/' + download.suggestedFilename();
        await download.saveAs(filePath)
        expect(fs.existsSync(filePath)).toBeTruthy()
    }

    async deleteReport(recordLength: number) {
        await this.page.locator("ag-grid-angular .ag-body-viewport .ag-center-cols-viewport .ag-center-cols-container .ag-row:nth-child(1) .text-danger").click()
        await Promise.all([
            await this.page.waitForSelector("button:has-text('Confirm')"),
            await this.page.locator("button:has-text('Confirm')").click(),
            await this.page.waitForEvent('response'),
            await this.page.waitForTimeout(3000)
        ]);
    }

    async downloadReport() {
        const fs = require('fs');
        const [download] = await Promise.all([
            this.page.waitForEvent('download'),
            await this.page.getByRole('button', { name: 'Create Report' }).click(),
            await this.page.waitForTimeout(1000)
        ]);
        const filePath = 'C:/test/1' + download.suggestedFilename();
        await download.saveAs(filePath)
        expect(fs.existsSync(filePath)).toBeTruthy()
    }

    async downloadSavedReport(rptName: string) {
        const newRecordLength = await this.page.locator("ag-grid-angular .ag-body-viewport .ag-center-cols-viewport .ag-center-cols-container .ag-row").count();
        let dlRptNumber = 0;
        for (let i = 0; i < newRecordLength; i++) {
            const lstName = await this.page.locator(".ag-center-cols-container .ag-row:nth-child(" + (i + 1) + ") .ag-cell:nth-child(2)").textContent();
            const flg = rptName == lstName ? true : false;
            if (flg) {
                dlRptNumber = i + 1;
                break;
            }
        }
        const fs = require('fs');
        const [download] = await Promise.all([
            this.page.waitForEvent('download'),
            await this.page.locator("ag-grid-angular .ag-body-viewport .ag-center-cols-viewport .ag-center-cols-container .ag-row:nth-child(" + dlRptNumber + ") .text-primary").click()
        ]);
        const filePath = 'C:/test/' + download.suggestedFilename();
        await download.saveAs(filePath)
        expect(fs.existsSync(filePath)).toBeTruthy()
    }

    async saveReportWithLongMessage(message: string) {
        await Promise.all([
            await this.page.getByRole('button', { name: 'Save Report' }).click(),
            expect(await this.page.getByRole('button', { name: 'Save' }).isDisabled()).toBeTruthy(),
            expect(await this.page.getByRole('button', { name: 'Cancel' }).isDisabled()).toBeFalsy(),
            await this.page.locator('#specialinstruction').fill(message),
            expect(await (await this.page.locator('#specialinstruction').inputValue()).length).toBeLessThanOrEqual(100),
            await this.page.getByRole('button', { name: 'Save' }).click()
        ]);
    }

    async changeSortOrder() {
        await Promise.all([
            await this.page.locator(".ag-header-row .ag-header-cell:nth-child(2)").click(),
            this.page.waitForTimeout(3000),
        ]);
        await expect(this.page.locator(".ag-header-row .ag-header-cell:nth-child(2) .ag-header-icon.ag-sort-ascending-icon.ag-hidden")).toHaveCount(0);
    }
    
    async deleteAllSavedReport() {
        const rcount = await this.page.locator(".ag-center-cols-container .ag-row").count();
        // await this.page.pause();
        for (let i = 0; i < rcount; i++) {
          await this.page.locator(".ag-center-cols-container .ag-row:nth-child(1) .ag-cell:nth-child(8)").getByText('Delete').click();
          await Promise.all([
            await this.page.waitForSelector("button:has-text('Confirm')"),
            await this.page.locator("button:has-text('Confirm')").click(),
            await this.page.waitForEvent('response'),
            await this.page.waitForTimeout(1000)
          ]);
        }
        // await this.page.pause();
    }

}

