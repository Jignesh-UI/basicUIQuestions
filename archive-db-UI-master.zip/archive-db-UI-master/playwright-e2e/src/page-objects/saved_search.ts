import { test, expect, Page, Locator } from "@playwright/test";
import saved_search_locators from "@locators/saved_search_locators";
import search_locators from "@locators/search_locators";
import globalSetup from "@globalSetup/global_setup";
const environment = globalSetup();

export class SavedSearchPage {
  readonly savedSearchesLabel: Locator;
  readonly searchContainer: Locator;
  readonly searchCriteria: Locator;
  readonly page_label: Locator;
  readonly properties_label: Locator;
  readonly contains_label: Locator;
  readonly value_label: Locator;
  readonly search_button: Locator;
  readonly save_search_button: Locator;
  readonly add_property_button: Locator;
  readonly remove_property_button: Locator;
  readonly page: Page;

  readonly test_data = [{
    search_page_type: 'Archive Record',
    properties: "Copyright Year",
    contains: 'Equals',
    value: "2021",
  }, {
    search_page_type: "AND",
    properties: "Owning Division",
    contains: 'Equals',
    value: "College",
  }];

  readonly test_data_Request = [{
    search_page_type: 'Archive Request',
    properties: "Copyright Year",
    contains: 'Equals',
    value: "2021",
  }, {
    search_page_type: "AND",
    properties: "Owning Division",
    contains: 'Equals',
    value: "College",
  }];

  constructor(page: Page) {
    this.page = page;
    this.savedSearchesLabel = page.locator(saved_search_locators.savedSearchesLabel);
    this.add_property_button = page.locator(search_locators.add_property_button);
  }

  async goto(baseURL: string) {
    await this.page.goto(baseURL);
  }

  async gridVisible() {
    expect(await this.page.locator("ag-grid-angular").isVisible()).toBeTruthy();
  }

  async adjustCriteria(search_data_request: any) {
    for (let i = 0; i < search_data_request.length; i++) {
      await this.page.locator("div:nth-child(" + (i + 1) + ") > div:nth-child(1) > .form-control").selectOption({ label: search_data_request[i].search_page_type });
      await this.page.locator("div:nth-child(" + (i + 1) + ") > div:nth-child(2) > .form-control").selectOption({ label: search_data_request[i].properties });
      await this.page.locator("div:nth-child(" + (i + 1) + ") > div:nth-child(3) > .form-control").selectOption({ label: search_data_request[i].contains });
      if (search_data_request[i].contains != 'Is Not Null' && search_data_request[i].contains != 'Is Null') {
        await this.page.locator("div:nth-child(" + (i + 1) + ") > div:nth-child(4) > .form-control").fill(search_data_request[i].value);
      }
      if (i < search_data_request.length - 1) {
        await this.add_property_button.nth(0).click();
        (await this.page.waitForSelector("div:nth-child(" + (i + 1) + ") > div:nth-child(1) > .form-control")).isVisible();
      }
    }
  }

  async searchForReport() {
    await this.adjustCriteria(this.test_data);
    await this.page.locator('button:has-text("Search")').nth(1).click();
    await this.page.waitForSelector(".dataTable > tbody > .dataTableRow");
    await (await this.page.waitForSelector('.dataTable tbody .dataTableRow:nth-child(1)')).isVisible();
    await this.saveReportWithMessage("Archive Rec: CP = 2021, College");
    await this.saveReportWithMessage("Archive Rec: CP = 2021, College - V2");
  }

  async saveReportWithMessage(message: string) {
    await Promise.all([
      await this.page.getByRole('button', { name: 'Save Search' }).click(),
      expect(await this.page.getByRole('button', { name: 'Save' }).isDisabled()).toBeTruthy(),
      expect(await this.page.getByRole('button', { name: 'Cancel' }).isDisabled()).toBeFalsy(),
      await this.page.locator('#specialinstruction').fill(message),
      await this.page.getByRole('button', { name: 'Save' }).click(),
    ]);
  }

  async additionalSearchCriteria() {
    const newcriteria = [{
      search_page_type: 'Archive Record',
      properties: "Copyright Year",
      contains: 'Equals',
      value: "2021",
    }, {
      search_page_type: "AND",
      properties: "Owning Division",
      contains: 'Equals',
      value: "College",
    }, {
      search_page_type: "AND",
      properties: "Marketing Title",
      contains: 'Starts with',
      value: "a",
    }, {
      search_page_type: "AND",
      properties: "Edition",
      contains: 'Ends with',
      value: "2",
    }, {
      search_page_type: "AND",
      properties: "Marketing Title",
      contains: 'Does not contain',
      value: 'z'
    }, {
      search_page_type: "AND",
      properties: "Edition",
      contains: 'Does not equal',
      value: "12",
    }];
    await this.adjustCriteria(newcriteria);
    await this.page.locator('button:has-text("Search")').nth(1).click();
    await this.page.waitForSelector(".dataTable > tbody > .dataTableRow");
    await (await this.page.waitForSelector('.dataTable tbody .dataTableRow:nth-child(1)')).isVisible();
    await this.saveReportWithMessage("Archive Rec Saved Search: V3");
    await (await this.page.waitForSelector(".toast-container .toast-success")).isVisible();
    await (await this.page.waitForSelector(".toast-container .toast-success")).isHidden();
  }

  async searchArchiveRequestReport() {
    await this.adjustCriteria(this.test_data_Request);
    await this.page.locator('button:has-text("Search")').nth(1).click();
    await this.page.waitForSelector(".dataTable > tbody > .dataTableRow");
    await (await this.page.waitForSelector('.dataTable tbody .dataTableRow:nth-child(1)')).isVisible();
    await this.saveReportWithMessage("Archive Req: CP = 2021, College");
    await (await this.page.waitForSelector(".toast-container .toast-success")).isVisible();
    await (await this.page.waitForSelector(".toast-container .toast-success")).isHidden();
  }

  async runSavedReport() {
    const url: String = environment.ApplicationURL + "#/search/"; // environment.ApplicationURL + "#/search/";
    const pageQueryUrl = await this.page.locator(".ag-center-cols-container .ag-row:nth-child(1) .ag-cell:nth-child(1)").innerText();
    await this.page.locator(".ag-center-cols-container .ag-row:nth-child(1) .ag-cell:nth-child(8)").getByText('Run').click();
    await Promise.all([
      await this.page.goto(url + pageQueryUrl),
      await this.page.waitForSelector(".totalRecordCount"),
      expect(await (await this.page.locator(".totalRecordCount").innerText()).trim()).not.toBeNull(),
      await this.page.goBack(),
      await this.page.waitForTimeout(5000),
      await this.page.waitForSelector(".dataTableContainer .dataTable tbody .dataTableRow"),
    ]);
    expect(await this.page.locator(".dataTableContainer .dataTable tbody .dataTableRow").count()).not.toBeNull();
  }


  async deleteSavedReport() {
    if(await this.page.locator(".ag-center-cols-container .ag-row:nth-child(1)")){

      await this.page.locator(".ag-center-cols-container .ag-row:nth-child(1) .ag-cell:nth-child(8)").getByText('Delete').click();
      await Promise.all([
        await this.page.waitForSelector("button:has-text('Confirm')"),
        await this.page.locator("button:has-text('Confirm')").click(),
        await this.page.waitForEvent('response'),
        await this.page.waitForTimeout(1000)
      ]);
      
      this.page.on("dialog", (dialog) => dialog.dismiss());
      
      await Promise.all([
        await this.page.reload(),
        await this.page.waitForSelector(".ag-center-cols-container .ag-row")
      ]);

    }
  }

  async deleteAllSavedSearches(){
      // await this.page.pause();
      const rcount = await this.page.locator(".ag-center-cols-container .ag-row").count();
      for (let i = 0; i < rcount; i++) {
          await this.page.locator(".ag-center-cols-container .ag-row:nth-child(1) .ag-cell:nth-child(8)").getByText('Delete').click();
          await Promise.all([
          await this.page.waitForSelector("button:has-text('Confirm')"),
          await this.page.locator("button:has-text('Confirm')").click(),
          await this.page.waitForTimeout(1000)
        ]);
      }
      // await this.page.pause();
  }

}
