import { test, expect, Page, chromium } from "@playwright/test";
import { App } from "@pages/app";
import globalSetup from "@globalSetup/global_setup";
const environment = globalSetup();

test.describe("Validate NIMAS Records by providing MHID", () => {
    let page: Page;

    test.beforeAll(async ({ browser }) => {
        page = await browser.newPage();
        console.log("Before tests");
        const app = new App(page, process.env.SDLC);
        app.logingPage.goto(environment.OKTAURL);
        app.logingPage.logintoOkta(
            process.env.OKTA_USERNAME,
            process.env.OKTA_PASSWORD
        );
        const app1 = new App(await launchApp(), process.env.SDLC);
        await app1.archiveDalMainPage.nimas.click();
        await app1.nimasRecordPage.enter_MHID(environment.MHID);
        await app1.page.close();
    });

    test.afterAll(async({browser})=>{
        page = await browser.newPage();
        await page.close();
    });

    async function launchApp(): Promise<Page> {
        const app = new App(page, process.env.SDLC);
        const [page2] = await Promise.all([
            page.waitForEvent("popup"),
            app.logingPage.launchArchiveDALapp(),
        ]);
        return page2;
    }

    test("Validate non editable fields", async () => {
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.nimas.click();
        await appPage.nimasRecordPage.enter_MHID(environment.MHID);
        await appPage.nimasRecordPage.fieldsNotEditable();
    });

    test('should disabled all the fields on page load', async () => {
        //Click on the NIMAS link on the menu bar at the top of the page
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.nimas.click();
        await appPage.nimasRecordPage.fieldsNotEditable();
    });

    test('should enabled all the fields of nimas archive information on page after mhid search', async () => {
        //Search for a product having NIMAS information, using MHID and tab
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.nimas.click();
        await appPage.nimasRecordPage.enter_MHID(environment.MHID);
        await appPage.nimasRecordPage.fieldsEditable();
    });

    test('should Update the NIMAS information and save', async () => {
        // Update the NIMAS information and save
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.nimas.click();
        await appPage.nimasRecordPage.enter_MHID(environment.expected_nimas_data.MHID);
        await appPage.nimasRecordPage.updateNimasRecord();
        await appPage.nimasRecordPage.saveNimasRecordButton.click();
        var nimasRecordMessage: string =
            "text=Nimas Record Updated Successfully for Nimas ID==>" +
            environment.expected_nimas_data.nimasId;
        expect(await appPage.page.locator(nimasRecordMessage).isVisible());
    });

    test('should disabled nimas archive comments', async () => {
        // Add Note
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.nimas.click();
        await appPage.nimasRecordPage.enter_MHID(environment.MHID);
        await appPage.nimasRecordPage.disabledAssociatedProductNotes();
    });

    test('should disabled nimas archive comments if it is empty', async () => {
        // Add blank note
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.nimas.click();
        await appPage.nimasRecordPage.enter_MHID(environment.MHID);
        await appPage.nimasRecordPage.disabledAssociatedProductNotesButton();
    });

    test('Make changes to the NIMAS record and click on the Archive record link from the menu, without saving the NIMAS record', async () => {
        // Make changes to the NIMAS record and click on the Archive record link from the menu, without saving the NIMAS record
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.nimas.click();
        await appPage.nimasRecordPage.enter_MHID(environment.MHID);
        await appPage.nimasRecordPage.fillNimasDetails();
        await appPage.page.locator('text=Archive Record (current)').click();
        await appPage.page.locator("text=Return to previous PAGE").click();
        await appPage.page.waitForNavigation(/*{ url:  ${environment.ApplicationURL} + '#/archiveRec' }*/),
            appPage.page.on("dialog", (dialog) => dialog.dismiss());
    });

    test('Load a new product by entring a new MHID without a NIMAS record', async () => {
        //Load a new product by entring a new MHID without a NIMAS record
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.nimas.click();
        await appPage.nimasRecordPage.enter_MHID(environment.expected_nimas_data.MHID);
        await appPage.nimasRecordPage.checkNimasDetails();
        await appPage.nimasRecordPage.saveNimasRecordButton.click();
        var nimasRecordMessage: string =
            "text=Nimas Record Updated Successfully for Nimas ID==>" +
            environment.expected_nimas_data.nimasId;
        expect(await appPage.page.locator(nimasRecordMessage).isVisible());
    });

    test('should enable Save Record if role policy is not read only.', async () =>{
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.nimas.click();
        await appPage.nimasRecordPage.enter_MHID(environment.MHID);
        await appPage.nimasRecordPage.saveRequestButtonEnable();
    });

    test('should disable Save Record if role policy is read only.', async () =>{
        const appPage = new App(await launchApp(), process.env.SDLC);
        await appPage.archiveDalMainPage.nimas.click();
        await appPage.nimasRecordPage.enter_MHID('test-mhid3');
        await appPage.nimasRecordPage.saveRequestButtonDisable();
    });

})
