import { Component, OnInit } from '@angular/core';
import * as OktaAuth from '@okta/okta-auth-js';
import { environment } from 'src/environments/environment';
import { RolesPolicyService } from './service/roles-policy.service';
import { OktaInfoService } from './shared/okta/okta-info.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'archiveDB';
  userEmail = '';
  constructor(private oktaService: OktaInfoService, private rolesService: RolesPolicyService) {
    console.log("TESTING NEW BUILD SYSYTEM", environment);
  }
  
  async ngOnInit(): Promise<void> {
    const promise = await this.oktaService.GetOktUserInfo();
    if(promise){
      this.userEmail = promise['claims']['email'];
      this.rolesService.userEmail = this.userEmail;
      await this.rolesService.listPolicies();
    }
  }

}
