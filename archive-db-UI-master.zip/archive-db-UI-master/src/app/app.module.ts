import { BrowserModule } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AgGridModule } from 'ag-grid-angular';
import { NgbModalModule } from '@ng-bootstrap/ng-bootstrap';
import { ToastrModule } from 'ngx-toastr';

import { AuthInterceptor } from './shared/okta/auth.interceptor';
import { OktaAuthService } from './service/okta-auth.service';
import { ComponentService } from './service/component.service';
import { OktaInfoService } from './shared/okta/okta-info.service';
import { CommonService } from './service/commonClasses/common.service';
import { InputHoverPopUpDirective } from './service/directives/input-hover-pop-up.directive';
import { MaterialModule } from './shared/material.module';
import { ConfirmDialogComponent } from './shared/confirm-dialog/confirm-dialog.component';
import { SortPaginationPipePipe } from './service/pipes/sort-pagination-pipe.pipe';
import { LoadingSpinnerComponent } from './shared/loading-spinner/loading-spinner.component';
import { FluidHeightDirective } from './service/directives/fluid-height.directive';
import { TrimValueDirective } from './service/directives/trim-value.directive';

import { AppComponent } from './app.component';
import { PopupComponent } from './components/popup/popup.component';
import { HeaderComponent } from './components/header/header.component';
import { MenuComponent } from './components/menu/menu.component';
import { LogoutComponent } from './components/logout/logout.component';
import { SearchComponent } from './components/search/search.component';
import { ReportsComponent } from './components/reports/reports.component';
import { SearchResultComponent } from './components/search-result/search-result.component';
import { ActionRenderComponent } from './components/action-render/action-render.component';
import { SearchHistoryComponent } from './components/search-history/search-history.component';
import { ReportHistoryComponent } from './components/report-history/report-history.component';
import { AlertComponent } from './components/alert/alert.component';
import { ArcRecordComponent } from './components/archive-record/arc-record.component';
import { RecordInformationComponent } from './components/record-information/record-information.component';
import { ArchiveRequestComponent } from './components/archive-request/archive-request.component';
import { AssociatedRecordComponent } from './components/associated-record/associated-record.component';
import { NimasComponent } from './components/nimas/nimas.component';



@NgModule({
    declarations: [
        AppComponent,
        HeaderComponent,
        MenuComponent,
        LogoutComponent,
        PopupComponent,
        ReportsComponent,
        SearchComponent,
        SearchResultComponent,
        ActionRenderComponent,
        SearchHistoryComponent,
        ReportHistoryComponent,
        AlertComponent,
        ArcRecordComponent,
        RecordInformationComponent,
        ArchiveRequestComponent,
        AssociatedRecordComponent,
        InputHoverPopUpDirective,
        ConfirmDialogComponent,
        SortPaginationPipePipe,
        LoadingSpinnerComponent,
        FluidHeightDirective,
        NimasComponent,
        TrimValueDirective
    ],
    imports: [
        BrowserModule,
        HttpClientModule,
        BrowserAnimationsModule,
        AppRoutingModule,
        FormsModule,
        ReactiveFormsModule,
        NgbModalModule,
        MaterialModule,
        AgGridModule,
        BrowserAnimationsModule,
        ToastrModule.forRoot({ positionClass: 'toast-center-center', closeButton: true, toastClass: 'ngx-toastr' })
    ],
    providers: [ComponentService, OktaAuthService, { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true }, OktaInfoService, CommonService],
    bootstrap: [AppComponent],
    exports: [PopupComponent, AlertComponent],
    schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
})
export class AppModule { }
