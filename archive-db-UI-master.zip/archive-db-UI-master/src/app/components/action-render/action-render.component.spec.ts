import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { ActionRenderComponent } from './action-render.component';

describe('ActionRenderComponent', () => {
  let component: ActionRenderComponent;
  let fixture: ComponentFixture<ActionRenderComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ActionRenderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActionRenderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize action component', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.label = 'test';
    cmpInstance.agInit(['test']);
    expect(cmpInstance.label).toBeNull();
  });

  it('should refresh instance', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    const refreshValue = cmpInstance.refresh(['test']);
    expect(refreshValue).toBeTruthy();
  });

});
