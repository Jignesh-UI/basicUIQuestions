import { Component, OnInit, OnDestroy } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { ActivatedRoute, Router } from "@angular/router";
import { HttpResponse } from "src/app/shared/response.model";
import { OktaInfoService } from "src/app/shared/okta/okta-info.service";
import { Details, Summary } from "./arc-record.model";
import { NotificationService } from "src/app/service/notification.service";
import { LovDataService } from "src/app/service/commonClasses/lov-data.service";
import { Observable } from "rxjs";
import { CommonService } from "src/app/service/commonClasses/common.service";
import { APP_Messages } from "src/app/service/commonClasses/app-defaults";
import {
  chkInterface,
  lovInterface,
} from "src/app/service/models/common.model";
import { environment } from "src/environments/environment";
import { RolesPolicyService } from "src/app/service/roles-policy.service";

@Component({
  selector: "app-arc-record",
  templateUrl: "./arc-record.component.html",
  styleUrls: ["./arc-record.component.css"],
})
export class ArcRecordComponent implements OnInit, OnDestroy {
  archiveData = new Details();
  archiveInfo = new Summary();
  compositors: [];
  message = "";
  iserror = false;
  userName: string;
  commnetsRows = 5;
  archiveNotesRows = 8;
  repcommnetsRows = 2;
  disabledPDHField = true;
  enablenotes = false;
  disabledSummaryFields = true;

  archivistArray: lovInterface[] = [];
  actualArchivistArray: lovInterface[] = [];
  compVendorArray: lovInterface[] = [];
  locationArray: lovInterface[] = [];
  reprintContactArray: lovInterface[] = [];
  actualReprintArray: lovInterface[] = [];
  insertsArray: lovInterface[] = [];
  endSheetsArray: lovInterface[] = [];
  prodSpecialistArray: lovInterface[] = [];

  pagingFilesArray: chkInterface[] = [];
  otherFilesArray: chkInterface[] = [];
  PDFsArray: chkInterface[] = [];

  compVendorOther = "";
  reprintContactOther = "";
  productionSpecialistOther = "";
  pagingFilesOther = "";
  otherFilesOther = "";

  maxLengthofControls = {
    mhidMaxLength: 15,
    ISBN13MaxLength: 50,
    PREVIOUS_ISBNMaxLength: 15,
    NEW_ISBNMaxLength: 15,
    authorMaxLength: 240,
    titleMaxLength: 1500,
    editionMaxLength: 22,
    priorityMaxLength: 16,
    ODDMaxLength: 150,
    SDDMaxLength: 150,
    CopyYearMaxLength: 22,
    calculatedBBDMaxLength: 7,
    PermissionEndDateMaxLength: 7,
    projectOPDateMaxLength: 7,
    DeliveryFormatMaxLength: 150,
    TitleTypeMaxLength: 240,
    GradeRangeMaxLength: 5,
    SpecificMarketMaxLength: 150,
    ipubPublishingGroupMaxLength: 20,
    iPubProgramTitleMaxLength: 500,
    noOfPagesMaxLength: 22,
    LibraryLocationMaxLength: 500,
    PrintingMaxLength: 22,
    SetsofDiscsMaxLength: 22,
    DiscsinSetMaxLength: 22,
    DiscSizeMaxLength: 22,
    ArchiveNotesMaxLength: 4000,
    MB_GBMaxLength: 2,
  };

  recordInformation = {
    uniqueId: null,
    dateCreated: null,
    createdBy: "",
    dateLastModified: null,
    lastModifiedBy: null,
  };

  showReprintInput = false;
  showCompVendor = false;
  showProdSpeInput = false;

  searchedMHID = "";
  searchedISBN = "";

  isLoading = false;
  url = environment.baseAPIUrl + "services/archiveRecords";
  private headers = {
    headers: new HttpHeaders({
      "Content-Type": "application/json",
    }),
  };

  defaultReprintOtherValue = "";
  defaultCompVendorOtherValue = "";
  defaultproductionSpecialist = "";

  permissionsStatus = false;

  constructor(
    private oktaService: OktaInfoService,
    private http: HttpClient,
    private activatedRoute: ActivatedRoute,
    private notify: NotificationService,
    private lovData: LovDataService,
    private cs: CommonService,
    private router: Router,
    private rolesService: RolesPolicyService
  ) {
    // this.router.onSameUrlNavigation = 'reload';
    activatedRoute.params.subscribe((val) => {
      const recordId = val["keyword"];
      if (recordId != null) {
        this.searchByTab(recordId, "recordId");
      }
    });
  }

  async canDeactivate(): Promise<boolean | Observable<boolean>> {
    if (
      JSON.parse(localStorage.getItem("arcRecoData")) == null ||
      JSON.parse(localStorage.getItem("arcRecoData")) == undefined
    ) {
      localStorage.setItem(
        "arcRecoData",
        JSON.stringify({ summary: this.archiveData, details: this.archiveInfo })
      );
    }
    const chkData = JSON.parse(localStorage.getItem("arcRecoData"));
    if (this.archiveData["recordid"]) {
      if (
        JSON.stringify(chkData.details) === JSON.stringify(this.archiveInfo) &&
        JSON.stringify(chkData.summary) === JSON.stringify(this.archiveData)
      ) {
        return true;
      }
      const flag = await this.cs.showModalConfirmation(true);
      if (!flag) {
        return false;
      }
    }
    return true;
  }

  async ngOnInit(): Promise<void> {
    // this.userName = sessionStorage.getItem("userName");
    this.archiveData = new Details();
    this.archiveInfo = new Summary();

    const promise = await this.oktaService.GetOktUserInfo();
    const user = promise["claims"]["name"];
    this.userName = user;
    await this.loadLovs();
    localStorage.removeItem("arcRecoData");
  }

  async ngOnDestroy(): Promise<void> {
    localStorage.removeItem("arcRecoData");
  }

  async searchByTab(input: string, filterTyle: string) {
    this.isLoading = true;
    if (input.trim().length < 1) {
      this.isLoading = false;
      return false;
    } else if (filterTyle == "mhid" && input == this.searchedMHID) {
      this.isLoading = false;
      return false;
    } else if (filterTyle == "isbn" && input == this.searchedISBN) {
      this.isLoading = false;
      return false;
    }

    if (this.searchedMHID.length > 1 && this.searchedISBN?.length > 1) {
      const chkData = JSON.parse(localStorage.getItem("arcRecoData"));
      const dataComparisonFlag: boolean = await this.cs.adjustData(
        chkData,
        this.archiveInfo,
        this.archiveData
      );

      if (!dataComparisonFlag) {
        const t = await this.cs.showModalConfirmation();
        if (!t) {
          this.archiveData.mhid = this.searchedMHID;
          this.archiveData.isbn13 = this.searchedISBN;
          this.isLoading = false;
          return false;
        }
      }
      this.archiveData.mhid = this.searchedMHID;
      this.archiveData.isbn13 = this.searchedISBN;
    }

    let apiUrl = "";
    if (filterTyle == "mhid" && input) {
      apiUrl = this.url + "/mhId/" + input.replaceAll(".", "%2525252E");
    } else if (filterTyle == "isbn" && input) {
      apiUrl = this.url + "/isbn13/" + input.replaceAll(".", "%2525252E");
    } else if (filterTyle == "recordId" && input) {
      apiUrl = this.url + "/id/" + input.replaceAll(".", "%2525252E");
    } else {
      this.isLoading = false;
      return false;
    }

    this.http.get(apiUrl, this.headers).subscribe({
      next: async (responseData): Promise<void> => {
        this.archiveInfo.archivist = "";
        this.compVendorOther = "";
        this.reprintContactOther = "";
        this.productionSpecialistOther = "";
        this.pagingFilesOther = "";
        this.otherFilesOther = "";

        if (responseData["data"] && responseData["succeeded"]) {
          this.fillFormSubscription(responseData["data"]);
        } else {
          this.resetArchiveModel();
          this.notify.showSuccess("", responseData["message"]);
          this.disabledSummaryFields = true;
        }
        this.isLoading = false;
      },
      error: (err) => {
        this.disabledSummaryFields = true;
        this.isLoading = false;
        this.notify.showSuccess("", APP_Messages.ServerErrorMessage);
      }
    });
  }

  async fillFormSubscription(data: any) {
    this.resetCheckboxes();
    this.archiveData = data["summary"] as Details;
    this.archiveInfo = data["details"] as Summary;

    this.defaultReprintOtherValue = this.archiveInfo?.reprintContact?.otherValue == null ? "" : this.archiveInfo?.reprintContact?.otherValue;
    this.defaultCompVendorOtherValue = this.archiveInfo?.compositorVendor?.otherValue == null ? "" : this.archiveInfo?.compositorVendor?.otherValue;
    this.defaultproductionSpecialist = this.archiveInfo?.productionSpecialist?.otherValue == null ? "" : this.archiveInfo?.productionSpecialist?.otherValue;

    this.searchedMHID = this.archiveData.mhid;
    this.searchedISBN = this.archiveData.isbn13;
    this.fillRecordInfo(true);
    this.disablePDHControls();
    this.setArchivest();
    this.setCompVendor();
    this.setLocation();
    this.setReprintContact();
    this.setProdSpeciality();
    this.setInserts();
    this.setEndSheets();
    this.setPaggingFiles();
    this.setOtherFiles();
    this.setPDFLists();
    this.disabledSummaryFields = false;
    this.permissionsStatus = await this.rolesService.authenticationStatus(
      this.archiveData.owningDivision
    );
    localStorage.setItem(
      "arcRecoData",
      JSON.stringify({ summary: this.archiveData, details: this.archiveInfo })
    );
  }

  onCommentAdd(comment: any) {
    this.archiveData.comments = this.archiveData.comments || "";
    if (this.archiveData.comments.length > 0) {
      const newLine =
        this.archiveData.comments.substr(
          this.archiveData.comments.length - 1,
          2
        ) == "\n"
          ? ""
          : "\n";
      this.archiveData.comments +=
        newLine +
        this.userName +
        " " +
        this.cs.getDateTime() +
        "\n" +
        comment +
        "\n";
    } else {
      this.archiveData.comments +=
        this.userName + " " + this.cs.getDateTime() + "\n" + comment + "\n";
    }
  }

  onSubmit() {
    // changing the date format from mm-dd-yyyy to mm/dd/yyy
    // this.dateFormatChange('-', '/', 'html');
    this.isLoading = true;
    if (this.archiveData["recordid"] === undefined) {
      this.isLoading = false;
      return false;
    }
    const url = this.url + "/" + this.archiveData["recordid"];
    this.archiveInfo.modifiedDate = this.cs.getDate();
    this.archiveInfo.modifiedBy = this.userName;

    delete this.archiveInfo?.reprintContactTest;
    delete this.archiveInfo?.compVendorTest;
    delete this.archiveInfo?.productionSpecialistTest;

    let data: any = { summary: this.archiveData, details: this.archiveInfo };
    data = this.saveArchivist(data);
    data = this.saveCompVendor(data);
    data = this.saveLocation(data);
    data = this.saveRePrint(data);
    data = this.saveProdSpeciality(data);

    data = this.saveInserts(data);
    data = this.saveEndSheets(data);

    data = this.savePaggingFiles(data);
    data = this.saveOtherFilesList(data);
    data = this.savePdfsList(data);

    this.http.put<HttpResponse>(url, data).subscribe(
      (response) => {
        if (response.data == null || response.data == undefined) {
          this.isLoading = false;
          this.notify.showSuccess("", response.message);
          return;
        }
        this.message = response.message;
        this.resetDrpLists();
        this.recordInformation.dateLastModified =
          response.data["details"].modifiedDate;
        this.recordInformation.lastModifiedBy =
          response.data["details"].modifiedBy;
        // this.iserror = !response.succeeded;
        this.notify.showSuccess("", response.message);
        localStorage.setItem(
          "arcRecoData",
          JSON.stringify({
            summary: this.archiveData,
            details: this.archiveInfo,
          })
        );
        this.isLoading = false;
      },
      (err) => {
        // this.resetArchiveModel();
        this.isLoading = false;
        this.notify.showSuccess("", APP_Messages.ServerErrorMessage);
      }
    );
  }

  reprintValueChange(selectedValue: any) {
    let cdata: any;
    if (selectedValue.currentTarget) {
      cdata = selectedValue.currentTarget.options[
        selectedValue.currentTarget.selectedIndex
      ].text
        .trim()
        .toLocaleLowerCase();
    } else {
      cdata = selectedValue;
    }
    this.showReprintInput =
      cdata.trim().toLowerCase() == "other" ? true : false;
  }

  pagingFilesSeletionChange(event: any): void {
    if (event.target.value == "None" && event.target.checked) {
      this.pagingFilesArray.forEach((v) => {
        if (v.description != "None") {
          v.enabled = "N";
          v.checked = false;
          this.pagingFilesOther = "";
        } else {
          v.enabled = "Y";
        }
      });
    } else if (event.target.value == "None" && !event.target.checked) {
      this.pagingFilesArray.forEach((v) => (v.enabled = "Y"));
    }

    if (
      event.target.value.trim().toLowerCase() == "other" &&
      !event.target.checked
    ) {
      this.pagingFilesOther = "";
    }
  }

  otherFilesSelectionChange(event: any): void {
    if (event.target.value == "None" && event.target.checked) {
      this.otherFilesArray.forEach((v) => {
        if (v.description != "None") {
          v.enabled = "N";
          v.checked = false;
          this.otherFilesOther = "";
        } else {
          v.enabled = "Y";
        }
      });
    } else if (event.target.value == "None" && !event.target.checked) {
      this.otherFilesArray.forEach((v) => (v.enabled = "Y"));
    }

    if (
      event.target.value.trim().toLowerCase() == "other" &&
      !event.target.checked
    ) {
      this.otherFilesOther = "";
    }
  }

  compVendorChange(selectedValue: any) {
    let cdata: any;
    if (selectedValue.currentTarget) {
      cdata = selectedValue.currentTarget.options[
        selectedValue.currentTarget.selectedIndex
      ].text
        .trim()
        .toLocaleLowerCase();
    } else {
      cdata = selectedValue;
    }

    this.showCompVendor = cdata.trim().toLowerCase() == "other" ? true : false;
  }

  async loadLovs() {
    this.actualArchivistArray = this.archivistArray = this.lovData.returnArchivistLOV();
    this.compVendorArray = this.lovData.returnSingleLOV("COMPOSITOR_VENDOR");
    this.locationArray = this.lovData.returnSingleLOV("STORAGE_LOCATION");
    this.actualReprintArray = this.reprintContactArray = this.lovData.returnSingleLOV("REPRINT_CONTACT");
    this.prodSpecialistArray = this.lovData.returnSingleLOV(
      "PRODUCTION_SPECIALIST"
    );

    this.insertsArray = this.lovData.returnSingleLOV("INSERTS");
    this.endSheetsArray = this.lovData.returnSingleLOV("ENDSHEETS");

    this.pagingFilesArray = this.lovData.returnSingleLOV("PAGINGFILES");
    this.otherFilesArray = this.lovData.returnSingleLOV("OTHERFILES");
    this.PDFsArray = this.lovData.returnSingleLOV("PDFS");

    this.archiveInfo.archivist = "";
    this.archiveInfo.compositorVendor = "";
    this.archiveInfo.storageLocation = "";
    this.archiveInfo.reprintContact = "";
    this.archiveInfo.endsheets = "";
    this.archiveInfo.inserts = "";
  }

  private fillRecordInfo(resetField: boolean) {
    this.recordInformation.uniqueId =
      resetField == true ? this.archiveData.recordid : null;
    this.recordInformation.createdBy =
      resetField == true ? this.archiveInfo.createdBy : null;
    this.recordInformation.dateCreated =
      resetField == true ? this.archiveInfo.createdDate : null;
    this.recordInformation.dateLastModified =
      resetField == true ? this.archiveInfo.modifiedDate : null;
    this.recordInformation.lastModifiedBy =
      resetField == true ? this.archiveInfo.modifiedBy : null;
  }

  private disablePDHControls() {
    this.disabledPDHField = true;
    this.enablenotes = true;
  }

  setArchivest() {
    if ( this.archiveInfo.archivist?.description == null || this.archiveInfo.archivist?.description == "" ) {
      this.archiveInfo.archivist = "";
      return false;
    } else if (this.checkExistingArchiviest(this.archiveInfo.archivist.description) != true) {
      return false;
    }

    let dbData: string;
    let flag: boolean;

    if (this.archiveInfo.archivist != null) {
      this.archivistArray = this.lovData.returnArchivistLOV();
      dbData = this.archiveInfo.archivist["description"];
    }

    this.archivistArray.filter((ary) => {
      if (ary.description == dbData) {
        flag = true;
        return true;
      }
    });

    if (flag != true) {
      this.archivistArray.push(this.archiveInfo.archivist);
    }

    const lovId = this.archivistArray.filter((arryData) => {
      return arryData.description.toLowerCase() == dbData.toLowerCase();
    })[0].lovid;
    this.archiveInfo.archivist = lovId;
  }

  checkExistingArchiviest(paramData: string) {
    this.archivistArray = this.cs.removePreviousArray(
      this.archivistArray,
      this.actualArchivistArray
    );
    const dataLength = this.archivistArray.filter((arData) => {
      return arData.description.toLowerCase() === paramData.toLowerCase();
    });
    if (dataLength.length >= 1) {
      this.archiveInfo.archivist = dataLength[0].lovid;
      return false;
    } else {
      return true;
    }
  }

  private setCompVendor() {
    if (this.archiveInfo && this.archiveInfo.compositorVendor) {
      const dbData: string = this.archiveInfo.compositorVendor.description;
      for (const keys in this.compVendorArray) {
        if (dbData == this.compVendorArray[keys].description) {
          if (dbData.trim().toLowerCase() === "other") {
            this.compVendorOther = this.archiveInfo.compositorVendor.otherValue
              ? this.archiveInfo.compositorVendor.otherValue.trim()
              : "";
          } else {
            this.compVendorOther = "";
          }
          this.archiveInfo.compositorVendor = this.compVendorArray[keys].lovid;
          this.compVendorChange(dbData);
        }
      }
    } else {
      this.archiveInfo.compositorVendor = "";
      this.compVendorChange("");
    }
  }

  private setLocation() {
    if (this.archiveInfo && this.archiveInfo.storageLocation) {
      const dbData: string = this.archiveInfo.storageLocation.description;
      for (const keys in this.locationArray) {
        if (dbData == this.locationArray[keys].description) {
          this.archiveInfo.storageLocation = this.locationArray[keys].lovid;
        }
      }
    } else {
      this.archiveInfo.storageLocation = "";
    }
  }

  private setReprintContact() {
    if (!this.archiveInfo && !this.archiveInfo.reprintContact) {
      return false;
    }
      if ( this.archiveInfo.reprintContact?.description == null || this.archiveInfo.reprintContact?.description == "" ) {
        this.archiveInfo.reprintContact = "";
        return false;
      } else if (this.checkExistingReprintContact(this.archiveInfo.reprintContact.description) != true) {
        return false;
      }

    let dbData: string;
    let flag: boolean;

    if (this.archiveInfo.reprintContact != null) {
      this.reprintContactArray = this.lovData.returnReprintContactLOV();
      dbData = this.archiveInfo.reprintContact["description"];
    }

    this.reprintContactArray.filter((ary) => {
      if (ary.description == dbData) {
        flag = true;
        return true;
      }
    });

    if (flag != true) {
      this.reprintContactArray.push(this.archiveInfo.reprintContact);
    }

    const lovId = this.reprintContactArray.filter((arryData) => {
      return arryData.description.toLowerCase() == dbData.toLowerCase();
    })[0];
    this.archiveInfo.reprintContact = lovId.lovid;
    this.adjustReprintContactOther(lovId.description);
  }

  private setInserts() {
    if (this.archiveInfo && this.archiveInfo.inserts) {
      const dbData: string = this.archiveInfo.inserts.description;
      for (const keys in this.insertsArray) {
        if (dbData == this.insertsArray[keys].description) {
          this.archiveInfo.inserts = this.insertsArray[keys].lovid;
        }
      }
    } else {
      this.archiveInfo.inserts = "";
    }
  }

  private setEndSheets() {
    if (this.archiveInfo && this.archiveInfo.endsheets) {
      const dbData: string = this.archiveInfo.endsheets.description;
      for (const keys in this.endSheetsArray) {
        if (dbData == this.endSheetsArray[keys].description) {
          this.archiveInfo.endsheets = this.endSheetsArray[keys].lovid;
        }
      }
    } else {
      this.archiveInfo.endsheets = "";
    }
  }

  private setPaggingFiles() {
    if (this.archiveInfo && this.archiveInfo.pagingFilesList) {
      const noneChecked = this.archiveInfo.pagingFilesList.filter(
        (values: { description: string }) => {
          if (values.description == "None") {
            this.pagingFilesArray.filter((arrayValues) => {
              if (arrayValues.description == "None") {
                arrayValues.enabled = "Y";
                arrayValues.checked = true;
              } else {
                arrayValues.enabled = "N";
              }
            });
          }
          return values.description == "None";
        }
      )[0];

      if (noneChecked) {
        this.pagingFilesOther = "";
        return false;
      }

      this.pagingFilesArray.forEach((arrData) => {
        this.archiveInfo.pagingFilesList.forEach(
          (respData: { description: string; otherValue: string }) => {
            if (
              arrData.description.trim().toLowerCase() ==
              respData.description.trim().toLowerCase()
            ) {
              if (respData.description.trim().toLowerCase() === "other") {
                this.pagingFilesOther =
                  respData.otherValue == null
                    ? " "
                    : respData.otherValue?.trim();
              }
              arrData.checked = true;
            }
          }
        );
      });
    }
  }

  private setOtherFiles() {
    if (this.archiveInfo && this.archiveInfo.otherFilesList) {
      const noneChecked = this.archiveInfo.otherFilesList.filter(
        (values: { description: string }) => {
          if (values.description == "None") {
            this.otherFilesArray.filter((arrayValues) => {
              if (arrayValues.description == "None") {
                arrayValues.enabled = "Y";
                arrayValues.checked = true;
              } else {
                arrayValues.enabled = "N";
              }
            });
          }
          return values.description == "None";
        }
      )[0];

      if (noneChecked) {
        this.otherFilesOther = "";
        return false;
      }

      this.otherFilesArray.forEach((arrData) => {
        this.archiveInfo.otherFilesList.forEach(
          (respData: { description: string; otherValue: string }) => {
            if (
              arrData.description.trim().toLowerCase() ==
              respData.description.trim().toLowerCase()
            ) {
              if (respData.description.trim().toLowerCase() === "other") {
                this.otherFilesOther =
                  respData.otherValue == null
                    ? " "
                    : respData.otherValue?.trim();
              }
              arrData.checked = true;
            }
          }
        );
      });
    }
  }

  private setPDFLists() {
    if (this.archiveInfo && this.archiveInfo.pdfsList) {
      this.PDFsArray.forEach((arrData) => {
        this.archiveInfo.pdfsList.forEach(
          (respData: { description: string }) => {
            if (
              arrData.description.trim().toLowerCase() ==
              respData.description.trim().toLowerCase()
            ) {
              arrData.checked = true;
            }
          }
        );
      });
    }
  }

  private resetDrpLists() {
    this.setArchivest();
    this.setCompVendor();
    this.setLocation();
    this.setReprintContact();
    this.setProdSpeciality();
    this.setInserts();
    this.setEndSheets();
  }

  private resetCheckboxes() {
    this.pagingFilesArray.forEach((v) => {
      v.checked = false;
      v.enabled = "Y";
    });
    this.otherFilesArray.forEach((v) => {
      v.checked = false;
      v.enabled = "Y";
    });
    this.PDFsArray.forEach((v) => {
      v.checked = false;
      v.enabled = "Y";
    });
  }

  private resetArchiveModel() {
    this.archiveData = new Details();
    this.archiveInfo = new Summary();
    this.resetCheckboxes();
    this.fillRecordInfo(false);
    this.searchedMHID = "";
    this.searchedISBN = "";
  }

  private saveArchivist(data: any) {
    const fdata = this.archivistArray.filter((arr) => {
      return arr.lovid === +this.archiveInfo.archivist;
    })[0];
    data.details.archivist = fdata;
    return data;
  }

  private saveCompVendor(data: any) {
    let otherField = false;
    const fdata = this.compVendorArray.filter((arr) => {
      if (arr.lovid === +this.archiveInfo.compositorVendor) {
        if (arr.description.trim().toLowerCase() === "other") {
          otherField = true;
        }
        return arr.lovid === +this.archiveInfo.compositorVendor;
      }
    })[0];
    if (otherField) {
      fdata.otherValue = this.compVendorOther?.trim();
    }
    data.details.compositorVendor = fdata;
    return data;
  }

  private saveLocation(data: any) {
    const fdata = this.locationArray.filter((arr) => {
      return arr.lovid === +this.archiveInfo.storageLocation;
    })[0];
    data.details.storageLocation = fdata;
    return data;
  }

  private saveRePrint(data: any) {
    let otherField = false;
    const fdata = this.reprintContactArray.filter((arr) => {
      if (arr.lovid === +this.archiveInfo.reprintContact) {
        if (arr.description.trim().toLowerCase() === "other") {
          otherField = true;
        }
        return arr.lovid === +this.archiveInfo.reprintContact;
      }
    })[0];
    if (otherField) {
      fdata.otherValue = this.reprintContactOther?.trim();
    }
    data.details.reprintContact = fdata;
    return data;
  }

  private saveInserts(data: any) {
    const fdata = this.insertsArray.filter((arr) => {
      return arr.lovid === +this.archiveInfo.inserts;
    })[0];
    data.details.inserts = fdata;
    return data;
  }

  private saveEndSheets(data: any) {
    const fdata = this.endSheetsArray.filter((arr) => {
      return arr.lovid === +this.archiveInfo.endsheets;
    })[0];
    data.details.endsheets = fdata;
    return data;
  }

  private savePaggingFiles(data: any) {
    let otherField = false;
    const fdata: chkInterface[] = [];
    this.pagingFilesArray.filter((arr) => {
      if (arr.checked) {
        if (arr.description.trim().toLowerCase() === "other") {
          otherField = true;
          arr.otherValue = this.pagingFilesOther?.trim();
        }
        fdata.push(arr);
      }
    });
    data.details.pagingFilesList = fdata;
    return data;
  }

  private saveOtherFilesList(data: any) {
    let otherField = false;
    const fdata: chkInterface[] = [];
    this.otherFilesArray.filter((arr) => {
      if (arr.checked) {
        if (arr.description.trim().toLowerCase() === "other") {
          otherField = true;
          arr.otherValue = this.otherFilesOther?.trim();
        }
        fdata.push(arr);
      }
    });
    data.details.otherFilesList = fdata;
    return data;
  }

  private savePdfsList(data: any) {
    const fdata: chkInterface[] = [];
    this.PDFsArray.filter((arr) => {
      if (arr.checked) {
        fdata.push(arr);
      }
    });
    data.details.pdfsList = fdata;
    return data;
  }

  pdfArrayChange(evt: any, dataList: chkInterface) {
    if (evt) {
      this.archiveInfo.pdfsList.push(dataList);
    } else {
      this.archiveInfo.pdfsList.forEach(
        (objList: { description: string }, index: any) => {
          if (
            objList.description.trim().toLowerCase() ==
            dataList.description.trim().toLowerCase()
          ) {
            this.archiveInfo.pdfsList.splice(index, 1);
          }
        }
      );
    }
  }

  othFilesArrayChange(evt: any, dataList: chkInterface) {
    if (evt) {
      this.archiveInfo.otherFilesList.push(dataList);
    } else {
      this.archiveInfo.otherFilesList.forEach(
        (objList: { description: string }, index: any) => {
          if (
            objList.description.trim().toLowerCase() ==
            dataList.description.trim().toLowerCase()
          ) {
            this.archiveInfo.otherFilesList.splice(index, 1);
          }
        }
      );
    }
  }

  pagingArrayChange(evt: any, dataList: chkInterface) {
    if (evt) {
      this.archiveInfo.pagingFilesList.push(dataList);
    } else {
      this.archiveInfo.pagingFilesList.forEach(
        (objList: { description: string }, index: any) => {
          if (
            objList.description.trim().toLowerCase() ==
            dataList.description.trim().toLowerCase()
          ) {
            this.archiveInfo.pagingFilesList.splice(index, 1);
          }
        }
      );
    }
  }

  movetoAssociatedPage() {
    // this.router.navigate(['associatedRecord', this.archiveData.mhid]);
    this.router.navigate([]).then((result) => {
      window.open(`/#/associatedRecord/${this.archiveData.mhid}`, "_blank");
    });
  }

  movetoAssociatedPageWithAssociated(id: string) {
    id = "associatedid&" + id;
    // this.router.navigate(['associatedRecord', id]);
    this.router.navigate([]).then((result) => {
      window.open(`/#/associatedRecord/${id}`, "_blank");
    });
  }

  iPubProgramTitleChange(event: any) {
    if (this.archiveData.ipubProgrammingTitle.length < 1) {
      this.archiveData.ipubProgrammingTitle = "";
    } else {
      this.archiveData.ipubProgrammingTitle =
        this.archiveData.ipubProgrammingTitle.trim();
    }
  }

  iPubPublishingGroupChange(event: any) {
    if (this.archiveData.ipubPublishingGroup.length < 1) {
      this.archiveData.ipubPublishingGroup = "";
    } else {
      this.archiveData.ipubPublishingGroup =
        this.archiveData.ipubPublishingGroup.trim();
    }
  }

  paggingFilesOtherValueChange(event: any, pfl: chkInterface) {
    this.archiveInfo.pagingFilesList.filter(
      (filterData: { lovid: number; otherValue: any }) => {
        if (filterData.lovid == pfl.lovid) {
          filterData.otherValue = event.currentTarget.value;
        }
        return filterData.lovid == pfl.lovid;
      }
    );
  }

  otherFilesOtherValueChange(event: any, ofl: chkInterface) {
    this.archiveInfo.otherFilesList.filter(
      (filterData: { lovid: number; otherValue: any }) => {
        if (filterData.lovid == ofl.lovid) {
          filterData.otherValue = event.currentTarget.value;
        }
        return filterData.lovid == ofl.lovid;
      }
    );
  }

  reprintContactOtherValueChange(event: any) {
    if (this.defaultReprintOtherValue == event.currentTarget.value) {
      delete this.archiveInfo?.reprintContactTest;
    } else {
      this.archiveInfo.reprintContactTest = event.currentTarget.value;
    }
  }

  compVendorOtherValueChange(event: any) {
    if (this.defaultCompVendorOtherValue == event.currentTarget.value) {
      delete this.archiveInfo?.compVendorTest;
    } else {
      this.archiveInfo.compVendorTest = event.currentTarget.value;
    }
  }

  productionSpecialistOtherValueChange(event: any) {
    if (this.defaultproductionSpecialist == event.currentTarget.value) {
      delete this.archiveInfo?.productionSpecialistTest;
    } else {
      this.archiveInfo.productionSpecialistTest = event.currentTarget.value;
    }
  }

  private saveProdSpeciality(data: any) {
    let otherField = false;
    const fdata = this.prodSpecialistArray.filter((arr) => {
      if (arr.lovid === +this.archiveInfo.productionSpecialist) {
        if (arr.description.trim().toLowerCase() === "other") {
          otherField = true;
        }
        return arr.lovid === +this.archiveInfo.productionSpecialist;
      }
    })[0];
    if (otherField) {
      fdata.otherValue = this.productionSpecialistOther?.trim();
    }
    data.details.productionSpecialist = fdata;
    return data;
  }

  private setProdSpeciality() {
    if (this.archiveInfo && this.archiveInfo.productionSpecialist) {
      const dbData: string = this.archiveInfo.productionSpecialist.description;
      for (const keys in this.prodSpecialistArray) {
        if (dbData == this.prodSpecialistArray[keys].description) {
          if (dbData.trim().toLowerCase() === "other") {
            this.productionSpecialistOther = this.archiveInfo
              .productionSpecialist.otherValue
              ? this.archiveInfo.productionSpecialist.otherValue.trim()
              : "";
          } else {
            this.productionSpecialistOther = "";
          }
          this.archiveInfo.productionSpecialist =
            this.prodSpecialistArray[keys].lovid;
          this.prodSpecilityValueChange(dbData);
        }
      }
    } else {
      this.archiveInfo.productionSpecialist = "";
      this.prodSpecilityValueChange("");
    }
  }

  prodSpecilityValueChange(selectedValue: any) {
    let cdata: any;
    if (selectedValue.currentTarget) {
      cdata = selectedValue.currentTarget.options[
        selectedValue.currentTarget.selectedIndex
      ].text
        .trim()
        .toLocaleLowerCase();
    } else {
      cdata = selectedValue;
    }
    this.showProdSpeInput =
      cdata.trim().toLowerCase() == "other" ? true : false;
  }

  checkExistingReprintContact(paramData: string) {
    this.reprintContactArray = this.cs.removePreviousArray(
      this.reprintContactArray,
      this.actualReprintArray
    );
    const dataLength = this.reprintContactArray.filter((arData) => {
      return arData.description.toLowerCase() === paramData.toLowerCase();
    });
    if (dataLength.length >= 1) {
      this.adjustReprintContactOther(dataLength[0].description);
      this.archiveInfo.reprintContact = dataLength[0].lovid;
      return false;
    } else {
      return true;
    }
  }

  adjustReprintContactOther(reprintValue:string){
    if (reprintValue.trim().toLowerCase() === "other") {
      this.reprintContactOther = this.archiveInfo.reprintContact.otherValue ? this.archiveInfo.reprintContact.otherValue.trim() : "";
    } else {
      this.reprintContactOther = "";
    }
    this.reprintValueChange(reprintValue);
  }

}
