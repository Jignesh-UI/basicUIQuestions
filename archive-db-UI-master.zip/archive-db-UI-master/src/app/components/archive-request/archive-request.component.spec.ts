import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ArchiveRequestComponent } from './archive-request.component';
import { FormsModule } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { RouterTestingModule } from '@angular/router/testing';
import { ToastrModule } from 'ngx-toastr';
import { OktaAuthService } from 'src/app/service/okta-auth.service';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { arcReqDetails, arcReqSummary } from './archive-request.model';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LovDataService } from 'src/app/service/commonClasses/lov-data.service';
import { OktaInfoService } from 'src/app/shared/okta/okta-info.service';
import { RolesPolicyService } from 'src/app/service/roles-policy.service';

describe('ArchiveRequestComponent', () => {
  let component: ArchiveRequestComponent;
  let fixture: ComponentFixture<ArchiveRequestComponent>;
  let matDialogService: jasmine.SpyObj<MatDialog>;
  matDialogService = jasmine.createSpyObj<MatDialog>('MatDialog', ['open']);
  let dataService: LovDataService;
  let iservice : OktaInfoService;

  let testData = {
    details: {
      taskid: 257938,
      recordid: 2272100,
      mhid: 'test-mhid',
      isbn13: 'test-isbn',
      requestReceivedDate: '2023-01-17',
      requestedBy: 'test',
      requestorDepartment: '',
      archivist: 1013,
      dueDate: '2023-01-25',
      completedDate: null,
      inProgress: true,
      deliveryMedium: '',
      compositorVendor: '',
      printingVersion: 0,
      requestedFilesList: [],
      specialInstructions: null,
      statusNotes: null,
      createdDate: '2023-01-17',
      createdBy: 'Patel, Jignesh',
      modifiedDate: '2023-01-17',
      modifiedBy: 'Patel, Jignesh',
    },
    summary: {
      recordid: 2272100,
      previousISBN: 'test_pd_4_123',
      newISBN: 'test_pd_4_000',
      author: 'test prax',
      title: 'testing api part 1',
      edition: 3,
      priority: 'test high',
      owningDivision: 'College',
      owningSubDivision: 'test own subdiv',
      copyrightYear: 2022,
      boundBookDate: '2022-12-25',
      permissionEndDate: '2022-11-20',
      projectOPDate: '2022-11-20',
      deliveryFormat: 'test delivery format 2',
      titleTypeDesc: 'test title desc 2',
      gradeRange: '13 - 17',
      specificMarket: 'testing market',
      ipubPublishingGroup: 'prax_grp_3',
      ipubProgrammingTitle: 'testing prog title - 2',
      noOfPages: 50,
      comments:
        'testing comment;\ntesting api update;\ntesting done by prakriti_de;\nDe, Prakriti 2023-1-2 19:37:45\nhello\n',
    },
  };

  let asDetails = {
    recordid: 2272100,
    previousISBN: 'test_pd_4_123',
    newISBN: 'test_pd_4_000',
    author: 'test prax',
    title: 'testing api part 1',
    edition: 3,
    priority: 'test high',
    owningDivision: 'College',
    owningSubDivision: 'test own subdiv',
    copyrightYear: 2022,
    boundBookDate: '2022-12-25',
    permissionEndDate: '2022-11-20',
    projectOPDate: '2022-11-20',
    deliveryFormat: 'test delivery format 2',
    titleTypeDesc: 'test title desc 2',
    gradeRange: '13 - 17',
    specificMarket: 'testing market',
    ipubPublishingGroup: 'prax_grp_3',
    ipubProgrammingTitle: 'testing prog title - 2',
    noOfPages: 50,
    comments:
      'testing comment;\ntesting api update;\ntesting done by prakriti_de;\nDe, Prakriti 2023-1-2 19:37:45\nhello\n',
  };

  let asSummary = {
    taskid: 257938,
    mhid: 'test-mhid',
    isbn13: 'test-isbn',
    recordid: 2272100,
    requestReceivedDate: '2023-01-17',
    requestedBy: 'test',
    requestorDepartment: '',
    archivist: 1013,
    dueDate: '2023-01-25',
    completedDate: null,
    inProgress: true,
    deliveryMedium: '',
    compositorVendor: '',
    printingVersion: 0,
    requestedFilesList: [],
    specialInstructions: null,
    statusNotes: null,
    createdDate: '2023-01-17',
    createdBy: 'Patel, Jignesh',
    modifiedDate: '2023-01-17',
    modifiedBy: 'Patel, Jignesh',
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule, FormsModule, ToastrModule.forRoot(), BrowserAnimationsModule],
      declarations: [ArchiveRequestComponent],
      providers: [OktaAuthService, HttpClient, HttpHandler, LovDataService, OktaInfoService, RolesPolicyService,
        {
          provide: MatDialog,
          useValue: matDialogService,
        }],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
    })
      .compileComponents();
    dataService = TestBed.inject(LovDataService);
    iservice = TestBed.inject(OktaInfoService);

  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ArchiveRequestComponent);
    component = fixture.componentInstance;
    component.arcReqDetails = new arcReqDetails();
    component.arcReqSummary = new arcReqSummary();
    fixture.detectChanges();
  });

  afterEach(() => {
    fixture.destroy();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display popup confirmation if user have changed some data ', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.arcReqDetails = new arcReqDetails();
    cmpInstance.arcReqSummary = new arcReqSummary();
    cmpInstance.searchedMHID = 'test-mhid';
    cmpInstance.searchedISBN = 'test-isbn';

    cmpInstance.searchByTab('test-mhid', 'mhid', false);
    fixture.detectChanges();
    expect(cmpInstance.arcReqSummary).not.toBeNull();
  });

  it('should add Archive Request Status Notes comment when comment is already added', () => {
    const message = 'Test Message \n';
    component.arcReqDetails.statusNotes = message;
    component.onARSNCommentAdd(message);
    expect(component.arcReqDetails.statusNotes).not.toBeNull();
  });

  it('should add Archive Request Status Notes comment when comment is blank ', () => {
    component.onARSNCommentAdd('new Test Message');
    expect(component.arcReqDetails.statusNotes).not.toBeNull();
  });

  it('should add Special Instructions when instructions is already added', () => {
    const message = 'Test Message \n';
    component.arcReqDetails.specialInstructions = message;
    component.onSICommentAdd(message);
    expect(component.arcReqDetails.specialInstructions).not.toBeNull();
  });

  it('should add Special Instructions when instructions is blank ', () => {
    component.onSICommentAdd('new Test Message');
    expect(component.arcReqDetails.specialInstructions).not.toBeNull();
  });

  it('should reset reset Archive Details', () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.arcReqDetails = new arcReqDetails();
    cmpInstance.arcReqSummary = new arcReqSummary();
    cmpInstance.resetArchiveDetails();
    fixture.detectChanges();
    expect(cmpInstance.arcReqDetails.requestReceivedDate).toBe('');
    expect(cmpInstance.arcReqDetails.dueDate).toBe('')
    expect(cmpInstance.arcReqDetails.completedDate).toBe('')
    expect(cmpInstance.arcReqDetails.inProgress).toBe(null);
    expect(cmpInstance.arcReqDetails.requestedBy).toBe('')
  });

  it('should return true when record Id is not available', () => {
    let cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.arcReqDetails = new arcReqDetails();
    cmpInstance.arcReqSummary = new arcReqSummary();
    cmpInstance.arcReqDetails = asDetails;
    cmpInstance.arcReqSummary = asSummary;

    cmpInstance.searchedMHID = '';
    cmpInstance.searchedISBN = '';
    localStorage.setItem('arcRequestoData', JSON.stringify({ "summary": testData.details, "details": testData.summary }));
    const flagNavigate = cmpInstance.canDeactivate();
    expect(flagNavigate).toBeTruthy();
  });

  // it('should return true when record Id is not available', async () => {
  //   let cmpInstance = fixture.debugElement.componentInstance;
  //   cmpInstance.arcReqDetails = new arcReqDetails();
  //   cmpInstance.arcReqSummary = new arcReqSummary();
  //   cmpInstance.arcReqDetails = asDetails;
  //   cmpInstance.arcReqSummary = asSummary;
  //   localStorage.setItem('arcRequestoData', JSON.stringify({ "summary": testData.details, "details": testData.summary }));
  //   cmpInstance.searchedMHID = 'test-mhid';
  //   cmpInstance.searchedISBN = 'test-mhid';
  //   // jasmine.createSpyObj<MatDialog>('MatDialog', ['open']);
  //   const flagNavigate = cmpInstance.canDeactivate();
  //   expect(flagNavigate).toBeTruthy();
  // });

  it('should call adjustData function to verify the changes on the form!', async () => {
    let cmpInstance = fixture.debugElement.componentInstance;
    const flag = await cmpInstance.adjustData(testData, asDetails, asSummary);
    expect(flag).toBeFalsy();
    asDetails.author = 'test prax asdf';
    const flag2 = await cmpInstance.adjustData(
      testData.details,
      asDetails,
      asSummary
    );
    expect(flag2).toBeFalsy();
  });

  it('should compare previous summary data with current one', async () => {
    let cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.asSummary = asSummary;
    const flag = await cmpInstance.chkSummaryValidation(asSummary);
    expect(flag).toBeTruthy();
  });

  it('should search with MHID and ISBN!', async () => {
    let cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.arcReqDetails = new arcReqDetails();
    cmpInstance.arcReqSummary = new arcReqSummary();
    cmpInstance.searchedMHID = '';
    cmpInstance.searchedISBN = '';
    cmpInstance.searchByTab('test-mhid', 'mhid', false);
    fixture.detectChanges();
    expect(cmpInstance.arcReqSummary).not.toBeNull();
    cmpInstance.searchByTab('test-isbn', 'isbn', false);
    fixture.detectChanges();
    expect(cmpInstance.arcReqSummary).not.toBeNull();
  });

  it('should search with task id!', async () => {
    let cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.arcReqDetails = new arcReqDetails();
    cmpInstance.arcReqSummary = new arcReqSummary();
    cmpInstance.searchedMHID = '';
    cmpInstance.searchedISBN = '';
    cmpInstance.searchByTab('1234', 'taskid', false);
    fixture.detectChanges();
    expect(cmpInstance.arcReqSummary).not.toBeNull();
  });
  
  it('should not search without keyword!', async () => {
    let cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.arcReqDetails = new arcReqDetails();
    cmpInstance.arcReqSummary = new arcReqSummary();
    cmpInstance.searchedMHID = '';
    cmpInstance.searchedISBN = '';
    cmpInstance.searchByTab('', '', false);
    fixture.detectChanges();
    expect(cmpInstance.assocSummary).toBe(undefined);
  });

  it('should not search if same isbn is there!', async () => {
    let cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.arcReqDetails = new arcReqDetails();
    cmpInstance.arcReqSummary = new arcReqSummary();
    cmpInstance.searchedMHID = '';
    cmpInstance.searchedISBN = 'test-isbn';
    cmpInstance.searchByTab('test-isbn', 'isbn', false);
    fixture.detectChanges();
    expect(cmpInstance.assocSummary).toBe(undefined);
  });

  it('should not search if keyword is not given!', async () => {
    let cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.arcReqDetails = new arcReqDetails();
    cmpInstance.arcReqSummary = new arcReqSummary();
    cmpInstance.searchedMHID = '';
    cmpInstance.searchedISBN = 'test-isbn';
    cmpInstance.searchByTab('test-isbn', '', false);
    fixture.detectChanges();
    expect(cmpInstance.assocSummary).toBe(undefined);
  });

  it('should fill the form after providing the isbn/mhid', async () => {
    let cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.arcReqDetails = new arcReqDetails();
    cmpInstance.arcReqSummary = new arcReqSummary();
    cmpInstance.arcReqDetails.requestReceivedDate = '';
    cmpInstance.arcReqDetails.inProgress;
    cmpInstance.fillFormSubscription({ summary: testData.summary }, false);
    expect(cmpInstance.searchedMHID).not.toBeNull();
  });

  it('should fill the form after hitting the save button', async () => {
    let cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.arcReqDetails = new arcReqDetails();
    cmpInstance.arcReqSummary = new arcReqSummary();
    cmpInstance.fillFormSubscription(testData, false);
    expect(cmpInstance.searchedMHID).not.toBeNull();
  });

  it('should change the date format!', async()=>{
    let cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.arcReqDetails = new arcReqDetails();
    cmpInstance.arcReqSummary = new arcReqSummary();
    cmpInstance.arcReqSummary.boundBookDate = '12-31-2022';
    cmpInstance.dateFormatChange('-', '/', 'html');
    fixture.autoDetectChanges();
    expect(cmpInstance.arcReqSummary.boundBookDate).toBe('12/31/2022');
  })


});
