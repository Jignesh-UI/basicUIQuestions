import { HttpClient, HttpHandler } from "@angular/common/http";
import { ComponentFixture, inject, TestBed } from "@angular/core/testing";
import { AssociatedRecordComponent } from "./associated-record.component";
import { FormsModule } from "@angular/forms";
import { MatDialog } from "@angular/material/dialog";
import { RouterTestingModule } from "@angular/router/testing";
import { ToastrModule } from "ngx-toastr";
import { OktaAuthService } from "src/app/service/okta-auth.service";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import {
  associatedDetails,
  associatedSummary,
} from "./associated-record.model";
import {
  chkInterface,
  lovInterface,
} from "src/app/service/models/common.model";
import { LovDataService } from "src/app/service/commonClasses/lov-data.service";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { Router } from "@angular/router";
import { CommonService } from "src/app/service/commonClasses/common.service";

describe("AssociatedRecordComponent", () => {
  let component: AssociatedRecordComponent;
  let fixture: ComponentFixture<AssociatedRecordComponent>;
  let matDialogService: jasmine.SpyObj<MatDialog>;
  matDialogService = jasmine.createSpyObj<MatDialog>("MatDialog", ["open"]);
  let dataService: LovDataService;
  let cs: CommonService;

  const testOtherFilesArray: chkInterface[] = [
    {
      lovid: 25004,
      lovType: "OTHERFILES",
      lovCode: "OTHERFILES-ALL",
      description: "Accessibility Files",
      valueField: undefined,
      enabled: "Y",
      orderSeq: 1,
    },
    {
      lovid: 25000,
      lovType: "OTHERFILES",
      lovCode: "OTHERFILES-ALL",
      description: "Cover/Design",
      valueField: undefined,
      enabled: "Y",
      orderSeq: 2,
    },
    {
      lovid: 25001,
      lovType: "OTHERFILES",
      lovCode: "OTHERFILES-ALL",
      description: "Images",
      valueField: undefined,
      enabled: "Y",
      orderSeq: 3,
    },
    {
      lovid: 25002,
      lovType: "OTHERFILES",
      lovCode: "OTHERFILES-ALL",
      description: "None",
      valueField: undefined,
      enabled: "Y",
      orderSeq: 4,
    },
    {
      lovid: 25003,
      lovType: "OTHERFILES",
      lovCode: "OTHERFILES-ALL",
      description: "Other",
      valueField: undefined,
      enabled: "Y",
      orderSeq: 5,
    },
  ];

  const testPaggingFilesArray: chkInterface[] = [
    {
      lovid: 31000,
      lovType: "PAGINGFILES",
      lovCode: "PAGINGFILES-MHHE",
      description: "InDesign",
      valueField: undefined,
      enabled: "Y",
      orderSeq: 1,
    },
    {
      lovid: 31001,
      lovType: "PAGINGFILES",
      lovCode: "PAGINGFILES-ALL",
      description: "MSWord",
      valueField: undefined,
      enabled: "Y",
      orderSeq: 2,
    },
    {
      lovid: 31002,
      lovType: "PAGINGFILES",
      lovCode: "PAGINGFILES-ALL",
      description: "None",
      valueField: undefined,
      enabled: "Y",
      orderSeq: 3,
    },
    {
      lovid: 31003,
      lovType: "PAGINGFILES",
      lovCode: "PAGINGFILES-MHHE",
      description: "Quark",
      valueField: undefined,
      enabled: "Y",
      orderSeq: 4,
    },
    {
      lovid: 31004,
      lovType: "PAGINGFILES",
      lovCode: "PAGINGFILES-MHHE",
      description: "Tex",
      valueField: undefined,
      enabled: "Y",
      orderSeq: 5,
    },
    {
      lovid: 31005,
      lovType: "PAGINGFILES",
      lovCode: "PAGINGFILES-ALL",
      description: "Other",
      valueField: undefined,
      enabled: "Y",
      orderSeq: 6,
    },
  ];

  const testPDFsFilesArray: chkInterface[] = [
    {
      lovid: 34000,
      lovType: "PDFS",
      lovCode: "PDFS-ALL",
      description: "Media PDFs",
      valueField: null,
      enabled: "Y",
      orderSeq: 1,
      checked: true,
    },
  ];

  const allCompVendor = [
    {
      lovid: 4000,
      lovType: "COMPOSITOR_VENDOR",
      lovCode: "COMPOSITOR_VENDOR-ALL",
      description: "Aptara",
      valueField: null,
      enabled: "Y",
      orderSeq: 1,
    },
    {
      lovid: 4001,
      lovType: "COMPOSITOR_VENDOR",
      lovCode: "COMPOSITOR_VENDOR-MHSE",
      description: "Editec",
      valueField: null,
      enabled: "Y",
      orderSeq: 2,
    },
    {
      lovid: 4002,
      lovType: "COMPOSITOR_VENDOR",
      lovCode: "COMPOSITOR_VENDOR-MHHE",
      description: "Hurix",
      valueField: null,
      enabled: "Y",
      orderSeq: 3,
    },
    {
      lovid: 4003,
      lovType: "COMPOSITOR_VENDOR",
      lovCode: "COMPOSITOR_VENDOR-ALL",
      description: "MPS",
      valueField: null,
      enabled: "Y",
      orderSeq: 4,
    },
    {
      lovid: 4004,
      lovType: "COMPOSITOR_VENDOR",
      lovCode: "COMPOSITOR_VENDOR-MHSE",
      description: "SeBue",
      valueField: null,
      enabled: "Y",
      orderSeq: 5,
    },
    {
      lovid: 4005,
      lovType: "COMPOSITOR_VENDOR",
      lovCode: "COMPOSITOR_VENDOR-ALL",
      description: "Other",
      valueField: null,
      enabled: "Y",
      orderSeq: 6,
    },
    {
      lovid: 4006,
      lovType: "COMPOSITOR_VENDOR",
      lovCode: "COMPOSITOR_VENDOR-ALL",
      description: "Straive",
      valueField: null,
      enabled: "Y",
      orderSeq: 7,
    },
    {
      lovid: 4007,
      lovType: "COMPOSITOR_VENDOR",
      lovCode: "COMPOSITOR_VENDOR-ALL",
      description: "Intertext",
      valueField: null,
      enabled: "Y",
      orderSeq: 8,
    },
    {
      lovid: 4008,
      lovType: "COMPOSITOR_VENDOR",
      lovCode: "COMPOSITOR_VENDOR-ALL",
      description: "Magic EdTech",
      valueField: null,
      enabled: "Y",
      orderSeq: 9,
    },
  ];

  const allReprintContact = [
    {
      lovid: 40000,
      lovType: "REPRINT_CONTACT",
      lovCode: "REPRINT_CONTACT-MHSE",
      description: "Adrienne Searcy",
      valueField: null,
      enabled: "Y",
      orderSeq: 1,
    },
    {
      lovid: 40001,
      lovType: "REPRINT_CONTACT",
      lovCode: "REPRINT_CONTACT-MHSE",
      description: "Angela Warner",
      valueField: null,
      enabled: "Y",
      orderSeq: 2,
    },
    {
      lovid: 40002,
      lovType: "REPRINT_CONTACT",
      lovCode: "REPRINT_CONTACT-MHSE",
      description: "Emily Dinsmore",
      valueField: null,
      enabled: "Y",
      orderSeq: 3,
    },
    {
      lovid: 40003,
      lovType: "REPRINT_CONTACT",
      lovCode: "REPRINT_CONTACT-MHSE",
      description: "Kim Cotter",
      valueField: null,
      enabled: "Y",
      orderSeq: 4,
    },
    {
      lovid: 40004,
      lovType: "REPRINT_CONTACT",
      lovCode: "REPRINT_CONTACT-MHSE",
      description: "Megan Milano",
      valueField: null,
      enabled: "Y",
      orderSeq: 5,
    },
    {
      lovid: 40005,
      lovType: "REPRINT_CONTACT",
      lovCode: "REPRINT_CONTACT-MHSE",
      description: "Sara Rutherford",
      valueField: null,
      enabled: "Y",
      orderSeq: 6,
    },
    {
      lovid: 40006,
      lovType: "REPRINT_CONTACT",
      lovCode: "REPRINT_CONTACT-MHSE",
      description: "Tim Heppner",
      valueField: null,
      enabled: "Y",
      orderSeq: 7,
    },
    {
      lovid: 40007,
      lovType: "REPRINT_CONTACT",
      lovCode: "REPRINT_CONTACT-MHSE",
      description: "Other",
      valueField: null,
      enabled: "Y",
      orderSeq: 8,
    },
  ];

  const testArchivestArray: lovInterface[] = [
    {
      lovid: 1003,
      lovType: "ARCHIVIST",
      lovCode: "ARCHIVIST-MHSE",
      description: "Andy Backs",
      valueField: "",
      enabled: "Y",
      orderSeq: 4,
    },
    {
      lovid: 1011,
      lovType: "ARCHIVIST",
      lovCode: "ARCHIVIST-MHSE",
      description: "Jeff Kemeter",
      valueField: "",
      enabled: "Y",
      orderSeq: 12,
    },
    {
      lovid: 1012,
      lovType: "ARCHIVIST",
      lovCode: "ARCHIVIST-MHSE",
      description: "Jessica Solomon",
      valueField: "",
      enabled: "Y",
      orderSeq: 13,
    },
    {
      lovid: 1013,
      lovType: "ARCHIVIST",
      lovCode: "ARCHIVIST-MHHE",
      description: "Jodi Gaherty",
      valueField: "",
      enabled: "Y",
      orderSeq: 14,
    },
    {
      lovid: 1014,
      lovType: "ARCHIVIST",
      lovCode: "ARCHIVIST-MHHE",
      description: "Kara Kudronowicz",
      valueField: "",
      enabled: "Y",
      orderSeq: 15,
    },
    {
      lovid: 1017,
      lovType: "ARCHIVIST",
      lovCode: "ARCHIVIST-MHHE",
      description: "Laurie Lenstra",
      valueField: "",
      enabled: "Y",
      orderSeq: 18,
    },
    {
      lovid: 1032,
      lovType: "ARCHIVIST",
      lovCode: "ARCHIVIST-MHHE",
      description: "Tina Flanagan",
      valueField: "",
      enabled: "Y",
      orderSeq: 33,
    },
    {
      lovid: 1005,
      lovType: "ARCHIVIST",
      lovCode: "ARCHIVIST-MHSE",
      description: "April Cleland",
      valueField: "",
      enabled: "N",
      orderSeq: 6,
    },
  ];

  const otherFilesArray = [
    {
      lovid: 25000,
      lovType: "OTHERFILES",
      lovCode: "OTHERFILES-ALL",
      description: "Accessibility Files",
      valueField: null,
      enabled: "Y",
      orderSeq: 1,
    },
    {
      lovid: 25001,
      lovType: "OTHERFILES",
      lovCode: "OTHERFILES-ALL",
      description: "Cover/Design",
      valueField: null,
      enabled: "Y",
      orderSeq: 2,
    },
    {
      lovid: 25002,
      lovType: "OTHERFILES",
      lovCode: "OTHERFILES-ALL",
      description: "Images",
      valueField: null,
      enabled: "Y",
      orderSeq: 3,
    },
  ];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        FormsModule,
        ToastrModule.forRoot(),
        BrowserAnimationsModule,
      ],
      declarations: [AssociatedRecordComponent],
      providers: [
        OktaAuthService,
        HttpClient,
        HttpHandler,
        LovDataService,
        CommonService,
        {
          provide: MatDialog,
          useValue: matDialogService,
        },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
    dataService = TestBed.inject(LovDataService);
    cs = TestBed.inject(CommonService);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssociatedRecordComponent);
    component = fixture.componentInstance;
    component.assocDetails = new associatedDetails();
    component.assocSummary = new associatedSummary();
    fixture.detectChanges();
  });

  afterEach(() => {
    fixture.destroy();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("should load all LOVs on Page Load", async () => {
    await dataService.loadListofLovs();
    const cmpInstance = fixture.debugElement.componentInstance;
    await cmpInstance.loadLovs();
    fixture.detectChanges();
    expect(cmpInstance.archivistArray).not.toBeNull();
  });

  it("should reset the resetDetails array", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.resetDetails();
    expect((cmpInstance.assocDetails = {})).toBeTruthy();
  });

  it("should reset the reset Summary array and others", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.resetArchiveModel();
    expect((cmpInstance.assocSummary = {})).toBeTruthy();
  });

  it("should reset the all Dropdown Lists", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.resetDrpLists();
    expect(cmpInstance.assocDetails.archivist).not.toBeNull();
  });

  it("should disable when MHID and ISBN is empty", () => {
    const component = fixture.debugElement.componentInstance;
    component.searchedMHID = "";
    component.searchedISBN = "";
    fixture.detectChanges();
    expect(
      fixture.debugElement.nativeElement.querySelector(".btn.btn-primary")
        .disabled
    ).toBeTruthy();
  });

  it("should add Associated comment when comment is already added", () => {
    component.assocDetails = new associatedDetails();
    const message = "Test Message\n";
    component.assocDetails.productNotes = message;
    component.onAssocProductCommentAdd(message);
    expect(component.assocDetails.productNotes).not.toBeNull();
  });

  it("should add Associated comment when comment is blank ", () => {
    component.onAssocProductCommentAdd("new Test Message");
    expect(component.assocDetails.productNotes).not.toBeNull();
  });

  it("should show others input when Other Comp Vendor is selected", () => {
    component.assocDetails = new associatedDetails();
    component.compVendorChange("other");
    component.assocDetails.compositorVendor = "other";
    expect(component.showCompVendor).toBeTruthy();
  });

  it("should show others input when Other Reprint Contact is selected", () => {
    component.assocDetails = new associatedDetails();
    component.reprintValueChange("other");
    component.assocDetails.reprintContact = "other";
    expect(component.showReprintInput).toBeTruthy();
  });

  it("should disabled PDH Field", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.disablePDHControls();
    expect(cmpInstance.disabledPDHField).toBeTruthy();
  });

  it("should enabled Summary Fields when MHID/ISBN is not Null", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.searchedMHID = "test";
    cmpInstance.searchedISBN = "test";
    fixture.detectChanges();
    expect(cmpInstance.disabledDetailsField).toBeTruthy();
  });

  it("should check PDF List are added in the Save Array List", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.PDFsArray = testPDFsFilesArray;
    fixture.detectChanges();
    const data = cmpInstance.savePdfsList([
      {
        lovid: 34001,
        lovType: "PDFS",
        lovCode: "PDFS-ALL",
        description: "Printer PDFs",
        valueField: null,
        enabled: "Y",
        orderSeq: 2,
      },
    ]);
    cmpInstance.assocDetails.pdfsList = data;
    expect(cmpInstance.assocDetails.pdfsList).not.toBeNull();
  });

  it("should check PDF List are added in the Save Other Files List", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.otherFilesArray = [
      {
        lovid: 25003,
        lovType: "OTHERFILES",
        lovCode: "OTHERFILES-ALL",
        description: "Other",
        valueField: undefined,
        enabled: "Y",
        orderSeq: 5,
        checked: true,
      },
    ];

    const testData = cmpInstance.saveOtherFilesList([
      {
        lovid: 25000,
        lovType: "OTHERFILES",
        lovCode: "OTHERFILES-ALL",
        description: "Cover/Design",
        valueField: null,
        enabled: "Y",
        orderSeq: 2,
        checked: true,
      },
    ]);
    cmpInstance.assocDetails.otherFilesList = testData;
    expect(cmpInstance.assocDetails.otherFilesList).not.toBeNull();
  });

  it("should check PDF List are added in the Save Pagging Files List", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.pagingFilesArray = [
      {
        lovid: 31000,
        lovType: "PAGINGFILES",
        lovCode: "PAGINGFILES-MHHE",
        description: "InDesign",
        valueField: null,
        enabled: "Y",
        orderSeq: 1,
        checked: true,
      },
      {
        lovid: 31003,
        lovType: "PAGINGFILES",
        lovCode: "PAGINGFILES-MHHE",
        description: "Quark",
        valueField: undefined,
        enabled: "Y",
        orderSeq: 4,
      },
      {
        lovid: 31004,
        lovType: "PAGINGFILES",
        lovCode: "PAGINGFILES-MHHE",
        description: "Tex",
        valueField: undefined,
        enabled: "Y",
        orderSeq: 5,
      },
      {
        lovid: 31005,
        lovType: "PAGINGFILES",
        lovCode: "PAGINGFILES-ALL",
        description: "Other",
        valueField: "Other Value",
        enabled: "Y",
        orderSeq: 6,
        checked: true,
      },
    ];
    cmpInstance.pagingFilesOther = "31005";
    let otherField = false;
    const fdata: chkInterface[] = [];
    cmpInstance.pagingFilesArray.filter((arr: chkInterface) => {
      if (arr.checked) {
        if (arr.description?.trim().toLowerCase() === "other") {
          otherField = true;
          arr.otherValue = cmpInstance.pagingFilesOther.trim();
        }
        fdata.push(arr);
      }
    });
    fixture.detectChanges();
    cmpInstance.savePaggingFiles();
    expect(cmpInstance.assocDetails.pagingFilesArray).not.toBeNull();
  });

  it("should check RePrint selection is added in the Save!", async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    const testData = cmpInstance.saveRePrint([
      {
        lovid: 40004,
        lovType: "REPRINT_CONTACT",
        lovCode: "REPRINT_CONTACT-MHSE",
        description: "Megan Milano",
        valueField: null,
        enabled: "Y",
        orderSeq: 5,
        otherValue: null,
      },
    ]);
    cmpInstance.assocDetails.reprintContact = testData;
    expect(cmpInstance.assocDetails.reprintContact).not.toBeNull();
  });

  it("should return array of Save Location from Save Location lovid", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();

    cmpInstance.locationArray = [
      {
        lovid: 49011,
        lovType: "STORAGE_LOCATION",
        lovCode: "STORAGE_LOCATION-ALL",
        description: "VideoTape",
        valueField: null,
        enabled: "Y",
        orderSeq: 12,
      },
      {
        lovid: 49012,
        lovType: "STORAGE_LOCATION",
        lovCode: "STORAGE_LOCATION-ALL",
        description: "Warehouse",
        valueField: null,
        enabled: "Y",
        orderSeq: 13,
      },
    ];
    cmpInstance.assocDetails.storageLocation = "49012";
    cmpInstance.saveLocation();

    expect(cmpInstance.assocDetails.storageLocation).not.toBeNull();
  });

  it("should return array of compositor Vendor from compositor Vendor lovid", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    const testData = cmpInstance.saveCompVendor([
      {
        lovid: 4002,
        lovType: "COMPOSITOR_VENDOR",
        lovCode: "COMPOSITOR_VENDOR-MHHE",
        description: "Hurix",
        valueField: null,
        enabled: "Y",
        orderSeq: 3,
        otherValue: null,
      },
    ]);
    fixture.detectChanges();

    cmpInstance.assocDetails.compositorVendor = testData;
    expect(cmpInstance.assocDetails.compositorVendor).not.toBeNull();
  });

  it("should return array of Archivist from Archivist lovid", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.archivistArray = testArchivestArray;
    const testData = cmpInstance.saveArchivist([
      {
        lovid: 1005,
        lovType: "ARCHIVIST",
        lovCode: "ARCHIVIST-MHSE",
        description: "April Cleland",
        valueField: null,
        enabled: "N",
        orderSeq: 6,
      },
    ]);
    fixture.detectChanges();

    cmpInstance.assocDetails.archivist = testData;
    expect(cmpInstance.assocDetails.archivist).not.toBeNull();
  });

  it("should checked PDF Lists when data is loaded", () => {
    const cmpInstance = fixture.debugElement.componentInstance;

    cmpInstance.PDFsArray = [
      {
        lovid: 34000,
        lovType: "PDFS",
        lovCode: "PDFS-ALL",
        description: "Media PDFs",
        valueField: null,
        enabled: "Y",
        orderSeq: 1,
        checked: true,
      },
      {
        lovid: 34001,
        lovType: "PDFS",
        lovCode: "PDFS-ALL",
        description: "Printer PDFs",
        valueField: null,
        enabled: "Y",
        orderSeq: 2,
        checked: true,
      },
    ];
    cmpInstance.assocDetails.pdfsList = [
      {
        lovid: 34001,
        lovType: "PDFS",
        lovCode: "PDFS-ALL",
        description: "Printer PDFs",
        valueField: null,
        enabled: "Y",
        orderSeq: 2,
      },
    ];
    cmpInstance.setPDFLists();

    fixture.detectChanges();
    cmpInstance.PDFsArray.forEach(
      (arrData: { description: string; checked: boolean }) => {
        cmpInstance.assocDetails.pdfsList.forEach(
          (respData: { description: string }) => {
            if (
              arrData.description?.trim().toLowerCase() ==
              respData.description.trim().toLowerCase()
            ) {
              arrData.checked = true;
            }
          }
        );
      }
    );
    expect(cmpInstance.PDFsArray).not.toBeNull();
  });

  it("should add Pagging array to the list", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    const testData: chkInterface = {
      lovid: 31004,
      lovType: "PAGINGFILES",
      lovCode: "PAGINGFILES-MHHE",
      description: "Tex",
      valueField: undefined,
      enabled: "Y",
      orderSeq: 5,
      checked: true,
    };

    cmpInstance.assocDetails.pagingFilesList = [];
    cmpInstance.assocDetails.pagingFilesList.push(testData);
    cmpInstance.pagingArrayChange(null, testData);

    expect(cmpInstance.assocDetails.pdfsList).not.toBeNull();
  });

  it("should add Pagging array to the list on Check", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    const testData: chkInterface = {
      lovid: 31004,
      lovType: "PAGINGFILES",
      lovCode: "PAGINGFILES-MHHE",
      description: "Tex",
      valueField: undefined,
      enabled: "Y",
      orderSeq: 5,
      checked: true,
    };
    cmpInstance.assocDetails.pagingFilesList = [];
    cmpInstance.assocDetails.pagingFilesList.push(testData);
    cmpInstance.pagingArrayChange(true, testData);
    expect(cmpInstance.assocDetails.pagingFilesList).not.toBeNull();
  });

  it("should add Other array to the list", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    const testData: chkInterface = {
      lovid: 25001,
      lovType: "OTHERFILES",
      lovCode: "OTHERFILES-ALL",
      description: "Images",
      valueField: undefined,
      enabled: "Y",
      orderSeq: 3,
      checked: false,
    };

    cmpInstance.assocDetails.otherFilesList = [];
    cmpInstance.assocDetails.otherFilesList.push(testData);
    cmpInstance.othFilesArrayChange(null, testData);

    cmpInstance.assocDetails.otherFilesList.forEach(
      (objList: { description: string }, index: any) => {
        if (
          objList.description.trim().toLowerCase() ==
          testData.description?.trim().toLowerCase()
        ) {
          cmpInstance.assocDetails.otherFilesList.splice(index, 1);
        }
      }
    );

    fixture.whenStable().then(() => {
      expect(cmpInstance.assocDetails.otherFilesList).not.toBeNull();
    });
  });

  it("should add PDF array to the list", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    const testData: chkInterface = {
      lovid: 34000,
      lovType: "PDFS",
      lovCode: "PDFS-ALL",
      description: "Media PDFs",
      valueField: undefined,
      enabled: "Y",
      orderSeq: 1,
      checked: true,
    };

    cmpInstance.assocDetails.pdfsList = [];
    cmpInstance.assocDetails.pdfsList.push(testData);
    cmpInstance.pdfArrayChange(null, testData);

    fixture.whenStable().then(() => {
      expect(cmpInstance.assocDetails.pdfsList).not.toBeNull();
    });
  });

  it("should add PDF array to the list on Check", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    const testData = {
      lovid: 34000,
      lovType: "PDFS",
      lovCode: "PDFS-ALL",
      description: "Media PDFs",
      valueField: undefined,
      enabled: "Y",
      orderSeq: 1,
      checked: true,
    };
    cmpInstance.assocDetails.pdfsList = [];
    cmpInstance.assocDetails.pdfsList.push(testData);
    cmpInstance.pdfArrayChange(true, testData);
    fixture.whenStable().then(() => {
      expect(cmpInstance.assocDetails.pdfsList).not.toBeNull();
    });
  });

  it("should disable selection when None is checked from Other Files list is checked", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.otherFilesArray = testOtherFilesArray;
    fixture.detectChanges();
    fixture.autoDetectChanges();
    const element = fixture.nativeElement.querySelector("#None25002");
    element.click();
    cmpInstance.disabledDetailsField = false;
    expect(cmpInstance.disabledDetailsField).toBeFalsy();
  });

  it("should disable selection when None is checked from Pagging Files list is checked", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.pagingFilesArray = testPaggingFilesArray;
    fixture.detectChanges();
    fixture.autoDetectChanges();
    const element = fixture.nativeElement.querySelector("#None31002");
    element.click();
    cmpInstance.disabledDetailsField = !element.checked;
    expect(cmpInstance.disabledDetailsField).toBeFalsy();
  });

  it("should Display compositor Vendor Other Input if Other compositor Vendor is selected ", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.compVendorArray = allCompVendor;
    let otherField = false;
    cmpInstance.assocDetails.compositorVendor = 4005;
    const fdata = cmpInstance.compVendorArray.filter(
      (arr: { lovid: number; description: string }) => {
        if (arr.lovid === +cmpInstance.assocDetails.compositorVendor) {
          if (arr.description?.trim().toLowerCase() === "other") {
            otherField = true;
          }
          return arr.lovid === +cmpInstance.assocDetails.compositorVendor;
        }
        return;
      }
    )[0];
    if (otherField) {
      fdata.otherValue = cmpInstance.compVendorOther.trim();
    }
    fixture.detectChanges();
    cmpInstance.saveCompVendor();
    expect(cmpInstance.compVendorOther).not.toBeNull();
  });

  it("should Display compositor Vendor Other Input if Other compositor Vendor is selected ", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.reprintContactArray = allReprintContact;

    let otherField = false;
    cmpInstance.assocDetails.reprintContact = 40007;

    const fdata = cmpInstance.reprintContactArray.filter(
      (arr: { lovid: number; description: string }) => {
        if (arr.lovid === +cmpInstance.assocDetails.reprintContact) {
          if (arr.description?.trim().toLowerCase() === "other") {
            otherField = true;
          }
          return arr.lovid === +cmpInstance.assocDetails.reprintContact;
        }
        return;
      }
    )[0];
    if (otherField) {
      fdata.otherValue = cmpInstance.reprintContactOther.trim();
    }
    fixture.detectChanges();
    cmpInstance.saveRePrint();
    expect(cmpInstance.reprintContactOther).not.toBeNull();
  });

  it("should return Empty array of Storage Location when Storage Location is not selected", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.resetDetails();
    cmpInstance.assocDetails.storageLocation = "";
    cmpInstance.assocDetails.storageLocation = cmpInstance.saveLocation();
    fixture.autoDetectChanges();
    expect(cmpInstance.assocDetails.storageLocation).toBeNull();
  });

  it("should return Empty array of Archiviest when Archiviest is not selected", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.resetDetails();
    cmpInstance.assocDetails.archivist = "";
    cmpInstance.assocDetails.archivist = cmpInstance.saveArchivist();
    fixture.detectChanges();
    expect(cmpInstance.assocDetails.archivist).toBeNull();
  });

  it("should return Empty array of RePrint Contact when RePrint Contact is not selected", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.resetDetails();
    cmpInstance.assocDetails.reprintContact = "";
    cmpInstance.assocDetails.reprintContact = cmpInstance.saveRePrint();
    fixture.detectChanges();
    expect(cmpInstance.assocDetails.reprintContact).toBeNull();
  });

  it("should return Empty array of Comp Vendor when Comp Vendor is not selected", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.resetDetails();
    cmpInstance.assocDetails.compositorVendor = "";
    cmpInstance.assocDetails.compositorVendor = cmpInstance.saveCompVendor();
    fixture.detectChanges();
    expect(cmpInstance.assocDetails.compositorVendor).toBeNull();
  });

  it("should adjust record ID is it is empty", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.assocSummary = new associatedSummary();
    cmpInstance.assocSummary.recordid = "1234";
    cmpInstance.adjustRecordId();
    expect(cmpInstance.assocDetails.recordid).not.toBeNull();
  });

  it("should fill all the required data in objects", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.assocSummary = new associatedSummary();

    const dummyData = {
      summary: {
        recordid: 1304182,
        mhid: "test-mhid",
        isbn13: "test-isbn",
        previousISBN: "test_pd_4_123",
        newISBN: "test_pd_4_000",
        author: "test prax",
        title: "testing api part 1",
        edition: 3,
        priority: "test high",
        owningDivision: "test owndiv",
        owningSubDivision: "test own subdiv",
        copyrightYear: 2022,
        boundBookDate: "2022-11-20",
        permissionEndDate: "2022-11-20",
        projectOPDate: "2022-11-20",
        deliveryFormat: "test delivery format 2",
        titleTypeDesc: "test title desc 2",
        gradeRange: "13 - 17",
        specificMarket: "testing market",
        ipubPublishingGroup: "",
        ipubProgrammingTitle: "",
        noOfPages: 50,
        comments:
          "\nfgdhyfh\ntesting comment;fdg\ntesting api update;\ntesting done by prakriti_de;\nPusti, Shuvendu 2022-9-2 15:20:47\ntestdfgdfg\ntest123dfgdfg\nkhfuhsjkdhf\nPusti, Shuvendu 2022-9-2 19:57:17\ntest123\nDe, Prakriti 2022-9-13 20:59:10\ntest\ntest2",
      },
      details: {
        associatedid: 10863,
        recordid: 1304182,
        productTitle: "testing product title from postman - 11",
        archivist: {
          lovid: 1005,
          lovType: "ARCHIVIST",
          lovCode: "ARCHIVIST-MHSE",
          description: "April Cleland",
          valueField: null,
          enabled: "N",
          orderSeq: 6,
        },
        compositorVendor: {
          lovid: 4002,
          lovType: "COMPOSITOR_VENDOR",
          lovCode: "COMPOSITOR_VENDOR-MHHE",
          description: "Hurix",
          valueField: null,
          enabled: "Y",
          orderSeq: 3,
          otherValue: null,
        },
        downloadReceivedDate: "2022-05-18",
        archivedDate: "2022-05-18",
        storageLocation: {
          lovid: 49012,
          lovType: "STORAGE_LOCATION",
          lovCode: "STORAGE_LOCATION-ALL",
          description: "Warehouse",
          valueField: null,
          enabled: "Y",
          orderSeq: 13,
        },
        libraryLocation: "testing product title from postman - 11",
        printingVersion: 0,
        reprintContact: {
          lovid: 40007,
          lovType: "REPRINT_CONTACT",
          lovCode: "REPRINT_CONTACT-MHSE",
          description: "Other",
          valueField: null,
          enabled: "Y",
          orderSeq: 8,
          otherValue: "asdf asdf",
        },
        pagingFilesList: [
          {
            lovid: 31005,
            lovType: "PAGINGFILES",
            lovCode: "PAGINGFILES-ALL",
            description: "Other",
            valueField: null,
            enabled: "Y",
            orderSeq: 6,
            otherValue: "testing paging files from postman - 01",
          },
        ],
        otherFilesList: [
          {
            lovid: 25001,
            lovType: "OTHERFILES",
            lovCode: "OTHERFILES-ALL",
            description: "Images",
            valueField: null,
            enabled: "Y",
            orderSeq: 3,
            otherValue: null,
          },
        ],
        pdfsList: [
          {
            lovid: 34001,
            lovType: "PDFS",
            lovCode: "PDFS-ALL",
            description: "Printer PDFs",
            valueField: null,
            enabled: "Y",
            orderSeq: 2,
          },
        ],
        productNotes: "testing product notes from postman - 01",
        createdDate: "2022-05-25",
        createdBy: "Prakriti De",
        modifiedDate: "2022-09-14",
        modifiedBy: "Patel, Jignesh",
      },
    };

    cmpInstance.fillFormSubscription(dummyData, false);
    expect(cmpInstance.searchedMHID).not.toBeNull();
  });

  it("should fill all the required data in objects not in details", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.assocSummary = new associatedSummary();
    const dummyData = {
      summary: {
        recordid: 1304182,
        mhid: "test-mhid",
        isbn13: "test-isbn",
        previousISBN: "test_pd_4_123",
        newISBN: "test_pd_4_000",
        author: "test prax",
        title: "testing api part 1",
        edition: 3,
        priority: "test high",
        owningDivision: "test owndiv",
        owningSubDivision: "test own subdiv",
        copyrightYear: 2022,
        boundBookDate: "2022-11-20",
        permissionEndDate: "2022-11-20",
        projectOPDate: "2022-11-20",
        deliveryFormat: "test delivery format 2",
        titleTypeDesc: "test title desc 2",
        gradeRange: "13 - 17",
        specificMarket: "testing market",
        ipubPublishingGroup: "",
        ipubProgrammingTitle: "",
        noOfPages: 50,
        comments:
          "\nfgdhyfh\ntesting comment;fdg\ntesting api update;\ntesting done by prakriti_de;\nPusti, Shuvendu 2022-9-2 15:20:47\ntestdfgdfg\ntest123dfgdfg\nkhfuhsjkdhf\nPusti, Shuvendu 2022-9-2 19:57:17\ntest123\nDe, Prakriti 2022-9-13 20:59:10\ntest\ntest2",
      },
    };
    cmpInstance.fillFormSubscription(dummyData, false);
    expect(cmpInstance.searchedMHID).not.toBeNull();
  });

  it("should search based on the url and filled data in objects", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.assocSummary = new associatedSummary();

    const dummyData = {
      summary: {
        recordid: 1304182,
        mhid: "test-mhid",
        isbn13: "test-isbn",
        previousISBN: "test_pd_4_123",
        newISBN: "test_pd_4_000",
        author: "test prax",
        title: "testing api part 1",
        edition: 3,
        priority: "test high",
        owningDivision: "test owndiv",
        owningSubDivision: "test own subdiv",
        copyrightYear: 2022,
        boundBookDate: "2022-11-20",
        permissionEndDate: "2022-11-20",
        projectOPDate: "2022-11-20",
        deliveryFormat: "test delivery format 2",
        titleTypeDesc: "test title desc 2",
        gradeRange: "13 - 17",
        specificMarket: "testing market",
        ipubPublishingGroup: "",
        ipubProgrammingTitle: "",
        noOfPages: 50,
        comments:
          "\nfgdhyfh\ntesting comment;fdg\ntesting api update;\ntesting done by prakriti_de;\nPusti, Shuvendu 2022-9-2 15:20:47\ntestdfgdfg\ntest123dfgdfg\nkhfuhsjkdhf\nPusti, Shuvendu 2022-9-2 19:57:17\ntest123\nDe, Prakriti 2022-9-13 20:59:10\ntest\ntest2",
      },
      details: {
        associatedid: 10863,
        recordid: 1304182,
        productTitle: "testing product title from postman - 11",
        archivist: 1005,
        compositorVendor: 4002,
        downloadReceivedDate: "2022-05-18",
        archivedDate: "2022-05-18",
        storageLocation: 49012,
        libraryLocation: "testing product title from postman - 11",
        printingVersion: 0,
        reprintContact: 40007,
      },
    };

    cmpInstance.fillFormSubscription(dummyData, true);
    expect(cmpInstance.searchedMHID).not.toBeNull();
  });

  it("should validate MHID the required fields", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocSummary = new associatedSummary();
    cmpInstance.assocSummary.mhid = null;
    const flag = cmpInstance.validation();
    expect(flag).toBeTruthy();
  });

  it("should validate ISBN the required fields", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocSummary = new associatedSummary();
    cmpInstance.assocSummary.mhid = "test";
    cmpInstance.assocSummary.isbn13 = undefined;
    const flag = cmpInstance.validation();
    expect(flag).toBeTruthy();
  });

  it("should validate Product Title the required fields", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocSummary = new associatedSummary();
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.assocSummary.mhid = "test";
    cmpInstance.assocSummary.isbn13 = "test";
    cmpInstance.assocDetails.productTitle = null;
    const flag = cmpInstance.validation();
    expect(flag).toBeTruthy();
  });

  it("should validate Product Title if it is undefined ", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocSummary = new associatedSummary();
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.assocSummary.mhid = "test";
    cmpInstance.assocSummary.isbn13 = "test";
    cmpInstance.assocDetails.productTitle = "";
    const flag = cmpInstance.validation();
    expect(flag).toBeTruthy();
  });

  it("should validate all the required fields", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocSummary = new associatedSummary();
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.assocSummary.mhid = "test";
    cmpInstance.assocSummary.isbn13 = "test";
    cmpInstance.assocDetails.productTitle = "test";
    const flag = cmpInstance.validation();
    expect(flag).toBeFalsy();
  });

  it("should validate all the required fields", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocSummary = new associatedSummary();
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.assocSummary.mhid = "test";
    cmpInstance.assocSummary.isbn13 = "test";
    cmpInstance.assocDetails.productTitle = "test";
    const flag = cmpInstance.validation();
    expect(flag).toBeFalsy();
  });

  it("should search using mhid", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.assocSummary = new associatedSummary();

    cmpInstance.searchByTab("test-mhid", "mhid", false);
    fixture.detectChanges();
    expect(cmpInstance.assocSummary).not.toBeNull();
  });

  it("should search using ISBN", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.assocSummary = new associatedSummary();

    cmpInstance.searchByTab("test-isbn", "isbn", false);
    fixture.detectChanges();
    expect(cmpInstance.assocSummary).not.toBeNull();
  });

  it("should search using Associated ID", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.assocSummary = new associatedSummary();

    cmpInstance.searchByTab("test", "assocId", false);
    fixture.detectChanges();
    expect(cmpInstance.assocSummary).not.toBeNull();
  });

  it("should not search if NOT using MHID/ISBN13/Associated ID", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.assocSummary = new associatedSummary();

    cmpInstance.searchByTab("test", "test", false);
    fixture.detectChanges();
    expect(cmpInstance.assocSummary).not.toBeNull();
  });

  it("should not search if no value for MHID/ISBN13/Associated is applied", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.assocSummary = new associatedSummary();

    cmpInstance.searchByTab("", "mhid", false);
    fixture.detectChanges();
    expect(cmpInstance.assocSummary).not.toBeNull();
  });

  it("should check archiviest if already exists in array", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.actualArchivistArray = [
      {
        lovid: 1005,
        lovType: "ARCHIVIST",
        lovCode: "ARCHIVIST-MHSE",
        description: "April Cleland",
        valueField: null,
        enabled: "N",
        orderSeq: 6,
      },
    ];
    cmpInstance.archivistArray = [
      {
        lovid: 1005,
        lovType: "ARCHIVIST",
        lovCode: "ARCHIVIST-MHSE",
        description: "April Cleland",
        valueField: null,
        enabled: "N",
        orderSeq: 6,
      },
    ];

    const j = cmpInstance.checkExistingArchiviest("April Cleland");
    fixture.detectChanges();
    expect(j).toBeFalsy();
  });

  it("should adjust archiviest", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.actualArchivistArray = [
      {
        lovid: 1005,
        lovType: "ARCHIVIST",
        lovCode: "ARCHIVIST-MHSE",
        description: "April Cleland",
        valueField: null,
        enabled: "N",
        orderSeq: 6,
      },
    ];
    cmpInstance.archivistArray = [
      {
        lovid: 1003,
        lovType: "ARCHIVIST",
        lovCode: "ARCHIVIST-MHSE",
        description: "Andy Backs",
        valueField: null,
        enabled: "Y",
        orderSeq: 4,
      },
      {
        lovid: 1011,
        lovType: "ARCHIVIST",
        lovCode: "ARCHIVIST-MHSE",
        description: "Jeff Kemeter",
        valueField: null,
        enabled: "Y",
        orderSeq: 12,
      },
      {
        lovid: 1012,
        lovType: "ARCHIVIST",
        lovCode: "ARCHIVIST-MHSE",
        description: "Jessica Solomon",
        valueField: null,
        enabled: "Y",
        orderSeq: 13,
      },
      {
        lovid: 1013,
        lovType: "ARCHIVIST",
        lovCode: "ARCHIVIST-MHHE",
        description: "Jodi Gaherty",
        valueField: null,
        enabled: "Y",
        orderSeq: 14,
      },
      {
        lovid: 1014,
        lovType: "ARCHIVIST",
        lovCode: "ARCHIVIST-MHHE",
        description: "Kara Kudronowicz",
        valueField: null,
        enabled: "Y",
        orderSeq: 15,
      },
      {
        lovid: 1017,
        lovType: "ARCHIVIST",
        lovCode: "ARCHIVIST-MHHE",
        description: "Laurie Lenstra",
        valueField: null,
        enabled: "Y",
        orderSeq: 18,
      },
      {
        lovid: 1032,
        lovType: "ARCHIVIST",
        lovCode: "ARCHIVIST-MHHE",
        description: "Tina Flanagan",
        valueField: null,
        enabled: "Y",
        orderSeq: 33,
      },
    ];
    cmpInstance.assocDetails.archivist = {
      lovid: 1005,
      lovType: "ARCHIVIST",
      lovCode: "ARCHIVIST-MHSE",
      description: "April Cleland",
      valueField: null,
      enabled: "N",
      orderSeq: 6,
    };
    const j = cmpInstance.setArchivest();
    fixture.detectChanges();
    expect(j).toBeFalsy();
  });

  it("should adjust compvendor when search", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.compVendorArray = [
      {
        lovid: 4000,
        lovType: "COMPOSITOR_VENDOR",
        lovCode: "COMPOSITOR_VENDOR-ALL",
        description: "Aptara",
        valueField: null,
        enabled: "Y",
        orderSeq: 1,
      },
      {
        lovid: 4001,
        lovType: "COMPOSITOR_VENDOR",
        lovCode: "COMPOSITOR_VENDOR-MHSE",
        description: "Editec",
        valueField: null,
        enabled: "Y",
        orderSeq: 2,
      },
      {
        lovid: 4002,
        lovType: "COMPOSITOR_VENDOR",
        lovCode: "COMPOSITOR_VENDOR-MHHE",
        description: "Hurix",
        valueField: null,
        enabled: "Y",
        orderSeq: 3,
      },
    ];
    cmpInstance.assocDetails.compositorVendor = [
      {
        lovid: 4002,
        lovType: "COMPOSITOR_VENDOR",
        lovCode: "COMPOSITOR_VENDOR-MHHE",
        description: "Hurix",
        valueField: null,
        enabled: "Y",
        orderSeq: 3,
        otherValue: null,
      },
    ];

    cmpInstance.setCompVendor();
    fixture.detectChanges();
    expect(cmpInstance.assocDetails.compositorVendor).not.toBeNull();
  });

  it("should adjust compvendor Other Field when search", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.compVendorArray = [
      {
        lovid: 4004,
        lovType: "COMPOSITOR_VENDOR",
        lovCode: "COMPOSITOR_VENDOR-MHSE",
        description: "SeBue",
        valueField: null,
        enabled: "Y",
        orderSeq: 5,
      },
      {
        lovid: 4005,
        lovType: "COMPOSITOR_VENDOR",
        lovCode: "COMPOSITOR_VENDOR-ALL",
        description: "Other",
        valueField: null,
        otherValue: "test",
        enabled: "Y",
        orderSeq: 6,
      },
      {
        lovid: 4006,
        lovType: "COMPOSITOR_VENDOR",
        lovCode: "COMPOSITOR_VENDOR-ALL",
        description: "Straive",
        valueField: null,
        enabled: "Y",
        orderSeq: 7,
      },
    ];

    cmpInstance.assocDetails.compositorVendor = {
      lovid: 4005,
      lovType: "COMPOSITOR_VENDOR",
      lovCode: "COMPOSITOR_VENDOR-ALL",
      description: "Other",
      valueField: null,
      otherValue: "test",
      enabled: "Y",
      orderSeq: 6,
    };
    fixture.autoDetectChanges();
    cmpInstance.setCompVendor();
    expect(cmpInstance.assocDetails.compositorVendor).not.toBeNull();
  });

  it("should adjust compvendor Other Field without value when search", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.locationArray = [
      {
        lovid: 49011,
        lovType: "STORAGE_LOCATION",
        lovCode: "STORAGE_LOCATION-ALL",
        description: "VideoTape",
        valueField: null,
        enabled: "Y",
        orderSeq: 12,
      },
      {
        lovid: 49012,
        lovType: "STORAGE_LOCATION",
        lovCode: "STORAGE_LOCATION-ALL",
        description: "Warehouse",
        valueField: null,
        enabled: "Y",
        orderSeq: 13,
      },
    ];

    cmpInstance.assocDetails.storageLocation = {
      lovid: 49012,
      lovType: "STORAGE_LOCATION",
      lovCode: "STORAGE_LOCATION-ALL",
      description: "Warehouse",
      valueField: null,
      enabled: "Y",
      orderSeq: 13,
    };
    fixture.autoDetectChanges();
    cmpInstance.setLocation();
    expect(cmpInstance.assocDetails.storageLocation).not.toBeNull();
  });

  it("should adjust compvendor Other Field without value when search", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.reprintContactArray = [
      {
        lovid: 40000,
        lovType: "REPRINT_CONTACT",
        lovCode: "REPRINT_CONTACT-MHSE",
        description: "Adrienne Searcy",
        valueField: null,
        enabled: "Y",
        orderSeq: 1,
      },
      {
        lovid: 40001,
        lovType: "REPRINT_CONTACT",
        lovCode: "REPRINT_CONTACT-MHSE",
        description: "Angela Warner",
        valueField: null,
        enabled: "Y",
        orderSeq: 2,
      },
      {
        lovid: 40007,
        lovType: "REPRINT_CONTACT",
        lovCode: "REPRINT_CONTACT-MHSE",
        description: "Other",
        valueField: null,
        enabled: "Y",
        orderSeq: 8,
      },
    ];
    cmpInstance.assocDetails.reprintContact = {
      lovid: 40007,
      lovType: "REPRINT_CONTACT",
      lovCode: "REPRINT_CONTACT-MHSE",
      description: "Other",
      valueField: null,
      otherValue: "",
      enabled: "Y",
      orderSeq: 8,
    };
    fixture.autoDetectChanges();
    cmpInstance.setReprintContact();
    expect(cmpInstance.assocDetails.reprintContact).not.toBeNull();
  });

  it("should checked Pagging Files Lists when data is loaded", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.pagingFilesArray = testPaggingFilesArray;
    cmpInstance.assocDetails.pagingFilesList = [
      {
        lovid: 31000,
        lovType: "PAGINGFILES",
        lovCode: "PAGINGFILES-MHHE",
        description: "InDesign",
        valueField: null,
        enabled: "Y",
        orderSeq: 1,
        otherValue: null,
        checked: true,
      },
      {
        lovid: 31005,
        lovType: "PAGINGFILES",
        lovCode: "PAGINGFILES-ALL",
        description: "Other",
        valueField: null,
        enabled: "Y",
        orderSeq: 6,
        otherValue: "testing paging files from postman - 01",
        checked: true,
      },
    ];
    fixture.autoDetectChanges();
    cmpInstance.setPaggingFiles();
    expect(cmpInstance.pagingFilesArray).not.toBeNull();
  });

  it("should adjust Pagging Files Lists when NONE is checked", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.pagingFilesArray = testPaggingFilesArray;
    cmpInstance.assocDetails.pagingFilesList = [
      {
        lovid: 31002,
        lovType: "PAGINGFILES",
        lovCode: "PAGINGFILES-ALL",
        description: "None",
        valueField: null,
        enabled: "Y",
        orderSeq: 3,
        checked: false,
      },
    ];
    fixture.autoDetectChanges();
    cmpInstance.setPaggingFiles();
    expect(cmpInstance.pagingFilesArray).not.toBeNull();
  });

  it("should checked Other Files Lists when data is loaded", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.otherFilesArray = testOtherFilesArray;
    cmpInstance.assocDetails.otherFilesList = [
      {
        lovid: 25000,
        lovType: "OTHERFILES",
        lovCode: "OTHERFILES-ALL",
        description: "Cover/Design",
        valueField: null,
        enabled: "Y",
        orderSeq: 2,
        otherValue: null,
      },
      {
        lovid: 25001,
        lovType: "OTHERFILES",
        lovCode: "OTHERFILES-ALL",
        description: "Images",
        valueField: null,
        enabled: "Y",
        orderSeq: 3,
        otherValue: null,
      },
    ];
    fixture.autoDetectChanges();
    cmpInstance.setOtherFiles();
    expect(cmpInstance.otherFilesArray).not.toBeNull();
  });

  it("should adjust Other Files Lists when NONE is checked", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.otherFilesArray = testOtherFilesArray;
    cmpInstance.assocDetails.otherFilesList = [
      {
        lovid: 25002,
        lovType: "OTHERFILES",
        lovCode: "OTHERFILES-ALL",
        description: "None",
        valueField: undefined,
        enabled: "Y",
        orderSeq: 4,
      },
    ];
    fixture.autoDetectChanges();
    cmpInstance.setOtherFiles();
    expect(cmpInstance.otherFilesArray).not.toBeNull();
  });

  it("should return true when record Id is not available", () => {
    const cmpInstance = fixture.debugElement.componentInstance;

    const flagNavigate = cmpInstance.canDeactivate();
    expect(flagNavigate).toBeTruthy();
  });

  it("should reset all checkboxes lists", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.pagingFilesArray = [
      {
        lovid: 31000,
        lovType: "PAGINGFILES",
        lovCode: "PAGINGFILES-MHHE",
        description: "InDesign",
        valueField: null,
        enabled: "Y",
        orderSeq: 1,
      },
    ];
    cmpInstance.otherFilesArray = [
      {
        lovid: 25004,
        lovType: "OTHERFILES",
        lovCode: "OTHERFILES-ALL",
        description: "Accessibility Files",
        valueField: null,
        enabled: "Y",
        orderSeq: 1,
      },
    ];

    cmpInstance.PDFsArray = [
      {
        lovid: 34000,
        lovType: "PDFS",
        lovCode: "PDFS-ALL",
        description: "Media PDFs",
        valueField: null,
        enabled: "Y",
        orderSeq: 1,
      },
    ];
    cmpInstance.resetCheckboxes();
    expect(cmpInstance.pagingFilesArray[0].enabled === "Y").toBeTruthy();
    expect(cmpInstance.otherFilesArray[0].enabled === "Y").toBeTruthy();
    expect(cmpInstance.PDFsArray[0].enabled === "Y").toBeTruthy();
  });

  it("should navigate to archive record page when Archive Record Link is clicked", async () => {
    inject([Router], async (mockRouter: Router) => {
      const spy = spyOn(mockRouter, "navigate").and.stub();
      component.assocSummary.mhid = "test-mhid";
      await component.movetoArchiveRequestPageWithMHID();
      expect(spy.calls.first().args[0][0]).toContain(["archiveRec"]);
    });
  });

  it("should disable Pagging Files Lists when NONE is checked", async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.pagingFilesArray = testPaggingFilesArray;
    cmpInstance.pagingFilesArray.forEach((v: chkInterface) => {
      v.checked = false;
      v.enabled = "Y";
    });
    fixture.detectChanges();
    const element = fixture.nativeElement.querySelector("#None31002");
    element.click();
    fixture.detectChanges();
    expect(
      cmpInstance.pagingFilesArray.filter((j: { enabled: string }) => {
        return j.enabled == "N";
      }).length
    ).toBe(5);
  });

  it("should Enabled Pagging Files Lists when NONE is checked", async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.pagingFilesArray = testPaggingFilesArray;
    cmpInstance.pagingFilesArray.forEach((v: chkInterface) => {
      v.checked = false;
      v.enabled = "Y";
    });
    fixture.detectChanges();
    const element = fixture.nativeElement.querySelector("#None31002");
    element.click();
    element.click();
    fixture.detectChanges();
    expect(
      cmpInstance.pagingFilesArray.filter((j: { enabled: string }) => {
        return j.enabled == "N";
      }).length
    ).toBe(0);
  });

  it("should display popup confirmation if user have changed some data ", () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.assocSummary = new associatedSummary();
    cmpInstance.searchedMHID = "test-mhid2";
    cmpInstance.searchedISBN = "test-isbn2";

    cmpInstance.searchByTab("test-mhid", "mhid", false);
    fixture.detectChanges();
    expect(cmpInstance.assocSummary).not.toBeNull();
  });

  it("should submit data when all test cases are passed ", async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.assocSummary = new associatedSummary();
    cmpInstance.assocDetails = {
      productTitle: "test",
      archivist: "1013",
      compositorVendor: "4002",
      downloadReceivedDate: "",
      archivedDate: "",
      storageLocation: "",
      libraryLocation: "",
      printingVersion: 0,
      reprintContact: "",
      pagingFilesList: [],
      otherFilesList: [],
      pdfsList: [],
      associatedid: 0,
      recordid: 2223643,
      productNotes: "",
      createdDate: "",
      createdBy: "",
      modifiedDate: "",
      modifiedBy: "",
    };
    cmpInstance.assocSummary = {
      recordid: 2223643,
      mhid: "test-mhid2",
      isbn13: "test-isbn2",
      previousISBN: "test_pd_4_567",
      newISBN: "test_pd_4_000",
      author: "test foo",
      title: "testing api part 2",
      edition: 5,
      priority: "test high",
      owningDivision: "test owndiv",
      owningSubDivision: "test own subdiv",
      copyrightYear: 2022,
      boundBookDate: "2022-11-20",
      permissionEndDate: "2022-11-20",
      projectOPDate: "2022-11-20",
      deliveryFormat: "test delivery format 3",
      titleTypeDesc: "test title desc 3",
      gradeRange: "13 - 17",
      specificMarket: "testing market",
      ipubPublishingGroup: "testing pub group",
      ipubProgrammingTitle: '"testing prog title - 3',
      noOfPages: 50,
      comments:
        "testing comment;\\ntesting api update;\\ntesting done by prakriti_de;",
    };
    fixture.detectChanges();
    await cmpInstance.onSubmit();
    const todayDate = cs.getDate();
    expect(cmpInstance.assocDetails.modifiedDate).toBe(todayDate);
    expect(cmpInstance.assocDetails).not.toBeNull();
    expect(cmpInstance.assocSummary).not.toBeNull();
  });

  it("should set other value of comp vendor field!", async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.defaultCompVendorOtherValue = "example value";
    cmpInstance.assocDetails = { compositorVendor: "initial value" };
    const event = { currentTarget: { value: "example value" } };
    cmpInstance.compVendorOtherValueChange(event);
    expect(cmpInstance.assocDetails?.compositorVendor).not.toBeUndefined();
  });

  it("should set other value of comp vendor not field!", async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.defaultCompVendorOtherValue = "example value";
    cmpInstance.assocDetails = { compositorVendor: "initial value" };
    const event = { currentTarget: { value: "" } };
    cmpInstance.compVendorOtherValueChange(event);
    expect(cmpInstance.assocDetails?.compositorVendor).not.toBeUndefined();
  });

  it("should set other value of reprint contact field!", async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.reprintContactOther = "example value";
    cmpInstance.assocDetails = { defaultproductionSpecialist: "initial value" };
    const event = { currentTarget: { value: "example value" } };
    cmpInstance.reprintContactOtherValueChange(event);
    expect(
      cmpInstance.assocDetails?.defaultproductionSpecialist
    ).not.toBeUndefined();
  });

  it("should set other value of reprint contact not field!", async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();
    cmpInstance.reprintContactOther = "example value";
    cmpInstance.assocDetails = { defaultproductionSpecialist: "initial value" };
    const event = { currentTarget: { value: "" } };
    cmpInstance.reprintContactOtherValueChange(event);
    expect(
      cmpInstance.assocDetails?.defaultproductionSpecialist
    ).not.toBeUndefined();
  });

  it("should call and return other files other checkbox", async () => {
    const cmpInstance = fixture.debugElement.componentInstance;
    cmpInstance.assocDetails = new associatedDetails();

    cmpInstance.otherFilesArray = otherFilesArray;
    cmpInstance.assocDetails.otherFilesList = [
      {
        lovid: 25001,
        lovType: "OTHERFILES",
        lovCode: "OTHERFILES-ALL",
        description: "Cover/Design",
        valueField: null,
        enabled: "Y",
        orderSeq: 2,
      },
    ];
    const event = { currentTarget: { lovid: 25001 } };
    const j = cmpInstance.otherFilesOtherValueChange(
      event,
      cmpInstance.assocDetails.otherFilesList
    );
    expect(j).not.toBeNull();
  });
});
