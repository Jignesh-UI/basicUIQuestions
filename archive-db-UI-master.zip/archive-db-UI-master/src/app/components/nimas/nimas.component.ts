import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CommonService } from 'src/app/service/commonClasses/common.service';
import { LovDataService } from 'src/app/service/commonClasses/lov-data.service';
import { OktaInfoService } from 'src/app/shared/okta/okta-info.service';
import { nimasDetails, nimasLovInterface, nimasSummary } from './nimas.model';
import { lovInterface } from 'src/app/service/models/common.model';
import { Observable } from 'rxjs';
import { APP_Messages } from 'src/app/service/commonClasses/app-defaults';
import { NotificationService } from 'src/app/service/notification.service';
import { HttpResponse } from 'src/app/shared/response.model';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { RolesPolicyService } from 'src/app/service/roles-policy.service';

@Component({
  selector: 'app-nimas',
  templateUrl: './nimas.component.html',
  styleUrls: ['./nimas.component.css']
})
export class NimasComponent implements OnInit, OnDestroy {

  @ViewChild('mhid') mhid: ElementRef | undefined;

  nimasDetails = new nimasDetails();
  nimasSummary = new nimasSummary();
  userName = '';

  maxLengthofControls = {
    'mhidMaxLength': 15,
    'ISBN13MaxLength': 50,
    'PREVIOUS_ISBNMaxLength': 15,
    'nimasCertiNumberMaxLength': 100,
    'NEW_ISBNMaxLength': 15,
    'authorMaxLength': 240,
    'titleMaxLength': 1500,
    'editionMaxLength': 22,
    'priorityMaxLength': 16,
    'ODDMaxLength': 150,
    'SDDMaxLength': 150,
    'CopyYearMaxLength': 22,
    'calculatedBBDMaxLength': 7,
    'PermissionEndDateMaxLength': 7,
    'projectOPDateMaxLength': 7,
    'DeliveryFormatMaxLength': 150,
    'TitleTypeMaxLength': 240,
    'GradeRangeMaxLength': 5,
    'SpecificMarketMaxLength': 150,
    'ipubPublishingGroupMaxLength': 20,
    'iPubProgramTitleMaxLength': 500,
    'noOfPagesMaxLength': 22,
    'NIMASArchiveNotesMaxLength': 4000,

  };

  recordInformation = {
    uniqueId: null,
    dateCreated: null,
    createdBy: '',
    dateLastModified: null,
    lastModifiedBy: null,
  }

  searchedMHID = '';
  searchedISBN = '';

  isLoading = false;
  disabledPDHField = true;
  disabledSummaryFields = true;

  archivistArray: lovInterface[] = [];
  actualArchivistArray: lovInterface[] = [];
  nimasCoordinatorArray: lovInterface[] = [];
  nimasconvVendorArray: nimasLovInterface[] = [];
  nimasDescVendorArray: nimasLovInterface[] = [];

  convVendorOther = '';
  descVendorOther = '';

  archiveNotesRows = 8;
  nimasNotesRows = 8;
  noteCommnetsCols = 50;

  showConvVendor = false;
  showDescVendor = false;

  url = environment.baseAPIUrl + "services/nimasRecords/";

  private headers = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }

  defaultReprintOtherValue = '';
  defaultCompVendorOtherValue = '';
  permissionsStatus = false;

  constructor(private oktaService: OktaInfoService, private lovData: LovDataService, private cs: CommonService,
    private notify: NotificationService, private http: HttpClient, private router: Router, private activatedRoute: ActivatedRoute,
    private rolesService: RolesPolicyService) {
    // this.router.onSameUrlNavigation = 'reload';
    activatedRoute.params.subscribe(val => {
      const taskid = val['keyword'];
      if (taskid != null) {
        this.searchByTab(taskid, 'nimasId');
      }
    });
    this.loadLovs();
  }

  async canDeactivate(): Promise<boolean | Observable<boolean>> {
    if (this.searchedMHID.length > 1 && this.searchedISBN?.length > 1) {
      const chkData = JSON.parse(localStorage.getItem('nimasoData'));
      const dataComparisonFlag: boolean = await this.cs.adjustData(chkData, this.nimasDetails, this.nimasSummary);
      if (!dataComparisonFlag) {
        const flag = await this.cs.showModalConfirmation(true);
        if (!flag) {
          this.nimasSummary.mhid = this.searchedMHID;
          this.nimasSummary.isbn13 = this.searchedISBN;
          this.isLoading = false;
          return false;
        }
      }
      this.nimasSummary.mhid = this.searchedMHID;
      this.nimasSummary.isbn13 = this.searchedISBN;
    }
    return true;
  }

  async ngOnInit(): Promise<void> {
    const promise = await this.oktaService.GetOktUserInfo();
    const user = promise['claims']['name'];
    this.userName = user;
    this.resetDetails();
    await this.loadLovs();
    this.mhid?.nativeElement.focus();
    localStorage.removeItem('nimasoData');
  }

  async ngOnDestroy(): Promise<void> {
    localStorage.removeItem('nimasoData');
  }

  async searchByTab(input: string, filterTyle: string) {

    let dbCall: Observable<Object>;
    this.isLoading = true;
    if (input.trim().length < 1) {
      this.isLoading = false;
      return false;
    } else if (filterTyle == 'mhid' && input == this.searchedMHID) {
      this.isLoading = false;
      return false;
    } else if (filterTyle == 'isbn' && input == this.searchedISBN) {
      this.isLoading = false;
      return false;
    }

    if (this.searchedMHID.length > 1 && this.searchedISBN?.length > 1) {
      const chkData = JSON.parse(localStorage.getItem('nimasoData'));
      const dataComparisonFlag: boolean = await this.cs.adjustData(chkData, this.nimasDetails, this.nimasSummary);
      if (!dataComparisonFlag) {
        const t = await this.cs.showModalConfirmation();
        if (!t) {
          this.nimasSummary.mhid = this.searchedMHID;
          this.nimasSummary.isbn13 = this.searchedISBN;
          this.isLoading = false;
          return false;
        }
      }
      this.nimasSummary.mhid = this.searchedMHID;
      this.nimasSummary.isbn13 = this.searchedISBN;
    }

    if (filterTyle == 'mhid' && input) {
      const url = this.url + "/mhId/" + input.replaceAll(".", "%2525252E");
      dbCall = this.http.get<HttpResponse>(url, this.headers);
    } else if (filterTyle == 'isbn' && input) {
      const url = this.url + "/isbn13/" + input.replaceAll(".", "%2525252E");
      dbCall = this.http.get<HttpResponse>(url, this.headers);
    } else if (filterTyle == 'nimasId' && input) {
      const url = this.url + "/nimasId/" + input.replaceAll(".", "%2525252E");
      dbCall = this.http.get<HttpResponse>(url, this.headers);
    } else {
      this.isLoading = false;
      return false;
    }

    dbCall.subscribe((responseData: HttpResponse): void => {
      this.convVendorOther = '';
      this.descVendorOther = '';
      if (responseData['data'] && responseData['succeeded']) {
        this.resetDataModel();
        this.fillFormSubscription(responseData['data']);
      } else {
        this.resetDataModel();
        this.resetDrpLists();
        this.disabledSummaryFields = true;
        this.notify.showSuccess('', responseData['message']);
      }
      this.isLoading = false;
    }, err => {
      this.disabledSummaryFields = true;
      this.isLoading = false;
      this.notify.showSuccess('', APP_Messages.ServerErrorMessage);
    });
    return true;
  }

  async fillFormSubscription(data: any) {
    this.nimasSummary = data['summary'] as nimasSummary;
    this.permissionsStatus = await this.rolesService.authenticationStatus(this.nimasSummary.owningDivision);
    if (data['details']) {
      this.nimasDetails = data['details'] as nimasDetails;
      this.defaultReprintOtherValue = this.nimasDetails?.nimasConvVendor?.otherValue == null ? "" : this.nimasDetails?.nimasConvVendor?.otherValue;
      this.defaultCompVendorOtherValue = this.nimasDetails?.nimasDescVendor?.otherValue == null ? "" : this.nimasDetails?.nimasDescVendor?.otherValue;

      this.fillRecordInfo(true);
      this.setArchivest();
      this.setCoordinator();
      this.setConversionVendor();
      this.setDescriptionVendor();
    } else {
      this.resetDetails();
    }

    this.adjustNimasId();
    this.searchedMHID = this.nimasSummary.mhid;
    this.searchedISBN = this.nimasSummary.isbn13;
    this.disabledSummaryFields = false;

    if (data['details']) {
      localStorage.setItem('nimasoData', JSON.stringify({ "summary": this.nimasSummary, "details": this.nimasDetails }));
    } else {
      localStorage.setItem('nimasoData', JSON.stringify({ "summary": this.nimasSummary }));
    }

  }

  adjustNimasId() {
    if (this.nimasDetails.nimasid == 0 || this.nimasDetails.nimasid == null || this.nimasDetails.nimasid == undefined) {
      this.nimasDetails.recordid = this.nimasSummary.recordid;
    }
  }

  onNIMASCommentAdd(comment: any) {
    this.nimasDetails.notes = this.nimasDetails.notes || '';
    if (this.nimasDetails.notes.length > 0) {
      const newLine = this.nimasDetails.notes.substr(this.nimasDetails.notes.length - 1, 2) == '\n' ? '' : '\n';
      this.nimasDetails.notes += newLine + this.userName + " " + this.cs.getDateTime() + '\n' + comment + '\n';
    } else {
      this.nimasDetails.notes += this.userName + " " + this.cs.getDateTime() + '\n' + comment + '\n';
    }
  }

  async loadLovs() {
    this.actualArchivistArray = this.archivistArray = this.lovData.returnArchivistLOV();
    this.nimasCoordinatorArray = this.lovData.returnSingleLOV('COORDINATOR');
    this.nimasconvVendorArray = this.lovData.returnSingleLOV('CONV_VENDOR');
    this.nimasDescVendorArray = this.lovData.returnSingleLOV('DESC_VENDOR');
  }

  async onSubmit() {

    this.isLoading = true;
    if (this.validation()) {
      this.isLoading = false;
      return false;
    }

    this.nimasDetails.modifiedDate = this.cs.getDate();
    this.nimasDetails.modifiedBy = this.userName;

    const data: any = { "summary": this.nimasSummary, "details": this.nimasDetails };

    data.details.archivist = this.saveArchivist();
    data.details.coordinator = this.saveCoordinatorVendor();
    data.details.nimasDescVendor = await this.saveDescVendor(data.details.filesDescriptionVendor);
    data.details.nimasConvVendor = await this.saveConvVendor(data.details.filesConversionVendor);

    if (this.nimasDetails.nimasid != null && this.nimasDetails.nimasid != undefined && this.nimasDetails.nimasid != 0) {
      await this.nimasPutCall(data)
    } else {
      await this.nimasPostCall(data);
    }
    this.isLoading = false;
    return data;
  }

  async nimasPutCall(putData: any) {
    const url: string = this.url + this.nimasDetails.nimasid;
    this.http.put<HttpResponse>(url, putData).subscribe(response => {
      this.resetDrpLists();
      if (response.data != null) {
        this.fillFormSubscription(response.data);
        this.recordInformation.dateLastModified = response.data['details'].modifiedDate;
        this.recordInformation.lastModifiedBy = response.data['details'].modifiedBy;
      }

      this.notify.showSuccess('', response.message);
      localStorage.setItem('nimasoData', JSON.stringify({ "summary": this.nimasSummary, "details": this.nimasDetails }));
      this.isLoading = false;
    }, err => {
      this.isLoading = false;
      this.notify.showSuccess('', APP_Messages.ServerErrorMessage);
    });
  }

  async nimasPostCall(postData: any) {
    const url: string = this.url;
    postData.details.createdDate = this.cs.getDate();
    postData.details.createdBy = this.userName;

    this.http.post<HttpResponse>(url, postData).subscribe(response => {
      this.resetDrpLists();
      if (response.data != null) {
        this.fillFormSubscription(response.data);
        this.recordInformation.dateLastModified = response.data['details'].modifiedDate;
        this.recordInformation.lastModifiedBy = response.data['details'].modifiedBy;
      }
      this.notify.showSuccess('', response.message);
      localStorage.setItem('nimasoData', JSON.stringify({ "summary": this.nimasSummary, "details": this.nimasDetails }));
      this.isLoading = false;
    }, err => {
      this.isLoading = false;
      this.notify.showSuccess('', APP_Messages.ServerErrorMessage);
    })
  }

  private fillRecordInfo(resetField: boolean) {
    this.recordInformation.uniqueId = resetField == true ? this.nimasDetails.nimasid : null;
    this.recordInformation.createdBy = resetField == true ? this.nimasDetails.createdBy : null;
    this.recordInformation.dateCreated = resetField == true ? this.nimasDetails.createdDate : null;
    this.recordInformation.dateLastModified = resetField == true ? this.nimasDetails.modifiedDate : null;
    this.recordInformation.lastModifiedBy = resetField == true ? this.nimasDetails.modifiedBy : null;
  }

  convVendorChange(selectedValue: any) {
    let cdata: any;
    if (selectedValue.currentTarget) {
      cdata = selectedValue.currentTarget.options[selectedValue.currentTarget.selectedIndex].text.trim().toLocaleLowerCase();
    } else {
      cdata = selectedValue;
    }
    this.showConvVendor = cdata.trim().toLowerCase() == "other" ? true : false;
  }

  descVendorChange(selectedValue: any) {
    let cdata: any;
    if (selectedValue.currentTarget) {
      cdata = selectedValue.currentTarget.options[selectedValue.currentTarget.selectedIndex].text.trim().toLocaleLowerCase();
    } else {
      cdata = selectedValue;
    }
    this.showDescVendor = cdata.trim().toLowerCase() == "other" ? true : false;
  }

  private resetDetails() {
    const emptyDetails = {
      archivist: "",
      nimasid: 0,
      recordid: 0,
      productNotes: "",
      createdDate: "",
      createdBy: "",
      modifiedDate: "",
      modifiedBy: "",
      coordinator: "",
      nimasCertNumber: "",
      nimasCertReceivedDate: "",
      nimasConvVendor: "",
      nimasDescVendor: "",
      filesDescriptionVendor: "",
      filesConversionVendor: "",
      notes: "",
      nimasCertiReceived: "",
      nimasCertiNumber: "",
      nimasCVTest: "any;",
      nimasDVTest: "any;"
    }
    this.nimasDetails = emptyDetails;
    this.convVendorChange('');
    this.descVendorChange('');
  }

  private resetDataModel() {
    this.nimasDetails = new nimasDetails();
    this.nimasSummary = new nimasSummary();
    this.fillRecordInfo(false);
    this.searchedMHID = '';
    this.searchedISBN = '';
  }

  private resetDrpLists() {
    this.setArchivest();
    this.setCoordinator();
    this.setConversionVendor();
    this.setDescriptionVendor();
  }

  private setArchivest() {

    if (this.nimasDetails.archivist?.description == null || this.nimasDetails.archivist?.description == "") {
      this.nimasDetails.archivist = '';
      return false;
    } else if (this.checkExistingArchiviest(this.nimasDetails.archivist.description) != true) {
      return false;
    }

    let dbData: string;
    let flag = false;

    if (this.nimasDetails.archivist != null) {
      this.archivistArray = this.lovData.returnArchivistLOV();
      dbData = this.nimasDetails.archivist['description'];
    }

    this.archivistArray.filter(ary => {
      if (ary.description == dbData) {
        flag = true;
        return true;
      }
    });

    if (flag) {
      this.archivistArray.push(this.nimasDetails.archivist);
    }

    const lovId = this.archivistArray.filter((arryData) => { return arryData.description?.toLowerCase() == dbData.toLowerCase() })[0].lovid;
    this.nimasDetails.archivist = lovId;
    return true;
  }

  checkExistingArchiviest(paramData = "") {
    this.archivistArray = this.cs.removePreviousArray(this.archivistArray, this.actualArchivistArray);
    const dataLength = this.archivistArray.filter((arData) => {
      return arData.description?.toLowerCase() === paramData.toLowerCase();
    });
    if (dataLength.length >= 1) {
      this.nimasDetails.archivist = dataLength[0].lovid;
      return false;
    } else {
      return true;
    }
  }

  setCoordinator() {
    if (this.nimasDetails && this.nimasDetails.coordinator) {
      const dbData: string = this.nimasDetails.coordinator.description;
      for (const keys in this.nimasCoordinatorArray) {
        if (dbData == this.nimasCoordinatorArray[keys].description) {
          this.nimasDetails.coordinator = this.nimasCoordinatorArray[keys].lovid;
        }
      }
    } else {
      this.nimasDetails.coordinator = '';
    }
  }

  setConversionVendor() {
    if (this.nimasDetails && this.nimasDetails.nimasConvVendor) {
      const dbData: string = this.nimasDetails.nimasConvVendor.description;
      this.nimasDetails.filesConversionVendor = this.nimasDetails.nimasConvVendor.filesSentDate;
      for (const keys in this.nimasconvVendorArray) {
        if (dbData == this.nimasconvVendorArray[keys].description) {
          if (dbData.trim().toLowerCase() === 'other') {
            this.convVendorOther = this.nimasDetails.nimasConvVendor.otherValue?.trim();
          } else {
            this.convVendorOther = '';
          }
          this.nimasDetails.nimasConvVendor = this.nimasconvVendorArray[keys].lovid;
          this.convVendorChange(dbData);
        }
      }
    } else {
      this.nimasDetails.nimasConvVendor = '';
      this.convVendorChange('');
    }
  }

  setDescriptionVendor() {
    if (this.nimasDetails && this.nimasDetails.nimasDescVendor) {
      const dbData: string = this.nimasDetails.nimasDescVendor.description;
      this.nimasDetails.filesDescriptionVendor = this.nimasDetails.nimasDescVendor.filesSentDate;
      for (const keys in this.nimasDescVendorArray) {
        if (dbData == this.nimasDescVendorArray[keys].description) {
          if (dbData.trim().toLowerCase() === 'other') {
            this.descVendorOther = this.nimasDetails.nimasDescVendor.otherValue?.trim();
          } else {
            this.descVendorOther = '';
          }
          this.nimasDetails.nimasDescVendor = this.nimasDescVendorArray[keys].lovid;
          this.descVendorChange(dbData);
        }
      }
    } else {
      this.nimasDetails.nimasDescVendor = '';
      this.descVendorChange('');
    }
  }

  validation() {
    if (this.nimasSummary.mhid == null || this.nimasSummary.mhid == undefined) {
      return true;
    }
    // if (this.nimasSummary.isbn13 == null || this.nimasSummary.isbn13 == undefined) {  // Removed ISBN Validation because it can be NULL or empty.
    //   return true;
    // }
    return false;
  }

  async saveDescVendor(filesDescriptionVendor: string) {
    if (this.nimasDetails.nimasDescVendor == '') {
      return null;
    } else {
      let otherField = false;
      const fdata = this.nimasDescVendorArray.filter(arr => {
        if (arr.lovid === +this.nimasDetails.nimasDescVendor) {
          if (arr.description.trim().toLowerCase() === 'other') {
            otherField = true;
          }
          return arr.lovid === +this.nimasDetails.nimasDescVendor;
        }
      })[0];

      if (fdata) {
        fdata.otherValue = otherField ? this.descVendorOther?.trim() : null;
        fdata.filesSentDate = filesDescriptionVendor;
      }
      return fdata;
    }
  }

  async saveConvVendor(filesConversionVendor: string) {
    if (this.nimasDetails.nimasConvVendor == '') {
      return null;
    } else {
      let otherField = false;
      const fdata = this.nimasconvVendorArray.filter(arr => {
        if (arr.lovid === +this.nimasDetails.nimasConvVendor) {
          if (arr.description.trim().toLowerCase() === 'other') {
            otherField = true;
          }
          return arr.lovid === +this.nimasDetails.nimasConvVendor;
        }
      })[0];

      if (fdata) {
        fdata.otherValue = otherField ? this.convVendorOther?.trim() : null;
        fdata.filesSentDate = filesConversionVendor;
      }
      return fdata;
    }
  }

  saveArchivist() {
    if (this.nimasDetails.archivist == '') {
      return null;
    } else {
      const fdata = this.archivistArray.filter(arr => {
        return arr.lovid === +this.nimasDetails.archivist;
      })[0];
      return fdata;
    }
  }

  saveCoordinatorVendor() {
    if (this.nimasDetails.coordinator == '') {
      return null;
    } else {
      let otherField = false;
      const fdata = this.nimasCoordinatorArray.filter(arr => {
        if (arr.lovid === +this.nimasDetails.coordinator) {
          if (arr.description.trim().toLowerCase() === 'other') {
            otherField = true;
          }
          return arr.lovid === +this.nimasDetails.coordinator;
        }
      })[0];
      return fdata;
    }
  }

  nimasCVOtherValueChange(event: any) {
    if (this.defaultReprintOtherValue == event.currentTarget.value) {
      delete this.nimasDetails?.nimasCVTest;
    } else {
      this.nimasDetails.nimasCVTest = event.currentTarget.value;
    }
  }

  nimasDVOtherValueChange(event: any) {
    if (this.defaultCompVendorOtherValue == event.currentTarget.value) {
      delete this.nimasDetails?.nimasDVTest;
    } else {
      this.nimasDetails.nimasDVTest = event.currentTarget.value;
    }
  }

}
