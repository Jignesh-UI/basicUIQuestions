export class nimasSummary {
    recordid: number;
    mhid: string;
    isbn13: string;
    previousISBN: string;
    newISBN: string;
    author: string;
    title: string;
    edition: number;
    priority: string;
    owningDivision: string;
    owningSubDivision: string;
    copyrightYear: number;
    boundBookDate: string;
    permissionEndDate: string;
    projectOPDate: string;
    deliveryFormat: string;
    titleTypeDesc: string;
    gradeRange: string;
    specificMarket: string;
    ipubPublishingGroup: string;
    ipubProgrammingTitle: string;
    noOfPages: number;
    comments: string;
}
export class nimasDetails {
    archivist: any;
    coordinator: any;
    nimasCertNumber: string;
    nimasCertReceivedDate: string;
    nimasConvVendor: any;
    nimasDescVendor: any;
    filesDescriptionVendor: string;
    filesConversionVendor: any;
    notes: any;

    nimasCertiReceived: string;
    nimasCertiNumber: string;
    createdDate: string;
    createdBy: string;
    modifiedDate: string;
    modifiedBy: string;

    nimasid: number;
    recordid: number;

    nimasCVTest:any;
    nimasDVTest:any;
}

export interface nimasLovInterface {
    lovid?: number,
    lovType?: string,
    lovCode?: string,
    description?: string,
    valueField?: string,
    enabled?: string,
    orderSeq?: number,
    otherValue?: string,
    filesSentDate?: string
}