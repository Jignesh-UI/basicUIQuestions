import { Component, EventEmitter, Output, Input } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-popup',
  templateUrl: './popup.component.html',
  styleUrls: ['./popup.component.css']
})
export class PopupComponent {

  @Input() Heading1: string;
  @Input() Heading2: string;
  @Input() ButtonText: string;
  @Input() submitButton: string;
  @Input() disabledInitially?: boolean = true;
  @Input() btnClass?: string;
  @Input() maxLength?: number = 0;

  closeResult: string;
  instruction = '';
  @Output() onAddEvent = new EventEmitter<any>();

  constructor(private modalService: NgbModal) { }

  open(content: any) {
    if (this.disabledInitially) {
      this.modalService.open(content, { ariaLabelledBy: 'status-modal-basic-title' });
    }
  }

  onAdd(content: any) {
    // on clicking the add button emit the click event
    this.instruction = this.instruction.trim();
    this.onAddEvent.emit(this.instruction);
    this.instruction = '';
    this.modalService.dismissAll();
  }

  instructionChange(event: any) {
    if (this.instruction.length < 1) {
      event.preventDefault();
    }
  }

  clearAndClosePopUp() {
    this.instruction = '';
    this.modalService.dismissAll('Cross click');
  }

}
