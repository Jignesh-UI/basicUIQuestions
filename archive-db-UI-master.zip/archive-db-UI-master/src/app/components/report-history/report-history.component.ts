import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ActionRenderComponent } from '../action-render/action-render.component';
import { ReportService } from 'src/app/service/reports.service';
import { ComponentService } from 'src/app/service/component.service';
import { saveAs as importedSaveAs } from 'file-saver';
import { OktaInfoService } from 'src/app/shared/okta/okta-info.service';
import { ColDef } from 'ag-grid-community';
import { APP_Messages, DeleteConfirmationMessages } from 'src/app/service/commonClasses/app-defaults';
import { NotificationService } from 'src/app/service/notification.service';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { ConfirmDialogComponent } from 'src/app/shared/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-report-history',
  templateUrl: './report-history.component.html',
  styleUrls: ['./report-history.component.css']
})

export class ReportHistoryComponent implements OnInit {
  userName: any;
  email: string;

  frameworkComponents: any;
  eventRowData = {};
  today: string;
  columnDefs = [
    { headerName: 'ID', field: 'id', width: 90, sortable: true },
    { headerName: 'Report Name', field: 'reportName', width: 300, sortable: true },
    { headerName: 'Report Type', field: 'reportType', width: 150, sortable: true },
    { headerName: 'Created By', field: 'createdBy', width: 200, sortable: true },
    {
      headerName: 'Created Date', field: 'createdDate', width: 120, sortable: true, valueFormatter: function (params: any) {
        let yyyy: any;
        let mm: any;
        let dd: any;
        [yyyy, mm, dd] = params.value.substring(0, 10).split('-');
        return [mm, dd, yyyy].join('/');
      }
    },
    { headerName: 'Modified By', width: 200, field: 'modifiedBy', sortable: true },
    {
      headerName: 'Modified Date', field: 'modifiedDate', width: 120, sortable: true, valueFormatter: function (params) {
        let yyyy;
        let mm;
        let dd;
        [yyyy, mm, dd] = params.value.substring(0, 10).split('-');
        return [mm, dd, yyyy].join('/');
      }
    },
    {
      headerName: 'Action', cellRenderer: 'buttonRenderer', cellRendererParams: {
        onClick: this.onActionClick.bind(this)
      }
    }
  ];

  public defaultColDef: ColDef = {
    resizable: true,
  };

  rowData = [];
  isLoading = false;

  constructor(private http: HttpClient, private activatedRoute: ActivatedRoute, private router: Router,
    private communicationService: ComponentService, private dataService: ReportService, private oktaservice: OktaInfoService,
    private notify: NotificationService, private dialog: MatDialog) {
    this.frameworkComponents = {
      buttonRenderer: ActionRenderComponent
    };
    const today = new Date();
    const date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    const time = today.getHours() + ':' + today.getMinutes() + ':' + today.getSeconds();
    // const time = today.getHours() + ':' + today.getMinutes();
    const dateTime = date + ' ' + time;
    this.today = dateTime;
  }

  async ngOnInit() {
    this.isLoading = true;
    const promise = await this.oktaservice.GetOktUserInfo();
    const userClaims = promise['claims'];
    this.userName = userClaims['name'];
    this.email = userClaims['email'];
    this.dataService.getReports(encodeURIComponent(this.userName)).subscribe(response => {
      if (response.data != null) {
        this.rowData = response.data;
      }
      this.isLoading = false;
    }, error => {
      this.isLoading = false;
      this.notify.showSuccess('', APP_Messages.ServerErrorMessage);
    });
  }

  onActionClick(event: any) {
    if (event.eventType === 'Run') {
      this.onRun(event);
    } else if (event.eventType === 'Delete') {
      this.deleteConfirmation(event);
    }
  }

  async deleteConfirmation(event: any) {
    const dConfig = new MatDialogConfig();
    dConfig.data = {
      'title': DeleteConfirmationMessages.confirmTitle,
      'message': DeleteConfirmationMessages.confirmReportMessage,
      'confirmText': DeleteConfirmationMessages.confirmText,
      'canceltext': DeleteConfirmationMessages.confirmCanceltext,
      success: (e: any) => {
        return false;
      },
      close: (e: any) => {
        this.onDelete(event);
        return false;
      }
    };
    const dialogRef = this.dialog.open(ConfirmDialogComponent, dConfig);
    return await dialogRef.afterClosed().toPromise();
  }

  onRun(params: any) {
    this.isLoading = true;
    this.dataService.createReportFromSearch(params.rowData.id).subscribe(response => {
      importedSaveAs(response, `Report_${this.today}.xlsx`);
      this.isLoading = false;
    }, error => {
      this.isLoading = false;
      this.notify.showSuccess('', APP_Messages.ServerErrorMessage);
    });
  }

  onDelete(event: any) {
    this.isLoading = true;
    this.dataService.deleteReport(event.rowData.id).subscribe(res => {
      // this.dataService.getReports(this.userName).subscribe(response => this.rowData = response.data);
      this.dataService.getReports(encodeURIComponent(this.userName)).subscribe(response => {
        this.rowData = response.data;
        this.isLoading = false;
      }, error => {
        this.isLoading = false;
        this.notify.showSuccess('', APP_Messages.ServerErrorMessage);
      });
      this.isLoading = false;

    }, error => {
      this.isLoading = false;
      this.notify.showSuccess('', APP_Messages.ServerErrorMessage);
    });
  }

  onFirstDataRendered(params: any) {
    params.api.sizeColumnsToFit();
  }

}
