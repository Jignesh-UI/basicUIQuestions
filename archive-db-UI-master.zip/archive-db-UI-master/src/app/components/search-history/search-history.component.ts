import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { ComponentService } from 'src/app/service/component.service';
import { ActionRenderComponent } from '../action-render/action-render.component';
import { SearchHistoryService } from 'src/app/service/search-history.service';
import { OktaInfoService } from 'src/app/shared/okta/okta-info.service';
import { ColDef } from 'ag-grid-community';
import { APP_Messages, DeleteConfirmationMessages } from 'src/app/service/commonClasses/app-defaults';
import { NotificationService } from 'src/app/service/notification.service';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { ConfirmDialogComponent } from 'src/app/shared/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-search-history',
  templateUrl: './search-history.component.html',
  styleUrls: ['./search-history.component.css']
})
export class SearchHistoryComponent implements OnInit {

  isLoading = false;
  searchCriteria: [] = [];
  requsetjson: {} = {
    'pageNumber': 1,
    'totalCount': 0,
    'totalPages': 0,
    'fields': this.searchCriteria
  };
  columnDefs = [
    { headerName: 'ID', field: 'id', width: 90, sortable: true },
    { headerName: 'Search Name', field: 'searchName', width: 300, sortable: true },
    { headerName: 'Search Type', field: 'searchType', width: 150, sortable: true },
    { headerName: 'Created By', width: 200, field: 'createdBy', sortable: true },
    {
      headerName: 'Created Date', field: 'createdDate', width: 120, sortable: true, valueFormatter: function (params) {
        let yyyy;
        let mm;
        let dd;
        [yyyy, mm, dd] = params.value.substring(0, 10).split('-');
        return [mm, dd, yyyy].join('/');
      }
    },
    { headerName: 'Modified By', width: 200, field: 'modifiedBy', sortable: true },
    {
      headerName: 'Modified Date', field: 'modifiedDate', width: 120, sortable: true, valueFormatter: function (params) {
        let yyyy;
        let mm;
        let dd;
        [yyyy, mm, dd] = params.value.substring(0, 10).split('-');
        return [mm, dd, yyyy].join('/');
      }
    },
    {
      headerName: 'Action', width: 150, cellRenderer: 'buttonRenderer', cellRendererParams: {
        onClick: this.onClickAction.bind(this)
      }
    }
  ];

  public defaultColDef: ColDef = {
    resizable: true,
  };

  rowData = [];
  frameworkComponents: any;
  userName = '';
  email = '';

  constructor(private http: HttpClient, private activatedRoute: ActivatedRoute, private router: Router, private communicationService: ComponentService,
    private saveSearch: SearchHistoryService, private commuincationService: ComponentService, private oktaservice: OktaInfoService,
    private notify: NotificationService, private dialog: MatDialog) {
    this.frameworkComponents = {
      buttonRenderer: ActionRenderComponent
    };
  }

  async ngOnInit() {
    this.isLoading = true;
    const promise = await this.oktaservice.GetOktUserInfo();
    const userClaims = promise['claims'];
    this.userName = userClaims['name'];
    this.email = userClaims['email'];
    this.saveSearch.getSearches(encodeURIComponent(this.userName)).subscribe(response => {
      if (response.data != null) {
        this.rowData = response.data;
        this.isLoading = false;
      }
      this.isLoading = false;
    });
  }

  onClickAction(event: any) {
    if (event.eventType === 'Run') {
      this.onRun(event);
    } else if (event.eventType === 'Delete') {
      this.deleteConfirmation(event);
    }
  }

  async deleteConfirmation(event: any) {
    const dConfig = new MatDialogConfig();
    dConfig.data = {
      'title': DeleteConfirmationMessages.confirmTitle,
      'message': DeleteConfirmationMessages.confirmSearchMessage,
      'confirmText': DeleteConfirmationMessages.confirmText,
      'canceltext': DeleteConfirmationMessages.confirmCanceltext,
      success: (e: any) => {
        return false;
      },
      close: (e: any) => {
        this.onDelete(event);
        return false;
      }
    };
    const dialogRef = this.dialog.open(ConfirmDialogComponent, dConfig);
    return await dialogRef.afterClosed().toPromise();
  }

  onRun(event: any) {
    this.router.navigate(['/search/' + event.rowData.id]);
  }

  onDelete(event: any) {
    this.isLoading = true;
    this.saveSearch.deleteSearch(event.rowData['id']).subscribe(response => {
      this.saveSearch.getSearches(encodeURIComponent(this.userName)).subscribe(response => {
        this.rowData = response.data;
        this.isLoading = false;
      }, err => {
        this.isLoading = false;
        this.notify.showSuccess('', APP_Messages.ServerErrorMessage);
      });
    }, err => {
      this.isLoading = false;
      this.notify.showSuccess('', APP_Messages.ServerErrorMessage);
    });
  }

  onFirstDataRendered(params: any) {
    params.api.sizeColumnsToFit();
  }

}
