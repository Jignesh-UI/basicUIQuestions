
export const APP_Messages = {
    SuccessMessage: "Success",
    ServerErrorMessage: "Something went wrong, Please try again!",
    differentCriteria: "Please Select Different Criteria",
    selectPropertyName: "Please Select Property Name!",
    selectContains: "Please Select Contains!",
    selectOperator: "Please Select Operator!",
    enterValue: "Please Enter Value!",
    selectValue: "Please Select Value!",
    selectPage: "Please Select Page!",
    selectColumns: "Please Select Columns!",

    selectSaveSrhPage: "Please Select Page to Save Search!",
    selectSaveSrhPropertyName: "Please Select Property Name to Save Search!",
    selectSaveSrhContains: "Please Select Contains to Save Search!",
    enterSaveSrhValue: "Please Enter Value to Save Search!",
    selectSaveSrhValue: "Please Select Value to Save Search!",
    selectSaveSrhPageValue: "Please Select Page to Save Search!",
    selectSaveSrhOperator: "Please Select Operator to Save Search!",
    selectSaveSrhColumns: "Please Select Columns to Save Search!",

    selectSaveRptPage: "Please Select Page to Save Report!",
    selectSaveRptPropertyName: "Please Select Property Name to Save Report!",
    selectSaveRptContains: "Please Select Contains to Save Report!",
    enterSaveRptValue: "Please Enter Value to Save Report!",
    selectSaveRptValue: "Please Select Value to Save Report!",
    selectSaveRptPageValue: "Please Select Page to Save Report!",
    selectSaveRptOperator: "Please Select Operator to Save Report!",
    selectSaveRptColumns: "Please Select Columns to Save Report!"

}

export const appDataChangeOnNavigationMessages = {
    confirmTitle: 'Please Confirm',
    confirmMessage: 'This option will leave the page without saving your changes.',
    confirmText: 'Continue',
    confirmCanceltext: 'Return to previous PAGE',
}

export const appDataChangeOnListedRecordMessages = {
    confirmTitle: 'Please Confirm',
    confirmMessage: 'This option will leave the record without saving your changes',
    confirmText: 'Continue',
    confirmCanceltext: 'Return to previous record',
}

export const DeleteConfirmationMessages = {
    confirmTitle: 'Please Confirm',
    confirmSearchMessage: 'This option will delete the saved search.',
    confirmReportMessage: 'This option will delete the saved report.',
    confirmText: "Confirm",
    confirmCanceltext: "Cancel",
}

export const deleteAssociatedConfirmationMessages = {
    confirmTitle: 'Please Confirm',
    confirmMessage: 'This option will delete the Associated Record',
    confirmText: 'Continue',
    confirmCanceltext: 'Cancel',
}