export interface pageSizeProperties {
    pageNumber: number;
    activePage: boolean;
}

export interface columnInterface {
    headerName: string;
    field: string;
    width: number;
    order: string;
}