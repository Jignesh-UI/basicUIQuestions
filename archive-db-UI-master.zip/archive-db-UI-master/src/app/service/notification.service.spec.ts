import { TestBed } from '@angular/core/testing';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { NotificationService } from './notification.service';

describe('NotificationService', () => {
  let service: NotificationService;
  let httpTestingController: HttpTestingController;
  let toastrService: jasmine.SpyObj<ToastrService>;

  beforeEach(() => {
    toastrService = jasmine.createSpyObj<ToastrService>('ToasterService',['error', 'success', 'info', 'warning']);
    TestBed.configureTestingModule({
      imports:[HttpClientTestingModule,ToastrModule.forRoot()],
      providers:[ ToastrService, NotificationService, { provide: ToastrService, useValue: toastrService }]
    }).compileComponents();
    service = TestBed.inject(NotificationService);
    httpTestingController = TestBed.inject(HttpTestingController);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should display Success Message when showSuccess method called!',()=>{
    service.showSuccess('hello world', 'hello');
    expect(toastrService.success).toHaveBeenCalledWith('hello world', 'hello');
  });

  it('should display Error Message when showError method called!',()=>{
    service.showError('hello world error', 'hello');
    expect(toastrService.error).toHaveBeenCalledWith('hello world error', 'hello');
  });

  it('should display Info Message when showInfo method called!',()=>{
    service.showInfo('hello world Info', 'hello');
    expect(toastrService.info).toHaveBeenCalledWith('hello world Info', 'hello');
  });

  it('should display Warning Message when showWarning method called!',()=>{
    service.showWarning('hello world Warning', 'hello');
    expect(toastrService.warning).toHaveBeenCalledWith('hello world Warning', 'hello');
  });

  afterEach(() => {
    httpTestingController.verify();
  });

});
