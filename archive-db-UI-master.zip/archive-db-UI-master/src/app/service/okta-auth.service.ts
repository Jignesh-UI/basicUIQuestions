import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import * as OktaAuth from '@okta/okta-auth-js';
import { environment } from 'src/environments/environment';
import { ComponentService } from './component.service';

@Injectable()
export class OktaAuthService implements CanActivate {

  constructor(private comm: ComponentService) { }
// LOCAL Server
  // CLIENT_ID = '0oaxietfj4H9aqvIS4x6';
  // ISSUER = 'https://dev-492979.okta.com/oauth2/default';
  // LOGIN_REDIRECT_URI = 'http://localhost:39090';
  // oktaAuth = new OktaAuth({
  //   clientId: this.CLIENT_ID,
  //   issuer: this.ISSUER,
  //   redirectUri: this.LOGIN_REDIRECT_URI,
  //   pkce: true
  // });

  // LOGOUT_REDIRECT_URI = 'https://archivedbdev.emhe.mhc:39090';

  // ArchiveDB DEV Server configuation - ew1dpbl7136.emhe.mhc

  // CLIENT_ID = '0oaobkb7bjQ8DCgGl0x7';
  // ISSUER = 'https://mhe.okta.com/oauth2/default';
  // LOGIN_REDIRECT_URI = 'https://archivedbdev.emhe.mhc:39090';
  // oktaAuth = new OktaAuth({
  //   clientId: this.CLIENT_ID,
  //   issuer: this.ISSUER,
  //   redirectUri: this.LOGIN_REDIRECT_URI,
  //   pkce: true
  // });

  // LOGOUT_REDIRECT_URI = 'https://archivedbqa.emhe.mhc:39090';

  // ArchiveDB QA Server configuation - ew1dpbl7137.emhe.mhc

  // CLIENT_ID = '0oaobkpb7vQDbcClk0x7';
  // ISSUER = 'https://mhe.okta.com/oauth2/default';
  // LOGIN_REDIRECT_URI = 'https://archivedbqa.emhe.mhc:39090';
  oktaAuth = new OktaAuth({
    clientId: environment.CLIENT_ID,
    issuer: environment.ISSUER,
    redirectUri: environment.LOGIN_REDIRECT_URI,
    pkce: true
  });

  // ArchiveDB PROD Server configuation - ew1dpgl7141.emhe.mhc

  // CLIENT_ID = '0oao6qx17vGEKbKC10x7';
  // ISSUER = 'https://mhe.okta.com/oauth2/default';
  // LOGIN_REDIRECT_URI = 'https://archivedb.emhe.mhc:39090';
  // oktaAuth = new OktaAuth({
  //   clientId: this.CLIENT_ID,
  //   issuer: this.ISSUER,
  //   redirectUri: this.LOGIN_REDIRECT_URI,
  //   pkce: true
  // });

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {

    if (!environment.oktaEnaled) {
      this.comm.changeIsAuthenticate(true);
      return true;
    }

    return this.oktaAuth.tokenManager.get('idToken')
      .then(idToken => {

        const expirationDate = new Date((idToken.expiresAt * 1000));
        // console.log('idToken expiresAt: ', expirationDate);
        this.comm.changeIsAuthenticate(true);
        // this.checkExpired();
        return true;
      })
      .catch(error => {
        console.log('error: ', error);
        return this.writeTokens();
      }
      );
  }
  writeTokens(): boolean {
    return this.oktaAuth.token.parseFromUrl().then(tokens => { // manage token or tokens
      if (tokens.tokens.idToken) {
        // sessionStorage.setItem ('userName', tokens.tokens.idToken.claims.name);
        this.oktaAuth.tokenManager.add('idToken', tokens.tokens.idToken);
        this.comm.changeIsAuthenticate(true);
      }
      if (tokens.tokens.accessToken) {
        this.oktaAuth.tokenManager.add('accessToken', tokens.tokens.accessToken);
        this.comm.changeIsAuthenticate(true);
      }
      this.checkLogin();
      return true;
    }).catch(error => { this.checkLogin(); return false; });


  }
  async checkLogin() {
    const authenticated = await this.oktaAuth.tokenManager.get('accessToken');
    if (authenticated === undefined) {
      // Save current URL before redirect
      //  sessionStorage.setItem('okta-app-url', 'http://localhost:4200');

      // Launches the login redirect.
      this.oktaAuth.token.getWithRedirect({
        scopes: ['openid', 'email', 'profile']
        , responseMode: 'query'
        , responseType: 'token'
      });
    }

    else {
      // sessionStorage.setItem('oktaAccessToken', authenticated.value);
      this.comm.changeIsAuthenticate(true);
      // this.checkExpired();
    }
  }
  // async checkExpired() {
  //   this.oktaAuth.tokenManager.get("accessToken").then( authenticated=>
  //     {
  //       var expirationDate = new Date((authenticated.expiresAt * 1000));
  //       console.log('accessToken expiresAt: ', expirationDate);}
  //   );}


}
