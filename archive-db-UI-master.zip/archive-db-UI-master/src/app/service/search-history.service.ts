import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { OktaInfoService } from '../shared/okta/okta-info.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SearchHistoryService {

  private searchesFetchURL = environment.baseAPIUrl + 'services/savedSearches/';

  constructor(private http: HttpClient, private oktaService: OktaInfoService) {
  }

  getSearches(userName: string) {
    if (this.searchesFetchURL) {
      return this.http.get<{ data: [] }>(this.searchesFetchURL + 'list?createdBy=' + userName);
    } else { return null; }
  }

  deleteSearch(id: any) {
    const deleteUrl = this.searchesFetchURL + id;
    return this.http.delete(deleteUrl, { headers: { 'Content-Type': 'application/json' } });
  }
}
