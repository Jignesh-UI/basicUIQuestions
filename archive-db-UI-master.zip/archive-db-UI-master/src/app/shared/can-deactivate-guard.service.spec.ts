import { TestBed } from '@angular/core/testing';
import { Observable, Subject } from 'rxjs';

import { CanDeactivateGuardService } from './can-deactivate-guard.service';

class MockComponent implements CanDeactivateGuardService {
  returnValue: boolean | Observable<boolean> = false;
  canDeactivate(): boolean | Observable<boolean> {
    console.log(this.returnValue)
    return this.returnValue;
  }
}

describe('CanDeactivateGuardService', () => {
  let service: CanDeactivateGuardService;
  let mockComponent: MockComponent;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CanDeactivateGuardService, MockComponent]
    });
    service = TestBed.inject(CanDeactivateGuardService);
    mockComponent = TestBed.get(MockComponent);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('can route if unguarded', () => {
    mockComponent.returnValue = true;
    expect(service.canDeactivate(mockComponent)).toBeTruthy();
  });

  it('will route if guarded and user accepted the dialog', () => {
    const subject$ = new Subject<boolean>();
    mockComponent.returnValue = subject$.asObservable();
    const canDeactivate$ = <Observable<boolean>>service.canDeactivate(mockComponent);
    canDeactivate$.subscribe((deactivate) => {
      expect(deactivate).toBeTruthy();
    });
    subject$.next(true);
  });

  it('will not route if guarded and user rejected the dialog', () => {
    const subject$ = new Subject<boolean>();
    mockComponent.returnValue = subject$.asObservable();
    const canDeactivate$ = <Observable<boolean>>service.canDeactivate(mockComponent);
    canDeactivate$.subscribe((deactivate) => {
      expect(deactivate).toBeFalsy();
    });
    subject$.next(false);
  });


});
