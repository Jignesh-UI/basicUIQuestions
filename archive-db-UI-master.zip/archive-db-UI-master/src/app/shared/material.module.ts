import { NgModule } from '@angular/core';
import { MatDialogModule, MAT_DIALOG_DEFAULT_OPTIONS } from '@angular/material/dialog';


@NgModule({
  declarations: [],
  imports: [
  ],
  exports: [
    MatDialogModule
  ],
  providers: [{
    provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: {hasBackdrop: false}
  }]
})
export class MaterialModule { }
