import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable, from } from 'rxjs';
import { OktaAuthService } from 'src/app/service/okta-auth.service';


@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  constructor(private oktaAuth: OktaAuthService) {
  }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return from(this.handleAccess(request, next));
  }

  private async handleAccess(request: HttpRequest<any>, next: HttpHandler): Promise<HttpEvent<any>> {
    // Only add to known domains since we don't want to send your tokens to just anyone
  const okta =  this.oktaAuth.oktaAuth.tokenManager.get('accessToken');
  const  accessToken = await okta;
  request = request.clone({
        setHeaders: {
          Authorization: 'Bearer ' + accessToken.value
        }
      });
  return next.handle(request).toPromise();
  }
}
