import { TestBed } from '@angular/core/testing';
import { OktaAuthService } from 'src/app/service/okta-auth.service';

import { OktaInfoService } from './okta-info.service';

describe('OktaInfoService', () => {
  let service: OktaInfoService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers:[OktaAuthService]
    });
    service = TestBed.inject(OktaInfoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
