import { Injectable } from '@angular/core';
import { OktaAuthService } from 'src/app/service/okta-auth.service';

@Injectable({
  providedIn: 'root'
})
export class OktaInfoService {

  constructor(private oktaAuth:OktaAuthService) { }
  async GetOktUserInfo(){
    const okta =  this.oktaAuth.oktaAuth.tokenManager.get('idToken');
    const  accessToken = await okta;
    return accessToken;
  }
}
