export const environment = {
    production: true,
    CLIENT_ID: '0oayqu6fnzu0TSMCR0x7',
    ISSUER: 'https://mhe.okta.com/oauth2/default',
    LOGIN_REDIRECT_URI: 'https://archivedb-ui-dev.aef.mh-int.dev/',
    oktaEnaled: true,
    baseAPIUrl: 'https://archivedb-api-dev.aef.mh-int.dev/archivedb/'
  };
