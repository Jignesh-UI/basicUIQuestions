export const environment = {
  production: true,
  CLIENT_ID: '0oazgt7uk9hSdiizc0x7',
  ISSUER: 'https://mhe.okta.com/oauth2/default',
  LOGIN_REDIRECT_URI: 'https://archivedb-ui-prod.aet.mh.com/',
  oktaEnaled: true,
  baseAPIUrl: 'https://archivedb-api-prod.aet.mh.com/archivedb/'
};
