import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookingsComponent } from './components/bookings/bookings.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AuthenticateComponent } from './components/authenticate/authenticate.component';
import { AuthGuardService } from './shared/services/auth-guard.service';
import { AddProductComponent } from './components/add-product/add-product.component';
import { ProductsListComponent } from './components/products-list/products-list.component';
import { SnsnotificationComponent } from './components/snsnotification/snsnotification.component';
import { ChatbotComponent } from './components/chatbot/chatbot.component';

const routes: Routes = [
  {path:'', component:DashboardComponent, pathMatch:'full'},
  {path:'home', component:DashboardComponent},
  {path:'dashboard', component:DashboardComponent},
  {path:'bookings', component:BookingsComponent, canActivate:[AuthGuardService]},
  {path:'addProduct', component:AddProductComponent, canActivate:[AuthGuardService]},
  {path:'listProduct', component:ProductsListComponent, canActivate:[AuthGuardService]},
  {path:'sns',component:SnsnotificationComponent},
  {path:'chatbot',component:ChatbotComponent},
  {path:'login', component:AuthenticateComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash:true})],
  exports: [RouterModule],
  providers:[AuthGuardService]
})
export class AppRoutingModule { }
