import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './shared/components/header/header.component';
import { FooterComponent } from './shared/components/footer/footer.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { BookingsComponent } from './components/bookings/bookings.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { LoadingComponent } from './shared/components/loading/loading.component';
import { AuthenticateComponent } from './components/authenticate/authenticate.component';
import { ProductsListComponent } from './components/products-list/products-list.component';
import { AddProductComponent } from './components/add-product/add-product.component';
import { SnsnotificationComponent } from './components/snsnotification/snsnotification.component';
import { ChatbotComponent } from './components/chatbot/chatbot.component';
import { AngularBotModuleModule } from './angular-bot-module/angular-bot-module.module';
import { ChatComponentComponent } from './angular-bot-module/chat-component/chat-component.component';
import { ChatService } from './shared/services/chat.service';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    DashboardComponent,
    BookingsComponent,
    LoadingComponent,
    AuthenticateComponent,
    ProductsListComponent,
    AddProductComponent,
    SnsnotificationComponent,
    ChatbotComponent,
    ChatComponentComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    AngularBotModuleModule,
    CommonModule,
    HttpClientModule,FormsModule,ReactiveFormsModule,
  ],
  providers: [ChatService],
  bootstrap: [AppComponent]
})
export class AppModule { }
