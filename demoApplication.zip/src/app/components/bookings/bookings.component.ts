import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/shared/services/data.service';

@Component({
  selector: 'app-bookings',
  templateUrl: './bookings.component.html',
  styleUrls: ['./bookings.component.scss']
})
export class BookingsComponent implements OnInit {
  data: any;

  constructor(private dataService: DataService){

  }
  ngOnInit(): void {
    this.dataService.getData().subscribe(data => {
      // console.log(data);
      this.data = data;
    });
  }

}
