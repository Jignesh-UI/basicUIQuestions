import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent implements OnInit {
  userMessage: any;
  // url:string = "https://mcdermott.cyberark.cloud/privilegecloud/API/auth/Cyberark/Logon/";
  // url:string = "https://api.restful-api.dev/objects";
  // url:string = "https://mcdermott.privilegecloud.cyberark.cloud/PasswordVault/API/Auth/Cyberark/Logon";
  // url:string = "https://abl4705.id.cyberark.cloud/oauth2/platformtoken";
  // url:string = "https://aaz4599.id.cyberark.cloud/oauth2/platformtoken";
    url:string ="https://mcdermott.privilegecloud.cyberark.cloud/PasswordVault/API/Safes/?limit=5";

  responseRecord:any;

  constructor(private http: HttpClient) {}

  ngOnInit() {}

  callApi() {
    console.log(1);
    this.userMessage = "";

    const accessToken = {
      "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjcyRUM1ODgwNTg0RTYxQzlCMjg4QzJCQzFCQUEwOEY4OUMwRkEzNTUiLCJ4NXQiOiJjdXhZZ0ZoT1ljbXlpTUs4RzZvSS1Kd1BvMVUiLCJhcHBfaWQiOiJfX2lkYXB0aXZlX2N5YnJfdXNlcl9vaWRjIn0.eyJwcmVmZXJyZWRfdXNlcm5hbWUiOiJjeWJhcmthcGlAY3liZXJhcmsuY2xvdWQuMTIzNzgiLCJmYW1pbHlfbmFtZSI6IkNZQkFSS0FQSSIsInRlbmFudF9zdWJkb21haW4iOiJodHRwczovL21jZGVybW90dC5jeWJlcmFyay5jbG91ZCIsInVuaXF1ZV9uYW1lIjoiY3liYXJrYXBpQGN5YmVyYXJrLmNsb3VkLjEyMzc4IiwiaWRhcHRpdmVfdGVuYW50X2lkIjoiQUFaNDU5OSIsInRlbmFudF9pZCI6IjIxZjU4ZDBjLTM3N2UtNDFlOC04MTNlLTA2MmE4Mzc2ZGJmNiIsInVzZXJfcm9sZXMiOlsiTWNEZXJtb3R0IFJFU1RBUEkgQXV0b21hdGlvbiIsIlByaXZpbGVnZSBDbG91ZCBBdWRpdG9ycyIsIk1lZGl1bSBSaXNrIFVzZXJzIl0sImlhdCI6MTczMjYxNjI3MSwic3ViIjoiOGY0NjVjNzQtYTM1Zi00ODYxLWIwNGItNTA4YTc5ZGNjY2UwIiwiYXV0aF90aW1lIjoxNzMyNjE1MDY4LCJwcmVmZXJyZWRfdGltZSI6IiIsImV4cCI6MTczMjYxNzE3MSwidXNlcl91dWlkIjoiOGY0NjVjNzQtYTM1Zi00ODYxLWIwNGItNTA4YTc5ZGNjY2UwIiwic2NvcGUiOiJvcGVuaWQgYXBpIHByb2ZpbGUiLCJsYXN0X2xvZ2luIjoiMTczMjYxMzI5NyIsImF1ZCI6Il9faWRhcHRpdmVfY3licl91c2VyX29pZGMiLCJwcmVmZXJyZWRfbGFuZ3VhZ2UiOiIiLCJhd3NfcmVnaW9uIjoidXMtZWFzdC0xIiwic3ViZG9tYWluIjoibWNkZXJtb3R0IiwiY3NyZl90b2tlbiI6ImJRS1pvX0NLY1VXTXRJejdiZ3pmX044dHVNSVVWdXRGbnhWVHQ5enRGYm8xIiwiaW50ZXJuYWxfc2Vzc2lvbl9pZCI6IjdHR3JLang4MzB1RnFmOTVPUVJrVXB0b1ZLSG9BZDk4T2hUSmRfeFBJS0UxIiwicGxhdGZvcm1fZG9tYWluIjoiY3liZXJhcmsuY2xvdWQiLCJpc3MiOiJodHRwczovL2FhejQ1OTkuaWQuY3liZXJhcmsuY2xvdWQvX19pZGFwdGl2ZV9jeWJyX3VzZXJfb2lkYy8iLCJhdF9oYXNoIjoiOFU3OHZHZ0ZGdmZKaExEZ09zZ1JsUSIsIm5hbWUiOiJDWUJBUktBUEkiLCJnaXZlbl9uYW1lIjoiQ1lCQVJLQVBJIiwiRXh0ZXJuYWxVdWlkIjoiOGY0NjVjNzQtYTM1Zi00ODYxLWIwNGItNTA4YTc5ZGNjY2UwIn0.oA76_4VYr2fNLx4ERbHLv3pN9TE5DwG9Aik_gCfXjW_X6lzB6idAZMK7HvRDO9e5GFM8o5ddnQbPcPGlRb9SJOXC4987f7XJs7zdnHoMe8-jdqVZvcTs4_tZ0K33JgIHliJY54Fxt6_mCHH7OVnfDOCTXIVd_I3OkLWZ9pKdPPQaiO6i99dVUDoCfS1FkBftI_SIcVyGm5Y9cMxcvERepyLZIWaILWpGjs2LQVUb3wiSxjmfAuuYChOWSohOn9m2DG_xyj1zZkpbGox0suwq0PUmJemUl_wIpFvrW783EuNbBUPWj41yN_558ek_KKqMb5wgMXedc5VFO3ORVkBdCg",
      "token_type": "Bearer",
      "expires_in": 900
  }

    const header = new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded',
      // 'Content-Type': 'application/json',
      'Accept': 'application/json',
      Authorization: 'Bearer ' + accessToken.access_token
      // 'Authorization': `${requestToken}`
    });


    const user = {
      "username": "cybarkapi@cyberark.cloud.12378",
      "password": "Mcdapi3102",
      "grant_type":"client_credentials"
    };

    this.http.post(this.url,user,{headers: header}).subscribe((response:any)=>{
      console.log(response);
      this.responseRecord = response;
    },err=>{
      this.responseRecord = JSON.stringify(err);
    })

  }
}
