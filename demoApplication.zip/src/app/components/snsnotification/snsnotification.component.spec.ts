import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SnsnotificationComponent } from './snsnotification.component';

describe('SnsnotificationComponent', () => {
  let component: SnsnotificationComponent;
  let fixture: ComponentFixture<SnsnotificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SnsnotificationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SnsnotificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
