import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CognitoService } from 'src/app/shared/services/cognito.service';
import { NotifyService } from 'src/app/shared/services/notify.service';

@Component({
  selector: 'app-snsnotification',
  templateUrl: './snsnotification.component.html',
  styleUrls: ['./snsnotification.component.scss']
})
export class SnsnotificationComponent implements OnInit {
  showLoading:boolean = false;
  @ViewChild('txtsubtitle') txtsubtitle!: ElementRef<HTMLInputElement>;
  notificationForm: FormGroup;

  constructor( private cognitoService: CognitoService, private http: HttpClient, private formBuilder: FormBuilder, private notifyService: NotifyService){
    this.notificationForm = this.formBuilder.group({
      txtsubtitle: ['', Validators.required],
      txtmessage: ['', Validators.required]
    })
  }

  ngOnInit(): void {
    // this.txtsubtitle.nativeElement.focus();
  }

  sendMessage(){
    const apiURL = "https://3eg5qzfgfi.execute-api.us-east-1.amazonaws.com/dev/notifyAPI";
    // console.log('send message');
    // console.log(this.notificationForm.controls['txtsubtitle'].value);
    // console.log(this.notificationForm.controls['txtmessage'].value);
    if (!this.notificationForm.valid) {
      this.notificationForm.markAllAsTouched();
      return;
    }

    const params ={
      "subjectLine": this.notificationForm.controls['txtsubtitle'].value,
      "message": this.notificationForm.controls['txtmessage'].value
    }

    this.showLoading = true;
    this.cognitoService.getAuthenticatedUser()?.getSession(async (err: any,session: any) => {
      if(err){
        console.log(err);
        this.showLoading = false;
        return;
      }

      const requestToken = await session.getIdToken().getJwtToken()
      // const header = new HttpHeaders({
      //   'Content-Type': 'application/json',
      //   'Authorization': `${requestToken}`
      // });
      console.log(requestToken);

      (await this.notifyService.snsNotification(params, requestToken)).subscribe({
        next: (response:any)=>{
          console.log(response);
          // console.log(response.body.message);
          // this.message = response.body.message;
          // this.notificationForm.controls['txtsubtitle'].value = '';
          // this.notificationForm.controls['txtmessage'].value = '';
          this.notificationForm.reset();
          this.txtsubtitle.nativeElement.focus();
          this.showLoading = false;
        },
        error: (err:any)=>{
          console.log(err);
          this.showLoading = false;
        }
      });

      // this.http.post(apiURL, params, {headers: header}).subscribe({
      //   next: (response:any)=>{
      //     console.log(response);
      //     // console.log(response.body.message);
      //     // this.message = response.body.message;
      //     this.txtsubtitle.nativeElement.focus();
      //     this.showLoading = false;
      //   },
      //   error: (err:any)=>{
      //     console.log(err);
      //     this.showLoading = false;
      //   }
      // })


    });


  }

}
