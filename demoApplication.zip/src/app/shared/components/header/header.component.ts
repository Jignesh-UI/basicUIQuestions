import { Component, OnDestroy, OnInit } from '@angular/core';
import { NotifyService } from '../../services/notify.service';
import { CognitoService } from '../../services/cognito.service';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit, OnDestroy {
  showNotification:boolean = false;
  nlength:number = 0;
  currentUser:any;
  private subscription: Subscription | undefined;

  async ngOnInit() {
    this.cognitoService.setUser();
    this.subscription = this.cognitoService.currentUserValue.subscribe(async name => {
      console.log((name === 'undefined') ? '' : name);
      this.currentUser = (name == 'undefined') ? '' : name;
      // this.currentUser = this.cognitoService.headerusername;
    });
  }

  ngOnDestroy(): void {
    this.subscription?.unsubscribe(); // Prevent memory leaks
  }

  constructor(public ns: NotifyService,private cognitoService: CognitoService, private router:Router){
    this.nlength = ns.notifyLength;
    // this.currentUser = cognitoService.getAuthenticatedUser();

  }

  expandCollapseNotification(){
    this.showNotification = !this.showNotification;
  }

  logout(){
    this.cognitoService.logout();
    this.cognitoService.setUser();
    this.router.navigate(['/login']);
  }

  getUserName(){
    console.log(this.cognitoService.getAuthenticatedUser()?.getUsername());
  }

}
