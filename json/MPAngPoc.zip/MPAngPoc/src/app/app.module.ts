import { RoleGaurd } from './rootgaurds/role-gaurd.service';
import { EmpService } from './services/employee/emp.service';
import { LoginService } from './services/login/login.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule, Http, BaseRequestOptions } from '@angular/http';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';

import { HomeComponent } from './components/home/home.component';
import { EmployeeComponent } from './components/employee/employee.component';
import { AuthGuard } from './rootgaurds/auth-guard.service';
import { AuthHttp, AUTH_PROVIDERS, provideAuth, AuthConfig } from 'angular2-jwt';
import { AccessDeniedComponent } from './components/access-denied/access-denied.component';
import { HeaderComponent } from './components/header/header.component';

export function getAuthHttp(http) {
  return new AuthHttp(new AuthConfig({
    tokenName: 'token'
  }), http);
}
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    EmployeeComponent,
    AccessDeniedComponent,
    HeaderComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot([
      { path: '', component: HomeComponent },
      { path: 'employees', component: EmployeeComponent, canActivate: [ AuthGuard, RoleGaurd ] },
      { path: 'login', component: LoginComponent },
      { path: 'access-denied', component: AccessDeniedComponent }

    ])
  ],
  providers: [ LoginService, AuthGuard, RoleGaurd, EmpService,  AuthHttp,
    {
      provide: AuthHttp,
      useFactory: getAuthHttp,
      deps: [Http]
    } ],
  bootstrap: [AppComponent]
})
export class AppModule { }
