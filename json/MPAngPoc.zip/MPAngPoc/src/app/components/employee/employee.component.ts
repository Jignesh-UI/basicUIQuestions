import { EmpService } from '../../services/employee/emp.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
 employees: any[];
  constructor(private empService: EmpService) { }

  ngOnInit() {

    this.empService.getEmployeeList()
    .subscribe(employees => this.employees = employees);
  }

}
