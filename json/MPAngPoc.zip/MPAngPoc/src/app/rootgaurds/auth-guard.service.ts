import { LoginService } from '../services/login/login.service';
import { CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';

@Injectable()
export class AuthGuard implements CanActivate {

  constructor(protected router: Router , protected loginService: LoginService) { }

  canActivate(route, state: RouterStateSnapshot)  {
    if ( this.loginService.isLoggedIn() ) {
      return true;
    }
    this.router.navigate(['/login'], { queryParams: { returnUrl: state.url }});
    return false;
  }

}
