import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { tokenNotExpired, JwtHelper } from 'angular2-jwt';
import 'rxjs/add/operator/map';

@Injectable()
export class LoginService {
 currentUser: any;
  constructor(private http: Http) {
    const token = localStorage.getItem('token');
    if (token) {
      const jwt = new JwtHelper();
      this.currentUser = jwt.decodeToken(token);
    }
  }
  login(loginobject) {
    const url = 'http://localhost:49953/api/login/login';
    const headers = new Headers({
      'Content-Type': 'application/json; charset=utf-8'
    });
    return this.http.post(url, JSON.stringify(loginobject),  {headers: headers})
    .map(response => {
      const result = JSON.parse(response.json());
      if (result && result.token) {
        localStorage.setItem('token', result.token);
         return true;
      } else {
        return false;
      }
    });
  }
  logout() {
    localStorage.removeItem('token');
    this.currentUser = null;
  }
  isLoggedIn() {

    return tokenNotExpired('token');
  }
  get loggedInUser()
  {
    const token = localStorage.getItem('token');
    if (!token) {
      return null;
    }
    return new JwtHelper().decodeToken(token);

  }

}
