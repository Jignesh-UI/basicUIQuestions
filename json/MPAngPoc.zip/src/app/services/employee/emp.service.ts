import { Headers, Http, RequestOptions } from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { AuthHttp } from 'angular2-jwt';

@Injectable()
export class EmpService {

  constructor(private http: AuthHttp) { }

  getEmployeeList() {
    /*
    const headers = new Headers();
    const token = localStorage.getItem('token');
    headers.append('Authorization', 'Bearer ' + token );
    const options = new RequestOptions({ headers: headers });
    return this.http.get('http://localhost:39048/api/employee/getallemployees', options)
      .map(response => response.json());
      */

      return this.http.get('http://localhost:49953/api/employee/getallemployees')
      .map(response => response.json());
  }

}
