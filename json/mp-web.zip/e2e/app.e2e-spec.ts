import { MpWebPage } from './app.po';

describe('mp-web App', () => {
  let page: MpWebPage;

  beforeEach(() => {
    page = new MpWebPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
