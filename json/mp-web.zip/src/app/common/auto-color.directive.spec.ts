import { AutoColorDirective } from './auto-color.directive';

describe('AutoColorDirective', () => {
  it('should create an instance', () => {
    const directive = new AutoColorDirective();
    expect(directive).toBeTruthy();
  });
});
