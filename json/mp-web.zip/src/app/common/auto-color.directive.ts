import { Directive, HostBinding, HostListener } from '@angular/core';

@Directive({
  selector: '[appAutoColor]'
})
export class AutoColorDirective {
  bdrColor = '#b6b9be';
  @HostBinding('style.border-color') color = this.bdrColor;

  @HostListener('focus') onFocus() {
    this.color = 'red';
  }
  @HostListener('blur') onBlur() {
    this.color = this.bdrColor;
  }
}
