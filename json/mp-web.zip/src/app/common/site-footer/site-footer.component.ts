import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'app-site-footer',
  templateUrl: './site-footer.component.html',
  styleUrls: ['./site-footer.component.css']
})
export class SiteFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
