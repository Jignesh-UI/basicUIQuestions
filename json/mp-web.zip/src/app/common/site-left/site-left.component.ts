import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  templateUrl: './site-left.component.html',
  styleUrls: ['./site-left.component.css']
})
export class SiteLeftComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  // scope.toggleOpen = function () {
  //   if (!scope.isDisabled) {
  //     scope.isOpen = !scope.isOpen;
  //   }
  // };

}
