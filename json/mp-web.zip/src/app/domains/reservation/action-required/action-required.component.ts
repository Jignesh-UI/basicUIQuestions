import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-action-required',
  templateUrl: './action-required.component.html',
  styleUrls: ['./action-required.component.css']
})
export class ActionRequiredComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
