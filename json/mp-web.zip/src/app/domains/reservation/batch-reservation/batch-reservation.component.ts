import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-batch-reservation',
  templateUrl: './batch-reservation.component.html',
  styleUrls: ['./batch-reservation.component.css']
})
export class BatchReservationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
