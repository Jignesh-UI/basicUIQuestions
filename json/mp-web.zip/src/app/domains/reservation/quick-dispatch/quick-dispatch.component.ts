import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quick-dispatch',
  templateUrl: './quick-dispatch.component.html',
  styleUrls: ['./quick-dispatch.component.css']
})
export class QuickDispatchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
