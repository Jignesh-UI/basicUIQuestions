import { AssetsFilterPipe } from './assets-filter.pipe';

describe('AssetsFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new AssetsFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
