export interface AssetsInterface {
  assetStatusID: number;
  assetsStatus: string;
  assetStatusDescription: string;
  isObsolete: boolean;
  isAvailableForReservation: boolean;
}
