import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'app-manage-asset-availability',
  templateUrl: './manage-asset-availability.component.html',
  styleUrls: ['./manage-asset-availability.component.css']
})
export class ManageAssetAvailabilityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
