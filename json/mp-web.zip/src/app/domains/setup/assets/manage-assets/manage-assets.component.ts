import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'app-manage-assets',
  templateUrl: './manage-assets.component.html',
  styleUrls: ['./manage-assets.component.css']
})
export class ManageAssetsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
