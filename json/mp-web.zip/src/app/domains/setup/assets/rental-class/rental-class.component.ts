import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  templateUrl: './rental-class.component.html',
  styleUrls: ['./rental-class.component.css']
})
export class RentalClassComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
