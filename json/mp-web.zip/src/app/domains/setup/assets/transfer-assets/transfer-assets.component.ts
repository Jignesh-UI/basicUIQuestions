import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'app-transfer-assets',
  templateUrl: './transfer-assets.component.html',
  styleUrls: ['./transfer-assets.component.css']
})
export class TransferAssetsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
