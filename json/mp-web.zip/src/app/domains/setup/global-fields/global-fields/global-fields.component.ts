import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'app-global-fields',
  templateUrl: './global-fields.component.html',
  styleUrls: ['./global-fields.component.css']
})
export class GlobalFieldsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
