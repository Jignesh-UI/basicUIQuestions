import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'app-license',
  templateUrl: './license.component.html',
  styleUrls: ['./license.component.css']
})
export class LicenseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
