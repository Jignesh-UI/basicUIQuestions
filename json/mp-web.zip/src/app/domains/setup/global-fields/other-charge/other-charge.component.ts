import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'app-other-charge',
  templateUrl: './other-charge.component.html',
  styleUrls: ['./other-charge.component.css']
})
export class OtherChargeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
