import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'app-reason',
  templateUrl: './reason.component.html',
  styleUrls: ['./reason.component.css']
})
export class ReasonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
