import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'app-tax-charge',
  templateUrl: './tax-charge.component.html',
  styleUrls: ['./tax-charge.component.css']
})
export class TaxChargeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
