import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'app-global-settings',
  templateUrl: './global-settings.component.html',
  styleUrls: ['./global-settings.component.css']
})
export class GlobalSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
