import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'app-aapa',
  templateUrl: './aapa.component.html',
  styleUrls: ['./aapa.component.css']
})
export class AapaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
