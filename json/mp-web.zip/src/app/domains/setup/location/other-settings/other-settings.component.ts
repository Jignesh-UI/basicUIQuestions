import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'app-other-settings',
  templateUrl: './other-settings.component.html',
  styleUrls: ['./other-settings.component.css']
})
export class OtherSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
