import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'app-rental-hours',
  templateUrl: './rental-hours.component.html',
  styleUrls: ['./rental-hours.component.css']
})
export class RentalHoursComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
