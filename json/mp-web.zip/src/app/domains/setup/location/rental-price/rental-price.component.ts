import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'app-rental-price',
  templateUrl: './rental-price.component.html',
  styleUrls: ['./rental-price.component.css']
})
export class RentalPriceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
