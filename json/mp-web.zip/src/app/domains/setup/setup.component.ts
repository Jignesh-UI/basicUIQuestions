import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'app-setup',
  templateUrl: './setup.component.html',
  styleUrls: ['./setup.component.css']
})
export class SetupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
