import { DataService } from './data.services';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';



@Injectable()
export class PostService  extends DataService {

  constructor(http: Http) {
    super('https://jsonplaceholder.typicode.com/posts', http);
   }


}
// tslint:disable-next-line:max-line-length
/* About error handling: We should not get the Response object to component as it is voilating the seperation of concersns, handling Response  object returned from the server is not the responsibility of the server. So it should have somthing of type application level error
*/
