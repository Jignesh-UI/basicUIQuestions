"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var forms_1 = require("@angular/forms");
var http_1 = require("@angular/http");
var ngx_bootstrap_1 = require("ngx-bootstrap");
var app_routes_1 = require("./app.routes");
var app_component_1 = require("./app.component");
var home_component_1 = require("./home/home.component");
var header_component_1 = require("./common/header.component");
var leftNav_component_1 = require("./common/leftNav.component");
var footer_component_1 = require("./common/footer.component");
var asset_component_1 = require("./assets/asset.component");
var adv_search_component_1 = require("./assets/search/adv.search.component");
var inventory_component_1 = require("./inventory/inventory.component");
var maintenance_component_1 = require("./maintenance/maintenance.component");
var fuel_component_1 = require("./fuel/fuel.component");
var accounting_component_1 = require("./accounting/accounting.component");
var vendor_component_1 = require("./vendor/vendor.component");
var setup_component_1 = require("./setup/setup.component");
var reports_component_1 = require("./reports/reports.component");
var ngx_pagination_1 = require("ngx-pagination");
var assets_adv_service_1 = require("./services/assets/assets.adv.service");
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule, forms_1.FormsModule, app_routes_1.routes, http_1.HttpModule, ngx_pagination_1.NgxPaginationModule, ngx_bootstrap_1.AccordionModule.forRoot()],
        declarations: [app_component_1.appComponent, header_component_1.headerComponent, leftNav_component_1.assetLeftnavComponent, footer_component_1.footerComponent, home_component_1.homeComponent, asset_component_1.assetComponent, adv_search_component_1.assetsAdvSearchComponent, inventory_component_1.inventoryComponent, maintenance_component_1.maintComponent, fuel_component_1.fuelComponent, accounting_component_1.accountComponent, vendor_component_1.vendorComponent, setup_component_1.setupComponent, reports_component_1.reportComponent],
        providers: [assets_adv_service_1.AdvanceSearchAssetsService],
        bootstrap: [app_component_1.appComponent, header_component_1.headerComponent, leftNav_component_1.assetLeftnavComponent, footer_component_1.footerComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map