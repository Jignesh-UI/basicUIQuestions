import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AccordionModule } from 'ngx-bootstrap'

import { routes } from './app.routes';

import { RouterModule, Routes } from '@angular/router';
import { appComponent } from './app.component';
import { homeComponent } from './home/home.component';
import { headerComponent } from './common/header.component';
import { assetLeftnavComponent } from './common/leftNav.component';
import { footerComponent } from './common/footer.component';


import { assetComponent } from './assets/asset.component';
import { assetsAdvSearchComponent } from './assets/search/adv.search.component';
import { inventoryComponent } from './inventory/inventory.component';
import { maintComponent } from './maintenance/maintenance.component';
import { fuelComponent } from './fuel/fuel.component';
import { accountComponent } from './accounting/accounting.component'
import { vendorComponent } from './vendor/vendor.component';
import { setupComponent } from './setup/setup.component';
import { reportComponent } from './reports/reports.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { AdvanceSearchAssetsService } from './services/assets/assets.adv.service';


@NgModule({
    imports: [BrowserModule, FormsModule, routes, HttpModule, NgxPaginationModule,AccordionModule.forRoot()],
    declarations: [appComponent, headerComponent, assetLeftnavComponent, footerComponent, homeComponent, assetComponent, assetsAdvSearchComponent, inventoryComponent, maintComponent, fuelComponent, accountComponent, vendorComponent, setupComponent, reportComponent],
    providers: [AdvanceSearchAssetsService],
    bootstrap: [appComponent, headerComponent, assetLeftnavComponent, footerComponent]
})

export class AppModule { }