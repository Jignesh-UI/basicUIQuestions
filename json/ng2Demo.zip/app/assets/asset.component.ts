import { Component } from '@angular/core';
import {ActivatedRoute} from '@angular/router';


@Component({
    moduleId: module.id,
    selector: 'assets',
    templateUrl: './default.html'
    //template:"<h1> Assets Component </h1>"
    
})
export class assetComponent  {
    componentName:'assetComponent';
    isAssetPanelOpen = true;
    constructor() { }
}  