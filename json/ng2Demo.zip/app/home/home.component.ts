import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
    moduleId: module.id,
    selector: 'homeCompo',
    templateUrl: '../../templates/home/home.html',
    //template: "<h1> Home Component </h1>"
})
export class homeComponent {
    componentName: homeComponent
    constructor() {

    }
}