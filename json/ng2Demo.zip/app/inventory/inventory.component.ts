import { Component, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute } from '@angular/router';


@Component({
    moduleId: module.id,
    selector: 'inventoryComponent',
    templateUrl: 'default.html',
    //template: '<h1>Inventory Component</h1>'
})
export class inventoryComponent {
    componentName: inventoryComponent;
    

    //isInventoryPanelOpen = true;
    constructor() {
        
    }
}