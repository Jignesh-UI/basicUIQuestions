"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
var Observable_1 = require("rxjs/Observable");
/**
* This class provides the AdvanceSearchAssets service with methods to read names and add names.
*/
var AdvanceSearchAssetsService = (function () {
    /**
    * Creates a new AdvanceSearchAssetsService with the injected Http.
    * @param {Http} http - The injected Http.
    * @constructor
    */
    function AdvanceSearchAssetsService(http) {
        this.http = http;
    }
    /**
    * Returns an Observable for the HTTP GET request for the JSON resource.
    * @return {string[]} The Observable for the HTTP request.
    */
    AdvanceSearchAssetsService.prototype.get = function () {
        return this.http.get('jsonDB/assets/assetAdvSearch.json')
            .map(function (res) { return res.json(); })
            .catch(this.handleError);
    };
    /**
    * Handle HTTP error
    */
    AdvanceSearchAssetsService.prototype.handleError = function (error) {
        var errMsg = (error.message) ? error.message :
            error.status ? "error.status - error.statusText" : 'Server error';
        console.error(errMsg); // log to console instead
        return Observable_1.Observable.throw(errMsg);
    };
    return AdvanceSearchAssetsService;
}());
AdvanceSearchAssetsService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [http_1.Http])
], AdvanceSearchAssetsService);
exports.AdvanceSearchAssetsService = AdvanceSearchAssetsService;
//# sourceMappingURL=assets.adv.service.js.map