$(document).ready(function () {
    var windowHeight = $(window).outerHeight();
    var contentC = $("headertemplate #header").outerHeight();
    var contentW = $(".contentWrapper").outerHeight();
    var ans = windowHeight - (contentC);
    $(".contentContainer").find(".mainContent").css("height", ans);
});
