import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Subscription } from 'rxjs';
import { Broadcast } from './shared/services/broadcast.service';
import { APP_EVENTS } from './app-defaults';
import { unsubscribe } from './shared/services/common.service';
import { NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs/operators';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'mediaportal';
  spinnerOn: boolean = false;
  usb: Subscription[] = [];
  spinnerPos: any = {};

  constructor(private sp: Broadcast) { }

  ngOnDestroy(): void {
  }

  ngOnInit() {
  }
}
