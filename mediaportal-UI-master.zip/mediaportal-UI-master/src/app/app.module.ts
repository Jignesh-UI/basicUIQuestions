import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginModule } from './modules/login/login.module';
import { HomeModule } from './modules/home/home.module';
import { MaterialModule } from './modules/material/material.module';
import { SharedModule } from './shared/shared.module';
import { AssetModule } from './modules/asset/asset.module';
import { AppRoutingModule } from './app-routing.module';
import { AuthGuard } from './shared/services/auth/guard.auth';
import { NgxSpinnerModule } from 'ngx-spinner';
import { LightboxModule } from './modules/lightbox/lightbox.module';
import { NativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { LayoutModule } from './modules/layout/layout.module';

@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgxSpinnerModule,
    BrowserAnimationsModule,
    LoginModule,
    HomeModule,
    AssetModule,
    MaterialModule,
    SharedModule,
    LightboxModule,
    MatDatepickerModule,
    NativeDateModule,
    LayoutModule
  ],
  providers: [AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
