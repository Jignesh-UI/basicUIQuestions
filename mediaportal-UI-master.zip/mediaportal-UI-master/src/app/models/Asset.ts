export class Asset {
  public assetId: string;
  public assetView: boolean;
  public commentsPermission: boolean;
  public contentType: string;
  public deleteAssetPermission: boolean;
  public editContentPermission: boolean;
  public editMembershipPermission: boolean;
  public editMetadataPermission: boolean;
  public editParentsPermission: boolean;
  public exportPermissions: boolean;
  public fields: {}[];
  public fileName: string;
  public mediumResolutionUrl: string;
  public originalAssetUrl: string;
  public previewViewPermission: boolean;
  public projectViewPermission: boolean;
  public subscribePermission: boolean;
  public summaryViewPermission: boolean;
  public thumbnailUrl: string;
  public title: string;
}
