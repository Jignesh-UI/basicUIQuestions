const FEEDBACK_SUPPORT_TYPES = {
  DUPLICATE: "Duplicate Asset",
  ROTATED: "Rotated / Flopped Asset",
  INCORRECT: "Incorrect / Question about Metadata / Missing Metadata",
  TECHNICAL: "Technical Issue / Corrupt File",
  TYPO: "Spelling Error / Typos",
  LICENSING: "Licensing Upgrade",
  QUESTION: "Question about Rights",
  OTHER: "Other"
};

export default FEEDBACK_SUPPORT_TYPES;
