const BUSINESS_UNITS = {
  ASIA: 'Asia',
  AUSTRALIA: 'Australia',
  CORPORATE_MHE: 'Corporate MHE',
  CTB: 'CTB',
  EDUCATION_SERVICES: 'Education Services',
  INDIA: 'India',
  ITALY: 'Italy',
  MCGRAW_HILL_EDUCATION: 'McGraw-Hill Education',
  MEA: 'MEA',
  MEXICO: 'Mexico',
  MHHE_ALL: 'MHHE-ALL',
  PROFESSIONAL: 'Professional',
  RYERSON_ALL: 'Ryerson-ALL',
  SEG_ALL: 'SEG-ALL',
  SPAIN: 'Spain',
  UNITED_KINGDOM: 'United Kingdom'
};

export default BUSINESS_UNITS;
