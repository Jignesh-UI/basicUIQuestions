export interface SearchCriteria {
    firstName: string;
    lastName: string;
    businessUnit: string;
    roleName?: string;
}