const DOCUMENT_TITLE = document.title;

export default DOCUMENT_TITLE;