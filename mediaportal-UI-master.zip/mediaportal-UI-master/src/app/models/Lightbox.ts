/**
 * a single, selected lightbox w/ assets populated
 */

export class Lightbox {
  public assets: {}[];
  public businessUnit: string;
  public collaborators: {}[];
  public createdDate: Date;
  public description: string;
  public expiryDate: Date;
  public fullfillLightbox: boolean;
  public fullfilments: {}[];
  public lastModifiedDate: Date;
  public lastModifiedUser: string;
  public lightBoxId: string;
  public lightBoxStatus: string;
  public name: string;
  public numberOfAssets: number;
  public owner: boolean = false;
  public owners: {}[];
  public requestFulfillment: boolean;
  public selfFulfill: boolean;
  public startDate: Date;
  public size:any;
};
