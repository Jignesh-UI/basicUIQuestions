import { PopUpService } from "../shared/services/pop-up.service";

export interface CollaboratorDataModel {
    lightbox: any,
    isRemoveCollaboratorPopupOpen: boolean,
    service?: PopUpService
}

export interface LightboxFulfillDataModel {
    lightbox: any
}