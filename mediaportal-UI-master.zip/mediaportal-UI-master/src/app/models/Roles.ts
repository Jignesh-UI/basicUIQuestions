const ROLES = {
  'administrator': {
    displayFormat: 'Administrator',
    iconStyle: 'administrator',
    ucode: '&#xe115;'
  },
  'archivist': {
    displayFormat: 'Archivist',
    iconStyle: 'archivist',
    ucode: '&#xe116;'
  },
  'fulfiller': {
    displayFormat: 'Fulfiller',
    iconStyle: 'fulfiller',
    ucode: '&#xe117'
  },
  'indexer': {
    displayFormat: 'Indexer',
    iconStyle: 'indexer',
    ucode: '&#xe118;'
  },
  'permissions': {
    displayFormat: 'Permissions',
    iconStyle: 'permissions',
    ucode: '&#xe11a;'
  },
  'power archivist': {
    displayFormat: 'Power Archivist',
    iconStyle: 'power-archivist',
    ucode: '&#xe119;'
  },
  'researcher': {
    displayFormat: 'Researcher',
    iconStyle: 'researcher',
    ucode: '&#xe11b;'
  }
};

export default ROLES;
