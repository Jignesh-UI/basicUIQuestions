import { User } from '../shared/services/User/User.model';
import SUPPORT_URGENCY from "./SupportUrgency";

export class SupportRequest {
  public userName: string;
  public email: string;
  public phone: string;
  public priority: string;
  public summary: string;
  public description: string;
  public files: {}[];
  public businessUnit: string;
  public issueType: string;
  public assetId: string;

  //These properties need to be sent to the backend but should never be needed
  public imageLicensing: string[];
  public issueWithImage: string[];
  public fileName: string;
  public projectName: string;
  public feedBack: boolean;

  constructor(user: User = null) {
    this.userName = user ? user.loginName : "";
    this.email = user ? user.email : "";
    this.phone = "";
    this.priority = SUPPORT_URGENCY.URGENT;
    this.summary = "";
    this.description = "";
    this.files = [];
    this.businessUnit = user ? user.participatingBusinessUnit : "";
    this.issueType = "";
    this.imageLicensing = [];
    this.issueWithImage = [];
    this.fileName = "";
    this.projectName = "";
    this.feedBack = false;
    this.assetId = "";
  }
}
