const SUPPORT_TYPES = {
  TRAINING_SUPPORT: "Training Support",
  TECHNICALSUPPORT: "Technical Support",
  FEEDBACK: "Feedback",
  OTHER: "Other"
};

export default SUPPORT_TYPES;
