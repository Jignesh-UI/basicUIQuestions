const SUPPORT_URGENCY = {
  URGENT: 'Urgent',
  VERY_HIGH: 'Very High',
  HIGH: 'High',
  MEDIUM: 'Medium',
  LOW: 'Low'
};

export default SUPPORT_URGENCY;
