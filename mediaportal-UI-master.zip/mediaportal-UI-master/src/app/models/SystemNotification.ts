export class SystemNotification {
  public notificationText: string;
  public notificationStartDate: Date;
  public notificationEndDate: Date;
}
