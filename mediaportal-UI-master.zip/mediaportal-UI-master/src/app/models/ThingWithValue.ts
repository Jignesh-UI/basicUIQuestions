export class ThingWithValue{
  value: any;
}
