import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ServiceModule } from 'src/app/shared/services/service.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { MaterialModule } from '../material/material.module';
import { AssetDownloadComponent } from './asset-download/asset-download.component';
import { AssetFullDetailsComponent } from './asset-full-details/asset-full-details.component';
import { AssetMediaPlayerComponent } from './asset-media-player/asset-media-player.component';
import { AssetPanelComponent } from './asset-panel/asset-panel.component';
import { AssetActionsComponent } from './asset-rollover-view/asset-actions/asset-actions.component';
import { AssetInfoComponent } from './asset-rollover-view/asset-info/asset-info.component';
import { AssetLargeViewComponent } from './asset-rollover-view/asset-large-view/asset-large-view.component';
import { AssetRolloverViewComponent } from './asset-rollover-view/asset-rollover-view.component';
import { AssetSpreadsheetComponent } from './asset-spreadsheet/asset-spreadsheet.component';
import { AssetComponent } from './asset/asset.component';
import { ActionbarComponent } from './components/actionbar/actionbar.component';
import { AssetPaginationComponent } from './components/asset-pagination/asset-pagination.component';
import { AssetSelectorComponent } from './components/asset-selector/asset-selector.component';
import { AssetSorterComponent } from './components/asset-sorter/asset-sorter.component';
import { AssetViewSettingsComponent } from './components/asset-view-settings/asset-view-settings.component';
import { FfuButtonComponent } from './filter/ffu-button/ffu-button.component';
import { FilterItemComponent } from './filter/filter-item/filter-item.component';
import { QuickPrintComponent } from './quick-print/quick-print.component';

@NgModule({
    declarations: [
        AssetPanelComponent,
        AssetComponent,
        ActionbarComponent,
        AssetViewSettingsComponent,
        AssetSorterComponent,
        AssetPaginationComponent,
        AssetSelectorComponent,
        AssetSpreadsheetComponent,
        AssetRolloverViewComponent,
        AssetInfoComponent,
        AssetActionsComponent,
        FfuButtonComponent,
        FilterItemComponent,
        AssetMediaPlayerComponent,
        AssetLargeViewComponent,
        QuickPrintComponent,
        AssetFullDetailsComponent,
        AssetDownloadComponent
    ],
    imports: [
        CommonModule,
        ServiceModule,
        MaterialModule,
        SharedModule,
    ],
    exports: [
        ServiceModule,
        MaterialModule,
        SharedModule,
        AssetPanelComponent,
        AssetComponent,
        ActionbarComponent,
        AssetViewSettingsComponent,
        AssetSorterComponent,
        AssetPaginationComponent,
        AssetSelectorComponent,
        AssetSpreadsheetComponent,
        AssetRolloverViewComponent,
        AssetInfoComponent,
        AssetActionsComponent,
        FfuButtonComponent,
        FilterItemComponent,
        AssetMediaPlayerComponent,
        AssetLargeViewComponent,
        QuickPrintComponent,
        AssetFullDetailsComponent,
        AssetDownloadComponent,
        ServiceModule,
        MaterialModule,
        SharedModule,
    ],
    providers: []
})
export class AssetCommonModule { }
