import { TestBed } from '@angular/core/testing';

import { AssetDownloadServiceService } from './asset-download-service.service';

describe('AssetDownloadServiceService', () => {
  let service: AssetDownloadServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AssetDownloadServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
