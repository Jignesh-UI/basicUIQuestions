import { Injectable } from '@angular/core';
import { HttpService } from 'src/app/shared/services/http/http.service';

@Injectable({
  providedIn: 'root'
})

export class AssetDownloadServiceService {
  // 
  constructor(private http: HttpService) { }

  private LOW_RES_PREFIX = 'low-res_';

  public exportLowResVersion(asset, option) {
    const assetUrl = '/mediaportal/services/api/lowres/asset/' + asset.assetId;
    const LOW_RES = true;
    this.downloadUrls(option, asset, assetUrl, LOW_RES);
  }

  public exportHiResVersion(asset, option) {
    const assetUrl = '/mediaportal/services/api/hires/asset/' + asset.assetId;
    const HI_RES = false;
    this.downloadUrls(option, asset, assetUrl, HI_RES);
  }

  private downloadUrls(option, asset, assetUrl, isLowRes) {
    const fileName = (this.isSafari() && isLowRes) ? `${this.LOW_RES_PREFIX}${asset.fileName}` : asset.fileName;
    const textFileName = this.getFileName(asset.fileName, 'txt');
    const xmlFileName = this.getFileName(asset.fileName, 'xml');
    const textUrl = '/mediaportal/services/api/hires/txt/' + asset.assetId;
    const xmlUrl = '/mediaportal/services/api/hires/xml/' + asset.assetId;
    switch (option) {
      case 'asset':
        this.download(assetUrl, fileName);
        break;
      case 'txt':
        this.download(assetUrl, fileName);
        this.download(textUrl, textFileName);
        break;
      case 'all':
        this.download(assetUrl, fileName);
        this.download(xmlUrl, xmlFileName);
        this.download(textUrl, textFileName);
        break;
    }

  }

  private getFileName(fileName, newExtension) {
    const newFileName = fileName.substr(0, fileName.lastIndexOf(".")) + "." + newExtension;
    return newFileName;
  }

  private download(url, fileName) {
    if (this.isUnsupportedSafari()) {
      this.downloadByWindow(url);
    } else {
      this.downloadByLink(url, fileName);
    }
  }

  private downloadByLink(url, fileName) {
    const link = document.createElement('a');
    link.href = url;
    if (this.canUseDownloadAttribute()) {
      link['download'] = fileName;
    }
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  private canUseDownloadAttribute() {
    const downloadLink = document.createElementNS('http://www.w3.org/1999/xhtml', 'a');
    return 'download' in downloadLink;
  }

  private downloadByWindow(url) {
    window.location.href = url;
    url = undefined; // releases url reference
  }

  private isSafari() {
    const browser = this.getBrowser();
    return browser === 'safari';
  }

  private isUnsupportedSafari() {
    const isSafari = this.isSafari();
    if (isSafari) {
      const versionTest = /Version\/10.1/i;
      const isUnsupported = !versionTest.test(window.navigator.appVersion);
      return isUnsupported;
    }
    return false;
  }

  private getBrowser() {
    const userAgent = window.navigator.userAgent;
    const browsers = { chrome: /chrome/i, safari: /safari/i, firefox: /firefox/i, ie: /internet explorer/i };
    for (var key in browsers) {
      if (browsers[key].test(userAgent)) {
        return key;
      }
    }
  }
}
