import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { AssetDialogDataModel } from '../asset.defaults';
import { AssetDownloadServiceService } from './asset-download-service.service';

@Component({
  selector: 'app-asset-download',
  templateUrl: './asset-download.component.html',
  styleUrls: ['./asset-download.component.scss']
})
export class AssetDownloadComponent implements OnInit, OnDestroy {

  public asset;
  public assetDetails;
  public isHiRes;
  public downloadOptions = {
    assetOnly: 'asset',
    assetWithText: 'txt',
    all: 'all'
  };
  public subscrition: Subscription;
  public selectedDownloadOption = this.downloadOptions.assetOnly;

  constructor(private exportService: AssetDownloadServiceService,
    @Inject(MAT_DIALOG_DATA) public data: AssetDialogDataModel, private dialogRef: MatDialogRef<AssetDownloadComponent>) {
    this.asset = data.asset;
    this.assetDetails = data.assetDetails;
    this.subscrition = data.subscription;
    this.isHiRes = data.isHiRes;
  }

  ngOnInit(): void {
  }

  ngOnDestroy(): void {
    if (this.subscrition) this.subscrition.unsubscribe();
  }

  public hideDialog() {
    this.dialogRef.close();
  }

  public downloadSelectedOption() {
    debugger
    const assetId = this.asset.assetId;
    if (this.isHiRes) {
      this.exportService.exportHiResVersion(this.asset, this.selectedDownloadOption);
    } else {
      this.exportService.exportLowResVersion(this.asset, this.selectedDownloadOption);
    }
    this.hideDialog();
  }

}
