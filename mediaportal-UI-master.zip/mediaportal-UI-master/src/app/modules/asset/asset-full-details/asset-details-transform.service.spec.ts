import { TestBed } from '@angular/core/testing';

import { AssetDetailsTransformService } from './asset-details-transform.service';

describe('AssetDetailsTransformService', () => {
  let service: AssetDetailsTransformService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AssetDetailsTransformService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
