import { Injectable } from '@angular/core';
import * as _ from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class AssetDetailsTransformService {

  private MISSING_VALUE_PLACEHOLDER = '-';

  constructor() { }

  private getSpanWrappedItemString(assetDetailValue) {
    var assetDetailValueCollection = assetDetailValue.split(';');
    var wrapped = _.map(assetDetailValueCollection, function (assetDetailValueItem) {
      return '<span>' + assetDetailValueItem + '</span>';
    }).join('');

    return wrapped;
  }

  public transformField(asset, field) {
    var assetDetailValue = _.result(_.find(asset.fields, { 'name': field }), 'value');
    return assetDetailValue || this.MISSING_VALUE_PLACEHOLDER;
  }
}
