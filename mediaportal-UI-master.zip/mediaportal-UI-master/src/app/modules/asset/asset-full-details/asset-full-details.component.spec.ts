import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetFullDetailsComponent } from './asset-full-details.component';

describe('AssetFullDetailsComponent', () => {
  let component: AssetFullDetailsComponent;
  let fixture: ComponentFixture<AssetFullDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetFullDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetFullDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
