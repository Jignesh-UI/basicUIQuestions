import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { AssetLargeViewComponent } from '../asset-rollover-view/asset-large-view/asset-large-view.component';
import { AssetDialogDataModel } from '../asset.defaults';
import { AssetDetailsTransformService } from './asset-details-transform.service';
import { ASSET_DETAILS } from './asset.details.model';

@Component({
  selector: 'app-asset-full-details',
  templateUrl: './asset-full-details.component.html',
  styleUrls: ['./asset-full-details.component.scss']
})
export class AssetFullDetailsComponent implements OnInit, OnDestroy {

  public asset;
  public assetDetailsCategories: any[] = ASSET_DETAILS;
  public assetDetails;
  public isVisible;
  private subs: Subscription;

  constructor(@Inject(MAT_DIALOG_DATA) public data: AssetDialogDataModel,
    private assetDetailsItemTransformService: AssetDetailsTransformService,
    public popupService: MatDialogRef<AssetFullDetailsComponent>, private dialog: MatDialog) {
    this.isVisible = false;
    this.assetDetails = data.assetDetails;
    this.asset = data.asset;
    this.subs = data.subscription;
  }

  ngOnDestroy(): void {
    if (this.subs) this.subs.unsubscribe();
  }

  ngOnInit(): void {
    this.assetDetailsCategories = this.assetDetailsCategories.map(({ label, value }) => {
      return {
        label,
        expand: false,
        value: Object.keys(value).map(key => {
          return {
            label: key,
            value: value[key]
          }
        })
      }
    })
  }

  public transformAssetDetailsItem(assetDetailsObject, field) {
    var transformedItem = this.assetDetailsItemTransformService.transformField(assetDetailsObject, field);
    return transformedItem;
  }

  public showAssetLargeViewDialog() {
    this.popupService.close();
    this.dialog.open(AssetLargeViewComponent, {
      data: {
        asset: this.asset,
        isPlayable: this.isPlayableMedia(this.asset)
      }
    })
  }

  public hideLargeView() {
  }

  public getCopyrightFriendlyUrl() {

    var copyrightFriendlyUrl;

    if (this.doesNotRequireWatermark()) {
      copyrightFriendlyUrl = (this.asset.thumbnailUrl) ? this.asset.thumbnailUrl : "";
    } else {
      copyrightFriendlyUrl = (this.asset.mediumResolutionUrl) ? this.asset.mediumResolutionUrl : "";
    }

    return copyrightFriendlyUrl;
  }

  private doesNotRequireWatermark() {
    var contentType = this.asset.contentType.toLowerCase();
    return (contentType === 'video' || contentType === 'audio');
  }

  public hideAssetDetailsDialog() {
    this.popupService.close();
  }

  public formatLabel(text) {
    return text.replace(/_/g, ' ');
  }

  public isPlayableMedia(asset) {
    return (asset.contentType.toLowerCase() === 'video' || asset.contentType.toLowerCase() === 'audio');
  }

  public isMediaTypeAudio(asset) {
    return (asset.contentType.toLowerCase() === 'audio');
  }

  public isExportPermitted(asset) {
    return asset.exportPermission;
  }

}
