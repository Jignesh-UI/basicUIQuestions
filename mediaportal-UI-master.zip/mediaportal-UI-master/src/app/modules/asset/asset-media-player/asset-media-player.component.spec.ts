import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetMediaPlayerComponent } from './asset-media-player.component';

describe('AssetMediaPlayerComponent', () => {
  let component: AssetMediaPlayerComponent;
  let fixture: ComponentFixture<AssetMediaPlayerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetMediaPlayerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetMediaPlayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
