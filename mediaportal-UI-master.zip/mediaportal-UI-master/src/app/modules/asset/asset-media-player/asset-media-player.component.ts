import { AfterViewChecked, AfterViewInit, Component, ElementRef, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { APP_EVENTS } from 'src/app/app-defaults';
import { AssetRolloverService } from '../asset-rollover.service.service';

@Component({
  selector: 'app-asset-media-player',
  templateUrl: './asset-media-player.component.html',
  styleUrls: ['./asset-media-player.component.scss']
})
export class AssetMediaPlayerComponent implements OnInit, AfterViewInit {

  @Input('content-type') public contentType;
  @Input() public url;
  public player;
  public seekbarElement;
  public seekbarValue;
  public volumebarValue;
  public timeElapsed;
  public timeRemaining;
  public duration;
  public dateCalc;

  @Input() public asset;
  @Input('player-id') public playerId;
  @Input('playable') public playable;
  @Input('large-view') public isLargeView = false;

  public isVideo;
  public isAudio;
  public isPlaying;
  public isMuted;
  public isLooping;
  public isFullscreen;
  public assetUrl: any = '';
  @Input('limited-controls') public limitedControls;
  @Output() onChange: EventEmitter<any> = new EventEmitter();

  constructor(private sanitizer: DomSanitizer, private popupService: AssetRolloverService,
    public el: ElementRef) { }

  ngAfterViewInit(): void {
    if (this.playable) {
      this.initPlayer();
    }
  }

  ngOnInit(): void {
    this.isVideo = this.contentType.toLowerCase() === 'video';
    this.isAudio = this.contentType.toLowerCase() === 'audio';
    this.isPlaying = false;
    this.isMuted = false;
    this.isFullscreen = false;
    this.isLooping = false;
    this.timeElapsed = '';
    this.timeRemaining = '';
    this.limitedControls = !!this.limitedControls;
    this.assetUrl = this.getTrustedUrl()
  }

  public getTrustedUrl() {
    return this.sanitizer.bypassSecurityTrustResourceUrl(this.asset.originalAssetUrl); //"http://www.quirksmode.org/html5/videos/big_buck_bunny.mp4"
  }

  public initPlayer() {

    this.player = <HTMLMediaElement>document.getElementById(this.playerId);
    this.seekbarElement = document.getElementById("mediaplayer__seekbar-" + this.playerId);
    this.initPlayerEvents(this.player);
    this.resetPosition();
    if (this.isAudio) {
      this.toggleVolume(true);
    }
    if (!this.limitedControls) {
      this.volumebarValue = 0.5;
    } else if (this.isVideo) {
      this.toggleVolume();
    }
  }

  public toggleVolume(override = false) {
    this.isMuted = (override) ? !override : !this.isMuted;
    if (this.isMuted) {
      this.volumebarValue = 0;
    } else {
      this.volumebarValue = 1;
    }
    this.player.volume = this.volumebarValue;
  }

  public togglePlayback() {
    this.isPlaying = !this.isPlaying;
    if (this.isPlaying && this.player) {
      this.player.play();
    } else if (this.player) {
      this.player.pause();
    }
  }

  public toggleLoop() {
    if (this.player) {
      this.player.loop = !this.player.loop;
      this.isLooping = !this.isLooping;
    }
  }

  public toggleFullScreen() {
    this.isFullscreen = !this.isFullscreen;
    if (this.player.requestFullscreen) {
      this.player.requestFullscreen();
    } else if (this.player.msRequestFullscreen) {
      this.player.msRequestFullscreen();
    } else if (this.player.mozRequestFullScreen) {
      this.player.mozRequestFullScreen();
    } else if (this.player.webkitRequestFullscreen) {
      this.player.webkitRequestFullscreen();
    }
  }

  public resetPosition() {
    this.player.currentTime = 0;
    this.seekbarValue = 0;
  }

  public resetPlayback() {
    this.resetPosition();
    this.togglePlayback();
  }

  public onSeekbarClickStart() {
    this.setCurrentTime();
    this.player.pause();
  }

  public onSeekbarClickEnd() {
    this.setCurrentTime();
    this.player.play();
  }

  public onSeekbarTimeUpdate() {
    this.setSeekbarValue();
    this.setTimeElapsed();
    this.setTimeRemaining();
    this.setDuration();
  }

  public onVolumebarChange() {
    this.player.volume = this.volumebarValue;
    this.isMuted = !this.volumebarValue;
  }

  public showAssetLargeViewDialog() {
    if (this.isLargeView) return false
    this.onChange.emit({ type: APP_EVENTS.ACTIVATE_LARGE_VIEW })
  }

  public getFormattedTime(timeInSeconds) {
    var dateCalc = new Date(0, 0, 0, 0, 0, 0, 0);
    dateCalc.setSeconds(timeInSeconds);
    var hours = dateCalc.getHours();
    var minutes = dateCalc.getMinutes();
    var seconds = dateCalc.getSeconds();
    return (hours < 10 ? "0" + hours : hours) + ":" + (minutes < 10 ? "0" + minutes : minutes) + ":" + (seconds < 10 ? "0" + seconds : seconds);
  }

  public initPlayerEvents(playerObject) {
    playerObject.addEventListener('timeupdate', () => {
      this.onSeekbarTimeUpdate();
    });
    playerObject.addEventListener('loadedmetadata', () => {
      this.onLoadedMetadata();
    });
    playerObject.addEventListener('error', (e) => {
    }, true);
    playerObject.addEventListener('ended', () => {
      this.resetPlayback();
    })
  }

  private onLoadedMetadata() {
    this.onChange.emit({
      type: APP_EVENTS.ASSET_READY
    });
    if (this.isVideo) {
      this.togglePlayback();
    }
  }

  private setSeekbarValue() {
    var _seekbarValue = (100 / this.player.duration) * this.player.currentTime;
    _seekbarValue = +_seekbarValue.toFixed(2);
    this.seekbarValue = _seekbarValue;
  }

  private setTimeElapsed() {
    this.timeElapsed = this.getFormattedTime(Math.floor(this.player.currentTime));
  }

  private setTimeRemaining() {
    this.timeRemaining = this.getFormattedTime(Math.floor(this.player.duration - this.player.currentTime));
  }

  private setDuration() {
    if (!this.duration) {
      this.duration = this.getFormattedTime(Math.floor(this.player.duration));
    }
  }

  private setCurrentTime() {
    var currentTime = this.seekbarValue / (100 / this.player.duration);
    this.player.currentTime = currentTime;
  }
}
