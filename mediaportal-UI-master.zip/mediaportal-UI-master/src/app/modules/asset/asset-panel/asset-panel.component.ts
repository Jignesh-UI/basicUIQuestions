import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { VIEW_TYPES } from 'src/app/app-defaults';

@Component({
  selector: 'app-asset-panel',
  templateUrl: './asset-panel.component.html',
  styleUrls: ['./asset-panel.component.scss']
})
export class AssetPanelComponent implements OnInit {

  @Input('lightbox') public lightbox: any = null;
  @Input('assets') public list: any[] = [];
  @Input('view') public view: string = VIEW_TYPES.grid;
  @Input('asset-container') public assetContainer: ElementRef;
  @Input('actions') public actions: boolean = true;

  constructor() { }

  ngOnInit(): void {
  }

  get isGridView() {
    return this.view === VIEW_TYPES.grid;
  }

  get isListView() {
    return this.view === VIEW_TYPES.list;
  }

  assetTrackByFn(item) {
    return item.id;
  }

}
