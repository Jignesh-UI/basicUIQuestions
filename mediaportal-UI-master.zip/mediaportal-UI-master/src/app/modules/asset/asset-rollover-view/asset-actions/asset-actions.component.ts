import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { APP_EVENTS } from 'src/app/app-defaults';
import { SupportComponent } from 'src/app/modules/layout/components/support/support.component';
import { LightboxService } from 'src/app/modules/lightbox/lightbox.service';
import { AssetService } from 'src/app/shared/services/assets/assets.service';
import { Broadcast } from 'src/app/shared/services/broadcast.service';
import { PopUpService } from 'src/app/shared/services/pop-up.service';
import { AssetDownloadComponent } from '../../asset-download/asset-download.component';
import { AssetFullDetailsComponent } from '../../asset-full-details/asset-full-details.component';
import { QuickPrintComponent } from '../../quick-print/quick-print.component';

@Component({
  selector: 'app-asset-actions',
  templateUrl: './asset-actions.component.html',
  styleUrls: ['./asset-actions.component.scss']
})
export class AssetActionsComponent implements OnInit, OnDestroy {

  @Input('asset') public asset;
  @Input('dialog') public dialogRef: MatDialogRef<any>;
  @Input('asset-details') public isAssetDetails: boolean = false;
  public foundUnplayableMedia = false;
  public usb: Subscription[] = [];

  constructor(private event: Broadcast, public dialog: MatDialog,
    public as: AssetService, private lightboxService: LightboxService,
    private popupService: PopUpService) { }

  ngOnDestroy(): void {
    this.usb.forEach((sb: Subscription) => {
      sb.unsubscribe()
    })
  }

  ngOnInit(): void {
  }

  //helper function 
  private popWithAssetDetails(asset, Component, paneClass, data = {}) {
    if (this.dialogRef) {
      this.dialogRef.close();
    }
    let assetId = asset.assetId;
    let subscription = this.as.details(assetId).subscribe((assetDetails) => {
      this.dialog.open(Component, {
        data: { asset, assetDetails, subscription, ...data },
        panelClass: paneClass
      });
    });
  }

  public showAssetDetailsDialog(asset) {
    this.popWithAssetDetails(asset, AssetFullDetailsComponent, 'full-aset-dialog-container')
  }

  public showQuickPrintDialog(asset) {
    this.popWithAssetDetails(asset, QuickPrintComponent, 'quick-print-dialog-container')
  }

  public showSupportDialog(asset) {
    this.popWithAssetDetails(asset, SupportComponent, 'support-dialog-container')
  }

  public showAssetDownloadOptionsDialog(asset, isHiRes) {
    this.popWithAssetDetails(asset, AssetDownloadComponent, 'asset-download-dialog-container', { isHiRes })
  }

  public isInCurrentLightbox(asset) {
    return this.lightboxService.isInCurrentLightbox(asset);
  }

  public isExportPermitted(asset) {
    return asset.exportPermission;
  }

  public addAsset(asset) {
    if (this.lightboxService.lightboxModel.lightBoxId) {
      this.lightboxService.addAsset(asset).then(() => {
        let hideDialog = this.popupService.showSuccessDialog(asset.fileName + ' added.');
        setTimeout(() => {
          hideDialog()
        }, 2000);
      },
        this.onAssetAddError);
    } else {
      this.popupService.showFailureDialog('No lightbox selected.')
    }
  }

  private onAssetRemovedError() {
    this.onAssetChangeError(false);
  }

  private onAssetAddError() {
    this.onAssetChangeError(true);
  }

  private onAssetChangeError(isAdd) {
    var message = 'Error while trying to ';
    if (isAdd) {
      message += 'add asset.';
    } else {
      message += 'remove asset.';
    }
    this.popupService.showFailureDialog(message);
  }

  public removeAsset(asset) {
    this.popupService.showConfirmDialog("This option will remove any assets you have selected from your lightbox.",
      (success) => {
        this.lightboxService.removeAsset(asset).subscribe((res) => {
          this.lightboxService.actionAfterRemove(res, asset)
          let hideDialog = this.popupService.showSuccessDialog(asset.fileName + ' removed.');
          setTimeout(() => {
            hideDialog()
          }, 2000);
        },
          this.onAssetRemovedError);
      }, (fail) => {

      },"CONTINUE", "BACK ")
  }


  public isPlayableMedia(asset) {
    var contentType = asset.contentType.toLowerCase();
    var isPlayable = (contentType === 'video' || contentType === 'audio');
    return isPlayable && !this.foundUnplayableMedia;
  }

  public isMediaTypeAudio(asset) {
    var contentType = asset.contentType.toLowerCase();
    return (contentType === 'audio');
  }

}
