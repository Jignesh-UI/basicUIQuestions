import { Component, Input, OnInit } from '@angular/core';
import { ThingWithValue } from 'src/app/models/ThingWithValue';
import * as _ from 'lodash';

@Component({
  selector: 'app-asset-info',
  templateUrl: './asset-info.component.html',
  styleUrls: ['./asset-info.component.scss']
})
export class AssetInfoComponent implements OnInit {

  public title;
  public businessUnitRights;
  public adaptationRights;
  public assetSource;
  public assetUsageRestrictions;
  public creditText;
  public gpsId;
  public assetRolloverIsReady = false;
  public foundUnplayableMedia = false;

  @Input() public asset;

  constructor() { }

  ngOnInit(): void {
    let asset = this.asset;
    this.title = this.getFieldValue(asset, 'DAL.FIELD.TITLE');
    this.businessUnitRights = this.getFieldValue(asset, 'DAL.FIELD.BUSINESS UNIT RIGHTS');
    this.adaptationRights = this.getFieldValue(asset, 'DAL.FIELD.ADAPTATION RIGHTS');
    this.assetSource = this.getFieldValue(asset, 'DAL.FIELD.ASSET SOURCE');
    this.assetUsageRestrictions = this.getFieldValue(asset, 'DAL.FIELD.USAGE RESTRICTIONS');
    this.creditText = this.getFieldValue(asset, 'DAL.FIELD.CREDIT TEXT');
    this.gpsId = this.getFieldValue(asset, 'DAL.FIELD.GPS UOIID');
  }

  public getFieldValue(asset, fieldName) {
    var selectedField = <ThingWithValue>_.find(asset.fields, { 'name': fieldName });
    if (selectedField) {
      return selectedField.value;
    }
  }

}
