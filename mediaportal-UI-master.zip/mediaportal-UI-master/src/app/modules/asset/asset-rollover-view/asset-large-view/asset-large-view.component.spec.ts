import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetLargeViewComponent } from './asset-large-view.component';

describe('AssetLargeViewComponent', () => {
  let component: AssetLargeViewComponent;
  let fixture: ComponentFixture<AssetLargeViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetLargeViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetLargeViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
