import { Component, EventEmitter, Inject, Input, OnInit, Output } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AssetDialogDataModel } from '../../asset.defaults';

@Component({
  selector: 'app-asset-large-view',
  templateUrl: './asset-large-view.component.html',
  styleUrls: ['./asset-large-view.component.scss']
})
export class AssetLargeViewComponent implements OnInit {

  @Input('playable') public isPlayable: boolean;
  @Input('asset') public asset: any;


  @Output() onLargeViewHide: EventEmitter<any> = new EventEmitter();

  constructor(@Inject(MAT_DIALOG_DATA) public data: AssetDialogDataModel,
    private dialogRef: MatDialogRef<AssetLargeViewComponent>) {
    if (this.data) {
      this.asset = this.data.asset;
      this.isPlayable = this.data.isPlayable;
    }
  }

  ngOnInit(): void {
  }

  onChangeState(e: Event) { }

  hideLargeView() {
    if (this.dialogRef) {
      this.dialogRef.close();
    }
  }

}
