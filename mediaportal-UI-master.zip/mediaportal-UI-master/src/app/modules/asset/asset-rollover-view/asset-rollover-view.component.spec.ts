import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetRolloverViewComponent } from './asset-rollover-view.component';

describe('AssetRolloverViewComponent', () => {
  let component: AssetRolloverViewComponent;
  let fixture: ComponentFixture<AssetRolloverViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetRolloverViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetRolloverViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
