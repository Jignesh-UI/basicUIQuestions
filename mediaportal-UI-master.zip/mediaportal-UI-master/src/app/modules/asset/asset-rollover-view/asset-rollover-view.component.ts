import { AfterViewChecked, AfterViewInit, Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import * as _ from 'lodash';
import { Subject } from 'rxjs';
import { APP_EVENTS } from 'src/app/app-defaults';
import { PopUpService } from 'src/app/shared/services/pop-up.service';
import { AssetRolloverService } from '../asset-rollover.service.service';
import { AssetLargeViewComponent } from './asset-large-view/asset-large-view.component';

@Component({
  selector: 'app-asset-rollover-view',
  templateUrl: './asset-rollover-view.component.html',
  styleUrls: ['./asset-rollover-view.component.scss']
})
export class AssetRolloverViewComponent implements OnInit, AfterViewInit {

  @Input('asset') public asset;
  public assetRolloverIsReady = false;
  public foundUnplayableMedia = false;
  @Input('playable') public isPlayable = false;
  public assetUrl = '';

  @Input('state') public state: boolean = false;

  @ViewChild('imgView') public imgView: ElementRef;
  @Output('onStateChange') public stateChange: EventEmitter<any> = new EventEmitter();

  constructor(public popupService: PopUpService) { }

  ngAfterViewInit(): void {
    if (!this.isPlayable) this.imgView.nativeElement.onload = () => {
      this.stateChange.emit({
        type: APP_EVENTS.ROLLOVER_READY
      })
    }
  }

  onChangeState(e) {
    if (e.type === APP_EVENTS.ASSET_READY) {
      this.stateChange.emit({
        type: APP_EVENTS.ROLLOVER_READY
      })
    }
    else if (e.type === APP_EVENTS.ACTIVATE_LARGE_VIEW) {
      this.stateChange.emit({
        type: APP_EVENTS.ACTIVATE_LARGE_VIEW
      })
    }
  }

  ngOnInit(): void {
    this.assetUrl = this.getCopyrightFriendlyUrl(this.asset);
  }

  public showAssetLargeViewDialog() {
    this.stateChange.emit({
      type: APP_EVENTS.ACTIVATE_LARGE_VIEW
    })
  }

  public getCopyrightFriendlyUrl(asset) {
    return asset.mediumResolutionUrl;
  }

  private onAssetRemovedError() {
    this.onAssetChangeError(false);
  }

  private onAssetAddError() {
    this.onAssetChangeError(true);
  }

  private onAssetChangeError(isAdd) {
    var message = 'Error while trying to ';
    if (isAdd) {
      message += 'add asset.';
    } else {
      message += 'remove asset.';
    }
    this.popupService.showFailureDialog(message);
  }
  public checkAssetReady(asset) {
  }

}

