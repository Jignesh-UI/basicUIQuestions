import { TestBed } from '@angular/core/testing';

import { AssetRollover.ServiceService } from './asset-rollover.service.service';

describe('AssetRollover.ServiceService', () => {
  let service: AssetRollover.ServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AssetRollover.ServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
