import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AssetRolloverService {

  constructor() { }

  public placePopup(config) {
    var e = config.event;

    var container = config.container || document.body;
    var containerOffset = this.getOffset(container);

    var popup = config.popup;
    var popupWidth = popup.offsetWidth;

    var eventTarget = config.targetOverride || e.target;
    var eventTargetOffset = this.getOffset(eventTarget);

    var offsetMiddleX = eventTargetOffset.left + eventTarget.offsetWidth / 2;
    var itemStartX = offsetMiddleX - popupWidth / 2;

    var itemDoesNotFitXRight = itemStartX + popupWidth > document.documentElement.clientWidth;
    var itemDoesNotFitXLeft = itemStartX < containerOffset.left;

    var itemDoesNotFitYBottom = itemStartX < containerOffset.left;

    var itemTooBigX = popupWidth > container.offsetWidth;

    var itemDoesNotYBottom = eventTargetOffset.top + popup.offsetHeight > document.documentElement.clientHeight;
    this.resetPosition(popup);

    if (itemTooBigX || itemDoesNotFitXLeft) {
      popup.style.left = containerOffset.left + 'px';
    } else if (itemDoesNotFitXRight) {
      popup.style.right = '0px';
    } else {
      popup.style.left = itemStartX + 'px';
    }

    if (itemDoesNotYBottom) {
      popup.style.bottom = '0px';
    } else {
      popup.style.top = eventTargetOffset.top + 'px';
    }
  }

  private getOffset(el) {
    var rect = el.getBoundingClientRect()

    return {
      top: rect.top + document.body.scrollTop,
      left: rect.left + document.body.scrollLeft
    }
  }

  public resetPosition(el) {
    el.style.left = null;
    el.style.right = null;
    el.style.top = null;
    el.style.bottom = null;
  }

}
