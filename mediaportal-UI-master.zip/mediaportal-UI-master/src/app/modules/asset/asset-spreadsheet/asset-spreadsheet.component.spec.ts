import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetSpreadsheetComponent } from './asset-spreadsheet.component';

describe('AssetSpreadsheetComponent', () => {
  let component: AssetSpreadsheetComponent;
  let fixture: ComponentFixture<AssetSpreadsheetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetSpreadsheetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetSpreadsheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
