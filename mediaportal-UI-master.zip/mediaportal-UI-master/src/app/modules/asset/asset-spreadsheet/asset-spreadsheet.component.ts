import { Component, Input, OnInit } from '@angular/core';
import { ThingWithValue } from 'src/app/models/ThingWithValue';
import * as _ from 'lodash';
import { LightboxService } from '../../lightbox/lightbox.service';
import { APP_EVENTS, VIEW_TYPES } from 'src/app/app-defaults';
import { Broadcast } from 'src/app/shared/services/broadcast.service';

@Component({
  selector: 'app-asset-spreadsheet',
  templateUrl: './asset-spreadsheet.component.html',
  styleUrls: ['./asset-spreadsheet.component.scss']
})
export class AssetSpreadsheetComponent implements OnInit {

  @Input() public assets = [];
  @Input('data') public asset;

  public view = VIEW_TYPES.list;
  public titleIndex;
  public rightsCategoryIndex;
  public businessUnitRightsIndex;
  public creditTextIndex;
  public distributionRightsIndex;
  public assetSourceIndex;
  public licensingLimitationsIndex;
  public assetStatusIndex;
  public assetTypeIndex;
  public durationIndex;
  public videoSoundIndex;
  public videoDimensionIndex;
  public screenRatioIndex;
  public currentAsset;
  public isGridView: boolean = false;
  public assetFieldsObj;
  public allAsset: boolean = false;
  public usageRestriction;

  constructor(private lightboxService: LightboxService,public es: Broadcast) {

  }

  ngOnInit(): void {
    this.setAssetFieldObj();
  }

  public setAssetFieldObj() {
    this.assetFieldsObj = {
      'TITLE': 'DAL.FIELD.TITLE',
      'RIGHTS_CATEGORY': 'DAL.FIELD.RIGHTS CATEGORY',
      'BUSINESS_UNIT_RIGHTS': 'DAL.FIELD.BUSINESS UNIT RIGHTS',
      'CREDIT_TEXT': 'DAL.FIELD.CREDIT TEXT',
      'GPS_ID':'DAL.FIELD.GPS UOIID',
      'DISTRIBUTION_RIGHTS': 'DAL.FIELD.DISTRIBUTION RIGHTS',
      'ASSET_SOURCE': 'DAL.FIELD.ASSET SOURCE',
      'LICENSING_LIMITATIONS': 'DAL.FIELD.LICENSING_LIMITATIONS',
      'ASSET_STATUS': 'DAL.FIELD.ASSET STATUS',
      'ASSET_TYPE': 'DAL.FIELD.ASSET TYPE',
      'ASSET_SIZE': 'DAL.FIELD.FILE SIZE',
      'DURATION': 'DAL.FIELD.DURATION',
      'VIDEO_SOUND': 'DAL.FIELD.VIDEO SOUND',
      'VIDEO_DIMENSION': 'DAL.FIELD.VIDEO DIMENSION',
      'SCREEN_RATIO': 'DAL.FIELD.VIDEO_ASPECT_RATIO',
      'USAGE_RESTRICTIONS': 'DAL.FIELD.USAGE RESTRICTIONS',
      'DISPLAYED_CREDIT_REQUIRED': 'DAL.FIELD.DISPLAYED CREDIT REQUIRED',
      'ADAPTATION_RIGHTS': 'DAL.FIELD.ADAPTATION RIGHTS',
      'MARKETING_USE':'DAL.FIELD.MARKETING USE',
      'BITMAP_WIDTH':'ARTESIA.FIELD.BITMAP WIDTH',
      'BITMAP_HEIGHT':'ARTESIA.FIELD.BITMAP HEIGHT',
      'FRAME_WIDTH':'ARTESIA.FIELD.VIDEO.FRAME WIDTH',
      'FRAME_HEIGHT':'ARTESIA.FIELD.VIDEO.FRAME HEIGHT'

    };
  }

  public getAssets() {
    return this.assets;
  }

  public getUsageRestrictions(asset) {
    var assetFields = asset;
    for(var j =0; j< asset.fields.length; j++){
        if (asset.fields[j].name === 'DAL.FIELD.USAGE RESTRICTIONS') {
          this.usageRestriction = assetFields.fields[j].value;
          break;
      }
    }
    return !!this.usageRestriction;
  }
  
  get isLightBoxSelected() { 
    return !this.lightboxService.lightboxModel?.lightBoxId;
  }

  public getAssetFieldValue(asset, fieldName) {
    if (asset.fields.length > 0) {
      var fieldValue = <ThingWithValue>_.find(asset.fields, { 'name': fieldName });
      return fieldValue.value;
    }
  }

  public getAdaptationRightsText(asset) {
    var restriction = <ThingWithValue>_.find(asset.fields, { 'name': this.assetFieldsObj.ADAPTATION_RIGHTS });
    if (typeof (restriction.value) === 'string') {
      return restriction.value.toUpperCase() === 'N' ? "No" : "Yes";
    } else {
      return '';
    }
  }

  public getDisplayedCreditRequiredText(asset) {
    var restriction = <ThingWithValue>_.find(asset.fields, { 'name': this.assetFieldsObj.DISPLAYED_CREDIT_REQUIRED });
    if (typeof (restriction.value) === 'string') {
      return restriction.value.toUpperCase() === 'N' ? "No" : "Yes";
    } else {
      return '';
    }
  }

  public assetStateChange() {
    this.es.broadcast(APP_EVENTS.ASSET_LIST_STATE_CHANGE, this.assets)
  }

  // public allAssetStateChange(evt){// This function is used to select all Items in the LightBox List.
  //   debugger;
  //   console.log(evt);
    
  //   this.lightboxService.currentPageAssets = this.lightboxService.currentPageAssets.map(i => ({...i, selected:evt.checked}));
    

  //   // if(evt.checked){
  //   //   this.es.broadcast(APP_EVENTS.ASSET_LIST_STATE_CHANGE, { action: 'SELECT_ALL', data: null })
  //   // }else{
  //   //   this.es.broadcast(APP_EVENTS.ASSET_LIST_STATE_CHANGE, { action: 'DESELECT_ALL', data: null })
  //   //   this.allAsset=false;
  //   // }
  // }

}
