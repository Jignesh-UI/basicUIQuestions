import { Subscription } from "rxjs";

export interface AssetDialogDataModel {
    asset: any;
    assetDetails: any;
    subscription: Subscription;
    isHiRes: boolean;
    isPlayable: boolean;
}