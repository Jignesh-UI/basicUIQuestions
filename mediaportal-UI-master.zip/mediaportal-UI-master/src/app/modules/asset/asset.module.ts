import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/shared/services/auth/guard.auth';
import { AssetCommonModule } from './asset-common.module';
import { FilterComponent } from './filter/filter.component';
import { BasicSearchComponent } from './search/basicsearch.component';

const ROUTES: Routes = [
  {
    path: 'basicsearch/:query',
    component: BasicSearchComponent,
    canActivate: [AuthGuard]
  }
]

@NgModule({
  declarations: [
    BasicSearchComponent,
    FilterComponent
  ],
  imports: [
    CommonModule,
    AssetCommonModule,
    RouterModule.forRoot(ROUTES, { useHash: true })
  ]
})
export class AssetModule { }
