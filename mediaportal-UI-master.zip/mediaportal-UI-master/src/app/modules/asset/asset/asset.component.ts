import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Observable, Observer, Subject } from 'rxjs';
import { APP_EVENTS, VIEW_TYPES } from 'src/app/app-defaults';
import { Broadcast } from 'src/app/shared/services/broadcast.service';
import { LightboxService } from '../../lightbox/lightbox.service';
import { AssetLargeViewComponent } from '../asset-rollover-view/asset-large-view/asset-large-view.component';
import { AssetRolloverService } from '../asset-rollover.service.service';

@Component({
  selector: 'app-asset',
  templateUrl: './asset.component.html',
  styleUrls: ['./asset.component.scss']
})
export class AssetComponent implements OnInit {

  @Input('data') public assetInfo;
  @Input('disable-rollover') public disableRollover: boolean = false;
  @Input('container') public assetContainer: ElementRef;
  @Input('view-type') public viewType;
  @Input('actions') public actions: boolean = true;

  public showRollOver: boolean = false;
  public usageRestriction;

  public event: MouseEvent;

  public rolloverTimeout: any;
  public rollOverLoaded: boolean = false;
  public isPlayable: boolean = false;
  public foundUnplayableMedia = false;
  public largeView: boolean = false;

  @ViewChild('rolloverView') public rolloverView: ElementRef;

  constructor(private popupService: AssetRolloverService, public es: Broadcast,
    public dialog: MatDialog, private lightboxService: LightboxService) { }

  ngOnInit(): void {
    this.isPlayable = this.isPlayableMedia(this.assetInfo)
    this.getUsageResctrictionValue();
  }

  get isLightBoxSelected() {
    return !this.lightboxService.lightboxModel?.lightBoxId;
  }

  get isListView() {
    return this.viewType === VIEW_TYPES.list;
  }

  onRollOverStateChange(e) {
    if (e.type == APP_EVENTS.ROLLOVER_READY) {
      this.rolloverAssetLoaded()
    } else if (e.type == APP_EVENTS.ACTIVATE_LARGE_VIEW) {
      this.onShowLargeView()
    }
  }

  public assetStateChange() {
    this.es.broadcast(APP_EVENTS.ASSET_LIST_STATE_CHANGE, this.assetInfo)
  }

  public isPlayableMedia(asset) {
    var contentType = asset.contentType.toLowerCase();
    var isPlayable = (contentType === 'video' || contentType === 'audio');
    return isPlayable && !this.foundUnplayableMedia;
  }

  public onLargeViewHide() {
    this.largeView = false;
  }

  onShowLargeView() {
    this.hideRollover();
    this.dialog.open(AssetLargeViewComponent, {
      data: {
        asset: this.assetInfo,
        isPlayable: this.isPlayable
      }
    })
  }

  hideRollover() {
    if (this.rolloverTimeout) clearTimeout(this.rolloverTimeout);
    this.showRollOver = false;
    this.rollOverLoaded = false;
    this.event = null;
    this.popupService.resetPosition(this.rolloverView.nativeElement)
  }

  rolling(event: MouseEvent) {
    this.es.broadcast(APP_EVENTS.SPINNER_ON, {
      show: !this.rollOverLoaded,
      pos: {
        x: event.clientX,
        y: event.clientY
      }
    })
  }

  rollover(event: MouseEvent) {

    if (this.rolloverTimeout) clearTimeout(this.rolloverTimeout);
    this.event = event;
    this.rolloverTimeout = setTimeout(() => {
      this.showRollOver = true;
    }, 500)
  }

  public get restritRollover() {
    return this.viewType === VIEW_TYPES.list || !this.actions || this.disableRollover
  }

  showPopup(event) {
    let config = {
      event,
      container: this.assetContainer,
      popup: this.rolloverView.nativeElement
    }

    this.popupService.placePopup(config);
  }

  rolloverAssetLoaded() {
    this.rollOverLoaded = true;
    this.showPopup(this.event)
    this.es.broadcast(APP_EVENTS.SPINNER_ON, {
      show: false,
      pos: {
        x: 0,
        y: 0
      }
    })
  }

  rollout(e: MouseEvent) {
    this.es.broadcast(APP_EVENTS.SPINNER_ON, {
      show: false,
      pos: {
        x: e.clientX,
        y: e.clientY
      }
    })
    this.hideRollover();
  }

  usageRestricted() {
    return !!this.usageRestriction;
  }

  private doesNotRequireWatermark() {
    var contentType = this.assetInfo.contentType.toLowerCase();
    return (contentType === 'video' || contentType === 'audio');
  }

  public getCopyrightFriendlyUrl() {
    var copyrightFriendlyUrl;

    if (this.doesNotRequireWatermark()) {
      copyrightFriendlyUrl = (this.assetInfo.thumbnailUrl) ? this.assetInfo.thumbnailUrl : "";
    } else {
      copyrightFriendlyUrl = (this.assetInfo.mediumResolutionUrl) ? this.assetInfo.mediumResolutionUrl : "";
    }

    return copyrightFriendlyUrl;
  }

  public getUsageResctrictionValue() {
    var assetFields = this.assetInfo.fields;
    for (var i = 0; i < this.assetInfo.fields.length; i++) {
      if (assetFields[i].name === 'DAL.FIELD.USAGE RESTRICTIONS') {
        this.usageRestriction = assetFields[i].value;
      }
    }
  }

}
