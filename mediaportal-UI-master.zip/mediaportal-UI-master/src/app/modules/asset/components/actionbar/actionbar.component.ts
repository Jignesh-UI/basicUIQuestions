import { Output } from '@angular/core';
import { Component, Input, OnInit, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-actionbar',
  templateUrl: './actionbar.component.html',
  styleUrls: ['./actionbar.component.scss']
})

export class ActionbarComponent implements OnInit {

  public assetCount: number = 0;
  public isGridView: boolean = false;

  @Output() public onPaginationChange: EventEmitter<any> = new EventEmitter<any>();
  @Output() public onPerPageChange: EventEmitter<any> = new EventEmitter<any>();
  @Output() public onSortChange: EventEmitter<any> = new EventEmitter<any>();
  @Output() public onViewChangeEvent: EventEmitter<any> = new EventEmitter<any>();

  @Input() public perPageCount: number = 0;
  @Input() public view: string;

  @Input('pagination') public pagination = {
    total: 0,
    perPage: 0,
    page: 1
  }

  constructor() { }

  ngOnInit(): void {
  }

  onChangeSort(event) {
    this.onSortChange.emit(event)
  }

  onPageChange(event) {
    this.onPaginationChange.emit(event);
  }

  onPageCountChange(e) {
    this.onPerPageChange.emit(e);
  }

  onViewChange(e) {
    this.onViewChangeEvent.emit(e)
  }

}
