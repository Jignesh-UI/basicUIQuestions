import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { MaterialModule } from 'src/app/modules/material/material.module';
import { SharedModule } from 'src/app/shared/shared.module';

import { AssetPaginationComponent } from './asset-pagination.component';

fdescribe('AssetPaginationComponent', () => {
  let component: AssetPaginationComponent;
  let fixture: ComponentFixture<AssetPaginationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AssetPaginationComponent],
      imports: [SharedModule, MaterialModule]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetPaginationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create pageination and current page no should be 1', () => {
    expect(component).toBeTruthy();
    expect(component.currentPageNumber).toEqual(1);
  });

  it('total number of page should be correct', fakeAsync(() => {
    component.totalCount = 211;
    component.countPerPage = 20;
    component.generate();
    fixture.detectChanges();
    let input = fixture.debugElement.query(By.css('.pagination__input-page-number')).nativeElement;
    let totalPAgeTextNode = fixture.debugElement.query(By.css('.pagination__last-page-link')).nativeElement;

    expect(component.countPerPage).toEqual(20);
    expect(component.totalCount).toEqual(211);
    expect(component.totalNumberOfPages).toEqual(11);
    expect(input).toBeTruthy();
    expect(totalPAgeTextNode).toBeTruthy();
    expect(totalPAgeTextNode.innerText).toEqual(component.totalNumberOfPages.toString());
  }));

  it("should navigate page properly", fakeAsync(() => {
    component.totalCount = 211;
    component.countPerPage = 20;
    component.generate();
    fixture.detectChanges();
    let cp = component.currentPageNumber;
    component.nextPageNumber();
    cp = cp + 1;
    expect(component.currentPageNumber).toEqual(cp)
    let rightArrow: HTMLElement = fixture.debugElement.query(By.css('[title="Next"]')).nativeElement;
    let LeftArrow: HTMLElement = fixture.debugElement.query(By.css('[title="Back"]')).nativeElement;
    let pageInput: HTMLElement = fixture.debugElement.query(By.css('.pagination__input-page-number')).nativeElement;
    let LastpageLink: HTMLElement = fixture.debugElement.query(By.css('.pagination__last-page-link')).nativeElement;
    rightArrow.click();
    tick();

    cp = cp + 1;
    expect(component.currentPageNumber).toEqual(cp)
    expect(component.currentPageNumber).toBe(3)
    component.previousPageNumber();
    cp = cp - 1;
    expect(component.currentPageNumber).toEqual(cp)

    LeftArrow.click();
    tick();
    cp = cp - 1;
    expect(component.currentPageNumber).toEqual(cp)
    expect(component.currentPageNumber).toBe(1)
    expect(LeftArrow.className).toContain('pagination__arrow-icon-disabled');
    expect(rightArrow.className).not.toContain('pagination__arrow-icon-disabled');
    LastpageLink.click();
    tick();

    expect(component.currentPageNumber).toEqual(11)
    expect(component.isRightArrowDisabled).toBeTrue();
  }))

});
