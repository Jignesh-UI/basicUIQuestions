import { OnChanges } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { Component, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { LightboxService } from 'src/app/modules/lightbox/lightbox.service';
import { PopUpService } from 'src/app/shared/services/pop-up.service';

@Component({
  selector: 'app-asset-pagination',
  templateUrl: './asset-pagination.component.html',
  styleUrls: ['./asset-pagination.component.scss']
})

export class AssetPaginationComponent implements OnInit, OnChanges {


  @Input('total') public totalCount: number = -1;
  @Input('perpage') public countPerPage: number;
  @Input('page') public page: number = 1;

  @Output('onPageChange') public onPageChange: EventEmitter<any> = new EventEmitter<any>();

  public totalNumberOfPages: number = 0;
  @Input('page') public currentPageNumber: number = 1;
  public isReadOnlyTextBox: boolean = false;

  constructor(private lightboxService: LightboxService, private popupService: PopUpService) { }

  ngOnInit(): void {
    this.generate();
  }


  ngOnChanges(changes: SimpleChanges) {
    this.generate();
  }

  public generate() {
    this.totalNumberOfPages = Math.ceil(this.totalCount / this.countPerPage);
    return this.totalNumberOfPages;
  }

  restrict(callback) {
    if (this.lightboxService.selectedAssets.length > 0) {
      this.popupService.showConfirmDialog(
        "This option will de-select any assets you have selected.",
        (confirmState) => {
          callback.call(this);
        },
        (cancelState) => {
          //Do nothing
        },
        "Continue",
        "Undo options"
      );
    } else {
      callback()
    }
  }

  public nextPageNumber() {
    this.currentPageNumber = this.currentPageNumber + 1;
    this.changePageNumber(this.currentPageNumber);
  }

  public nextPageNumberWithRestrict() {
    if (this.isRightArrowDisabled) {
      return false;
    }

    this.restrict(() => {
      this.nextPageNumber();
    })
  }

  public previousPageNumberWithRestrict() {
    if (this.isLeftArrowDisabled) {
      return false;
    }

    this.restrict(() => {
      this.previousPageNumber();
    })
  }

  public previousPageNumber() {
    this.currentPageNumber = this.currentPageNumber - 1;
    this.changePageNumber(this.currentPageNumber);
  }

  public goToSpecificPageWithRestrict(e) {
    if (e.which === 13) {
      this.restrict(() => {
        this.goToSpecificPage();
      })
    }
  }

  public goToSpecificPage() {
    this.isReadOnlyTextBox = true;

    if (this.currentPageNumber <= 0) {
      this.changePageNumber(1);
      this.currentPageNumber = 1;
    } else {
      this.whenPageNumberIsPositive();
    }

    this.isReadOnlyTextBox = false;
  }

  public whenPageNumberIsPositive() {
    if (this.currentPageNumber >= this.totalNumberOfPages) {
      this.currentPageNumber = this.totalNumberOfPages;
    }

    this.changePageNumber(this.currentPageNumber);
  }

  public get isRightArrowDisabled() {
    return this.currentPageNumber >= this.totalNumberOfPages;
  }

  public get isLeftArrowDisabled() {
    return this.currentPageNumber <= 1;
  }

  public get shouldShowPagination() {
    return this.totalCount > 0;
  }

  public goToLastPageWithRestrict() {
    this.restrict(() => {
      this.goToLastPage();
    })
  }
  public goToLastPage() {
    this.currentPageNumber = this.totalNumberOfPages;
    this.changePageNumber(this.totalNumberOfPages);
  }

  public changePageNumber(pageNumber) {
    this.lightboxService.isGalleryAssetRequiredToClear = true;
    this.lightboxService.clearSelectedAssets();
    this.onPageChange.emit(pageNumber);
  }

  public get isLastPageLinkDisabled() {
    return this.currentPageNumber >= this.totalNumberOfPages;
  }
}
