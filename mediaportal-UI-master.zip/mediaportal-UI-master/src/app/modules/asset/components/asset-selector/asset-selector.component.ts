import { Component, OnInit } from '@angular/core';
import { APP_EVENTS } from 'src/app/app-defaults';
import { LightboxService } from 'src/app/modules/lightbox/lightbox.service';
import { Broadcast } from 'src/app/shared/services/broadcast.service';
import { SearchHelperService } from 'src/app/shared/services/search/search-helper.service';

@Component({
  selector: 'app-asset-selector',
  templateUrl: './asset-selector.component.html',
  styleUrls: ['./asset-selector.component.scss']
})
export class AssetSelectorComponent implements OnInit {

  public selectedAction: string = '';
  public tooltipPos = "above";

  constructor(private lightboxService: LightboxService,
    private event: Broadcast, private searchService: SearchHelperService) { }

  ngOnInit(): void {
  }

  change() {
    let pos = ['above'];
    this.tooltipPos = 'above';
  }

  public checkForReset() {
    if (this.lightboxService.isGalleryAssetRequiredToClear) {
      this.selectedAction = '0';
    }
  }

  public changeSelectionState() {
    //add all
    if (this.selectedAction === '1') {
      this.event.broadcast(APP_EVENTS.ASSET_LIST_STATE_CHANGE, { action: 'SELECT_ALL', data: null })
      // this.lightboxService.selectedAssets = this.searchService.getAssets();
    } else if (this.selectedAction === '2') {
      //clear all and reset option
      // this.lightboxService.selectedAssets = [];
      this.event.broadcast(APP_EVENTS.ASSET_LIST_STATE_CHANGE, { action: 'DESELECT_ALL', data: null })
    }

    setTimeout(() => {
      this.selectedAction = '';
    }, 50)

    // this.unwatch = this.$scope.$watch(
    //   'vm.lightboxService.isGalleryAssetRequiredToClear', () => {
    //     this.checkForReset();
    //   }
    // );
  }

  public isAssetCheckboxEnabled() {
    return this.lightboxService.isAddAssetsCheckboxEnabled();
  }

  public getImageLocation() {
    return this.isAssetCheckboxEnabled() ? 'mint' : 'charcoal';
  }

  public getPromptText() {
    if (this.isAssetCheckboxEnabled()) {
      return 'Add asset(s) to selected lightbox.';
    } else {
      return 'Select a lightbox first.'
    }
  }

  public addMultipleAsset(e) {
    e.preventDefault()
    this.lightboxService.isGalleryAssetRequiredToClear = true;
    if (this.lightboxService.lightboxModel.lightBoxId && this.lightboxService.selectedAssets.length > 0) {
      this.lightboxService.addAsset(this.lightboxService.selectedAssets);
    } else {
      this.lightboxService.clearSelectedAssets();
    }
  }

  get addImage() {
    let location = this.getImageLocation();
    return `assets/img/icons/42x42/${location}/42x42-asset-add.png`;
  }

}
