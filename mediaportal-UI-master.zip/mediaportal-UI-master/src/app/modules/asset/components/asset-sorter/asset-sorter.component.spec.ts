import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetSorterComponent } from './asset-sorter.component';

describe('AssetSorterComponent', () => {
  let component: AssetSorterComponent;
  let fixture: ComponentFixture<AssetSorterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetSorterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetSorterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
