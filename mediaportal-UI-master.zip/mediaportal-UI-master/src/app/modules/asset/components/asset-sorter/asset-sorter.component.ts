import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { SearchHelperService } from 'src/app/shared/services/search/search-helper.service';

const DATE_IMPORTED = "ARTESIA.FIELD.DATE IMPORTED";

@Component({
  selector: 'app-asset-sorter',
  templateUrl: './asset-sorter.component.html',
  styleUrls: ['./asset-sorter.component.scss']
})
export class AssetSorterComponent implements OnInit {

  @Input('disabled') public disabled: boolean = false;
  @Input('enable-provider-bu') public enableProviderBu: boolean = false;
  @Input('is-grid-view') public gridView: boolean = false;
  @Output('onChange') onChangeEvent: EventEmitter<any> = new EventEmitter<any>();

  public isGridView;
  public selectedSortField: string;

  constructor(private searchService: SearchHelperService) { }

  ngOnInit(): void {
    this.selectedSortField = DATE_IMPORTED;
    this.searchService.setSortField(this.selectedSortField);
  }

  public getSortImageSrc() {
    return this.searchService.getSortImageSrc();
  }

  public sortBasicSearch() {
    if (this.selectedSortField === DATE_IMPORTED) {
      this.searchService.setSortOrder('desc');
    } else {
      this.searchService.setSortOrder('asc');
    }
    this.searchService.setSortField(this.selectedSortField);
    this.searchService.sendUpdatedSearchRequest('freeTextSearch');
    this.onChangeEvent.emit('SORT_CHANGE')
  }

  public getSortOrderCallToAction() {
    return (this.searchService.getCurrentSortOrder() === 'desc') ? "Sort Ascending" : "Sort Descending";
  }

  public changeSortOrder() {
    if (this.searchService.getCurrentSortOrder() === 'desc') {
      this.searchService.setSortOrder('asc');
    } else {
      this.searchService.setSortOrder('desc');
    }
    this.searchService.sendUpdatedSearchRequest('freeTextSearch');
    this.onChangeEvent.emit('SORT_ORDER_CHANGE')
  }

}
