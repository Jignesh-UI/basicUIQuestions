import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetViewSettingsComponent } from './asset-view-settings.component';

describe('AssetViewSettingsComponent', () => {
  let component: AssetViewSettingsComponent;
  let fixture: ComponentFixture<AssetViewSettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetViewSettingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetViewSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
