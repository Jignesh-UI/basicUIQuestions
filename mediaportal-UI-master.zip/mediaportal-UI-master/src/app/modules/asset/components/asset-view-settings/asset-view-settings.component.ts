import { EventEmitter, HostListener } from '@angular/core';
import { Output } from '@angular/core';
import { Component, Input, OnInit } from '@angular/core';
import { APP_EVENTS, VIEW_TYPES } from 'src/app/app-defaults';
import { LightboxService } from 'src/app/modules/lightbox/lightbox.service';
import { Broadcast } from 'src/app/shared/services/broadcast.service';
import { PopUpService } from 'src/app/shared/services/pop-up.service';

@Component({
  selector: 'app-asset-view-settings',
  templateUrl: './asset-view-settings.component.html',
  styleUrls: ['./asset-view-settings.component.scss']
})
export class AssetViewSettingsComponent implements OnInit {

  public viewTypes = VIEW_TYPES;
  @Input('view') public view: string = VIEW_TYPES.grid;
  @Input('count') public countPerPage: number = 50;
  @Input('showOnHover') public showOnHover: boolean = true;
  public previousCountPerPage: number = 50;
  public previousView: string = this.view;
  public showpanel: boolean = false;

  public togglePanelView: string = '';

  @Output('onPageCountChange') public onPageCountChange: EventEmitter<any> = new EventEmitter<any>();
  @Output('onViewChange') public onViewTypeChanges: EventEmitter<string> = new EventEmitter<string>();
  @Output('onViewChangeLB') public onViewTypeChangesLB: EventEmitter<string> = new EventEmitter<string>();

  constructor(private lightboxService: LightboxService,
    private popupService: PopUpService, private event: Broadcast) { }

  @HostListener('mouseleave', ['$event']) onOut(e: any) {
    if (!(this.checkPos(e?.toElement?.className))) {
      this.showpanel = false;
    }
  }

  checkPos(classname) {
    let cls = ['cdk-overlay-backdrop', 'mat-option-text', 'mat-option'];
    if (classname === undefined) {
      return false;
    }
    return cls.some(item => classname.indexOf(item) >= 0)
  }

  ngOnInit(): void {
  }

  onViewChange() {
    this.previousView = this.view;
    this.onViewTypeChanges.emit(this.view)
  }

  onViewChangeLB(){
    this.previousView = this.view;
    this.onViewTypeChangesLB.emit(this.view);
  }

  get isGridView() {
    return this.previousView === VIEW_TYPES.grid
  }

  onOptionChange(viewChange = false) {
   
    if(!this.showOnHover){
      if(this.lightboxService.getSelectedAssets().length>0){
        this.popupService.showConfirmDialog(
          "This option will de-select any assets you have selected.",
          (confirmState) => { this.onSettingsChangeConfirmLightBox(viewChange) },
          (cancelState) => { this.noChangeInView() },
          "Continue",
          "Undo options"
        );
      }else {
        this.onSettingsChangeConfirmLightBox(viewChange);
      }
      return false;
    }
    // if (this.isGridView && this.lightboxService.selectedAssets.length > 0) {
    if (this.lightboxService.selectedAssets.length > 0) {
      this.popupService.showConfirmDialog(
        "This option will de-select any assets you have selected.",
        (confirmState) => { this.onSettingsChangeConfirm(viewChange) },
        (cancelState) => { this.noChangeInView() },
        "Continue",
        "Undo options"
      );
    } else {
      this.onSettingsChangeConfirm(viewChange);
    }

  }

  public onSettingsChangeConfirm(viewChange) {

    if (viewChange) {
      this.onViewChange();
    } else {
      this.previousCountPerPage = this.countPerPage;
      this.onPageCountChange.emit(this.countPerPage);
    }

    this.lightboxService.isGalleryAssetRequiredToClear = true;
    this.lightboxService.clearSelectedAssets();
    this.event.broadcast(APP_EVENTS.ASSET_LIST_STATE_CHANGE, {
      action: "DESELECT_ALL"
    });
  }

  onSettingsChangeConfirmLightBox(viewChange){
    if (viewChange) {
      this.onViewChangeLB();
    } else {
      this.previousCountPerPage = this.countPerPage;
      this.onPageCountChange.emit(this.countPerPage);
    }
    this.lightboxService.isGalleryAssetRequiredToClear = false;
    this.lightboxService.clearSelectedAssets();
    this.event.broadcast(APP_EVENTS.ON_LIGHTBOX_VIEW_CHANGE, this.view)
    
  }

  public noChangeInView() {
    this.view = this.previousView;
    this.countPerPage = this.previousCountPerPage;
  }

}
