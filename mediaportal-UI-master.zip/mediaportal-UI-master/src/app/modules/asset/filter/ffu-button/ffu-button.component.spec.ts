import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FfuButtonComponent } from './ffu-button.component';

describe('FfuButtonComponent', () => {
  let component: FfuButtonComponent;
  let fixture: ComponentFixture<FfuButtonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FfuButtonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FfuButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
