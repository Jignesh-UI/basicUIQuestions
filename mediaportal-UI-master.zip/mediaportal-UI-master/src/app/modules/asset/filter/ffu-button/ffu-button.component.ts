import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Broadcast } from 'src/app/shared/services/broadcast.service';
import { SearchHelperService } from 'src/app/shared/services/search/search-helper.service';
import { FILTER_EVENTS } from '../filter.events';

@Component({
  selector: 'app-ffu-button',
  templateUrl: './ffu-button.component.html',
  styleUrls: ['./ffu-button.component.scss']
})
export class FfuButtonComponent implements OnInit {

  public imgsrc = 'assets/img/icons/24x24/mint/24x24-close-delete.png';
  public activeImgsrc = 'assets/img/icons/24x24/charcoal/24x24-close-delete.png';
  public areRightsResultsHidden: boolean = false;
  public isMetaDataFieldHidden: Array<boolean> = new Array<boolean>();
  public upArrow = 'assets/img/icons/24x24/mint/24x24-arrow-up.png';
  public downArrow = 'assets/img/icons/24x24/mint/24x24-arrow-down.png';
  public searchRequestObject;
  public rightFilters: any[] = [];
  public META_DATA_FIELD_NAMES = {
    BUSINESS_UNIT_RIGHTS: "DAL.FIELD.BUSINESS UNIT RIGHTS",
    ADAPTATION_RIGHTS: "DAL.FIELD.ADAPTATION RIGHTS",
    USAGE_RESTRICTIONS: "DAL.FIELD.USAGE RESTRICTIONS"
  };

  @Output('label-click') public onLabelSelect = new EventEmitter()
  @Output('option-select') public onOptionSelect = new EventEmitter()
  @Input('filters') public filters: any[] = [];
  @Input('isRightFilterEnabled') public isRightFilterEnabled: boolean = false;


  constructor(public searchService: SearchHelperService, public event: Broadcast) { 
  }

  ngOnInit(): void {
  }

  filter(facetvalue) {
    facetvalue.checked = true;
    this.onLabelSelect.emit(facetvalue)
  }

  onFilterSelection($event) {
    this.onOptionSelect.emit('');
    
  }

  isKeyWordNull() {
    return this.searchService.isKeyWordNull();
  }

  public toggleSectoion(facet) {
    facet.expand = !facet.expand;
  }

  public onResetMetadata(e: MouseEvent, fieldRestrictionID) {
    e.preventDefault();
    e.stopPropagation();
    if (this.isRightFilterEnabled) {
      return false;
    } else {
      this.rightFilters = this.searchService.resetFieldFilters(fieldRestrictionID).getRightFilters();
      this.event.broadcast(FILTER_EVENTS.ON_FILTER, false)
    }
  }

  trackByFnValues(i, item) {
    return item.value;
  }

  trackByFnFacets(i, item) {
    return item.fieldId;
  }

  public disableRightsFilter(facetId){
    /*console.log("this.isRightFilterEnabled \
    || (facetId==this.META_DATA_FIELD_NAMES.USAGE_RESTRICTIONS && !this.searchService.SearchHelper_chkDUR) \
    || (facetId==this.META_DATA_FIELD_NAMES.ADAPTATION_RIGHTS && !this.searchService.SearchHelper_chkDAR)\
    || (facetId==this.META_DATA_FIELD_NAMES.BUSINESS_UNIT_RIGHTS && !this.searchService.SearchHelper_chkDBUR"
    +this.isRightFilterEnabled 
    || (facetId==this.META_DATA_FIELD_NAMES.USAGE_RESTRICTIONS && !this.searchService.SearchHelper_chkDUR) 
    || (facetId==this.META_DATA_FIELD_NAMES.ADAPTATION_RIGHTS && !this.searchService.SearchHelper_chkDAR)
    || (facetId==this.META_DATA_FIELD_NAMES.BUSINESS_UNIT_RIGHTS && !this.searchService.SearchHelper_chkDBUR))*/
    return this.isRightFilterEnabled 
    || (facetId==this.META_DATA_FIELD_NAMES.USAGE_RESTRICTIONS && !this.searchService.SearchHelper_chkDUR) 
    || (facetId==this.META_DATA_FIELD_NAMES.ADAPTATION_RIGHTS && !this.searchService.SearchHelper_chkDAR)
    || (facetId==this.META_DATA_FIELD_NAMES.BUSINESS_UNIT_RIGHTS && !this.searchService.SearchHelper_chkDBUR);
}

  public hideRightsFilter(facet){
    return (facet.valueList.length == 0 || 
      (facet.fieldId==this.META_DATA_FIELD_NAMES.USAGE_RESTRICTIONS && !this.searchService.SearchHelper_chkDUR))
  }
}