import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-filter-item',
  templateUrl: './filter-item.component.html',
  styleUrls: ['./filter-item.component.scss']
})
export class FilterItemComponent implements OnInit {

  @Input('value') public facetValue;
  @Output('filter') public filter = new EventEmitter();
  @Input('right-filter') public isRightFilterEnabled;
  @Output('change') public onFilterSelection = new EventEmitter();

  onChange() {
    this.onFilterSelection.emit('')
  }

  constructor() { }

  ngOnInit(): void {
  }

}
