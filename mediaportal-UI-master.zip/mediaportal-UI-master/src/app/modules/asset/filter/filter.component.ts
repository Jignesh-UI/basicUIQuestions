import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { debounceTime, switchMap } from 'rxjs/operators';
import { Broadcast } from 'src/app/shared/services/broadcast.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { SearchHelperService } from 'src/app/shared/services/search/search-helper.service';
import { FILTER_EVENTS } from './filter.events';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.scss']
})
export class FilterComponent implements OnInit, OnDestroy {

  constructor(public searchService: SearchHelperService, private event: Broadcast, public cs: CommonService) { }

  ngOnDestroy(): void {
    this.unsubscribes.forEach((item: Subscription) => {
      item.unsubscribe();
    })
  }

  public rightFilterStatus: string;
  public filterChanged: boolean = false;
  public filters: any[] = [];
  public rightFilters: any[] = [];
  public nonRightFilters: any[] = [];
  public unsubscribes: Subscription[] = [];
  chkDAR: boolean = false;
  chkDBUR: boolean = false;
  chkDUR: boolean = false;
  public adaptationRightsLabel = 'Disable Adaptation Rights';
  public adaptationRightsLabelSelected = 'Adaptation Rights Disabled';
  public businessUnitRightsLabel = 'Disable Business Unit Rights';
  public businessUnitRightsLabelSelected = 'Business Unit Rights Disabled';
  public usageRestrictionsLabel = 'Disable Usage Restrictions';
  public usageRestrictionsLabelSelected = 'Usage Restrictions Disabled';

  ngOnInit(): void {

    this.rightFilterStatus = this.searchService.ffuFilterStatus;

    this.unsubscribes.push(this.event.on(FILTER_EVENTS.ON_FILTER_CHANGE)
      .pipe(debounceTime(300)).subscribe((data: any) => {
        this.filterChanged = data.some(item => {
          return item.valueList.some(__item => __item.checked)
        })
      }))

    this.unsubscribes.push(this.event.on(FILTER_EVENTS.FILTER_OPTION_UPDATE)
      .subscribe(({ filters, rightFilters, nonRightFilters }) => {
        this.filters = filters;
        this.rightFilters = filters.filter(f => f.isRightsFilter)
        this.nonRightFilters = filters.filter(f => !f.isRightsFilter)
      }));

    this.unsubscribes.push(this.event.on(FILTER_EVENTS.RESET_RIGHT_FILTER)
      .subscribe((status: string) => {
        this.rightFilterStatus = status;
        this.searchService.setFfuFilterStatus(this.rightFilterStatus)
        this.searchService.toggleFfuFilter(true);
        this.resetExpandButton();
      }));
  }

  // Current search filter expand collapse
  public csi = {
    upArrow: '24x24-arrows-up.png',
    downArrow: '24x24-arrows-down.png',
    expanded: false,
    src: '24x24-arrows-up.png',
    title: 'Expand All'
  }

  //Rights filter expand collapse
  public rfi = {
    upArrow: '24x24-arrow-up.png',
    downArrow: '24x24-arrow-down.png',
    expanded: false,
    src: '24x24-arrow-up.png',
    title: 'Expand'
  }

  expandRightsFilters(expandAll: boolean = null) {
    this.rfi.expanded = expandAll === null ? !this.rfi.expanded : expandAll;
    this.rfi.src = this.rfi.expanded ? this.rfi.downArrow : this.rfi.upArrow;
    this.rfi.title = this.rfi.expanded ? 'Collapse' : 'Expand'
    if (expandAll !== null) return;
    this.searchService.expandFilters(this.rfi.expanded, true);
    this.event.broadcast(FILTER_EVENTS.FILTER_OPTION_UPDATE, this.searchService.getFilterOptions())
  }

  expandAll() {
    this.csi.expanded = !this.csi.expanded;
    this.csi.src = this.csi.expanded ? this.csi.downArrow : this.csi.upArrow;
    this.csi.title = this.csi.expanded ? 'Collapse All' : 'Expand All'
    this.expandRightsFilters(this.csi.expanded);
    this.searchService.expandFilters(this.csi.expanded);
    this.event.broadcast(FILTER_EVENTS.FILTER_OPTION_UPDATE, this.searchService.getFilterOptions())
  }

  resetExpandButton() {
    this.csi.expanded = false;
    this.csi.src = this.csi.expanded ? this.csi.downArrow : this.csi.upArrow;
    this.csi.title = this.csi.expanded ? 'Collapse All' : 'Expand All'

    this.rfi.expanded = false;
    this.rfi.src = this.rfi.expanded ? this.rfi.downArrow : this.rfi.upArrow;
    this.rfi.title = this.rfi.expanded ? 'Collapse' : 'Expand'
  }

  toggleRights() {
    this.searchService.setFfuFilterStatus('enabled');
    this.chkDAR = false;
    this.searchService.SearchHelper_chkDAR = this.chkDAR;
    this.chkDBUR = false;
    this.searchService.SearchHelper_chkDBUR = this.chkDBUR;
    this.chkDUR = false;
    this.searchService.SearchHelper_chkDUR = this.chkDUR;
    setTimeout(() => {
      this.searchService.toggleFfuFilter();
      this.event.broadcast(FILTER_EVENTS.ON_FILTER, false)
    }, 100);
  }

  get isRightFilterEnabled() {
    return this.searchService.rightFilterEnabled;
  }

  public isClickingFilterButtonEnabled() {
    return this.filterChanged;
  }

  private didUserSelectAnyFilterWhenFfuDisabled() {
    if (this.searchService.getUserSelectedFilters().length > 0) {
      return false;
    } else {
      return true;
    }
  }

  private didUserSelectAnyFilterWhenFfuEnabled() {
    if (this.searchService.getUserSelectedFilters().length > 0 || this.searchService.getUsageRestrictionsFilters().length > 0) {
      return false;
    } else {
      return true;
    }
  }

  public clearFilters() {
    this.searchService.clearAllFilters();
    this.searchService.resetFilterStates();
    this.searchService.filterUpdated = false;
    this.event.broadcast(FILTER_EVENTS.ON_FILTER, false)
  }

  filter(e) {
    this.searchService.resetFilters(this.filters)
    this.searchService.filterUpdated = true;
    this.event.broadcast(FILTER_EVENTS.ON_FILTER, false)
  }

  onOptionSelect(e) {
    this.event.broadcast(FILTER_EVENTS.ON_FILTER_CHANGE, this.filters)
  }

  get isKeyWordNull() {
    return this.searchService.isKeyWordNull();
  }

  get filterDisabled() {
    if (this.searchService.filterUpdated) return false;
    return (this.isRightFilterEnabled && !this.filterChanged) ||
      (!this.isRightFilterEnabled && !this.filterChanged) || this.isKeyWordNull;
  }


  onChangeDUR(){
    this.searchService.SearchHelper_chkDUR = this.chkDUR;
    this.searchService.manageRights();

    if(this.searchService.SearchHelper_chkDUR){
      this.event.broadcast(FILTER_EVENTS.ON_FILTER, true);
    }else{
      this.event.broadcast(FILTER_EVENTS.ON_FILTER, false);
    }

  }

  onChangeDAR(){
    this.searchService.SearchHelper_chkDAR = this.chkDAR;
    this.searchService.manageRights();

    if(this.searchService.SearchHelper_chkDAR){
      this.event.broadcast(FILTER_EVENTS.ON_FILTER, true);
    }else{
      this.event.broadcast(FILTER_EVENTS.ON_FILTER, false);
    }
  }

  onChangeDBUR(){
    this.searchService.SearchHelper_chkDBUR = this.chkDBUR;
    this.searchService.manageRights();

    if(this.searchService.SearchHelper_chkDBUR){
      this.event.broadcast(FILTER_EVENTS.ON_FILTER, true);
    }else{
      this.event.broadcast(FILTER_EVENTS.ON_FILTER, false);
    } 
  } 

}