export const FILTER_EVENTS = {
    ON_FILTER: 'ON_FILTER', //This event will trigger the filter API call and refresh the page with filtered data
    FILTER_OPTION_UPDATE: 'FILTER_OPTION_UPDATE', //This event will trigger the refresh the filter dom with the updated data
    ON_FILTER_CHANGE: 'ON_FILTER_CHANGE', //this event will trigger the check uncheck of any filter value and will update the filter dom with new data
    RESET_RIGHT_FILTER: 'RESET_RIGHT_FILTER'
}