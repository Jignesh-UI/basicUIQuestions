import { TestBed } from '@angular/core/testing';

import { QuickPrintServiceService } from './quick-print-service.service';

describe('QuickPrintServiceService', () => {
  let service: QuickPrintServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(QuickPrintServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
