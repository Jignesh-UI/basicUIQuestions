import { Injectable } from '@angular/core';
import * as _ from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class QuickPrintServiceService {

  private MISSING_VALUE_PLACEHOLDER = '-';

  public transformField(asset, field) {
    var assetDetailValue = _.result(_.find(asset.fields, { 'name': field }), 'value');
    return assetDetailValue || this.MISSING_VALUE_PLACEHOLDER;
  }

  public getQuickPrintDetails(quickPrintCategories, assetDetails) {
    var quickPrintDetails = [];
    _.forEach(quickPrintCategories, (field, key) => {
      let d = _.result(_.find(assetDetails.fields, { 'name': field }), 'value');
      quickPrintDetails.push({
        label: key,
        value: d
      })
    });

    return quickPrintDetails;
  }
}
