import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { QUICK_PRINT } from 'src/app/app-defaults';
import { ElementService } from 'src/app/shared/services/jQlite';
import { AssetDialogDataModel } from '../asset.defaults';
import { QuickPrintServiceService } from './quick-print-service.service';

@Component({
  selector: 'app-quick-print',
  templateUrl: './quick-print.component.html',
  styleUrls: ['./quick-print.component.scss']
})
export class QuickPrintComponent implements OnInit, OnDestroy {

  public asset;
  public assetDetails;
  public quickPrintDetails: any[] = [];
  public quickPrintCategories = QUICK_PRINT;
  public quickPrintThumbnailAlign = "start center";
  public quickPrintCharacterLimit = 381;
  public subscrition: Subscription;

  constructor(private quickPrintTransformService: QuickPrintServiceService,
    @Inject(MAT_DIALOG_DATA) public data: AssetDialogDataModel,
    private dialogRef: MatDialogRef<QuickPrintComponent>, public angular: ElementService) {
    this.asset = data.asset;
    this.assetDetails = data.assetDetails;
    this.subscrition = data.subscription;
    this.quickPrintDetails = this.quickPrintTransformService.getQuickPrintDetails(this.quickPrintCategories, this.assetDetails);
  }
  ngOnDestroy(): void {
    if (this.subscrition) this.subscrition.unsubscribe();
  }

  ngOnInit(): void {
    this.setThumbnailAlign();


    setTimeout(() => {
      let scrollEl = document.querySelector('.quick-print-dialog-container .mat-dialog-container');
      if (scrollEl) {
        scrollEl.scrollTop = 0;
      }
    }, 1000)
  }

  print() {
    let scrollEl = document.querySelector('.quick-print-dialog-container .mat-dialog-container');

    if (scrollEl) {
      scrollEl.scrollTop = 0;
    }

    setTimeout(() => {
      window.print();
    }, 200)
  }

  public setThumbnailAlign() {
    if (this.asset && this.asset.mediaType == "Audio") {
      this.quickPrintThumbnailAlign = "center center";
    }
  }

  public transformQuickPrintDetailsItem(assetDetailsObject, field) {
    let transformedItem = this.quickPrintTransformService.transformField(assetDetailsObject, field);
  }

  public formatLabel(text) {
    var replacedText = text.replace(/_/g, ' ');
    if (text != 'DAL_ID') {
      replacedText = replacedText.toLowerCase();
    }
    return replacedText;
  }

  public formatDescription(metaKey, metaValue) {
    if (metaKey == "DESCRIPTION" && metaValue.length > this.quickPrintCharacterLimit) {
      return metaValue.substring(0, this.quickPrintCharacterLimit) + '...';
    } else {
      return metaValue;
    }
  }

  public getPrintFormattedFileName() {
    var splitFileName = this.asset.fileName.split('.');
    return splitFileName.slice(0, splitFileName.length - 1).join('.');
  }

  public hideQuickprintDialog() {
    this.dialogRef.close()
  }

  public getCopyrightFriendlyUrl() {
    var copyrightFriendlyUrl;
    if (this.doesNotRequireWatermark()) {
      copyrightFriendlyUrl = (this.asset.thumbnailUrl) ? this.asset.thumbnailUrl : "";
    } else {
      copyrightFriendlyUrl = (this.asset.mediumResolutionUrl) ? this.asset.mediumResolutionUrl : "";
    }

    return copyrightFriendlyUrl;
  }

  private doesNotRequireWatermark() {
    var contentType = this.asset.contentType.toLowerCase();
    return (contentType === 'video' || contentType === 'audio');

  }

}
