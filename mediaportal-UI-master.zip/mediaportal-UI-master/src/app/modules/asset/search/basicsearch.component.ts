import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDrawer } from '@angular/material/sidenav';
import { ActivatedRoute, Router } from '@angular/router';
import { distinctUntilChanged } from 'rxjs/operators';
import { APP_EVENTS, VIEW_TYPES } from 'src/app/app-defaults';
import { ErrorTypes } from 'src/app/shared/components/errors/error-message/error-message.component';
import { AssetService } from 'src/app/shared/services/assets/assets.service';
import { Broadcast } from 'src/app/shared/services/broadcast.service';
import { CommonService, Unsubscriber } from 'src/app/shared/services/common.service';
import { SearchHelperService } from 'src/app/shared/services/search/search-helper.service';
import { LightboxService } from '../../lightbox/lightbox.service';
import { FILTER_EVENTS } from '../filter/filter.events';

const RADIO_BUTTON = {
  SELECTED: 'Selected',
  NOT_SELECTED: 'Not Selected',
  DISABLED: 'Disabled'
};

@Component({
  selector: 'app-basicsearch',
  templateUrl: './basicsearch.component.html',
  styleUrls: ['./basicsearch.component.scss']
})
export class BasicSearchComponent implements OnInit, OnDestroy {

  public view: string = VIEW_TYPES.grid;
  public keyword: string = '';
  private sbs: Unsubscriber;
  public assets: any[] = [];
  public totalAssetCount: number = 0;
  public currentPage: number = 1;
  public message: string = '';
  public messageType: string = '';
  public pagination = {
    total: 0,
    perPage: 0,
    page: 1
  }
  public freeTextSearch = 'freeTextSearch';
  public filterFreeTextSearch = 'filterFreeTextSearch';
  public filterSelected: boolean = false;

  public errorWithSupport: boolean = false;

  @ViewChild('drawer') public drawer: MatDrawer;

  public assetPerPage = 50;
  public searching: boolean = false;

  public areAllMetaDataFieldsHidden = true;
  public areRightsResultsHidden = true;
  public isFfuToggleEnabled = false;
  public upArrow = '24x24-arrow-up.png';
  public downArrow = '24x24-arrow-down.png';
  public allElementsUpArrow = '24x24-arrows-up.png';
  public allElementsDownArrow = '24x24-arrows-down.png';
  public leftArrow = '24x24-arrow-left.png';
  public rightArrow = '24x24-arrow-right.png';
  public searchRequestObject;
  public currentFFUDisabledState: string;
  public isMetaDataFieldHidden: Array<boolean> = new Array<boolean>();
  public metadataFieldName = {
    Model: "Model",
    Color: "Color B&W"
  };

  constructor(private route: ActivatedRoute, private event: Broadcast, private router: Router,
    private cs: CommonService, private as: AssetService, private searchService: SearchHelperService,
    private lightboxService: LightboxService) {
    this.sbs = this.cs.sbs();
  }

  ngOnInit(): void {

    this.event.on(APP_EVENTS.ASSET_LIST_STATE_CHANGE).subscribe(({ action, data }) => {
      let selectedAsset = [];
      if (action == 'SELECT_ALL') {
        this.assets.forEach(data => {
          data.selected = true
        })
        selectedAsset = this.assets;
      } else if (action == 'DESELECT_ALL') {
        this.assets.forEach(data => {
          data.selected = false
        })
      }
      selectedAsset = this.assets.filter(item => item.selected);
      this.lightboxService.addSelectedAsset(selectedAsset);
    });

    this.setMessage('');
    this.route.params.pipe(distinctUntilChanged()).subscribe(({ query }) => {
      this.searching = true;
      this.searchService.setBasicsearchJsonRequest({
        keyword: query
      });
      this.keyword = query;
      this.prepare();
      this.event.broadcast(FILTER_EVENTS.RESET_RIGHT_FILTER, 'enabled')
      this.event.broadcast(APP_EVENTS.SEARCH_VALUE_CHANGED, query)

      //reseting the pagination
      this.pagination.page = 1;
      this.searchService.setBasicsearchJsonRequest({
        pageNumber: 0 //Current page 1 mean the API request page number is 0
      });
      //Resetting the view

      this.search(false)
    });

    this.event.on(FILTER_EVENTS.ON_FILTER).subscribe(data => {
      //First reset the page no to 1 then go for API call
      this.onPageChange(1)
    });

  }

  prepare() {
    let emptyArray = [];

    this.searchService.setUserSelectedFilters(emptyArray);
    this.searchService.sendUpdatedSearchRequest(this.freeTextSearch)
    this.searchService.setUsageRestrictionFilters(emptyArray);
    this.searchService.setFilters(emptyArray);
    this.searchService.setAssets(emptyArray);
    this.searchService.setFacets(emptyArray);
    this.searchService.setTotalAssets(0);
    this.searchService.setBasicsearchJsonRequest({
      pageNumber: 0,
      facetRestrictionFields: []
    });
    this.searchService.setFfuFilterStatus("enabled");
  }

  beforeAPI() {
    let searchType;

    if (this.searchService.ffuFilterStatus === "enabled") {
      if (!this.searchService.isUserUsageRestrictionsLoaded()) {
        this.setSearchRequestOnFirstSearch();
        searchType = this.freeTextSearch;
      } else {
        this.setSearchRequestOnRefinementOfSearch();
        searchType = this.filterFreeTextSearch;
      }
    } else {
      this.setSearchRequestOnRefinementOfSearch();
      searchType = this.filterFreeTextSearch;
    }

    return searchType;
  }

  search(isFilter: boolean = false) {

    //remove all selected assets before search
    this.lightboxService.isGalleryAssetRequiredToClear = true;
    this.lightboxService.clearSelectedAssets();

    this.searching = true;
    this.resetMessage();
    this.searchService.keyword = this.keyword;

    let searchType;

    if (isFilter) {
      searchType = this.filterFreeTextSearch;
    } else if (this.searchService.getExistingFilters().length > 0) {
      searchType = this.filterFreeTextSearch;
    } else {
      searchType = this.freeTextSearch;
    }

    this.sbs.add(this.searchService.sendUpdatedSearchRequest(searchType)
      .search().subscribe((res) => {
        if (!isFilter) this.view = VIEW_TYPES.grid;
        this.searchService.fetchResponseData(res.data);
        this.success(res)
      }, (err) => {
        this.searchService.fetchResponseData(err);
        this.fail(err)
      }, () => {
        this.searchService.searchFinally();
      }));
  }

  filter(query = null) {
    this.resetMessage();
    this.searching = true;
    this.search(true);
  }

  onSortChange(e) {
    this.pagination.page = 1;
    this.searchService.setBasicsearchJsonRequest({
      pageNumber: 0 //Current page 1 mean the API request page number is 0
    });
    this.lightboxService.imidiatelyClearSelectedAsset();
    this.filter()
  }

  onPerPageChange(e) {
    this.assetPerPage = e;
    this.pagination.page = 1;
    this.pagination.perPage = this.assetPerPage;
    this.searchService.setBasicsearchJsonRequest({
      countPerPage: this.assetPerPage,
      pageNumber: 0 //Current page 1 mean the API request page number is 0
    });
    this.lightboxService.imidiatelyClearSelectedAsset();
    this.filter()
  }

  onPageChange(page) {
    this.pagination.page = page;
    page = page > 0 ? page - 1 : page;
    this.searchService.setBasicsearchJsonRequest({
      pageNumber: page
    });
    this.lightboxService.imidiatelyClearSelectedAsset();
    this.filter()
  }

  onViewChangeEvent(view) {
    this.lightboxService.imidiatelyClearSelectedAsset();
    this.view = view;
  }

  success(res) {
    let { data, succeeded, message } = res;
    this.searching = false;

    if (!succeeded) {
      this.assets = [];
      this.searchService.setAssets([]);
      this.errorWithSupport = true;
      this.messageType = ErrorTypes.error;
      this.pagination.total = 0;
    } else {
      this.assets = data.assets.map(asset => ({ ...asset, selected: false }));
      this.pagination.total = data.totalCount;
      this.pagination.perPage = this.assetPerPage;
    }

    this.searchService.searchSuccess(res);
    this.event.broadcast(FILTER_EVENTS.FILTER_OPTION_UPDATE, this.searchService.getFilterOptions())
  }

  fail(err) {
    console.error("Asset search request error", err)
    this.searching = false;
    this.errorWithSupport = true;
    this.assets = [];
  }

  setMessage(msg: string, type = ErrorTypes.info) {
    this.message = msg;
    this.messageType = type;
  }

  resetMessage() {
    this.message = '';
    this.messageType = '';
    this.errorWithSupport = false;
  }


  //NEW ELEMENTS
  public getBasicSearchResults() {

    if (this.keyword.length > 0) {
      this.isFfuToggleEnabled = true;
      this.setFilterDefaults();
      this.setSearchDefaults();
      this.search(true);
    } else {
      this.searchService.setTotalAssets(0);
    }

  }

  private setFilterDefaults() {
    this.searchService.clearAllFilters();
    this.searchService.toggleFfuFilter(true);
  }

  private setSearchDefaults() {
    this.searchService.setToggleSearchHeaderClass(true);
    this.searchService.setBasicsearchJsonRequest({
      'facetRestrictionFields': [],
      'keyword': this.keyword
    });
  }

  private setSearchRequestOnFirstSearch() {
    this.searchService.setIsFreeTextSearch(true);
    this.isFfuToggleEnabled = true;
    this.areAllMetaDataFieldsHidden = true;
    this.areRightsResultsHidden = true;
  }

  private setSearchRequestOnRefinementOfSearch() {
    this.searchService.setIsFreeTextSearch(false);

    if (!this.searchService.getIsFfuFilterDisabled()) {
      this.searchService.pushRightsFiltersInRequest();
    } else {
      this.searchService.combineAllFiltersForNewRequest();
    }
  }

  public fetchResponseOnSingleFilterClick(fieldRestrictionID, fieldRestrictionValue) {
    this.searchService.updateRequestOnSingleFilterClick(fieldRestrictionID, fieldRestrictionValue)
    this.filter();
  }


  public getMetaDataFieldArrowImageUrl(index) {
    return (this.isMetaDataFieldHidden[index]) ? this.upArrow : this.downArrow;
  }

  public toggleRightsFilterSectionVisibility() {
    this.areRightsResultsHidden = !this.areRightsResultsHidden;

    if (this.areRightsResultsHidden) {
      this.hideAllRightsFilters();
    } else {
      this.showAllRightsFilters();
    }
    return this.areRightsResultsHidden;
  }

  public getRightsArrowImageUrl(toggleArrow) {
    return (this[toggleArrow]) ? this.upArrow : this.downArrow;
  }

  public getRightsArrowCallToAction(toggleArrow) {
    return (this[toggleArrow]) ? 'Expand' : 'Collapse';
  }

  public toggleSidenavFiltersVisibiity() {
    this.areAllMetaDataFieldsHidden = !this.areAllMetaDataFieldsHidden;

    if (this.areAllMetaDataFieldsHidden) {
      this.areRightsResultsHidden = true;
      this.hideAllFilters();
    } else {
      this.areRightsResultsHidden = false;
      this.showAllFilters();
    }
  }

  public getAllSidenavFiltersArrowImageUrl() {
    return (this.areAllMetaDataFieldsHidden) ? this.allElementsUpArrow : this.allElementsDownArrow;
  }

  public getAllFiltersCallToAction() {
    return (this.areAllMetaDataFieldsHidden) ? 'Expand All' : 'Collapse All';
  }

  public toggleFfuAndSearch() {
    this.searchService.toggleFfuFilter();
    this.search();
  }

  public getAssets() {
    return this.searchService.getAssets();
  }

  public getTotalCountOfAssets() {
    return this.searchService.getTotalCountOfAssets();
  }

  public getToggleSearchHeaderClass() {
    return this.searchService.getToggleSearchHeaderClass();
  }

  public isFfuDisabledSelected() {
    if (this.getCurrentStateOfFfuDisabled() === RADIO_BUTTON.SELECTED) {
      return true;
    }
  }

  public isFfuDisabledNotSelected() {
    if (this.getCurrentStateOfFfuDisabled() === RADIO_BUTTON.NOT_SELECTED) {
      return true;
    }
  }

  public isFfuDisabledDisabled() {
    if (this.getCurrentStateOfFfuDisabled() === RADIO_BUTTON.DISABLED) {
      return true;
    }
  }

  public getCurrentStateOfFfuDisabled() {
    if (this.searchService.getIsFfuFilterDisabled() && this.isFfuToggleEnabled) {
      this.currentFFUDisabledState = RADIO_BUTTON.SELECTED;
    }
    if (!this.searchService.getIsFfuFilterDisabled() && this.isFfuToggleEnabled) {
      this.currentFFUDisabledState = RADIO_BUTTON.NOT_SELECTED;
    }
    if (!this.searchService.getIsFfuFilterDisabled() && !this.isFfuToggleEnabled) {
      this.currentFFUDisabledState = RADIO_BUTTON.DISABLED;
    }
    return this.currentFFUDisabledState;
  }



  public getIsSideNavHidden() {
    return this.searchService.getIsSideNavHidden();
  }

  public hideAllRightsFilters() {
    this.isMetaDataFieldHidden[0] = true;
    this.isMetaDataFieldHidden[1] = true;
    this.isMetaDataFieldHidden[2] = true;
  }

  public showAllRightsFilters() {
    this.isMetaDataFieldHidden[0] = false;
    this.isMetaDataFieldHidden[1] = false;
    this.isMetaDataFieldHidden[2] = false;
  }

  public hideAllFilters() {
    for (let i = 0; i < this.searchService.getFacets().length; i++) {
      this.isMetaDataFieldHidden[i] = true;
    }
  }

  public showAllFilters() {
    this.isMetaDataFieldHidden = new Array<boolean>();
  }

  private isRightsFilter(fieldPrompt) {
    if (fieldPrompt === 'Business Unit Rights' ||
      fieldPrompt === 'Adaptation Rights' ||
      fieldPrompt === 'Usage Restrictions'
    ) {
      return true;
    }

    return false;
  }

  ngOnDestroy() {
    this.searchService.reset();
    this.prepare();
    this.sbs.reset();
    this.message = '';
  }

}
