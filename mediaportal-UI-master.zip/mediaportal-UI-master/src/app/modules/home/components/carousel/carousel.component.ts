import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/shared/services/common.service';
import { ElementService } from 'src/app/shared/services/jQlite';
import { Utility } from 'src/app/shared/Utility';

@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.scss']
})
export class CarouselComponent implements OnInit, OnDestroy {

  public carouselImages: any[] = [];
  public updatedCarouselImages: Array<any> = new Array<any>();
  public leftSideOfCarousel: any;
  public rightSideOfCarousel: any;
  public centralImageId: string;
  public centralImageIndex: number;
  public centralImageWidth: number;
  public centralImageElement: any;
  public centralImageWrapperDiv: any;
  public leftPositionOfCentralImage: number;
  public widthOfViewport: number
  public startCarrousel: any;
  public widthOfLeftSideOfCarousel: number = 0;
  public subs;

  constructor(private angular: ElementService, private commonService: CommonService, private router: Router) {
    this.subs = this.commonService.sbs();
  }

  ngOnInit(): void {
    this.subs.add(this.commonService.getCarousel().subscribe((res: any) => {
      this.onCarouselImagesGot(res.data)
    }))
  }

  ngOnDestroy() {
    this.subs.reset();
    this.stopCarousel()
  }

  @Input() slides: any[] = [];

  $interval = {
    cancel: clearInterval,
    set: setInterval
  }

  private onCarouselImagesGot(carouselImages) {
    this.carouselImages = carouselImages;
    this.setImageCarouselDefaults();
    setTimeout(() => {
      this.checkIfCentralImageHasLoaded();
    }, 300)
  }

  private checkIfCentralImageHasLoaded() {

    this.centralImageElement = document.querySelector('#a' + this.centralImageId + ' > img');
    this.widthOfViewport = window.innerWidth;

    if (this.centralImageElement.width != 0) {
      this.setCSSProperties();
      this.startSlideSlow();
    } else {
      this.centralImageElement.onload = () => {
        this.setCSSProperties();
        this.startSlideSlow();
      }
    }
  }

  private stopCarousel() {
    this.$interval.cancel(this.startCarrousel);
  }

  private startSlideSlow() {
    this.startCarrousel = this.$interval.set(() => {
      this.nextSlide()
    }, 5000);
  }

  private setImageCarouselDefaults() {
    if (this.isNoOfImagesInCarouselOdd()) {
      this.centralImageIndex = Math.floor(this.carouselImages.length / 2);
    } else {
      this.centralImageIndex = this.carouselImages.length / 2;
    }
    this.updateImageCarousel();
    this.centralImageId = this.updatedCarouselImages[this.centralImageIndex].assetId;
  }

  private isNoOfImagesInCarouselOdd() {
    if (this.carouselImages.length % 2 === 0) {
      return false;
    }
    return true;
  }

  private updateImageCarousel() {
    if (this.isNoOfImagesInCarouselOdd()) {
      this.leftSideOfCarousel = this.carouselImages.slice(this.centralImageIndex + 1, this.carouselImages.length);
      this.rightSideOfCarousel = this.carouselImages.slice(1, this.centralImageIndex + 1);
    } else {
      this.leftSideOfCarousel = this.carouselImages.slice(this.centralImageIndex, this.carouselImages.length);
      this.rightSideOfCarousel = this.carouselImages.slice(1, this.centralImageIndex);
    }
    this.updatedCarouselImages = this.leftSideOfCarousel.concat(this.carouselImages[0], this.rightSideOfCarousel);
  }

  public nextSlide() {
    var elementToBePoppedFromLeft;

    // this.$interval.cancel(this.startCarrousel); //need to keep this for future ref, if some error comes have to revise 
    elementToBePoppedFromLeft = this.updatedCarouselImages[0];

    this.updatedCarouselImages = this.updatedCarouselImages.slice(1);
    this.updatedCarouselImages = this.updatedCarouselImages.concat(elementToBePoppedFromLeft);
    this.resetPositionOfCarouselImages();
    this.setCSSProperties();
    // this.startSlideSlow(); //need to keep this for future ref, if some error comes have to revise
  }

  public previousSlide() {
    var elementToBePoppedFromRight;

    this.$interval.cancel(this.startCarrousel);
    elementToBePoppedFromRight = this.updatedCarouselImages[this.carouselImages.length - 1];

    this.updatedCarouselImages.pop();
    this.updatedCarouselImages.unshift(elementToBePoppedFromRight);
    this.resetPositionOfCarouselImages();
    this.setCSSProperties();
    this.startSlideSlow();
  }

  private resetPositionOfCarouselImages() {
    this.centralImageId = this.updatedCarouselImages[this.centralImageIndex].assetId;
    this.leftSideOfCarousel = this.updatedCarouselImages.slice(0, this.centralImageIndex);
    this.rightSideOfCarousel = this.updatedCarouselImages.slice(this.centralImageIndex + 1, this.carouselImages.length);
  }

  private setCSSProperties() {
    this.setOpacityOfAllImages();
    this.removeOpacityOfCentralImage();
    this.setLeftPositionOfCentralImage();
    this.getWidthOfLeftSideOfCarousel();
    this.setLeftPositionOfLeftSideOfCarousel();
    this.setLeftPositionOfRightSideOfCarousel();
  }

  private setLeftPositionOfCentralImage() {
    this.centralImageElement = document.querySelector('#a' + this.centralImageId + ' > img');
    this.centralImageWrapperDiv = <any>this.angular.element(document.querySelector('#a' + this.centralImageId));
    this.centralImageWidth = this.centralImageElement.width;
    this.leftPositionOfCentralImage = (this.widthOfViewport - this.centralImageWidth) / 2;
    this.centralImageWrapperDiv.css({ 'left': this.leftPositionOfCentralImage + 'px' });
  }


  private getWidthOfLeftSideOfCarousel() {
    this.widthOfLeftSideOfCarousel = 0;
    var imageElement;

    Utility.each(this.leftSideOfCarousel, (image) => {
      imageElement = document.querySelector('#a' + image['assetId'] + ' > img');
      this.widthOfLeftSideOfCarousel = this.widthOfLeftSideOfCarousel + imageElement.width;
    });

    if (this.leftPositionOfCentralImage > 0) {
      this.widthOfLeftSideOfCarousel = this.widthOfLeftSideOfCarousel - this.leftPositionOfCentralImage;
    }
  }

  private setLeftPositionOfLeftSideOfCarousel() {
    var left;
    var imageWrapperDiv;
    var imageElement;
    left = this.widthOfLeftSideOfCarousel;

    Utility.each(this.leftSideOfCarousel, (image) => {
      imageWrapperDiv = <any>this.angular.element(document.querySelector('#a' + image['assetId']));
      imageElement = <any>this.angular.element(document.querySelector('#a' + image['assetId'] + ' > img'));
      imageWrapperDiv.css({ 'left': -left + 'px' });
      left = left - imageElement.width;
    });
  }

  private setLeftPositionOfRightSideOfCarousel() {
    var left;
    var imageWrapperDiv;
    var imageElement;
    left = this.leftPositionOfCentralImage + this.centralImageWidth;

    Utility.each(this.rightSideOfCarousel, (image) => {
      imageWrapperDiv = <any>this.angular.element(document.querySelector('#a' + image['assetId']));
      imageElement = <any>this.angular.element(document.querySelector('#a' + image['assetId'] + ' > img'));
      imageWrapperDiv.css({ 'left': left + 'px' });
      left = left + imageElement.width;
    });
  }

  private setOpacityOfAllImages() {
    this.angular.element(document.querySelectorAll('.homepage__image-tile > img') as any).css({ 'opacity': .3 });
  }

  private removeOpacityOfCentralImage() {
    this.angular.element(document.querySelector('#a' + this.centralImageId + ' > img')).css({ 'opacity': 1 });
  }


  public searchAsset(assetId) {
    if (assetId === this.centralImageId) {
      this.router.navigate(['basicsearch', assetId])
    }
  }
}