import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { SupportComponent } from 'src/app/modules/layout/components/support/support.component';
import { CommonService, Unsubscriber } from 'src/app/shared/services/common.service';
import { UserService } from 'src/app/shared/services/User/user.service';
import { TrainingService } from '../../training/training.service';
import { SystemNotificationService } from 'src/app/modules/login/components/system-notifcation/system-notification.service';

@Component({
  selector: 'app-home',
  templateUrl: "./home.component.html",
  styleUrls: ['./home.component.scss']
})

export class HomeComponent implements OnInit, OnDestroy {

  public name: string = '';
  public subs: Unsubscriber;
  trainingMaterials: any[] = [];

  constructor(
    private userService: UserService,
    private cs: CommonService,
    private router: Router,
    public dialog: MatDialog,
    private ts: TrainingService,
    private systemNotificationService: SystemNotificationService) {

    this.subs = this.cs.sbs();
  }

  ngOnInit() {
    this.name = this.userService.user.firstName;
    this.loadTrainings();
    this.showMNotify();
  }

  ngOnDestroy() {
    this.subs.reset();
  }

  public showSupportDialog() {
    const dialogRef = this.dialog.open(SupportComponent);

    dialogRef.afterClosed().subscribe(result => { });
  }

  public goToTrainings() {
    this.router.navigate(['training']);
  }

  public loadTrainings(){
    this.ts.maretial().subscribe(materials => {
      this.trainingMaterials = materials;
    });
  }

  public getFilenNameWithoutExtension(fileName) {
    return fileName.split(".")[0];
  }

  public showMNotify(){
    return this.systemNotificationService.getSysNotification();
  }

}
