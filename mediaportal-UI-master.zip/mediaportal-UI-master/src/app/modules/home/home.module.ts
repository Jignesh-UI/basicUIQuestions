import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { CarouselComponent } from './components/carousel/carousel.component';
import { ServiceModule } from 'src/app/shared/services/service.module';
import { AuthGuard } from 'src/app/shared/services/auth/guard.auth';
import { MaterialModule } from '../material/material.module';
import { LayoutModule } from '../layout/layout.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { TrainingComponent } from './training/training.component';
import { TrainingService } from './training/training.service';

const ROUTES: Routes = [
  {
    path: 'home',
    component: HomeComponent,
    canActivate: [AuthGuard]
  }
  , {
    path: 'training',
    component: TrainingComponent,
    canActivate: [AuthGuard]
  }
]

@NgModule({
  declarations: [HomeComponent, CarouselComponent, TrainingComponent],
  imports: [
    CommonModule,
    ServiceModule,
    RouterModule.forRoot(ROUTES, { useHash: true }),
    MaterialModule,
    SharedModule
  ],
  providers: [TrainingService]
})
export class HomeModule { }
