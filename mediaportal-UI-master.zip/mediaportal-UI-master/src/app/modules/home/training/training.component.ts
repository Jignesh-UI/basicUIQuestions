import { Component, OnInit } from '@angular/core';
import { CommonService, Unsubscriber } from 'src/app/shared/services/common.service';
import { TrainingService } from './training.service';

@Component({
  selector: 'app-training',
  templateUrl: './training.component.html',
  styleUrls: ['./training.component.scss']
})
export class TrainingComponent implements OnInit {

  trainingMaterials: any[] = [];
  public subs: Unsubscriber;


  constructor(private ts: TrainingService,private cs: CommonService) { 
    this.subs = this.cs.sbs();
  }

  ngOnInit(): void {
    this.ts.maretial().subscribe(materials => {
      this.trainingMaterials = materials;
    });
  }

  public getFilenNameWithoutExtension(fileName) {
    return fileName.split(".")[0];
  }

  public openPDF(fileName) {
    // var index = _.findIndex(this.trainingMaterials, (trainingMaterial: any) => {
    //   return trainingMaterial.fileName === fileName;
    // });

    // var url = this.trainingMaterials[index].originalAssetUrl;
    // this.$window.open(url);
  }

  ngOnDestroy() {
    this.subs.reset();
  }

}
