import { Injectable } from '@angular/core';
import { HttpService } from 'src/app/shared/services/http/http.service';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class TrainingService {

  constructor(private http: HttpService) { }

  maretial() {
    return this.http.get('trainingMaterials').pipe(map((result: any) => {
      return result.data;
    }));
  }
}
