import { Component, HostBinding, Input, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs/operators';
import { APP_EVENTS } from 'src/app/app-defaults';
import { Broadcast } from 'src/app/shared/services/broadcast.service';
import { ACTIONS } from 'src/app/shared/services/consts/actions.consts';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss']
})
export class LayoutComponent implements OnInit {

  isFlexContainer: boolean = false;
  className: string = '';
  keyword: string = '';
  isLogin: boolean = true;

  @Input('flex-container') public flexContainer = false;
  @HostBinding('class.home-layout') homeLayout: boolean = false;

  constructor(private router: Router, private route: ActivatedRoute, private event: Broadcast) { }

  ngOnInit(): void {
    this.event.on(APP_EVENTS.SEARCH_VALUE_CHANGED).subscribe((query: string) => this.keyword = query);
    this.router.events.pipe(filter((event: any) => event instanceof NavigationEnd))
      .subscribe(event => {
        if (event.url.indexOf('/login') >= 0 || event.url.indexOf('/faq') >= 0 || event.url == "/") {
          this.isLogin = true
          this.homeLayout = false;
          this.flexContainer = false;
        } else if (event.url.indexOf('/home') >= 0) {
          this.className = 'home-layout';
          this.homeLayout = true;
          this.flexContainer = true;
          this.isLogin = false
          this.keyword = '';
        } else {
          this.isLogin = false
          this.className = ''
          this.homeLayout = false;
          this.flexContainer = false;
        }
      });

    this.event.on(ACTIONS.logout).subscribe(() => {
      this.keyword = "";
      
    });
  }

}
