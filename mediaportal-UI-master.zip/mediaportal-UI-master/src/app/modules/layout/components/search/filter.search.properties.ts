export const filterSearchProperties = {
    noOfSuggestedWords: 20, // This is the property to fetch the records from API.
    minLength:3, // This property to set minimum required length to call API
    delayAPICall:500 // This property will delay the API call 
}