import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { debounceTime, distinctUntilChanged, map, startWith } from 'rxjs/operators';
import { CommonService, Unsubscriber } from 'src/app/shared/services/common.service';
import { filterSearchProperties } from './filter.search.properties';
import { HttpService } from 'src/app/shared/services/http/http.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit, OnDestroy {

  @Input() public keyword: string = '';
  private subs: Unsubscriber;
  public noofAutoComplete = filterSearchProperties.noOfSuggestedWords;
  public minLength = filterSearchProperties.minLength;
  public delayAPICAll = filterSearchProperties.delayAPICall;

  myControl = new FormControl();
  options: string[] = [];
  filteredOptions: string[];

  constructor(private router: Router, private route: ActivatedRoute, private cs: CommonService,
    private http: HttpService,
    private spinner: NgxSpinnerService) {
    this.subs = this.cs.sbs()
  }

  ngOnInit(): void {
    this.myControl.valueChanges.pipe(
      startWith(''),
      debounceTime(this.delayAPICAll),
      distinctUntilChanged(),
      map(value => {
        if (value.length > (this.minLength-1)) {
          this._filter(value);
          this.updateAutoCompleteList(value);
        } else {
          this.filteredOptions = [];
        }
      })
    ).subscribe((val) => {
    });
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.options.filter(option => option.toLowerCase().indexOf(filterValue) === 0);
  }

  search(e: Event = null) {
    if (e) e.preventDefault();
    let keyword = this.keyword.trim();
    if (keyword.replace(' ', '').length <= 0) return false;
    this.router.navigate(['basicsearch', keyword])
  }


  public fetchAutoCompleteList(searchKeyword: string, noOfList: number) {
    let payload = {
      'keyword': searchKeyword,
      'noOfSuggestedWords': noOfList
    };
    this.beforeCall();
    this.filteredOptions = [];
    return this.http.post('freeTextSearchSuggestion', payload);
  }

  public updateAutoCompleteList(searchKeyword: string) {
    this.fetchAutoCompleteList(
      searchKeyword.trim(),
      this.noofAutoComplete
    ).subscribe((res) => {
      this.afterCall();
      this.filteredOptions = res.data.suggestedKeywords.sort();
    });
  }

  beforeCall() {
    this.spinner.show();
  }

  afterCall() {
    this.spinner.hide();
  }

  customSearch(paramValue){
    if(paramValue.key === 'Enter') {
      this.search()
    }
  }

  ngOnDestroy() {
    this.subs.reset();
  }

}
