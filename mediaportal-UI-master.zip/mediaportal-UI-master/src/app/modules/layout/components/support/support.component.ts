import { Component, ElementRef, Inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { SupportRequest } from 'src/app/models/SupportRequest';
import SUPPORT_TYPES from 'src/app/models/SupportType';
import ASSET_SUPPORT_TYPES from 'src/app/models/AssetSupportTypes';
import SUPPORT_URGENCY from 'src/app/models/SupportUrgency';
import { FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Utility } from 'src/app/shared/Utility';
import { CommonService } from 'src/app/shared/services/common.service';
import { UserService } from 'src/app/shared/services/User/user.service';
import { AssetDialogDataModel } from 'src/app/modules/asset/asset.defaults';
import { Subscription } from 'rxjs/internal/Subscription';
import { MyLightboxNameErrorMatcher } from 'src/app/modules/lightbox/lightbox-form/lightbox-form.component';

@Component({
  selector: 'app-support',
  templateUrl: './support.component.html',
  styleUrls: ['./support.component.scss']
})
export class SupportComponent implements OnInit, OnDestroy {

  public supportTypes: any[] = Utility.Ob2Arr(SUPPORT_TYPES);
  public assetSupportTypes = Utility.Ob2Arr(ASSET_SUPPORT_TYPES);
  public supportUrgencies = Utility.Ob2Arr(SUPPORT_URGENCY);
  public supportRequest: SupportRequest;
  public onUserInfoPage: boolean = true;
  public businessUnits: string[] = [];
  public mailtoLink = '';

  @ViewChild('mailtoRef') public mailtoRef: ElementRef;

  //from dialog locals object
  private asset;
  private assetDetails;
  private subscrition: Subscription;

  public matcher = new MyLightboxNameErrorMatcher();

  constructor(private cs: CommonService, private us: UserService, public dref: MatDialogRef<SupportComponent>,
    @Inject(MAT_DIALOG_DATA) public data: AssetDialogDataModel) {
    this.supportRequest = new SupportRequest(this.us.user);
    if (this.data) {
      this.asset = this.data.asset;
      this.assetDetails = data.assetDetails;
      this.subscrition = data.subscription;
    }
  }

  ngOnDestroy(): void {
    this.subscrition ?? this.subscrition?.unsubscribe();
  }

  closeDialog(): void {
    this.dref.close();
  }

  ngOnInit(): void {
    this.cs.getPortalConfig('businessUnits')
      .subscribe((businessUnits: any[]) => {
        this.businessUnits = businessUnits;
        this.supportRequest.priority = SUPPORT_URGENCY.MEDIUM;
      });
    this.onUserInfoPage = true;
    if (this.asset) {
      this.supportTypes = this.assetSupportTypes;
      this.supportRequest.feedBack = true;
      this.supportRequest.fileName = this.asset.fileName;
      this.supportRequest.assetId = this.asset.assetId;
    }
  }

  showIssuePage(supportForm) {
    if (this.firstPageIsValid(supportForm)) {
      this.onUserInfoPage = false;
    }
  }

  private firstPageIsValid(supportForm) {
    let form: FormGroup = supportForm.form;
    return form.get('email').valid && form.get('businessUnits').valid && form.get('userName').valid;
  }

  showUserInfoPage() {
    this.onUserInfoPage = true;
  }

  submit(supportForm) {
    if (supportForm.form.valid) {
      let DAL_SUPPORT_EMAIL = 'DAL_Support@mheducation.com';
      let subject = `DALSupport: ${this.supportRequest.summary}`;
      let body = this.getEmailBody(this.supportRequest, this.asset);
      this.mailtoLink = `mailto:${DAL_SUPPORT_EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      setTimeout(() => {
        this.mailtoRef.nativeElement.click();
      }, 100)
      this.hideSupportDialog();
    }
  }

  private getEmailBody(supportRequest, asset) {

    var emailBody =

      `Name: ${supportRequest.userName}
Email: ${supportRequest.email}
Phone: ${supportRequest.phone}
Business Unit: ${supportRequest.businessUnit}
Priority: ${supportRequest.priority}
Description: ${supportRequest.description}
Summary: ${supportRequest.summary}
Issue Type: ${supportRequest.issueType}`

    if (asset) {
      emailBody += `\nFilename: ${supportRequest.fileName}\nAsset Id: ${supportRequest.assetId}`
    }

    return emailBody;
  }

  getPageTitle() {
    if (this.onUserInfoPage) {
      return "User Info";
    }

    return "Issue";
  }

  hideSupportDialog() {
    this.closeDialog();
  }

}
