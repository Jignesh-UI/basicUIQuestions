import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { LightboxService } from 'src/app/modules/lightbox/lightbox.service';
import { Broadcast } from 'src/app/shared/services/broadcast.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { ACTIONS } from 'src/app/shared/services/consts/actions.consts';
import { BusinessUnitService } from 'src/app/shared/services/User/business-unit.service';
import { User } from 'src/app/shared/services/User/User.model';
import { UserService } from 'src/app/shared/services/User/user.service';
import { SupportComponent } from '../support/support.component';
import { SystemNotificationService } from 'src/app/modules/login/components/system-notifcation/system-notification.service';

@Component({
  selector: 'app-uinfo',
  templateUrl: './uinfo.component.html',
  styleUrls: ['./uinfo.component.scss']
})

export class UinfoComponent implements OnInit, OnDestroy {

  public user: User;
  public businessUnits: string = '';
  public showBox: boolean = false;

  private ICON_PREFIX = 'assets/img/icons/24x24/roles/24x24-';
  private ICON_SUFFIX = '.png';
  private sbs = null;

  constructor(private userService: UserService, public dialog: MatDialog,
    private event: Broadcast, private cs: CommonService,
    public lightboxService: LightboxService, private bs: BusinessUnitService,
    private systemNotificationService: SystemNotificationService) {
    this.sbs = this.cs.sbs()
  }

  ngOnDestroy(): void {
    this.sbs.reset()
  }

  ngOnInit(): void {
    this.user = this.userService.user;
    this.sbs.add(this.event.on(ACTIONS.support).subscribe(data => {
      this.openSupportDialog();
    }))
  }

  getRoleIcon() {
    return this.ICON_PREFIX + this.userService.user.roleName.split(' ').join('').toLowerCase() + this.ICON_SUFFIX;
  }

  onClickUserInfo(state) {
    this.showBox = state;
  }

  openSupportDialog() {
    this.dialog.open(SupportComponent, {
      panelClass: 'support-dialog-container'
    });
  }

  logout() {
    //reset all services
    this.sbs.add(this.userService.logout().subscribe(res => {
      this.lightboxService.resetLightboxDefaults();
      this.lightboxService.reset();
      this.bs.resetBusinessUnit();
      this.event.broadcast(ACTIONS.logout, res);
    }));
    this.systemNotificationService.closeSysNotifiation(true);
  }
}
