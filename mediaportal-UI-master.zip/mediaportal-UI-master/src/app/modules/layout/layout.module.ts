import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LayoutComponent } from './components/layout/layout.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { SearchComponent } from './components/search/search.component';
import { UinfoComponent } from './components/uinfo/uinfo.component';
import { SupportComponent } from './components/support/support.component';
import { MaterialModule } from '../material/material.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { SpinnerComponent } from './spinner/spinner.component';
import { SpinnerService } from './spinner/spinner.service';
import { LightboxModule } from '../lightbox/lightbox.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';



@NgModule({
  declarations: [LayoutComponent, HeaderComponent, FooterComponent,
    SearchComponent, UinfoComponent, SupportComponent, SpinnerComponent],
  exports: [LayoutComponent, HeaderComponent, FooterComponent,
    SearchComponent, UinfoComponent, SupportComponent, SpinnerComponent],
  imports: [
    CommonModule,
    MaterialModule,
    SharedModule,
    LightboxModule,
    FormsModule,
    ReactiveFormsModule,
    MatAutocompleteModule
  ],
  providers: [SpinnerService]
})
export class LayoutModule { }
