import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonService, Unsubscriber } from 'src/app/shared/services/common.service';
import { SpinnerService } from './spinner.service';

@Component({
  selector: 'app-spinner',
  templateUrl: './spinner.component.html',
  styleUrls: ['./spinner.component.scss']
})
export class SpinnerComponent implements OnInit, OnDestroy {

  public loading: boolean = false;
  public unsubscriver: Unsubscriber;
  constructor(public spinnerService: SpinnerService, private cs: CommonService) {
    this.unsubscriver = this.cs.sbs();
  }

  ngOnDestroy(): void {
    this.unsubscriver.reset();
  }

  ngOnInit(): void {
    this.unsubscriver.add(this.spinnerService.service.subscribe(state => {
      this.loading = state
    }))
  }



}
