import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SpinnerService {

  constructor() { }

  private _spinnerService: Subject<boolean> = new Subject<boolean>();

  get service() {
    return this._spinnerService.asObservable();
  }

  public show() {
    this._spinnerService.next(true)
  }

  public hide() {
    this._spinnerService.next(false)
  }
}
