import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as _ from 'lodash';
import { APP_EVENTS } from 'src/app/app-defaults';
import { SearchCriteria } from 'src/app/models/CollaboratorModels';
import { Lightbox } from 'src/app/models/Lightbox';
import { CollaboratorDataModel } from 'src/app/models/PopupDataModels';
import ROLES from 'src/app/models/Roles';
import { ThingWithValue } from 'src/app/models/ThingWithValue';
import { Broadcast } from 'src/app/shared/services/broadcast.service';
import { unsubscribable } from 'src/app/shared/services/common.service';
import { PopUpService } from 'src/app/shared/services/pop-up.service';
import { BusinessUnitService } from 'src/app/shared/services/User/business-unit.service';
import { UserService } from 'src/app/shared/services/User/user.service';
import { LightboxService } from '../lightbox.service';
import { CollaboratorService } from './collaborator.service';

const LISTS = {
  COLLABORATORS: 1,
  FOUND: 2,
  OWNERS: 3
};

const MAX_LIST_SIZE = {};
MAX_LIST_SIZE[LISTS.COLLABORATORS] = 20;
MAX_LIST_SIZE[LISTS.OWNERS] = 10;

const DEFAULT_TOP_VALUE_OF_ELEMENT_BEING_DRAGGED = 0;

@Component({
  selector: 'app-collaborator',
  templateUrl: './collaborator.component.html',
  styleUrls: ['./collaborator.component.scss']
})
export class CollaboratorComponent implements OnInit, OnDestroy {

  public lightboxModel: Lightbox = new Lightbox();
  public searchCriteria: SearchCriteria = {
    firstName: '',
    lastName: '',
    businessUnit: '',
    roleName: ''
  };
  public foundUsers = [];
  public oneOrMoreSearchesSent: boolean = false;
  public requestOut: boolean = false;

  public collaborators;
  public owners;
  public lightbox;
  public userToListMap = {};
  public topMap = {};
  public dblClickedUserId;
  public latestSearchResults = [];
  public listLastRemovedFrom;

  public originalCollaborators = [];
  public originalOwners = [];
  public businessUnits: string[] = [];
  public collaboratorsModalPositionFromTop = 0;
  public heightOfCollaboratorsModal = 0;
  public heightOfWindow = 0;
  public isRemoveCollaboratorPopupOpen;

  public $timeout;
  public $window;
  public $document;
  public ubs = unsubscribable()

  constructor(
    public businessUnitsService: BusinessUnitService,
    public collaboratorService: CollaboratorService,
    public popupService: PopUpService,
    public userService: UserService,
    public lightboxService: LightboxService,
    @Inject(MAT_DIALOG_DATA) public data: CollaboratorDataModel,
    public event: Broadcast
  ) {
    this.$timeout = setTimeout;
    this.$window = window;
    this.$document = document;
    this.lightbox = data.lightbox
    this.isRemoveCollaboratorPopupOpen = data.isRemoveCollaboratorPopupOpen
  }

  ngOnInit() {

    this.userToListMap = {};
    this.topMap = {};
    this.collaborators = [...this.lightbox.collaborators]
    this.owners = [...this.lightbox.owners];

    _.each(this.collaborators, (collaborator: any) => {
      this.userToListMap[collaborator.userId] = LISTS.COLLABORATORS;
      this.topMap[collaborator.userId] = DEFAULT_TOP_VALUE_OF_ELEMENT_BEING_DRAGGED + 'px';
      this.originalCollaborators.push(collaborator);
    });

    _.each(this.owners, (owner: any) => {
      this.userToListMap[owner.userId] = LISTS.OWNERS;
      this.topMap[owner.userId] = DEFAULT_TOP_VALUE_OF_ELEMENT_BEING_DRAGGED + 'px';
      this.originalOwners.push(owner);
    });

    this.ubs.add(this.businessUnitsService.getBusinessUnits()
      .subscribe((businessUnits: any) => {
        console.log(businessUnits)
        this.businessUnits = businessUnits;
      }));

    this.getCollaboratorsModalPositionFromTop();
  }

  ngOnDestroy() {
    if (this.hasChangesToSave()) {
      this.restoreCollaboratorsAndOwners();
    }
    this.ubs.reset();
  }

  public getCollaboratorsModalPositionFromTop() {
  }

  public getRoles() {
    let roles = [];

    _.each(ROLES, (role: any) => {
      roles.push(role.displayFormat);
    });
    return roles;
  }

  public removeCollaborator() {
    this.requestOut = true;
    // let that = this;
    this.collaboratorService.removeCollaborator(this.lightbox.lightBoxId, this.userService.user.userId).then((data) => {
      if (data.succeeded) {
        this.requestOut = false;
        // _.remove(this.lightboxService.lightboxCollection, { lightBoxId: that.lightbox.lightBoxId });
        this.lightboxService.lightboxCollection = this.lightboxService.lightboxCollection.filter(item => {
          return item.lightBoxId != this.lightbox.lightBoxId;
        })
        this.lightboxService.lightboxModel = new Lightbox();
        this.lightboxService.resetLightboxDefaults();
        this.event.broadcast(APP_EVENTS.RESET_LIGHTBOX);
        let hideDialog = this.popupService.showSuccessDialog('You have removed yourself from the ' + data.data.name + ' lightbox.');
        this.$timeout(hideDialog, 2000);
        this.hideCollaboratorsSearchDialog();
      }
    });

  }

  public removeMeFromLightbox() {
    let matchedCollaborator;
    matchedCollaborator = <ThingWithValue>_.find(this.collaborators,
      { 'userId': this.userService.user.userId });
    if (!!matchedCollaborator) {

      this.removeCollaborator();
    }

  }

  drop(event: CdkDragDrop<any[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex);
    }
  }

  public search() {
    this.requestOut = true;
    this.oneOrMoreSearchesSent = false;
    this.collaboratorService.search(this.searchCriteria).then((searchResults) => {
      this.requestOut = false;
      this.oneOrMoreSearchesSent = true;
      this.setTopMap(searchResults);
      this.latestSearchResults = searchResults;

      this.foundUsers = this.manageTheSearchREsult(searchResults);
    });
  }

  manageTheSearchREsult(searchResults) {

    let collaborator_list = this.collaborators.map(user => user.userId);
    let owner_list = this.owners.map(user => user.userId);

    let list = searchResults.map(item => ({ ...item, isSearch: true }));

    list = _.reject(searchResults, (searchResult: any) => {

      let rejectUser = collaborator_list.indexOf(searchResult.userId) >= 0
        || owner_list.indexOf(searchResult.userId) >= 0;
      // let rejectUser = this.userToListMap[searchResult.userId] === LISTS.COLLABORATORS
      //   || this.userToListMap[searchResult.userId] === LISTS.OWNERS;

      if (rejectUser) {
        return true;
      }

      this.userToListMap[searchResult.userId] = LISTS.FOUND;

      return false;
    });

    return list;
  }

  public setTopMap(searchResults) {
    _.each(searchResults, (user: any) => {
      this.topMap[user.userId] = DEFAULT_TOP_VALUE_OF_ELEMENT_BEING_DRAGGED + 'px';
    });
  }

  public getIconInfo(info, roleName) {
    roleName = roleName.toLowerCase();
    return ROLES[roleName][info];
  }

  public getList(listEnum) {
    if (listEnum === LISTS.COLLABORATORS) {
      return this.collaborators;
    }

    if (listEnum === LISTS.FOUND) {
      return this.foundUsers;
    }

    return this.owners;
  }

  public onRemoveFromOwners(user) {
    if (user) {
      this.removeUser(user.userId, LISTS.OWNERS);
    }
  }

  public onRemoveFromCollaborators(user) {
    if (user) {
      this.removeUser(user.userId, LISTS.COLLABORATORS);
    }
  }

  public onRemoveFromFound(user) {
    if (user) {
      // this.removeUser(user.userId, LISTS.FOUND);
    }
  }

  public removeUser(userId, from = LISTS.OWNERS) {
    if (from) {
      let list = this.getList(from);
      if (!this.tryingToRemoveLastOwner(from, list)) {
        let user;

        if (from === LISTS.OWNERS) {
          user = this.owners.find(user => user.userId == userId)
          this.owners = this.owners.filter(user => user.userId != userId)
        }
        else if (from === LISTS.COLLABORATORS) {
          user = this.collaborators.find(user => user.userId == userId)
          this.collaborators = this.collaborators.filter(user => user.userId != userId)
        }
        else if (from === LISTS.FOUND) {
          // this.foundUsers = this.foundUsers.filter(user => user.userId != userId)
          // user = this.foundUsers.find(user => user.userId == userId);
        }

        this.listLastRemovedFrom = this.userToListMap[userId];
        delete this.userToListMap[userId];

        //This is to reappear the user which is in search result
        this.foundUsers = this.manageTheSearchREsult(this.latestSearchResults);
      }
    }
  }

  public tryingToRemoveLastOwner(from, list) {
    return from === LISTS.OWNERS && list.length === 1
  }

  public userFromLatestSearch(userId) {
    let index = _.findIndex(this.latestSearchResults, (user: any) => {
      return user.userId === userId;
    });

    return index > -1;
  }

  public hasChangesToSave() {
    if (_.isEqual(this.originalCollaborators, this.collaborators) &&
      _.isEqual(this.originalOwners, this.owners)
    ) {
      return false;
    }

    return true;
  }

  public update() {
    this.requestOut = true;
    this.collaboratorService.update(this.lightbox.lightBoxId, this.collaborators, this.owners).then((success) => {
      if (success) {
        this.updateOwner();
        this.lightbox.collaborators = this.collaborators;
        this.lightbox.owners = this.owners;
        this.originalOwners = this.owners;
        this.originalCollaborators = this.collaborators;
        this.hideCollaboratorsSearchDialog();
        let hideSuccessDialog = this.popupService.showSuccessDialog('Your collaborators were edited');
        this.$timeout(hideSuccessDialog, 2000);
      } else {
        let hideFailureDialog = this.popupService.showFailureDialog('There was an error!');
        this.$timeout(hideFailureDialog, 2000);

        this.restoreCollaboratorsAndOwners();
      }
    });
  }

  public updateOwner() {
    let currentOwnerUserIds = _.map(this.owners, 'userId');
    this.lightbox.owner =
      _.includes(
        currentOwnerUserIds,
        this.userService.user.userId
      );
  }

  public restoreCollaboratorsAndOwners() {
    this.originalCollaborators = this.collaborators;
    this.originalOwners = this.owners;
  }

  public hideCollaboratorsSearchDialog() {
    this.popupService.hideDialog();
  }

}
