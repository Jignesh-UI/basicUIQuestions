import { Injectable } from '@angular/core';
import * as _ from 'lodash';
import { HttpService } from 'src/app/shared/services/http/http.service';

@Injectable({
  providedIn: 'root'
})

export class CollaboratorService {

  constructor(public $http: HttpService) { }

  public search(criteria) {
    return this.$http.post('searchBusinessUnitUsers', criteria)
      .toPromise().then((res) => {
        if (res.succeeded) {
          return _.filter(res.data, (user: any) => {
            return user.roleName.toLowerCase() !== 'no access';
          });
        } else {
          return [];
        }
      });
  }

  public update(lightboxId, collaborators, owners) {
    var payload = {
      lightBoxId: lightboxId,
      collaborators,
      owners
    };

    return this.$http.post('lb/modifyOwnerCollaborator', payload).toPromise().then((res) => {
      return res.succeeded;
    });
  }

  public removeCollaborator(lightboxId, collaboratorId) {
    var payload = {
      lightBoxId: lightboxId,
      collaborators: [{ "userId": collaboratorId }]
    };

    return this.$http.post('lb/removeCollaborators', payload).toPromise();
  }

}
