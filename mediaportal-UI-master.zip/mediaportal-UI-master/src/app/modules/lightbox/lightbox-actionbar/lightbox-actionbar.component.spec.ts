import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LightboxActionbarComponent } from './lightbox-actionbar.component';

describe('LightboxActionbarComponent', () => {
  let component: LightboxActionbarComponent;
  let fixture: ComponentFixture<LightboxActionbarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LightboxActionbarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LightboxActionbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
