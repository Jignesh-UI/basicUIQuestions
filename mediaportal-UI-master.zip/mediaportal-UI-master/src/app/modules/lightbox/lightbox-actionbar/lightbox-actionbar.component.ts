import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import * as _ from 'lodash';
import { Subscription } from 'rxjs';
import { APP_EVENTS, LIGHTBOX_HEIGHTS, VIEW_TYPES } from 'src/app/app-defaults';
import { Asset } from 'src/app/models/Asset';
import { Lightbox } from 'src/app/models/Lightbox';
import { ThingWithValue } from 'src/app/models/ThingWithValue';
import { Broadcast } from 'src/app/shared/services/broadcast.service';
import { ElementService } from 'src/app/shared/services/jQlite';
import { PopUpService } from 'src/app/shared/services/pop-up.service';
import { UserService } from 'src/app/shared/services/User/user.service';
import { LightboxFormComponent } from '../lightbox-form/lightbox-form.component';
import { LightboxService } from '../lightbox.service';

@Component({
  selector: 'app-lightbox-actionbar',
  templateUrl: './lightbox-actionbar.component.html',
  styleUrls: ['./lightbox-actionbar.component.scss']
})
export class LightboxActionbarComponent implements OnInit {

  @Output('onCreated') public onCreated: EventEmitter<any> = new EventEmitter();
  public subscriptions: Subscription[] = [];

  public lightboxModel: Lightbox = new Lightbox();
  public isFullScreen: boolean = false;
  public isSingleRow: boolean = false;
  public isSettingsPanelVisible: boolean = false;
  public isFulfillPanelVisible: boolean = false;
  public isGridView: boolean = true;
  public isPanelBelow: boolean = false;
  public isDescendingOrder: boolean = true;
  public selectedSortField: string = null;
  public selectedSortFieldOldValue: string = null;
  public centerOfThePage: number;
  public LIGHTBOXBAR_MIN_HEIGHT: number = LIGHTBOX_HEIGHTS.LIGHTBOXBAR_MIN_HEIGHT;
  public LIGHTBOXBAR_FULLSCREEN_HEIGHT: number = LIGHTBOX_HEIGHTS.LIGHTBOXBAR_FULLSCREEN_HEIGHT();
  public LIGHTBOXBAR_SINGLEROW_HEIGHT: number = LIGHTBOX_HEIGHTS.LIGHTBOXBAR_SINGLEROW_HEIGHT;
  @Input('collections') public lightboxCollection: any[] = [];
  @Input('view') public view: string = VIEW_TYPES.grid;

  constructor(public lightboxService: LightboxService, public dialog: MatDialog,
    public angular: ElementService, public popupService: PopUpService, public event: Broadcast, public userService: UserService) { }

  public hideLightboxSize = false;
  public isUserIsCollaborator = false;

  public lightboxState = {
    selected: false
  };

  lightboxselected() {
    return this.lightboxState.selected;
  }

  ngOnInit(): void {

    this.setLightboxbarFullScreenHeight()
    this.event.on(APP_EVENTS.LIGHTBOX_ONCHANGE)
      .subscribe((lightbox: Lightbox) => {
        this.centerOfThePage = window.innerHeight / 2;
        this.lightboxModel = lightbox;
        this.isFulfillPanelVisible = this.isSettingsPanelVisible = false;
        // this.isUserIsCollaborator = this.isCollaborator(this.lightboxModel);
        this.lightboxState.selected = lightbox && lightbox.hasOwnProperty('lightBoxId') ? true : false
        this.onLightboxBarOffsetHeightChange((document.querySelector('lightbox-bar') as HTMLElement).offsetHeight)
      })
    this.event.on(APP_EVENTS.LIGHTBOX_STYLE_CHANGE)
      .subscribe((height) => {
        this.centerOfThePage = window.innerHeight / 2;
        this.onLightboxBarOffsetHeightChange(height)
      })
  }

  public onSettingPanelChange() {
    this.isSettingsPanelVisible = false;
  }

  public onLightboxBarOffsetHeightChange(newValue) {
    if (newValue < this.centerOfThePage) {
      this.isPanelBelow = false;
    } else {
      this.isPanelBelow = true;
    }
    this.updateLightboxPositionProperties(newValue);
  }

  public onLightboxesAreAvailable() {
    this.lightboxModel = this.lightboxService.lightboxModel;
    this.lightboxCollection = this.lightboxService.lightboxCollection;
    this.onLightboxSelect();
  }

  public setLightboxbarFullScreenHeight() {
    this.LIGHTBOXBAR_FULLSCREEN_HEIGHT = window.innerHeight - 100;
  }

  public populateLightboxBar() {
    this.lightboxModel = this.lightboxService.lightboxModel;
    this.lightboxCollection = this.lightboxService.lightboxCollection;
    this.onLightboxSelect();
  }

  public updateLightboxPositionProperties(newValue) {
    if (this.lightboxselected()) {
      this.isSingleRow = newValue === this.LIGHTBOXBAR_SINGLEROW_HEIGHT;
      this.isFullScreen = newValue >= this.LIGHTBOXBAR_FULLSCREEN_HEIGHT;
    }
  }

  public onLightboxSelect() {

    if (this.lightboxModel.hasOwnProperty('lightBoxId')) {
      this.validOptionSelection();
    } else if (!this.isAcutallyALightboxModel(this.lightboxModel)) {
      this.defaultOptionSelected();
    }
    this.lightboxService.selectedAssets = [];
    this.lightboxService.assetsSelectedToRemove = [];

  }

  public isAcutallyALightboxModel(lightboxModel) {
    let hasLightboxId = lightboxModel.hasOwnProperty('lightBoxId');

    return typeof lightboxModel === 'object' && hasLightboxId;
  }

  public validOptionSelection() {
    if (this.isSelectedLightboxDifferentFromPreviousOption()) {
      this.isFulfillPanelVisible = false;
      this.lightboxState.selected = true;
      this.lightboxService.lightboxModel = this.lightboxModel;
      this.lightboxService.onLightboxSelect(this.lightboxModel.lightBoxId);
    }
  }

  public isSelectedLightboxDifferentFromPreviousOption() {
    return this.lightboxService.lightboxModel.lightBoxId !== this.lightboxModel.lightBoxId
  }

  public defaultOptionSelected() {
    if (this.isSelectedLightboxDifferentFromPreviousOption()) {
      //TODO :  These values needed to be reset here as all the data is in the Service.We can get rid of it when we have this.angular.copy
      this.lightboxService.lightboxModel = {} as any;
      this.lightboxState.selected = false;
      this.lightboxService.resetLightboxDefaults();
    }
  }

  public removeMultipleAsset() {
    this.lightboxService.isGalleryAssetRequiredToClear = false;
    let lightboxService = this.lightboxService;
    if (lightboxService.lightboxModel.lightBoxId && lightboxService.assetsSelectedToRemove.length > 0) {
      lightboxService.removeAsset(lightboxService.assetsSelectedToRemove);
    } else {
      lightboxService.clearSelectedAssets();
    }
  }
  public isLightboxDeletable() {
    return this.lightboxService.isLightboxDeletable();
  }

  public isLightboxEditable() {
    return this.lightboxService.isLightboxEditable();
  }

  public isLightboxFulfillable() {
    return this.lightboxState.selected && this.lightboxService.allAssets.length > 0;
  }

  public canAddCollaborators() {
    return this.lightboxService.canAddCollaborators();
  }

  public canCollaboratorRemoveSelf(): any {
    return (this.lightboxService.lightboxModel.lightBoxId
      && this.lightboxService.lightboxModel.collaborators
      && this.isCollaborator(this.lightboxService.lightboxModel));
  }

  public get isEditCollaboratorIconEnabled() {
    if (this.canAddCollaborators()) {
      return true;
    } else if (this.canCollaboratorRemoveSelf()) {
      return true;
    } else {
      return false
    }
  }

  public getLightboxName() {
    return this.lightboxService.lightboxModel.name;
  }

  public deleteLightbox() {
    if (this.isLightboxEditable()) {
      this.lightboxService.deleteLightbox();
    }
  }

  public popupOnLightboxbarSettingsChange(isSortOderCliked) {
    if (this.isGridView && this.lightboxService.assetsSelectedToRemove.length > 0) {
      this.popupService.showConfirmDialog(
        "This option will de-select any assets you have selected.",
        () => { this.onSettingsChangeConfirm(isSortOderCliked) },
        () => { this.noChangeInView(isSortOderCliked) },
        "Continue",
        "Undo options"
      );
    } else {
      this.onSettingsChangeConfirm(isSortOderCliked);
    }
  }

  public onSettingsChangeConfirm(isSortOderCliked) {
    if (!isSortOderCliked) {
      this.applySort();
    } else {
      this.reverseSort();
    }
    this.lightboxService.isGalleryAssetRequiredToClear = false;
    this.lightboxService.clearSelectedAssets();
  }

  public noChangeInView(isSortOderCliked) {
    if (!isSortOderCliked) {
      this.selectedSortField = this.selectedSortFieldOldValue;
    }
  }

  public updateOldValue(oldValue) {
    this.selectedSortFieldOldValue = oldValue;
  }

  public applySort() {
    if (this.selectedSortField === 'DATE_ADDED_TO_LIGHTBOX') {
      this.isDescendingOrder = true;
      this.lightboxService.onLightboxSelect(this.lightboxService.lightboxModel.lightBoxId);
      return;
    }

    this.lightboxService.allAssets = _.sortBy(this.lightboxService.lightboxModel.assets, this.bySelectedSortField, this);
    this.lightboxService.pageNumber = 1;
    this.lightboxService.goToPageNumber(1);
  }

  public bySelectedSortField(o: Asset) {
    let a = new Array();
    a = _.where(o.fields, { 'name': this.selectedSortField });
    return a[0].value;
  }

  public reverseSort() {
    this.lightboxService.allAssets = this.lightboxService.allAssets.reverse();
    this.lightboxService.pageNumber = 1;
    this.lightboxService.goToPageNumber(1);
    this.isDescendingOrder = !this.isDescendingOrder;
  }

  public toggleSingleRow() {
    if (this.lightboxState.selected) {
      this.isSingleRow = !this.isSingleRow;
      this.isFullScreen = false;
      const lightboxbar = (document.querySelector('lightbox-bar') as HTMLElement);
      let height = 0;
      if (this.isSingleRow) {
        height = this.LIGHTBOXBAR_SINGLEROW_HEIGHT;
      } else {
        height = this.LIGHTBOXBAR_MIN_HEIGHT;
      }
      this.event.broadcast(APP_EVENTS.LIGHTBOX_STYLE_CHANGE, height)
      lightboxbar.style.height = height + 'px'
    }
  }

  public toggleFullScreen() {
    if (this.lightboxState.selected) {
      this.setLightboxbarFullScreenHeight();
      this.isFullScreen = !this.isFullScreen;
      this.isSingleRow = false;
      let height = 0;
      if (this.isFullScreen) {
        height = this.LIGHTBOXBAR_FULLSCREEN_HEIGHT;
      } else {
        height = this.LIGHTBOXBAR_MIN_HEIGHT;
      }
      this.event.broadcast(APP_EVENTS.LIGHTBOX_STYLE_CHANGE, height);
      (document.querySelector('lightbox-bar') as HTMLElement).style.height = height + 'px';
    }
  }

  public isDownloadable() {
    return !!this.lightboxService.lightboxModel.selfFulfill && this.lightboxModel.assets.length > 0;
  }

  // get some vals out of 259 generic "fields" array
  public hasUsageRestrictions(asset) {
    let restriction = <ThingWithValue>_.findWhere(asset.fields, { 'name': 'DAL.FIELD.ADAPTATION RIGHTS' });
    return restriction.value.toUpperCase() === 'N' ? false : true;
  }

  public getField(asset, fieldName) {
    let restriction = <ThingWithValue>_.findWhere(asset.fields, { 'name': fieldName });
    return restriction.value;
  }

  public viewStyleIcon() {
    return this.isGridView ? '&#xe135;' : '&#xe11d;';
  }

  public get getAllAssetsArray() {
    return this.lightboxService.getAllAssetsArray();
  }

  public getLightBoxSize() {
    let myCurrentSize = <any>parseFloat(this.lightboxService.lightboxModel.size).toFixed(2);
    let myDisplayString = '';

    this.hideLightboxSize = false;

    if (myCurrentSize < 1000) {
      myDisplayString = `${myCurrentSize} MB`;
    } else {
      //format the megabyte value to gigabyte display
      myCurrentSize = (myCurrentSize / 1000).toFixed(2);
      myDisplayString = `${myCurrentSize}`;

      if (myDisplayString === 'NaN') {
        this.hideLightboxSize = true;
      }

      //trim
      if (myDisplayString.charAt(myDisplayString.length - 1) === '0') {
        myDisplayString = myDisplayString.substr(0, myDisplayString.length - 1);
      }
      myDisplayString += ' GB';
    }

    return myDisplayString;
  }

  public getLightBoxLimit() {
    return (this.lightboxService.downloadSizeLimit / 1000).toFixed(1) + ' GB';
  }

  public isNearOrOverLimit() {
    return this.lightboxService.downloadSizeWarn < this.lightboxService.lightboxModel.size;
  }

  public getCurrentPageAssetsArray() {
    return this.lightboxService.getCurrentPageAssetsArray();
  }

  public toggleFulfillPanel() {
    if (this.lightboxState.selected) {
      if (this.lightboxService.hasAssets(this.lightboxService.lightboxModel)) {
        this.isSettingsPanelVisible = false;
        this.isFulfillPanelVisible = !this.isFulfillPanelVisible;
      } else {
        this.popupService.showFailureDialog("Denied. 0 assets in this lightbox");
      }
    }
  }

  public toggleSettingsPanel() {
    this.isFulfillPanelVisible = false;
    this.isSettingsPanelVisible = !this.isSettingsPanelVisible;
  }

  public showNewLightboxDialog() {
    let ref = this.dialog.open(LightboxFormComponent);
    let subsc = ref.afterClosed().subscribe(() => {
      this.onCreated.emit('success');
      subsc.unsubscribe();
    })
  }

  public editLightbox() {
    if (this.isLightboxEditable()) {
      this.popupService.showEditLightboxDialog(LightboxFormComponent);
    }
  }

  public cloneLightBox(){
    if (this.isLightboxEditable()) {
      this.popupService.showCloneLightboxDialog(LightboxFormComponent);
    }
  }

  public showCollaboratorsSearchDialog() {
    let lightboxModel = this.lightboxService.lightboxModel;
    if (this.canAddCollaborators()) {
      this.popupService.showCollaboratorsSearchDialog(lightboxModel, false);
    } else if (this.canCollaboratorRemoveSelf()) {
      this.popupService.showCollaboratorsSearchDialog(lightboxModel, true);
    }
  }

  public isCollaborator(lightboxModel) {
    let matchedCollaborator;

    if (lightboxModel.collaborators.length !== 0 && !lightboxModel.owner) {
      matchedCollaborator = <ThingWithValue>_.find(lightboxModel.collaborators,
        { 'userId': this.userService.userDetails.userId });
      return !!matchedCollaborator;
    }
    return false;
  }

  public isAwaitingApproval(lightbox) {
    return this.lightboxService.isAwaitingApproval(lightbox);
  }

  public isRecentlyFulfilled(lightbox) {
    return this.lightboxService.isRecentlyFulfilled(lightbox);
  }

  public shouldShowComments(lightbox) {
    if (this.lightboxService.isFulfilledOrRejected(lightbox) && this.lightboxService.hasComments(lightbox)) {
      return true;
    }

    return false;
  }

  public getComment(lightbox) {
    return this.lightboxService.getComment(lightbox);
  }

  public hasSelectedAssetsToRemove() {
    return this.lightboxService.isRemoveAssetsIconEnabled();
  }
}
