import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LightboxExportComponent } from './lightbox-export.component';

describe('LightboxExportComponent', () => {
  let component: LightboxExportComponent;
  let fixture: ComponentFixture<LightboxExportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LightboxExportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LightboxExportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
