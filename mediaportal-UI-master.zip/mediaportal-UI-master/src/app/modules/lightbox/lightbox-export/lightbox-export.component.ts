import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { PopUpService } from 'src/app/shared/services/pop-up.service';
import { LightboxService } from '../lightbox.service';

@Component({
  selector: 'app-lightbox-export',
  templateUrl: './lightbox-export.component.html',
  styleUrls: ['./lightbox-export.component.scss']
})
export class LightboxExportComponent implements OnInit {

  @Input('is-fulfill-panel-visible') public isFulfillPanelVisible;
  @Input('is-panel-below') public isPanelBelow;
  @Input('lightbox-state') public lightboxState;
  @Input('lightbox') public lightbox;
  public downloadQueue;
  public downloadSizeLimit = 4000;

  @Output('onSelect') public onSelect: EventEmitter<boolean> = new EventEmitter();

  constructor(public popupService: PopUpService, public lightboxService: LightboxService) { }

  ngOnInit(): void {
    this.downloadQueue = this.lightboxService.downloadQueue
  }

  public onSelectItem() {
    this.onSelect.emit(true);
  }

  public canDownload() {
    return this.canSelfFulfill()
      && this.lightboxService.lightboxModel.size < this.downloadSizeLimit;
  }

  public downloadLowRes() {
    this.hideFulfillmentPanel();
    this.lightboxService.downloadLowRes();
  };

  public downloadLightbox() {
    this.hideFulfillmentPanel();
    this.lightboxService.downloadLightbox();
  }

  public ftpLightbox() {
    this.hideFulfillmentPanel();
    this.lightboxService.ftpLightbox();
  }

  public canRequestFulfillment() {
    return this.lightboxService.canRequestFulfillment();
  }

  public isLightboxDownloading() {
    return this.lightboxService.isLightboxDownloading(this.lightboxService.lightboxModel.lightBoxId)
  }

  public requestFulfillment() {
    this.hideFulfillmentPanel();
    if (this.lightboxService.lightboxModel.assets.length != 0) {
      this.popupService.showRequestFulfillmentDialog(this.lightbox);
    }
  }

  public canSelfFulfill() {
    return this.lightboxService.canSelfFulfill();
  }

  //need to pass fulfillment related vars here so they can be updated in the modal
  public showFulfillmentApprovalDialog() {
    this.hideFulfillmentPanel();
    this.popupService.showFulfillmentApprovalDialog(this.lightbox);
  }

  public canFulfill() {
    return this.lightboxService.canFulfill(this.lightbox);
  }

  public hideFulfillmentPanel() {
    this.isFulfillPanelVisible = false;
    this.onSelectItem();
  }

}
