import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LightboxFormComponent } from './lightbox-form.component';

describe('LightboxFormComponent', () => {
  let component: LightboxFormComponent;
  let fixture: ComponentFixture<LightboxFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LightboxFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LightboxFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
