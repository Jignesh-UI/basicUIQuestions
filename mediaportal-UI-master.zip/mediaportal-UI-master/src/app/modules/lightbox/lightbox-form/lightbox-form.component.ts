import { Component, ElementRef, Inject, OnInit, ViewChild } from '@angular/core';
import { Lightbox } from 'src/app/models/Lightbox';
import * as _ from 'lodash';
import { LightboxService } from '../lightbox.service';
import { UserService } from 'src/app/shared/services/User/user.service';
import { ElementService } from 'src/app/shared/services/jQlite';
import { BusinessUnitService } from 'src/app/shared/services/User/business-unit.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { PopUpService } from 'src/app/shared/services/pop-up.service';
import { Broadcast } from 'src/app/shared/services/broadcast.service';
import { APP_EVENTS } from 'src/app/app-defaults';
import { ErrorStateMatcher } from '@angular/material/core';
import { FormControl, FormGroupDirective, NgForm } from '@angular/forms';

/** Error when invalid control is dirty, touched, or submitted. */
export class MyLightboxNameErrorMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isEmpty = control.value?.replace(/\s+/g, '') === ''
    isEmpty && control.setErrors({
      'empty': isEmpty
    })
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-lightbox-form',
  templateUrl: './lightbox-form.component.html',
  styleUrls: ['./lightbox-form.component.scss']
})
export class LightboxFormComponent implements OnInit {

  public matcher = new MyLightboxNameErrorMatcher();

  public lightboxModel: Lightbox = new Lightbox();
  public businessUnits: string[] = [];
  public startDate: Date;
  public minDate: Date;
  public maxDate: Date;
  public createNewLightboxRequestObject: {};
  public requestPending = false;
  public lightboxState;
  public edit: boolean = false;
  public cloneLBFlag: boolean = false;
  public lightbox: any = {};
  public currentSysDate: Date;
  public isMaxExpiryDateOk = true;
  public title: string = "New Lightbox";
  public btnTitle: string = "Create";
  public validateName: boolean = false;
  public errorLabel: string = "The lightbox name must be unique. Please update the lightbox name to proceed.";
  @ViewChild('lightboxName', {static: true}) lightboxName:any;

  constructor(public lightboxService: LightboxService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    @Inject(MAT_DIALOG_DATA) public dataClone: any,
    private popupService: PopUpService,
    private userService: UserService,
    private businessUnitsService: BusinessUnitService,
    private dialogRef: MatDialogRef<LightboxFormComponent>,
    private event: Broadcast) {
    this.edit = this.data?.edit;
    this.cloneLBFlag = this.dataClone?.clone;
    this.lightbox = Object.assign({}, this.lightboxService.lightboxModel);

    if (this.edit) {
      this.title = "Edit Lightbox";
      this.btnTitle = "Update";
      this.lightboxModel = Object.assign({}, this.lightboxModel, this.lightboxService.lightboxModel);
    }else if(this.cloneLBFlag){
      this.title = "Clone Lightbox";
      this.btnTitle = "Update";
      this.lightboxModel = Object.assign({}, this.lightboxModel, this.lightboxService.lightboxModel);
    }
    
  }

  ngOnInit(): void {
    this.businessUnitsService.getBusinessUnits().subscribe((data: any) => {
      this.businessUnits = data;
      this.lightboxModel.businessUnit = this.lightboxService.getModelAttr('businessUnit');
      this.setNewLightboxDefaults();
    }, this.businessUnitsService.errorGettingBusinessUnits);

    if (this.edit) {
      this.setEditLightboxDefaults();
    }
    if(this.cloneLBFlag){
      this.setCloneLightBoxDefaults();
    }

  }

  public isDateWithinMaxRange(currentdate) {
    return currentdate != null && currentdate.getTime && !isNaN(currentdate.getTime()) && this.maxDate >= currentdate;
  }

  public checkExpiryDate(editLightBoxForm) {
    let currentValue = new Date(this.lightboxModel.expiryDate);
    if (!this.isDateWithinMaxRange(currentValue)) {
      let hideDialog = this.popupService.showFailureDialog('Expiration date change failed. Change the expiration date to <365 days from current date.');
      setTimeout(() => {
        hideDialog()
      }, 5000);
    } else {
      if(this.cloneLBFlag){
        this.updateCloneLB(editLightBoxForm);
      }else if(this.edit){
        this.editLightbox(editLightBoxForm);
      }
    }
  }

  public update(form) {
    this.checkExpiryDate(form);
  }

  public updateClone(form){
    this.checkExpiryDate(form);
  }

  save(form) {
    if (form.invalid) return false;

    if(this.cloneLBFlag){
      if(this.listLightBoxNames()){
        this.focusErrorOnName(form);
        return false;
      } else{
        form.controls.lightboxName.setErrors(null);
        this.validateName = false;
      }
      this.updateClone(form);
      return false;
    }

    if (this.edit) {
      this.update(form);
    } else {
      this.createNewLightbox(form);
    }
  }

  private listLightBoxNames(){ 
    return this.lightboxService.lightboxCollection.filter((lbNames)=> {
      return lbNames.name.trim().toLowerCase() === this.lightboxModel.name.trim().toLowerCase()
    }).length > 0 ? true : false
  }

  private focusErrorOnName(form){ 
    form.controls.lightboxName.setErrors({'incorrect': true});
    this.validateName = true;
    this.lightboxName.nativeElement.focus();
  }

  public modelChangeFn(evt){
    this.validateName = false;
  }

  public editLightbox(editLightBoxForm) {
    this.lightboxService.editLightbox(
      this.lightboxService.getModelAttr('lightBoxId'),
      this.lightboxModel.name,
      this.lightboxModel.businessUnit,
      this.lightboxModel.description,
      this.getExpirationDate(),
      this.lightboxService.getModelAttr('startDate')
    ).subscribe((res) => {
      this.hideNewLightboxDialog();
      this.onLightboxEdited(res.data);
    });
  }

  public updateCloneLB(form){
    this.lightboxService.cloneLightbox(
      this.lightboxModel.name,
      this.lightboxModel.businessUnit,
      this.lightboxModel.description,
      this.getExpirationDate(),
      this.lightboxService.getModelAttr('startDate'),
      this.lightboxService.getModelAttr('lightBoxId')
      ).subscribe((res) => {
      this.hideNewLightboxDialog();
      this.onLightboxCloned(res.data);
    });
  }

  private onLightboxEdited(lightboxModel) {
    if (lightboxModel) {
      this.event.broadcast(APP_EVENTS.LIGHTBOX_ADDED, lightboxModel);

      var onLightboxSelect = this.lightboxService.onLightboxSelect(lightboxModel.lightBoxId);
      onLightboxSelect.subscribe(() => {
        var hideDialog = this.popupService.showSuccessDialog('Your lightbox ' + lightboxModel.name + ' was updated.');
        setTimeout(hideDialog, 2000);
      }, this.showErrorSavingEditsDialog);
    } else {
      this.showErrorSavingEditsDialog()
    }
  }

  private onLightboxCloned(lightboxModel) {
    if (lightboxModel) {
      this.event.broadcast(APP_EVENTS.LIGHTBOX_ADDED, lightboxModel);

      var onLightboxSelect = this.lightboxService.onLightboxSelect(lightboxModel.lightBoxId);
      onLightboxSelect.subscribe(() => {
        var hideDialog = this.popupService.showSuccessDialog('Your lightbox ' + lightboxModel.name + ' was created.');
        setTimeout(hideDialog, 2000);
      }, this.showErrorSavingEditsDialog);
    } else {
      this.showErrorSavingEditsDialog()
    }
  }

  private showErrorSavingEditsDialog() {
    this.popupService.showFailureDialog('There was an error updating your lightBox. Please try again');
    throw new Error('There was an error updating your lightBox. Please try again');
  }

  public setEditLightboxDefaults() {
    this.lightboxModel.name = this.lightboxService.getModelAttr('name');
    this.lightboxModel.businessUnit = this.lightboxService.getModelAttr('businessUnit');
    this.lightboxModel.description = this.lightboxService.getModelAttr('description');
    this.minDate = new Date();
    this.minDate.setDate(this.minDate.getDate() + 1);
    this.lightboxModel.expiryDate = new Date(this.lightboxService.getModelAttr('expiryDate'));
    this.currentSysDate = new Date(this.lightboxService.getModelAttr('currentSysDate'));
    this.maxDate = this.oneYearAndTwoDayFromCurrentSysDate();
  }

  public setCloneLightBoxDefaults(){
    this.lightboxModel.name = this.checkNameLength();
    this.lightboxModel.businessUnit = this.lightboxService.getModelAttr('businessUnit');
    this.lightboxModel.description = this.lightboxService.getModelAttr('description');
    this.minDate = new Date();
    this.lightboxModel.expiryDate = this.returnExpireyDateCloneLB();
    this.minDate.setDate(this.minDate.getDate() + 1);
    this.currentSysDate = new Date(this.lightboxService.getModelAttr('currentSysDate'));
    this.maxDate = this.oneYearAndTwoDayFromCurrentSysDate();
  }

  public checkNameLength(){
    let lbname = this.lightboxService.getModelAttr('name');
    if(lbname.length>99){
      lbname = lbname.substring(0,(lbname.length-10));
    }
    return lbname + " (CLONE)";
  }

  public oneYearAndTwoDayFromCurrentSysDate() {
    return new Date(
      this.currentSysDate.getFullYear() + 1,
      this.currentSysDate.getMonth(),
      this.currentSysDate.getDate() + 2
    );
  }

  public setNewLightboxDefaults() {
    this.lightboxModel.businessUnit = this.userService.getParticipatingBusinessUnit();
    this.minDate = new Date();
    this.minDate.setDate(this.minDate.getDate() + 1);
    this.maxDate = this.oneYearAndOneDayFromNow();
    if(!this.cloneLBFlag){
      this.lightboxModel.expiryDate = this.maxDate;
    }
  }

  private oneYearAndOneDayFromNow() {
    return new Date(
      this.minDate.getFullYear() + 1,
      this.minDate.getMonth(),
      this.minDate.getDate()
    );
  }

  private returnExpireyDateCloneLB() {
    let minimunDate= new Date();
    minimunDate.setDate(this.minDate.getDate() + 364);
    return new Date(
      minimunDate.getFullYear(),
      minimunDate.getMonth(),
      minimunDate.getDate()
    );
  }

  public createNewLightbox(newLightBoxForm) {
    this.onNewLightboxDialogHidden(newLightBoxForm);
    this.lightboxService.clearSelectedAssets();
  }

  private onNewLightboxDialogHidden(newLightBoxForm) {
    this.lightboxService.createNewLightbox(
      this.lightboxModel.name,
      this.lightboxModel.businessUnit,
      this.lightboxModel.description,
      this.getExpirationDate(),
      this.getStartDate()
    ).subscribe(res => {
      this.onNewLightboxCreated(res.data);
    }, this.onErrorCreatingNewLightbox);
  }

  private onNewLightboxCreated(lightboxModel) {
    if (!!lightboxModel) {
      this.selectNewlyCreatedLightbox(lightboxModel).subscribe(() => {
        this.resetLightboxDefaults();
        this.hideNewLightboxDialog();
        this.event.broadcast(APP_EVENTS.LIGHTBOX_ADDED, lightboxModel);
        let ref = this.popupService.showSuccessDialog('Your lightbox ' + lightboxModel.name + ' was created.');
        setTimeout(() => {
          ref();
        }, 2000)
      });
    } else {
      this.onErrorCreatingNewLightbox();
    }
  }


  private onErrorCreatingNewLightbox() {
    this.popupService.showFailureDialog('There was an error creating your lightbox. Please try again');
    throw new Error('There was an error creating your lightBox. Please try again');
  }

  private resetLightboxDefaults() {
    this.lightboxService.currentPageAssets = [];
    this.lightboxService.allAssets = [];
    this.lightboxService.pageNumber = 1;
    this.lightboxService.setTotalPageNumbers(0);
    this.lightboxService.totalItems = 0;
    
    (document.querySelector('lightbox-bar') as HTMLElement).style.height = '48px';
  }

  private selectNewlyCreatedLightbox(lightBoxModel) {
    this.lightboxService.lightboxCollection.push(lightBoxModel);
    this.lightboxService.lightboxModel = lightBoxModel;
    return this.lightboxService.onLightboxSelect(lightBoxModel.lightBoxId)
  }

  private getExpirationDate() {
    return this.getServerFormattedDate(this.lightboxModel.expiryDate);
  }

  private getStartDate() {
    return this.getServerFormattedDate(this.minDate);
  }


  private getServerFormattedDate(date: Date) {
    return (date.getMonth() + 1) + '/' + date.getDate() + '/' + date.getFullYear();
  }

  public hideNewLightboxDialog() {
    this.dialogRef.close()
  }

}
