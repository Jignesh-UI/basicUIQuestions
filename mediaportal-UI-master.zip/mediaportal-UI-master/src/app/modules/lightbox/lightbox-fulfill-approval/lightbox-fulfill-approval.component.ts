import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { APP_EVENTS } from 'src/app/app-defaults';
import { Lightbox } from 'src/app/models/Lightbox';
import { LightboxFulfillDataModel } from 'src/app/models/PopupDataModels';
import { Broadcast } from 'src/app/shared/services/broadcast.service';
import { PopUpService } from 'src/app/shared/services/pop-up.service';
import { MyLightboxNameErrorMatcher } from '../lightbox-form/lightbox-form.component';
import { LightboxService } from '../lightbox.service';

@Component({
  selector: 'app-lightbox-fulfill-approval',
  templateUrl: './lightbox-fulfill-approval.component.html',
  styleUrls: ['./lightbox-fulfill-approval.component.scss']
})
export class LightboxFulfillApprovalComponent implements OnInit {

  public matcher = new MyLightboxNameErrorMatcher();

  public comment: string = '';
  public approved: boolean = false;
  public notApproved: boolean = false;
  public lightbox: Lightbox;
  public requestOut: boolean = false;
  public $timeout = setTimeout;

  constructor(public lightboxService: LightboxService,
    public popupService: PopUpService,
    public event: Broadcast,
    @Inject(MAT_DIALOG_DATA) public data: LightboxFulfillDataModel) {
    this.lightbox = data.lightbox;
  }

  hsComment(comment) {
    return comment.trim();
  }

  ngOnInit(): void {
  }

  public submit(form) {
    if (this.approved || this.notApproved) {
      if ((this.notApproved && !this.comment) || (this.notApproved && !form.valid)) return false;
      this.approveFulfillment();
    }
  }

  public uncheckNotApproved() {
    this.notApproved = false;
  }

  public uncheckApproved() {
    this.approved = false;
  }

  public hasRequiredFields() {
    if (this.approved) {
      return true;
    } else if (this.notApproved && this.comment != undefined) {
      return true;
    }
    return false;
  }

  public hideFulfillmentApprovalDialog() {
    return this.popupService.hideDialog();
  }

  public approveFulfillment() {
    this.onLightboxFulfillmentApprovalDialogHidden(true);
  }

  public onLightboxFulfillmentApprovalDialogHidden(dialogIsHidden) {
    if (dialogIsHidden) {
      let actuallyApproved = this.approved || !this.notApproved;
      this.lightboxService.approveFulfillment(
        this.lightbox.lightBoxId,
        actuallyApproved,
        this.comment)
        .then((data) => {
          this.onLightboxFulfillmentApprovalCompleted(data);
        });
    } else {
      this.showErrorApprovingFulfilmentDialog()
    }
  }

  public onLightboxFulfillmentApprovalCompleted(succeeded) {
    if (succeeded) {
      let succesMessage = " ";

      if (this.approved) {
        succesMessage = "Your lightbox fulfillment approval was submitted";
      } else {
        succesMessage = "Your lightbox fulfillment denial was submitted";
      }
      this.lightboxService.getAvailableLightboxes().subscribe(() => {

        this.lightboxService.resetLightboxDefaults();
        this.lightboxService.lightboxModel = new Lightbox();
        let hideDialog = this.popupService.showSuccessDialog(succesMessage);

        this.event.broadcast(APP_EVENTS.LIGHTBOX_STYLE_CHANGE,
          (document.querySelector('lightbox-bar') as HTMLElement).clientHeight);
        this.event.broadcast(APP_EVENTS.RESET_LIGHTBOX, this.lightboxService.lightboxModel);

        this.$timeout(() => {
          hideDialog();
          this.hideFulfillmentApprovalDialog();
        }, 2000);

      }, this.showErrorApprovingFulfilmentDialog);
    } else {
      this.showErrorApprovingFulfilmentDialog()
    }
  }

  public showErrorApprovingFulfilmentDialog() {
    this.popupService.showFailureDialog('Error trying to fulfill lightbox.');
    throw new Error("error fulfilling lightbox");
  }
}
