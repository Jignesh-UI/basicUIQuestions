import { TestBed } from '@angular/core/testing';

import { FulfillService } from './fulfill.service';

describe('FulfillService', () => {
  let service: FulfillService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FulfillService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
