import { Injectable } from '@angular/core';
import * as _ from 'lodash';
import { HttpService } from 'src/app/shared/services/http/http.service';

@Injectable({
  providedIn: 'root'
})
export class FulfillService {

  constructor(private $http: HttpService) { }

  public search(criteria) {
    return this.$http.post('searchFullfiller', criteria).toPromise().then((res) => {
      if (res.succeeded) {
        return res.data;
      } else {
        return [];
      }
    });
  }

  public update(lightboxId, primaryUser, secondaryUser) {
    var payload = {
      lightBoxId: lightboxId,
      fullfillments: [
        {
          fullfiller: {
            userId: primaryUser.userId
          }
        }
      ]
    };

    if (secondaryUser) {
      _.extend(payload.fullfillments[0], {
        secondaryFullfiller: {
          userId: secondaryUser.userId
        }
      });
    }

    return this.$http.post('lb/createFullfillment', payload);
  }
}
