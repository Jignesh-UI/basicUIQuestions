import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LightboxFulfillComponent } from './lightbox-fulfill.component';

describe('LightboxFulfillComponent', () => {
  let component: LightboxFulfillComponent;
  let fixture: ComponentFixture<LightboxFulfillComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LightboxFulfillComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LightboxFulfillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
