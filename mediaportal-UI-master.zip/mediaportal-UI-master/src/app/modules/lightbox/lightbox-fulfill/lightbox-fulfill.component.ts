import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as _ from 'lodash';
import ROLES from 'src/app/models/Roles';
import { PopUpService } from 'src/app/shared/services/pop-up.service';
import { BusinessUnitService } from 'src/app/shared/services/User/business-unit.service';
import { LightboxService } from '../lightbox.service';
import { FulfillService } from './fulfill.service';
import { LightboxFulfillDataModel } from 'src/app/models/PopupDataModels';
import { SearchCriteria } from 'src/app/models/CollaboratorModels';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { Observable, Subscription } from 'rxjs';
import { Utility } from 'src/app/shared/Utility';

const DEFAULT_TOP_VALUE_FOR_ELEMENT_BEING_DRAGGED = 0;

@Component({
  selector: 'app-lightbox-fulfill',
  templateUrl: './lightbox-fulfill.component.html',
  styleUrls: ['./lightbox-fulfill.component.scss', '../collaborator/collaborator.component.scss']
})
export class LightboxFulfillComponent implements OnInit, OnDestroy {

  public searchCriteria: SearchCriteria = {
    firstName: '',
    lastName: '',
    businessUnit: ''
  };
  public oneOrMoreSearchesSent: boolean = false;
  public hasSearchResults: boolean = false;
  public isUserDoubleClicked: boolean = false;
  public requestOut: boolean = false;
  public foundUsers = [];
  public fulfillers = [];
  public originalFulfillers = [];
  public originalFoundUsers = [];
  public MAX_FULFILLERS = 2;
  public lightbox;
  public topMap = {};
  public businessUnits: string[] = [];
  public allFulfillersElements: any;
  public requestFulfillmentModalPositionFromTop = 0;
  public heightOfRequestFulfillmentModal = 0;
  public heightOfWindow = 0;

  public $timeout = setTimeout;
  public $window = window;
  public $document = window.document;
  public subs: Subscription[] = [];

  constructor(
    public businessUnitsService: BusinessUnitService,
    public fulfillmentService: FulfillService,
    public popupService: PopUpService,
    public lightboxService: LightboxService,
    @Inject(MAT_DIALOG_DATA) public data: LightboxFulfillDataModel,
    private dialog: MatDialogRef<LightboxFulfillComponent>
  ) {
    this.lightbox = data.lightbox;
    this.businessUnitsService.getBusinessUnits().subscribe((businessUnits: any) => {
      this.businessUnits = businessUnits;
    });
    this.topMap = {};
    this.getRequestFulfillmentModalPositionFromTop();
  }
  ngOnDestroy(): void {
    Utility.unsubscribeAll(this.subs)
  }

  ngOnInit(): void {
  }

  public getRequestFulfillmentModalPositionFromTop() {

  }

  public search() {
    this.requestOut = true;
    this.hasSearchResults = false;
    this.fulfillmentService.search(this.searchCriteria).then((searchResults) => {
      this.requestOut = false;
      this.originalFoundUsers = [];
      this.setOriginalFoundUsers(searchResults);
      this.setTopMap(searchResults);
      if (searchResults.length != 0) {
        this.hasSearchResults = true;
      }
      this.oneOrMoreSearchesSent = true;
      this.foundUsers = this.removeAlreadyAddedFulfillersFromSearchResults(searchResults);
    });
  }

  drop(event: CdkDragDrop<any[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex);
    }
  }

  public setTopMap(searchResults) {
    _.each(searchResults, (user: any) => {
      this.topMap[user.userId] = DEFAULT_TOP_VALUE_FOR_ELEMENT_BEING_DRAGGED + 'px';
    });
  }

  public setOriginalFoundUsers(searchResults) {
    _.each(searchResults, (user: any) => {
      this.originalFoundUsers.push(user.userId);
    });
  }

  public onRemoveFromSearchResults(user) {
    if (user && this.fulfillers.length != this.MAX_FULFILLERS) {
      this.removeUser(this.foundUsers, user);
    }
  }

  public removeAlreadyAddedFulfillersFromSearchResults(searchResults) {
    let primaryFulfiller = this.fulfillers[0];
    let secondaryFulfiller = this.fulfillers[1];

    if (!!primaryFulfiller) {
      this.removeUser(searchResults, primaryFulfiller);
      if (!!secondaryFulfiller) {
        this.removeUser(searchResults, secondaryFulfiller);
      }
    }
    return searchResults;
  }

  public onRemoveFromFulfillers(user) {
    if (user) {
      this.removeUser(this.fulfillers, user);
    }
  }

  public removeUser(list, userToBeRemoved) {
    let isUserinList = false;

    isUserinList = !!this.getUserFromList(list, userToBeRemoved.userId);
    if (isUserinList) {
      _.remove(list, { userId: userToBeRemoved.userId });
    }
  }

  public userFromLatestSearch(userId) {
    let index = _.findIndex(this.originalFoundUsers, (user) => {
      return user.userId === userId;
    });
    return index > -1;
  }

  public onDropToFulfillers(user) {
    if (user && this.fulfillers.length != this.MAX_FULFILLERS) {
      this.addUser(this.fulfillers, user);
    }
  }

  public addUser(list, userToBeAdded) {
    list.push(userToBeAdded);
  }

  public getUserFromList(list, userId) {
    let userFromList;

    _.each(list, (user: any) => {
      if (userId === user.userId) {
        userFromList = user;
      }
    });
    return userFromList;
  }

  public hasChangesToSave() {
    if (_.isEqual(this.originalFulfillers, this.fulfillers)) {
      return false;
    }
    return true;
  }

  public update() {

    this.onRequestFulfillmentDialogHidden()
  }

  public onRequestFulfillmentDialogHidden() {
    this.subs.push(this.fulfillmentService.update(this.lightbox.lightBoxId, this.fulfillers[0], this.fulfillers[1])
      .subscribe((res) => {
        console.log(res);
        this.onRequestFulfillmentCompleted(res?.succeeded)
      }, this.showErrorRequestingFulfilmentDialog));
  }

  public onRequestFulfillmentCompleted(succeeded) {
    if (succeeded) {
      this.lightboxService.getAvailableLightboxes().subscribe(data => {
        this.lightboxService.onLightboxSelect(this.lightbox.lightBoxId).subscribe(res => {
          let hideDialog = this.popupService.showSuccessDialog('Your fulfillment request has been submitted');
          this.$timeout(() => {
            hideDialog();
            this.dialog.close();
          }, 1000)

        }, this.showErrorRequestingFulfilmentDialog)
      }, this.showErrorRequestingFulfilmentDialog);
    } else {
      this.showErrorRequestingFulfilmentDialog()
    }
  }

  public showErrorRequestingFulfilmentDialog() {
    this.popupService.showFailureDialog("There was an error in sending your request");
    throw new Error("error requesting fulfillment");
  }

  public getIconInfo(info, roleName) {
    roleName = roleName.toLowerCase();
    return ROLES[roleName][info];
  }

  public hideRequestFulfillmentDialog() {
    this.dialog.close();
  }

  public isMaximumFulfillersReached() {
    if (this.fulfillers.length >= this.MAX_FULFILLERS) {
      return true;
    }
    return false;
  }

}
