import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LightboxPaginationComponent } from './lightbox-pagination.component';

describe('LightboxPaginationComponent', () => {
  let component: LightboxPaginationComponent;
  let fixture: ComponentFixture<LightboxPaginationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LightboxPaginationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LightboxPaginationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
