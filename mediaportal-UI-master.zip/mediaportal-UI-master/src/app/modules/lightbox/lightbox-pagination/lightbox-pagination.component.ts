import { Component, OnInit } from '@angular/core';
import { Lightbox } from 'src/app/models/Lightbox';
import { LightboxService } from '../lightbox.service';

@Component({
  selector: 'pagination-lightbox',
  templateUrl: './lightbox-pagination.component.html',
  styleUrls: ['./lightbox-pagination.component.scss',
    '../../asset/components/asset-pagination/asset-pagination.component.scss']
})
export class LightboxPaginationComponent implements OnInit {

  constructor(public pageableService: LightboxService) { }

  ngOnInit(): void {
  }

  public goToPageNumber(keyEvent) {
    if (keyEvent.which === 13) {
      if (this.pageNumberTooSmall(this.pageableService.pageNumber)) {
        this.pageableService.pageNumber = 1;
      } else if (this.pageNumberTooBig(this.pageableService.pageNumber)) {
        this.pageableService.pageNumber = this.getTotalPages();
      }
      this.pageableService.goToPageNumber(this.pageableService.pageNumber);
    }
  }

  private pageNumberTooSmall(purposedPage) {
    return purposedPage <= 0;
  }

  private pageNumberTooBig(purposedPage) {
    return purposedPage > this.getTotalPages();
  }

  public nextPage() {
    this.pageableService.pageNumber = this.pageableService.pageNumber + 1;
    this.pageableService.nextPage(this.pageableService.pageNumber);
  }

  public previousPage() {
    this.pageableService.pageNumber = this.pageableService.pageNumber - 1;
    this.pageableService.previousPage(this.pageableService.pageNumber);
  }

  public goToLastPage() {
    this.pageableService.pageNumber = this.getTotalPages();
    this.pageableService.goToPageNumber(this.pageableService.pageNumber);
  }

  public isLastPageLinkDisabled() {
    return this.pageableService.pageNumber >= this.getTotalPages();
  }

  public isRightArrowDisabled() {
    return this.pageableService.pageNumber >= this.getTotalPages();
  }

  public isLeftArrowDisabled() {
    return this.pageableService.pageNumber <= 1;
  }

  public shouldShowPagination() {
    return this.getTotalPages() > 0;
  }

  public getTotalPages() {
    return this.pageableService.getTotalPages();
  }

}
