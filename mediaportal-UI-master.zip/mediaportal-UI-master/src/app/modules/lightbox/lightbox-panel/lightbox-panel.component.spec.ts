import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LightboxPanelComponent } from './lightbox-panel.component';

describe('LightboxPanelComponent', () => {
  let component: LightboxPanelComponent;
  let fixture: ComponentFixture<LightboxPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LightboxPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LightboxPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
