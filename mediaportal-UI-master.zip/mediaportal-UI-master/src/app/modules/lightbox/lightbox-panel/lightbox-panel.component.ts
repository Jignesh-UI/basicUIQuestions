import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { ResizeEvent } from 'angular-resizable-element';
import { ThingWithValue } from 'src/app/models/ThingWithValue';
import { Lightbox } from 'src/app/models/Lightbox';
import { LightboxService } from '../lightbox.service';
import { Asset } from 'src/app/models/Asset';
import * as _ from 'lodash';
import { ElementService } from 'src/app/shared/services/jQlite';
import { Subscription } from 'rxjs';
import { Broadcast } from 'src/app/shared/services/broadcast.service';
import { APP_EVENTS, LIGHTBOX_HEIGHTS, VIEW_TYPES } from 'src/app/app-defaults';
import { UserService } from 'src/app/shared/services/User/user.service';
import { PopUpService } from 'src/app/shared/services/pop-up.service';
import { unsubscribable } from 'src/app/shared/services/common.service';
import { SearchHelperService } from 'src/app/shared/services/search/search-helper.service';

@Component({
  selector: 'lightbox-bar',
  templateUrl: './lightbox-panel.component.html',
  styleUrls: ['./lightbox-panel.component.scss']
})

export class LightboxPanelComponent implements OnInit, OnDestroy {

  public lightboxCollection: any[] = [];
  public view: string = VIEW_TYPES.grid;

  public lightboxModel: Lightbox = new Lightbox();
  public isFullScreen: boolean = false;
  public isSingleRow: boolean = false;
  public isSettingsPanelVisible: boolean = false;
  public isFulfillPanelVisible: boolean = false;
  public isGridView: boolean = true;
  public isPanelBelow: boolean = false;
  public isDescendingOrder: boolean = false;
  public selectedSortField: string = '';
  public selectedSortFieldOldValue: string = null;

  public hideLightboxSize = false;
  public showSortBy = true;
  public selectedLightbox = "";

  public lightboxState = {
    selected: false
  };
  public subscriptions: Subscription[] = [];
  public collection = null;
  public LIGHTBOXBAR_FULLSCREEN_HEIGHT: any = LIGHTBOX_HEIGHTS.LIGHTBOXBAR_FULLSCREEN_HEIGHT;
  public unsubscriber = unsubscribable();
  public selectedAction: string = '';


  constructor(public lightboxService: LightboxService,
    private event: Broadcast,
    private angular: ElementService,
    private popupService: PopUpService,
    private userService: UserService,
    private searchService: SearchHelperService) { }

  ngOnDestroy(): void {
    this.unsubscriber.reset();
  }

  ngOnInit(): void {

    this.unsubscriber.add(this.event.on(APP_EVENTS.LIGHTBOX_ADDED).subscribe((data: any) => {
      this.loadLightBox();
      this.selectedLightbox = data.lightBoxId;
      this.lightboxService.lightboxModel = data;
    }))

    this.unsubscriber.add(this.event.on(APP_EVENTS.LIGHTBOX_STYLE_CHANGE).subscribe((height) => {
      this.updateLightboxPositionProperties(height)
    }))

    this.unsubscriber.add(this.event.on(APP_EVENTS.ON_LIGHTBOX_VIEW_CHANGE).subscribe((view: string) => {
      this.view = view;
    }));

    this.unsubscriber.add(this.event.on(APP_EVENTS.RESET_LIGHTBOX).subscribe((model) => {
      this.populateLightboxBar();
      this.selectedLightbox = '';
      this.hideLightboxSize = false;
    }));

    this.setLightboxbarFullScreenHeight();
    let isLightboxCollectionPopulated = this.lightboxService.lightboxCollection.length > 0;
    let isLightboxModel = this.isAcutallyALightboxModel(this.lightboxService.lightboxModel);
    this.lightboxState.selected = !!this.isAcutallyALightboxModel(this.lightboxService.lightboxModel);

    if (isLightboxModel || isLightboxCollectionPopulated) {
      this.populateLightboxBar();
    } else {
      this.initPanel();
    }
  }

  initPanel() {
    this.lightboxService.getAvailableLightboxes().subscribe(() => {
      this.loadLightBox();
      this.populateLightboxBar();
    });
  }

  onViewChange(view) {
    this.view = view;
  }

  private isAcutallyALightboxModel(lightboxModel) {
    let hasLightboxId = lightboxModel.hasOwnProperty('lightBoxId');

    return typeof lightboxModel === 'object' && hasLightboxId;
  }

  private setLightboxbarFullScreenHeight() {
    this.LIGHTBOXBAR_FULLSCREEN_HEIGHT = window.innerHeight - 100;
  }

  public hasSelectedAssetsToRemove() {
    return this.getSelectedAssets().length > 0;
  }

  public getSelectedAssets() {
    return this.lightboxService.getCurrentPageAssetsArray().filter(item => item.selected)
  }

  public get getAllAssetsArray() {
    return this.lightboxService.getAllAssetsArray();
  }

  public getLightBoxSize() {
    let myCurrentSize = <any>parseFloat(this.lightboxService.lightboxModel.size).toFixed(2);
    let myDisplayString = '';

    this.hideLightboxSize = false;

    if (myCurrentSize < 1000) {
      myDisplayString = `${myCurrentSize} MB`;
    } else {
      //format the megabyte value to gigabyte display
      myCurrentSize = (myCurrentSize / 1000).toFixed(2);
      myDisplayString = `${myCurrentSize}`;

      if (myDisplayString === 'NaN') {
        this.hideLightboxSize = true;
      }

      //trim
      if (myDisplayString.charAt(myDisplayString.length - 1) === '0') {
        myDisplayString = myDisplayString.substr(0, myDisplayString.length - 1);
      }
      myDisplayString += ' GB';
    }

    return myDisplayString;
  }

  public getLightBoxLimit() {
    return (this.lightboxService.downloadSizeLimit / 1000).toFixed(1) + ' GB';
  }

  public isNearOrOverLimit() {
    return this.lightboxService.downloadSizeWarn < this.lightboxService.lightboxModel.size;
  }

  public get getCurrentPageAssetsArray() {
    return this.lightboxService.getCurrentPageAssetsArray();
  }

  public removeMultipleAsset() {
    this.lightboxService.assetsSelectedToRemove = this.getSelectedAssets();
    if (this.lightboxService.lightboxModel.lightBoxId && this.lightboxService.assetsSelectedToRemove.length > 0) {
      this.popupService.showConfirmDialog("This option will remove any assets you have selected from your lightbox.",
        (success) => {
          this.lightboxService.isGalleryAssetRequiredToClear = false;
          this.lightboxService.removeAsset(this.lightboxService.assetsSelectedToRemove).subscribe(res => {
            this.lightboxService.actionAfterRemove(res, this.lightboxService.assetsSelectedToRemove)
          });
        }, (fail) => {

        }, "CONTINUE", "BACK ")

    } else {
      this.lightboxService.clearSelectedAssets();
    }
  }

  onChangeLightBox() {
    let model = null;
    if (this.selectedLightbox) {
      model = this.lightboxCollection.find(item => item.lightBoxId === this.selectedLightbox)
      this.lightboxService.lightboxModel = model
      this.lightboxState.selected = true;
      this.hideLightboxSize = false;
      this.resetSortFieldAndOrder();
      this.loadLightboxAsset().subscribe(d => {
        setTimeout(() => {
          this.lightboxChange({ ...model });
        }, 100)
      });
    } else {
      this.hideLightboxSize = false;
      this.lightboxState.selected = false;
      this.lightboxService.resetLightboxDefaults();
      this.defaultOptionSelected();
      setTimeout(() => {
        this.lightboxChange({ ...this.lightboxService.lightboxModel });
      }, 100)
    }
  }

  lightboxChange(model) {
    this.event.broadcast(APP_EVENTS.LIGHTBOX_ONCHANGE, Object.assign({}, model));
    this.updateLightboxPositionProperties((document.querySelector('lightbox-bar') as HTMLElement).clientHeight)
  }

  loadLightboxAsset() {
    return this.lightboxService.onLightboxSelect(this.lightboxService.lightboxModel.lightBoxId)
  }

  loadLightBox() {
    this.subscriptions.push(this.lightboxService.getAvailableLightboxes().subscribe((collections) => {
      this.lightboxCollection = collections;
      this.onChangeLightBox()
    }, () => {
      throw new Error('Could not get any lightboxes from endpoint: `retrieveLightBoxes`');
    }))
  }

  private populateLightboxBar() {
    this.lightboxModel = this.lightboxService.lightboxModel;
    this.lightboxCollection = this.lightboxService.lightboxCollection;
    this.onLightboxSelect();
  }

  public onLightboxSelect() {

    if (this.lightboxModel.hasOwnProperty('lightBoxId')) {
      this.validOptionSelection();
    } else if (!this.isAcutallyALightboxModel(this.lightboxModel)) {
      this.defaultOptionSelected();
    }
    this.updateLightboxPositionProperties((document.querySelector('lightbox-bar') as HTMLElement).offsetHeight);
    this.lightboxService.selectedAssets = [];
    this.lightboxService.assetsSelectedToRemove = [];

  }

  private updateLightboxPositionProperties(newValue) {
    this.showSortBy = this.lightboxState.selected && newValue >= LIGHTBOX_HEIGHTS.LIGHTBOXBAR_SORTBY_VISIBLE_HEIGHT;
    this.isSingleRow = newValue === LIGHTBOX_HEIGHTS.LIGHTBOXBAR_SINGLEROW_HEIGHT;
    this.isFullScreen = newValue === this.LIGHTBOXBAR_FULLSCREEN_HEIGHT;
  }


  private validOptionSelection() {
    if (this.isSelectedLightboxDifferentFromPreviousOption()) {
      this.resetSortFieldAndOrder();
      this.isFulfillPanelVisible = false;
      this.lightboxState.selected = true;
      this.lightboxService.lightboxModel = this.lightboxModel;
      this.lightboxService.onLightboxSelect(this.lightboxModel.lightBoxId);
    }
  }

  private defaultOptionSelected() {
    if (this.isSelectedLightboxDifferentFromPreviousOption()) {
      //TODO :  These values needed to be reset here as all the data is in the Service.We can get rid of it when we have angular.copy
      this.resetSortFieldAndOrder();
      this.lightboxService.lightboxModel = {};
      this.lightboxState.selected = false;
      this.lightboxService.resetLightboxDefaults();
    }
  }

  /**
   * This function will reset the sort field name and sort order to
   * its default values.
   */
  public resetSortFieldAndOrder() {
    this.isDescendingOrder = false;
    this.selectedSortField = '';
    this.selectedAction = '';
  }

  private isSelectedLightboxDifferentFromPreviousOption() {
    return this.lightboxService.lightboxModel.lightBoxId !== this.lightboxModel.lightBoxId
  }

  public onResize(e) {
  }

  public onResizeEnd(event: ResizeEvent): void {
  }


  public isCollaborator(lightboxModel) {
    let matchedCollaborator;

    if (lightboxModel.collaborators.length !== 0 && !lightboxModel.owner) {
      matchedCollaborator = <ThingWithValue>_.find(lightboxModel.collaborators,
        { 'userId': this.userService.user.userId });
      return !!matchedCollaborator;
    }
    return false;
  }

  public isAwaitingApproval(lightbox) {
    return this.lightboxService.isAwaitingApproval(lightbox);
  }

  public isRecentlyFulfilled(lightbox) {
    return this.lightboxService.isRecentlyFulfilled(lightbox);
  }

  public shouldShowComments(lightbox) {
    if (this.lightboxService.isFulfilledOrRejected(lightbox) && this.lightboxService.hasComments(lightbox)) {
      return true;
    }

    return false;
  }

  public getComment(lightbox) {
    return this.lightboxService.getComment(lightbox);
  }

  /**
   * This function is used to sort the lightbox asset
   * @param isSortOderCliked 
   */
  public popupOnLightboxbarSettingsChange(isSortOderCliked) {
    if (this.isGridView && this.lightboxService.assetsSelectedToRemove.length > 0) {
      this.popupService.showConfirmDialog(
        "This option will de-select any assets you have selected.",
        () => { this.onSettingsChangeConfirm(isSortOderCliked) },
        () => { this.noChangeInView(isSortOderCliked) },
        "Continue",
        "Undo options"
      );
    } else {
      this.onSettingsChangeConfirm(isSortOderCliked);
    }
  }

  public noChangeInView(isSortOderCliked) {
    if (!isSortOderCliked) {
      this.selectedSortField = this.selectedSortFieldOldValue;
    }
  }

  public updateOldValue(oldValue) {
    this.selectedSortFieldOldValue = oldValue;
  }


  public onSettingsChangeConfirm(isSortOderCliked) {

    if (!this.selectedSortField) return false;
    if (!isSortOderCliked) {
      this.applySort();
    } else {
      this.reverseSort();
    }

    this.lightboxService.isGalleryAssetRequiredToClear = false;
    this.lightboxService.clearSelectedAssets();
  }

  public applySort() {
    if (this.selectedSortField === 'DATE_ADDED_TO_LIGHTBOX') {
      this.isDescendingOrder = false;
      this.unsubscriber.add(this.lightboxService
        .onLightboxSelect(this.lightboxService.lightboxModel.lightBoxId)
        .subscribe(model => {
          // console.log(model)
        }));
      return;
    }
    this.lightboxService.allAssets = _.sortBy(this.lightboxService.lightboxModel.assets,
      this.bySelectedSortField.bind(this));
    /**This is kept for future refference please delete when its */
    // if (this.isDescendingOrder) {
    //   this.lightboxService.allAssets = this.lightboxService.allAssets.reverse();
    // }
    this.lightboxService.pageNumber = 1;
    this.lightboxService.goToPageNumber(1);
  }

  private bySelectedSortField(o: Asset) {
    let a: any = _.find(o.fields, { 'name': this.selectedSortField });
    return a.value;
  }

  public reverseSort() {
    this.lightboxService.allAssets = this.lightboxService.allAssets.reverse();
    this.lightboxService.pageNumber = 1;
    this.lightboxService.goToPageNumber(1);
    this.isDescendingOrder = !this.isDescendingOrder;
  }


  public isAssetCheckboxEnabled() {
    return this.lightboxService.isAddAssetsCheckboxEnabled();
  }

  public getImageLocation() {
    return this.isAssetCheckboxEnabled() ? 'mint' : 'charcoal';
  }

  public getPromptText() {
    if (this.isAssetCheckboxEnabled()) {
      return 'Add asset(s) to selected lightbox.';
    } else {
      return 'Select a lightbox first.'
    }
  }

  public changeSelectionState() {
    if (this.selectedAction === '1') {
      this.lightboxService.currentPageAssets.map(item => item.selected=true);
    } else if (this.selectedAction === '2') {
      this.lightboxService.currentPageAssets.map(item => item.selected=false);
    }
    setTimeout(() => {
      this.selectedAction = '';
    }, 50) 
  }


}
