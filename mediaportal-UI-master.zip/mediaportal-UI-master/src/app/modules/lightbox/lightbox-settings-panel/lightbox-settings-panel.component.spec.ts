import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LightboxSettingsPanelComponent } from './lightbox-settings-panel.component';

describe('LightboxSettingsPanelComponent', () => {
  let component: LightboxSettingsPanelComponent;
  let fixture: ComponentFixture<LightboxSettingsPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LightboxSettingsPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LightboxSettingsPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
