import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { APP_EVENTS, VIEW_TYPES } from 'src/app/app-defaults';
import { Broadcast } from 'src/app/shared/services/broadcast.service';
import { PopUpService } from 'src/app/shared/services/pop-up.service';
import { LightboxService } from '../lightbox.service';

@Component({
  selector: 'lightbox-settings-panel',
  templateUrl: './lightbox-settings-panel.component.html',
  styleUrls: ['./lightbox-settings-panel.component.scss']
})
export class LightboxSettingsPanelComponent implements OnInit {

  public viewTypes = VIEW_TYPES;
  public toggleSettingsPanel = "grid";
  public countPerPageOldValue = 50;

  @Input('view') public view = VIEW_TYPES.grid;
  @Input('pageable-service') public pageableService;
  @Input('is-settings-panel-visible') public isSettingsPanelVisible;
  @Input('is-panel-below') public isPanelBelow;
  @Output('onChange') public onChange: EventEmitter<any> = new EventEmitter();
  @Output('onSelect') public onSelect: EventEmitter<any> = new EventEmitter();

  constructor(private lightboxService: LightboxService, private popupService: PopUpService, private event: Broadcast) { }

  public changeCountPerPage(perPage) {
    this.isSettingsPanelVisible = false;
    this.pageableService.countPerPage = parseInt(perPage);
    this.pageableService.setTotalPageNumbers(this.pageableService.getTotalItems());
    this.pageableService.pageNumber = 1;
    this.pageableService.goToPageNumber(this.pageableService.pageNumber);
    this.countPerPageOldValue = this.pageableService.countPerPage;
  }

  onViewChange(view) {
    this.toggleSettingsPanel = view;
    this.onChange.emit('changed')
    this.event.broadcast(APP_EVENTS.ON_LIGHTBOX_VIEW_CHANGE, view)
  }

  public get isGridView() {
    return this.toggleSettingsPanel === VIEW_TYPES.grid;
  }

  public popupOnLightboxSettingsChange(isViewChange, view = '') {
    this.onSelect.emit('1');
    this.lightboxService.assetsSelectedToRemove = this.lightboxService.getSelectedAssets();
    if (this.isGridView && this.lightboxService.assetsSelectedToRemove.length > 0) {
      this.popupService.showConfirmDialog(
        "This option will de-select any assets you have selected.",
        () => { this.onSettingsChangeConfirm(isViewChange, view) },
        () => { this.noChangeInView() },
        "Continue",
        "Undo options"
      );
    } else {
      this.onSettingsChangeConfirm(isViewChange, view);
    }
  }

  public onSettingsChangeConfirm(isViewChange, view) {
    if (!isViewChange) {
      this.changeCountPerPage(view);
      this.lightboxService.clearSelectedAssets();
    } else {
      this.onViewChange(view);
    }
    this.lightboxService.isGalleryAssetRequiredToClear = false;
    this.lightboxService.clearSelectedAssets();
  }

  public updateOldValue(oldValue) {
    this.countPerPageOldValue = oldValue;
  }

  public noChangeInView() {
    this.onChange.emit('changed')
    this.toggleSettingsPanel = VIEW_TYPES.grid;
    //this.event.broadcast(APP_EVENTS.ON_LIGHTBOX_VIEW_CHANGE, this.toggleSettingsPanel)
    this.pageableService.countPerPage = 50;
  }

  ngOnInit(): void {
  }

}
