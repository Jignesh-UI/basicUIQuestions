import { DragDropModule } from '@angular/cdk/drag-drop';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ErrorStateMatcher, MAT_DATE_FORMATS, ShowOnDirtyErrorStateMatcher } from '@angular/material/core';
import { ServiceModule } from 'src/app/shared/services/service.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { AssetCommonModule } from '../asset/asset-common.module';
import { MaterialModule } from '../material/material.module';
import { CollaboratorComponent } from './collaborator/collaborator.component';
import { LightboxActionbarComponent } from './lightbox-actionbar/lightbox-actionbar.component';
import { LightboxExportComponent } from './lightbox-export/lightbox-export.component';
import { LightboxFormComponent } from './lightbox-form/lightbox-form.component';
import { LightboxFulfillApprovalComponent } from './lightbox-fulfill-approval/lightbox-fulfill-approval.component';
import { LightboxFulfillComponent } from './lightbox-fulfill/lightbox-fulfill.component';
import { LightboxPaginationComponent } from './lightbox-pagination/lightbox-pagination.component';
import { LightboxPanelComponent } from './lightbox-panel/lightbox-panel.component';
import { LightboxSettingsPanelComponent } from './lightbox-settings-panel/lightbox-settings-panel.component';
import { LightboxService } from './lightbox.service';
import { RemoveCollaboratorComponent } from './remove-collaborator/remove-collaborator.component';
import { SearchUserComponent } from './search-user/search-user.component';


@NgModule({
  declarations: [
    LightboxPanelComponent,
    LightboxActionbarComponent,
    LightboxFormComponent,
    LightboxExportComponent,
    LightboxSettingsPanelComponent,
    CollaboratorComponent,
    SearchUserComponent,
    RemoveCollaboratorComponent,
    LightboxFulfillComponent,
    LightboxFulfillApprovalComponent,
    LightboxPaginationComponent
  ],
  imports: [
    CommonModule,
    ServiceModule,
    MaterialModule,
    SharedModule,
    AssetCommonModule,
    DragDropModule
  ],
  exports: [
    LightboxPanelComponent
  ],
  providers: [
    LightboxService,
    {
      provide: MAT_DATE_FORMATS,
      useValue: {
        parse: {
          dateInput: ['l', 'LL'],
        },
        display: {
          dateInput: 'L',
          monthYearLabel: 'MMM YYYY',
          dateA11yLabel: 'LL',
          monthYearA11yLabel: 'MMMM YYYY',
        },
      },
    },
    {
      provide: ErrorStateMatcher,
      useClass: ShowOnDirtyErrorStateMatcher
    }
  ]
})
export class LightboxModule { }
