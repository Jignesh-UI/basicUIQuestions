import { Lightbox } from '../../models/Lightbox';
import * as _ from 'lodash';
import { Injectable } from '@angular/core';
import { HttpService } from 'src/app/shared/services/http/http.service';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { Broadcast } from 'src/app/shared/services/broadcast.service';
import { APP_EVENTS } from 'src/app/app-defaults';
import { PopUpService } from 'src/app/shared/services/pop-up.service';
import { environment } from 'src/environments/environment';

export interface IPageableService {
    totalPageNumbers: number;
    totalItems: number;
    countPerPage: number;
    pageNumber: number;
    goToPageNumber(pageNumber: number): void;
    nextPage(pageNumber: number): void;
    previousPage(pageNumber: number): void;
}

@Injectable({ providedIn: 'root' })

export class LightboxService implements IPageableService {

    public lightboxModel: Lightbox | any = new Lightbox();
    public isAdditionSuccessful: boolean = false;
    public lightboxCollection: Array<Lightbox> = new Array<Lightbox>();
    public totalPageNumbers: number = 0;
    public totalItems: number = 0;
    public countPerPage: number = 50;
    public pageNumber: number = 1;
    public allAssets: Array<any> = new Array<any>();
    public currentPageAssets: Array<any> = new Array<any>();
    private downloadPollIntervals: Array<any> = new Array<any>();
    private heartBeat: number = 5000;
    public downloadQueue = new Array<any>();
    public selectedAssets: Array<any> = new Array<any>();
    public assetsSelectedToRemove: Array<any> = new Array<any>();
    public isGalleryAssetRequiredToClear: boolean = false;
    public downloadSizeLimit = 4000;
    public downloadSizeWarn = 3750;

    constructor(private http: HttpService, private event: Broadcast,
        private popupService: PopUpService) {
        this.setTotalPageNumbers(0);
    }

    public reset() {
        this.lightboxModel = new Lightbox();
        this.isAdditionSuccessful = false;
        this.lightboxCollection = [];
        this.totalPageNumbers = 0;
        this.totalItems = 0;
        this.countPerPage = 50;
        this.pageNumber = 1;
        this.allAssets = [];
        this.currentPageAssets = [];
        this.setTotalPageNumbers(0);
    }

    public getAvailableLightboxes() {
        return this.http.get('retrieveLightBoxes').pipe(map((res: any) => {
            if (res.succeeded) {
                this.lightboxCollection = res.data;
            }
            return res.data;
        }));
    }

    public onLightboxSelect(lightBoxId) {
        return new Observable((observer) => {
            this.http.get('retrieveLightLightBox?lightBoxId=' + lightBoxId).subscribe((res) => {
                let lightbox = res.data;
                this.lightboxModel = lightbox;
                this.allAssets = lightbox.assets;
                this.currentPageAssets = lightbox.assets;
                this.totalItems = lightbox.assets.length;
                this.setTotalPageNumbers(lightbox.assets.length);
                this.goToPageNumber(1);
                this.clearSelectedAssets();
                observer.next(this.lightboxModel);
            }, () => {
                throw new Error('Could not get the selected Lightbox from endpoint: `retrieveLightBoxes`: ' + this.lightboxModel);
            });
        });

    }

    private isLightboxEmpty() {
        if (this.allAssets.length <= 0) {
            let close = this.popupService.showFailureDialog('No assets in lightbox.');
            setTimeout(() => {
                close();
            }, 2000)
            return true;
        }
        return false;
    }

    public canAddCollaborators(): boolean {
        return this.lightboxModel.owner ? !!this.lightboxModel.owner : false;
    }

    private pollDownloadStatus(myDownloadPID) {
        let url = 'lb/getDownloadRequestStatus/' + myDownloadPID;
        this.http.get(url).toPromise().then((res) => {
            if (res.data.processStatus === 'Completed' && res.data.downloadUrl !== null) {
                window.open(res.data.downloadUrl);
                this.downloadQueue = _.reject(this.downloadQueue, { 'downloadPID': myDownloadPID });
            } else if (res.data.processStatus === 'Failed') {
                this.downloadQueue = _.reject(this.downloadQueue, { 'downloadPID': myDownloadPID });
            } else if (res.data.processStatus === 'In progress') {
                _.delay(_.bind(this.pollDownloadStatus, this), this.heartBeat, myDownloadPID);
            }
        });
    }

    public downloadLightbox() {
        if (this.isLightboxDownloading(this.lightboxModel.lightBoxId)) {
            let hideDialog = this.popupService.showSuccessDialog('Your download has already been queued and will begin automatically.');
            setTimeout(hideDialog, 3000);
            return;
        }
        if (!this.isLightboxEmpty()) {
            let url = 'lb/directDownloadFulfill/' + this.lightboxModel.lightBoxId;

            this.http.get(url).toPromise().then((res) => {
                let hideDialog = this.popupService.showSuccessDialog('Your download has been queued and will begin automatically.');
                setTimeout(hideDialog, 3000);
                let myDownloadPID = res.data;
                this.downloadQueue.push({
                    'lightboxID': this.lightboxModel.lightBoxId,
                    'downloadPID': myDownloadPID
                });
                this.pollDownloadStatus(myDownloadPID);
            });
        }
    }

    public isLightboxDownloading(lightboxID) {
        return !!_.find(this.downloadQueue, function (queueItem) {
            return queueItem.lightboxID === lightboxID;
        })
    }

    public downloadLowRes() {
        if (!this.isLightboxEmpty()) {
            let url = 'thumbnail/lightbox/' + this.lightboxModel.lightBoxId;
            this.http.get(url).toPromise().then((res) => {
                let full_url = environment.baseUrl + url;
                window.open(full_url);
            });
        }
    }

    public ftpLightbox() {
        if (!this.isLightboxEmpty()) {
            let that = this;
            let payload = { 'lightBoxId': this.lightboxModel.lightBoxId };
            let url = 'lb/selfFulfillFtp';
            this.http.post(url, payload).toPromise().then((res) => {
                let hideDialog = this.popupService.showSuccessDialog('Fulfillment requested. You will be notified by email when it\'s complete.');
                setTimeout(hideDialog, 2000);
            });
        }
    }

    public approveFulfillment(lightboxId: string, approve: boolean, comment: string) {
        let payload = {
            lightBoxId: lightboxId,
            fullfillments: [
                { comments: comment }
            ]
        };

        if (approve) {
            return this.http.post('lb/fulfillFtp', payload).toPromise().then((res) => {
                return res.succeeded;
            });
        } else {
            return this.http.post('lb/rejectLightBox', payload).toPromise().then((res) => {
                return res.succeeded;
            });
        }
    }

    public isLightboxDeletable() {
        return this.lightboxModel.owner;
    }

    public isLightboxEditable(lightboxRoles = null) {
        return this.lightboxModel.owner;
    }

    public deleteLightbox() {
        if (!this.isLightboxDeletable()) { return; }
        let message = "Are you sure you want to delete this lightbox: " + this.lightboxModel.name + "?";

        let successCb = () => {
            this.onDeleteLightboxConfirm();
        };

        let failureCb = () => {
            setTimeout(this.popupService.showSuccessDialog('Your delete lightbox request has been cancelled.'), 2000);
        };

        this.popupService.showConfirmDialog(message, successCb, failureCb);
    }

    public onDeleteLightboxConfirm() {
        let that = this;
        let payload = {
            'assetIds': [this.lightboxModel.lightBoxId], //backend uses assetId here when it should be lightboxId
            'metadataFields': []
        };

        this.http.post('deleteLightBoxes', payload).toPromise().then((res) => {
            if (res.succeeded) {
                this.lightboxCollection = res.data;
                let hideDialog = this.popupService.showSuccessDialog('Your lightbox was deleted.');
                setTimeout(hideDialog, 2000);
                this.lightboxModel = new Lightbox();
                this.resetLightboxDefaults();
                this.event.broadcast(APP_EVENTS.RESET_LIGHTBOX, this.lightboxModel)
            } else {
                throw new Error('Can\'t delete lightbox ' + this.lightboxModel);
            }
        }, () => {
            throw new Error('Can\'t delete lightbox ' + this.lightboxModel);
        });
    }

    public clearSelectedAssets() {
        if (this.isGalleryAssetRequiredToClear) {
            //this will clear all the assets selected to add to lightbox
            this.selectedAssets = [];
        } else {
            //this will clear all the assets selected to remove from lightbox
            this.assetsSelectedToRemove = [];
            this.currentPageAssets = this.currentPageAssets.map(item => ({ ...item, selected: false }))
        }
        this.resetSelection();
    }

    resetSelection() {
        this.allAssets = this.allAssets.map(item => ({ ...item, selected: false }))
    }

    addSelectedAsset(assets) {
        this.selectedAssets = assets;
    }

    public addAsset(assets) {
        if (!Array.isArray(assets)) {
            assets = [assets];
        }

        let assetsToAdd = [];
        let cas = [];
        for (let i = 0; i < assets.length; i++) {
            if (!this.isInCurrentLightbox(assets[i])) {
                cas.push({ assetId: assets[i].assetId });
                assetsToAdd.push(assets[i]);
            }
        }

        let payload = {
            'lightBoxId': this.lightboxModel.lightBoxId,
            'assets': cas
        };

        return new Promise((resolve, reject) => {
            this.http.post('lb/addAssets', payload).subscribe((res) => {
                this.isGalleryAssetRequiredToClear = true;
                this.clearSelectedAssets();
                this.addAssetToAllAssets(assetsToAdd.map(asset => ({ ...asset, selected: false })));
                this.onLightboxAssetsChanged(res);
                this.event.broadcast(APP_EVENTS.ASSET_LIST_STATE_CHANGE, { action: "DESELECT_ALL", data: null })
                resolve(true);
            });
        });
    }

    public removeAsset(assets) {
        let payload = {
            lightBoxId: this.lightboxModel.lightBoxId,
            assets: []
        };
        if (Array.isArray(assets)) {
            payload.assets = this.getAssetIds(assets)
        } else {
            payload.assets.push({ assetId: assets.assetId });
        }
        return this.http.post('lb/removeAssets', payload)
    }

    actionAfterRemove(res, assets) {
        this.isGalleryAssetRequiredToClear = false;
        this.clearSelectedAssets();
        this.removeAssetFromAllAssets(assets);
        this.onLightboxAssetsChanged(res);
    }

    getAssetIds(assets) {
        return [...assets].map(({ assetId }) => ({ assetId }))
    }

    private onLightboxAssetsChanged(response) {
        let lightbox = response.data;
        lightbox.assets = this.allAssets;
        this.lightboxModel = lightbox;
        this.totalItems = this.allAssets.length;
        this.setTotalPageNumbers(this.totalItems);
        this.goToPageNumber(1);
    }

    private addAssetToAllAssets(assets) {
        let i;
        if (Array.isArray(assets)) {
            for (i = 0; i < assets.length; i++) {
                this.allAssets.push(assets[i]);
            }
        } else {
            this.allAssets.push(assets);
        }
    }

    private removeAssetFromAllAssets(assets) {
        assets = Array.isArray(assets) ? assets.map(as => as.assetId) : [assets.assetId];
        this.allAssets = this.allAssets.filter(ast => assets.indexOf(ast.assetId) < 0);
        this.lightboxModel.assets = this.allAssets;
    }

    public isInCurrentLightbox(asset) {
        return !!_.find(this.lightboxModel.assets, { assetId: asset.assetId });
    }

    public goToPageNumber(pageNumber) {
        let firstAssetIndex;
        let lastAssetIndex;
        let currentPageAssets;

        //reset the selection
        this.isGalleryAssetRequiredToClear = false;
        this.clearSelectedAssets();

        this.pageNumber = pageNumber;
        firstAssetIndex = this.getCountPerPage() * (this.getPageNumber() - 1);
        lastAssetIndex = firstAssetIndex + this.getCountPerPage();
        this.currentPageAssets = this.allAssets.slice(firstAssetIndex, lastAssetIndex);
    }

    public nextPage(pageNumber) {
        this.goToPageNumber(pageNumber);
    }

    public previousPage(pageNumber) {
        this.goToPageNumber(pageNumber);
    }

    public setTotalPageNumbers(totalAssetsInLightBox) {
        this.totalPageNumbers = Math.ceil(totalAssetsInLightBox / this.getCountPerPage());
    }

    public getPageNumber() {
        return this.pageNumber;
    }

    public getTotalPages() {
        return this.totalPageNumbers;
    }

    public getTotalItems() {
        return this.totalItems;
    }

    public getCountPerPage() {
        return this.countPerPage;
    }

    public getAllAssetsArray() {
        return this.allAssets;
    }

    public getCurrentPageAssetsArray() {
        return this.currentPageAssets;
    }

    public getSelectedAssets() {
        return this.currentPageAssets.filter(item => item.selected);
    }

    public getLightboxCollection() {
        return this.lightboxCollection;
    }

    public createNewLightbox(name, businessUnit, description, expiryDate, startDate) {
        let payload = {
            'name': name,
            'businessUnit': businessUnit,
            'description': description,
            'expiryDate': expiryDate,
            'startDate': startDate
        };
        return this.http.post('lightBox', payload);
    }

    public resetLightboxDefaults() {
        this.currentPageAssets = [];
        this.allAssets = [];
        this.pageNumber = 1;
        this.setTotalPageNumbers(0);
        this.totalItems = 0;
        let el = (document.querySelector('lightbox-bar') as HTMLElement);
        if (el) el.style.height = 'auto';
    }

    public editLightbox(lightboxId, name, businessUnit, description, expiryDate, startDate) {
        let payload = {
            'lightBoxId': lightboxId,
            'name': name,
            'businessUnit': businessUnit,
            'description': description,
            'expiryDate': expiryDate,
            'startDate': startDate
        };
        return this.http.put('lightBox', payload);
    }

    public cloneLightbox(name, businessUnit, description, expiryDate, startDate, lightboxId) {
        let payload = {
            'name': name,
            'businessUnit': businessUnit,
            'description': description,
            'expiryDate': expiryDate,
            'startDate': startDate,
            'lightboxIdForCloning': lightboxId
        };
        return this.http.post('clonelightBox', payload);
    }

    public isLightboxOwner() {
        return this.lightboxModel.owner;
    }

    public canRequestFulfillment() {
        return this.lightboxModel.requestFulfillment;
    }

    public canSelfFulfill() {
        return this.lightboxModel.selfFulfill;
    }

    public getModelAttr(attr) {
        return this.lightboxModel[attr];
    }

    public canFulfill(lightbox) {
        return lightbox.fullfillLightBox;
    }

    public hasAssets(lightbox) {
        return lightbox && lightbox.assets && lightbox.assets.length;
    }

    public hasComments(lightbox) {
        return !!this.getComment(lightbox);
    }

    public getComment(lightbox): string {
        if (this.hasFulfillment(lightbox)) {
            let comment = lightbox.fullfillments[0].comments;
            if (typeof comment === 'string' && comment.length > 0) {
                return lightbox.fullfillments[0].comments;
            }
        }
        return undefined;
    }

    public isAwaitingApproval(lightbox) {
        if (lightbox.lightBoxStatus === "AWAITING_APPROVAL") {
            return true;
        }

        return false
    }

    public isRecentlyFulfilled(lightbox): boolean {
        if (this.isFulfilled(lightbox)) {
            let fulfillmentDate = <any>this.getFulfillmentDate(lightbox);
            let millisSinceCreated = Date.now() - fulfillmentDate;

            if (millisSinceCreated < 1209600000) { // 1000ms * 60s * 60m * 24h * 14days
                return true;
            }
        }

        return false
    }

    public hasFulfillment(lightbox): boolean {
        if (lightbox.fullfillments && lightbox.fullfillments[0]) {
            return true;
        }

        return false;
    }

    public getFulfillmentDate(lightbox) {
        if (this.hasFulfillment(lightbox) && typeof lightbox.fullfillments[0].submissionDate === "string") {
            return new Date(lightbox.fullfillments[0].submissionDate);
        }

        return null;
    }

    public isFulfilled(lightbox): boolean {
        return lightbox.lightBoxStatus === 'FULLFILLED';
    }

    public isRejected(lightbox): boolean {
        return lightbox.lightBoxStatus === 'NOT_APPROVED';
    }

    public isFulfilledOrRejected(lightbox) {
        return this.isFulfilled(lightbox) || this.isRejected(lightbox);
    }

    public isAddAssetsCheckboxEnabled() {
        if (this.lightboxModel.lightBoxId) {
            return true;
        } else {
            return false;
        }
    }

    public isRemoveAssetsIconEnabled() {
        if (this.assetsSelectedToRemove.length > 0 && this.lightboxModel.lightBoxId) {
            return true;
        } else {
            return false;
        }
    }

    public imidiatelyClearSelectedAsset() {
        this.isGalleryAssetRequiredToClear = true;
        this.clearSelectedAssets();
    }
}

