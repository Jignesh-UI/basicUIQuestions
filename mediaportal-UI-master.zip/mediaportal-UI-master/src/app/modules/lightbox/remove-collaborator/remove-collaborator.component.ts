import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-remove-collaborator',
  templateUrl: './remove-collaborator.component.html',
  styleUrls: ['./remove-collaborator.component.scss']
})
export class RemoveCollaboratorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
