import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PopUpService } from 'src/app/shared/services/pop-up.service';

@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.scss']
})

export class FaqComponent implements OnInit {

  constructor(private popupService: PopUpService, private router: Router) { }

  ngOnInit(): void { }

  public scrollToHash(id: string) {
    document.getElementById(id).scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
  }

  public getCurrentYear() {
    return new Date().getFullYear();
  }

  showSupportDialog() {
    this.popupService.showSupportDialog();
  }

}
