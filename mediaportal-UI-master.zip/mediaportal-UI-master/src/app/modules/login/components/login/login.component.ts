import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/app/shared/services/User/User.model';
import { StorageService } from 'src/app/shared/services/storage.service';
import { UserService } from 'src/app/shared/services/User/user.service';
import { MatDialog } from '@angular/material/dialog';
import { MultipleBusinessUnitComponent } from '../multiple-business-unit/multiple-business-unit.component';
import { LightboxService } from 'src/app/modules/lightbox/lightbox.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  private user: User;
  public loginRequestObject;
  public loginError = false;
  public currentYear = (new Date()).getFullYear();

  constructor(public userService: UserService, private router: Router,
    public storage: StorageService, public dialog: MatDialog, private lightboxService: LightboxService) { }

  ngOnInit(): void {
    window.sessionStorage.setItem("dismissed",'false');
  }

  goFaq() {
    this.router.navigate(['faq']);
  }

  public login(form) {

    if (!form.valid) {
      return false
    }

    let user: any = {};

    user.loginName = form.value.username;
    user.password = form.value.password;

    this.loginError = false;

    this.userService.login(user).subscribe(({ data, succeeded }: any) => {
      if (succeeded) {
        if (data.businessUnits && data.businessUnits.length > 1) {
          this.lightboxService.resetLightboxDefaults();
          this.lightboxService.reset();
          let dialog = this.dialog.open(MultipleBusinessUnitComponent, {
            data: data,
            panelClass: 'support-dialog-container'
          })
        } else {
          this.success(data);
        }
      } else {
        this.loginError = true;
      }
    }, err => {
      this.loginError = true;
    });
  }

  success(data) {
    this.userService.authSuccess(data);
  }

  showSupportDialog() {
  }

}
