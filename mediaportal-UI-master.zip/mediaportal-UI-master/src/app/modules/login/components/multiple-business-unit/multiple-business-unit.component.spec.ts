import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultipleBusinessUnitComponent } from './multiple-business-unit.component';

describe('MultipleBusinessUnitComponent', () => {
  let component: MultipleBusinessUnitComponent;
  let fixture: ComponentFixture<MultipleBusinessUnitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultipleBusinessUnitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultipleBusinessUnitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
