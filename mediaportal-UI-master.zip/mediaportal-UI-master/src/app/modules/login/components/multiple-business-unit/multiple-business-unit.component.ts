import { Component, Inject, OnInit, Optional } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { UserService } from 'src/app/shared/services/User/user.service';

@Component({
  selector: 'app-multiple-business-unit',
  templateUrl: './multiple-business-unit.component.html',
  styleUrls: ['./multiple-business-unit.component.scss']
})
export class MultipleBusinessUnitComponent implements OnInit {

  public fail: boolean = false;
  public businessUnits: string[] = [];
  public selectBusinessUnitForm: FormGroup = new FormGroup({
    selectedbBusinessUnit: new FormControl('')
  });

  constructor(public dialogRef: MatDialogRef<MultipleBusinessUnitComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any, public userService: UserService) { }

  ngOnInit(): void {
    this.businessUnits = this.data.businessUnits;
    this.selectBusinessUnitForm.get('selectedbBusinessUnit').setValue(this.businessUnits[0]);
  }

  hideDialog() {
    this.dialogRef.close();
  }

  public selectBusinessUnit() {
    this.fail = false;
    let { loginName, userId } = this.data;
    let bu = this.selectBusinessUnitForm.get('selectedbBusinessUnit').value;
    this.userService.selectBU(bu, loginName, userId)
      .subscribe((res) => {
        if (res.succeeded) {
          let authData = {
            ...this.data,
            participatingBusinessUnit: res.data.participantBU,
          }
          this.hideDialog();
          this.userService.authSuccess(authData);
        } else {
          this.fail = true;
        }
      })
  }

}
