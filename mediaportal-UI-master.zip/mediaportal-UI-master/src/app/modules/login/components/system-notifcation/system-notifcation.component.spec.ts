import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SystemNotifcationComponent } from './system-notifcation.component';

describe('SystemNotifcationComponent', () => {
  let component: SystemNotifcationComponent;
  let fixture: ComponentFixture<SystemNotifcationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SystemNotifcationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SystemNotifcationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
