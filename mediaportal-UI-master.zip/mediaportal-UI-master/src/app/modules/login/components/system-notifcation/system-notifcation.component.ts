import { Component, OnInit } from '@angular/core';
import { SystemNotification } from 'src/app/models/SystemNotification';
import { SystemNotificationService } from './system-notification.service';

@Component({
  selector: 'system-notification',
  templateUrl: './system-notifcation.component.html',
  styleUrls: ['./system-notifcation.component.scss']
})
export class SystemNotifcationComponent implements OnInit {

  private isDismissed: boolean = false;
  public model: SystemNotification = new SystemNotification();
  
  constructor(private systemNotificationService: SystemNotificationService) { }
  
  ngOnInit(): void {
    this.systemNotificationService.getNotifications().then((model: any) => {
      this.model = model;
    });
  }

  public getNotificationText() {
    return this.model.notificationText;
  }

  public isNotificationVisible() {
    if (!!!this.model?.notificationStartDate && !!!this.model?.notificationEndDate) {
      return false;
    }
    if(!sessionStorage.getItem('dismissed')) {
      return false;
    }
    var start = new Date(this.model.notificationStartDate.toString());
    var end = new Date(this.model.notificationEndDate.toString());
    var now = new Date();
    return !this.isDismissed && now > start && now < end && !!this.model.notificationText;
  }

  public dismissNotification() {
    this.systemNotificationService.closeSysNotifiation(false);
    this.isDismissed = !this.systemNotificationService.getSysNotification();
    window.sessionStorage.removeItem("dismissed");
  }

  getLocalStorageNotificationFlag(){
    return window.sessionStorage.getItem('dismissed');
  }


}
