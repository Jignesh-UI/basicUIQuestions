import { Injectable } from '@angular/core';
import { SystemNotification } from 'src/app/models/SystemNotification';
import { HttpService } from 'src/app/shared/services/http/http.service';

@Injectable({
  providedIn: 'root'
})
export class SystemNotificationService {

  public model: SystemNotification = new SystemNotification();
  sysNotifyDismiss:boolean = true;

  constructor(private $http: HttpService) { }

  public getNotifications() {
    return new Promise((resolve, reject) => {
      this.$http.get('systemNotification').toPromise().then((res) => {
        if (res.succeeded === true) {
          this.model = <SystemNotification>res.data;
          resolve(this.model);
        } else {
          reject(res);
          throw new Error('Can\'t load systemNotifications ' + res);
        }
      });
    })
  }

  public closeSysNotifiation(flag:boolean){
    this.sysNotifyDismiss = flag;
  }

  public getSysNotification(){
    return this.sysNotifyDismiss;
  }
  
}
