import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './components/login/login.component';
import { RouterModule, Routes } from '@angular/router';
import { FaqComponent } from './components/faq/faq.component';
import { ServiceModule } from 'src/app/shared/services/service.module';
import { MaterialModule } from '../material/material.module';
import { MultipleBusinessUnitComponent } from './components/multiple-business-unit/multiple-business-unit.component';
import { ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';

const RouteList: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'faq',
    component: FaqComponent
  }
]

@NgModule({
  declarations: [LoginComponent, FaqComponent, MultipleBusinessUnitComponent],
  imports: [
    CommonModule,
    RouterModule.forRoot(RouteList, { useHash: true, anchorScrolling: 'enabled', }),
    MaterialModule,
    ReactiveFormsModule,
    ServiceModule,
    SharedModule
  ]
})
export class LoginModule { }
