import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { RouterModule } from '@angular/router';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatRadioModule, MAT_RADIO_DEFAULT_OPTIONS } from '@angular/material/radio';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatAutocompleteModule } from "@angular/material/autocomplete";


@NgModule({
  declarations: [],
  imports: [
    // FormsModule,
    // MatDividerModule,
    // MatButtonModule,
    // MatDialogModule,
    // MatFormFieldModule,
    // MatInputModule,
    // MatButtonModule,
    // MatSelectModule,
    // MatFormFieldModule,
    // MatInputModule,
    // MatButtonModule,
    // MatSidenavModule,
    // MatCheckboxModule,
    // MatProgressSpinnerModule,
    // MatRadioModule,
    // RouterModule,
  ],
  exports: [
    FormsModule,
    MatDividerModule,
    MatButtonModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSidenavModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    RouterModule,
    MatToolbarModule,
    MatDatepickerModule,
    MatTooltipModule,
    MatAutocompleteModule
  ],
  providers: [{
    provide: MAT_RADIO_DEFAULT_OPTIONS,
    useValue: { color: 'primary' },
  }]
})
export class MaterialModule { }
