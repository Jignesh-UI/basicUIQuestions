import { Subscription } from "rxjs";

export const Utility = {
    each: (item, fn) => item.forEach(fn),
    Ob2Arr: (ob) => {
        return Object.keys(ob).map(i => ob[i]);
    },
    unsubscribeAll: (subscriptions: Subscription[] = []) => {
        for (let i = 0; i < subscriptions.length; i++) {
            subscriptions[i].unsubscribe();
        }
    }
}