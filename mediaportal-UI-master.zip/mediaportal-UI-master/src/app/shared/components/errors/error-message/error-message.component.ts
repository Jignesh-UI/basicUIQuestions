import { Component, Input, OnInit } from '@angular/core';
import { Broadcast } from 'src/app/shared/services/broadcast.service';
import { ACTIONS } from 'src/app/shared/services/consts/actions.consts';

export const ErrorTypes = {
  error: 'error',
  warning: 'warning',
  info: 'info'
}

@Component({
  selector: 'app-error-message',
  templateUrl: './error-message.component.html',
  styleUrls: ['./error-message.component.scss']
})
export class ErrorMessageComponent implements OnInit {

  @Input() text: string = '';
  @Input() type: string = ErrorTypes.error;
  @Input('error-with-support') public dalErrorWithSupport: boolean = false;

  constructor(private event: Broadcast) { }

  ngOnInit(): void {

  }

  showSupportDialog() {
    this.event.broadcast(ACTIONS.support)
  }

}
