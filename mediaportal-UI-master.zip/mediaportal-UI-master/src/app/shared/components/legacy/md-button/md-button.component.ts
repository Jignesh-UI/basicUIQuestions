import { Component, ElementRef, EventEmitter, HostListener, Input, OnChanges, OnInit, Output, Renderer2, SimpleChange, SimpleChanges } from '@angular/core';

@Component({
  selector: 'md-button',
  templateUrl: './md-button.component.html',
  styleUrls: ['./md-button.component.scss']
})
export class MdButtonComponent implements OnInit, OnChanges {

  @Input() disabled: boolean = false;
  @Input() color: string = '';
  @Output('click') click: EventEmitter<any> = new EventEmitter();

  constructor(public el: ElementRef, public redner: Renderer2) { }

  ngOnInit(): void {
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.hasOwnProperty('disabled')) {
      if (changes.disabled.currentValue) {
        this.redner.addClass(this.el.nativeElement, 'disabled')
      } else {
        this.redner.removeClass(this.el.nativeElement, 'disabled')
      }
    }
  }

}
