import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'md-content',
  templateUrl: './md-content.component.html',
  styleUrls: ['./md-content.component.scss']
})
export class MdContentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
