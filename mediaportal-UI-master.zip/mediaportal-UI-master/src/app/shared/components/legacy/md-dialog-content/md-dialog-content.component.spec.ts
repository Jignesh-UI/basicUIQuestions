import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MdDialogContentComponent } from './md-dialog-content.component';

describe('MdDialogContentComponent', () => {
  let component: MdDialogContentComponent;
  let fixture: ComponentFixture<MdDialogContentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MdDialogContentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MdDialogContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
