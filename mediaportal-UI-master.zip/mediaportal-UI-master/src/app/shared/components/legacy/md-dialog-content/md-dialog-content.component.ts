import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'md-dialog-content',
  templateUrl: './md-dialog-content.component.html',
  styleUrls: ['./md-dialog-content.component.scss']
})
export class MdDialogContentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
