import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'md-dialog',
  templateUrl: './md-dialog.component.html',
  styleUrls: ['./md-dialog.component.scss']
})
export class MdDialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
