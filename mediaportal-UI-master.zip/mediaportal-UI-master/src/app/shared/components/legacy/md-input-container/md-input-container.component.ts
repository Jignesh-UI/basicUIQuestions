import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-md-input-container',
  templateUrl: './md-input-container.component.html',
  styleUrls: ['./md-input-container.component.scss']
})
export class MdInputContainerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
