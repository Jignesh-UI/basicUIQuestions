import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'md-sidenav',
  templateUrl: './md-sidenav.component.html',
  styleUrls: ['./md-sidenav.component.scss']
})
export class MdSidenavComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
