import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-md-toolbar',
  templateUrl: './md-toolbar.component.html',
  styleUrls: ['./md-toolbar.component.scss']
})
export class MdToolbarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
