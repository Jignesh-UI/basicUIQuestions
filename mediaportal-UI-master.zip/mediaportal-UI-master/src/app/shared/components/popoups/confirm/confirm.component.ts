import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Subscription } from 'rxjs';

const noop = (status) => { }

interface ConfirmDialog {
  message: string;
  success: any;
  cancel: any;
  subscription: Subscription;
  confirmText: string;
  canceltext: string;
}

@Component({
  selector: 'app-confirm',
  templateUrl: './confirm.component.html',
  styleUrls: ['./confirm.component.scss']
})

export class ConfirmComponent implements OnInit {

  public cancelText: string = "Undo options";
  public confirmText: string = "Continue";

  constructor(@Inject(MAT_DIALOG_DATA) public dialog: ConfirmDialog) {
    this.cancelText = dialog.canceltext || this.cancelText ;
    this.confirmText = dialog.confirmText || this.confirmText;
  }

  success() {
    this.dialog.success(1)
  }

  cancel () {
    this.dialog.cancel(0)
  }

  ngOnInit(): void {

  }

}
