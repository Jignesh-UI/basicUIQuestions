import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { AssetDialogDataModel } from 'src/app/modules/asset/asset.defaults';
import { QuickPrintComponent } from 'src/app/modules/asset/quick-print/quick-print.component';

interface PopupDialog {
  message: string;
  success: boolean;
  subscription: Subscription;
}

@Component({
  selector: 'app-success',
  templateUrl: './popup.component.html',
  styleUrls: ['./popup.component.scss']
})

export class PopupComponent implements OnInit, OnDestroy {

  private subscrition: Subscription;
  public message: string = '';
  public success: boolean = true;

  constructor(@Inject(MAT_DIALOG_DATA) public data: PopupDialog,
    private dialogRef: MatDialogRef<PopupComponent>) {
    this.message = data.message;
    this.success = data.success;
    this.subscrition = data.subscription;

  }

  ngOnDestroy(): void {
  }

  hide() {
    this.dialogRef.close();
  }

  ngOnInit(): void {
  }

}
