import { AngularResizeDirective } from './angular-resize.directive';

describe('AngularResizeDirective', () => {
  it('should create an instance', () => {
    const directive = new AngularResizeDirective();
    expect(directive).toBeTruthy();
  });
});
