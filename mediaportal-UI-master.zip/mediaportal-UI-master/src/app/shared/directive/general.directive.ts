import { Directive, ElementRef, HostListener, Input, OnInit, Renderer2, RendererFactory2 } from '@angular/core';

@Directive({ selector: '[flex]' })
export class FlexDirective implements OnInit {
    private render: Renderer2;
    @Input('flex') public flexValue: number = 1
    constructor(private el: ElementRef, private renderFactory: RendererFactory2) {
        this.render = this.renderFactory.createRenderer(null, null)
    }
    ngOnInit(): void {
        this.render.addClass(this.el.nativeElement, 'flex');
        this.render.addClass(this.el.nativeElement, 'flex-' + this.flexValue);
        this.render.setStyle(this.el.nativeElement, 'flex', this.flexValue);
    }
}

@Directive({ selector: '[layout]' })
export class Layout implements OnInit {
    private render: Renderer2;
    @Input('layout') layout: string = '';
    constructor(private el: ElementRef, private renderFactory: RendererFactory2) {
        this.render = this.renderFactory.createRenderer(null, null)
    }
    ngOnInit(): void {
        this.render.addClass(this.el.nativeElement, 'flex-' + this.layout)
        this.render.addClass(this.el.nativeElement, 'md-layout-' + this.layout)
    }
}

@Directive({ selector: '[layout-align]' })
export class LayoutAlign implements OnInit {

    private render: Renderer2;
    @Input('layout-align') layoutAlign: string = '';

    constructor(private el: ElementRef, private renderFactory: RendererFactory2) {
        this.render = this.renderFactory.createRenderer(null, null)
    }

    ngOnInit(): void {
        let [alignItems, justifyContent] = this.layoutAlign.split(' ');
        if (!justifyContent) {
            justifyContent = alignItems;
        }
        this.render.setStyle(this.el.nativeElement, 'align-items', alignItems);
        this.render.setStyle(this.el.nativeElement, 'justify-content', justifyContent);
        this.render.setStyle(this.el.nativeElement, 'max-width', "100%");
    }
}

@Directive({ selector: '[offset]' })
export class OffsetDirective implements OnInit {

    private render: Renderer2;
    @Input('offset') offset: any = '';

    constructor(private el: ElementRef, private renderFactory: RendererFactory2) {
        this.render = this.renderFactory.createRenderer(null, null)
    }

    ngOnInit(): void {
        this.render.setStyle(this.el.nativeElement, 'margin-left', this.offset + "%");
    }
}
@Directive({ selector: '[right-click-disabled]' })
export class RightClickDisabled {

    constructor(private el: ElementRef) { }

    @HostListener('contextmenu', ['$event'])
    onRightClick(event) {
        event.preventDefault();
    }
}