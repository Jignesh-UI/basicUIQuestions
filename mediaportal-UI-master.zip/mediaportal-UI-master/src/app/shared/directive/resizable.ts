import { Directive, ElementRef, OnInit, Input, HostListener } from '@angular/core';
import { APP_EVENTS, LIGHTBOX_HEIGHTS } from 'src/app/app-defaults';
import { Broadcast } from '../services/broadcast.service';

@Directive({
    selector: '[appResizable]' // Attribute selector
})

export class ResizableDirective implements OnInit {


    @Input('grabber-size') resizableGrabHeight: number = 12;
    @Input('min-height') resizableMinHeight: number = 10;
    @Input('max-height') resizableMaxHeight: number = 10;

    public dragging = false;

    constructor(private el: ElementRef, private event: Broadcast) {
        const EventListenerMode = { capture: true };

        document.addEventListener('mousemove', this.mouseMoveG.bind(this), true);
        document.addEventListener('mouseup', this.mouseUpG.bind(this), true);
        el.nativeElement.addEventListener('mousedown', this.mouseDown.bind(this), true);
        el.nativeElement.addEventListener('mousemove', this.mouseMove.bind(this), true);
    }


    ngOnInit(): void {
    }


    preventGlobalMouseEvents() {
        document.body.style['pointer-events'] = 'none';
    }

    restoreGlobalMouseEvents() {
        document.body.style['pointer-events'] = 'auto';
    }

    newHeight(height) {
        height = this.el.nativeElement.clientHeight + (height)

        let fullscreenMaxHeight = LIGHTBOX_HEIGHTS.LIGHTBOXBAR_FULLSCREEN_HEIGHT();
        if (fullscreenMaxHeight == height) {
            this.el.nativeElement.style.height = fullscreenMaxHeight + "px";
            return false;
        }
        this.event.broadcast(APP_EVENTS.LIGHTBOX_STYLE_CHANGE, height);
        this.el.nativeElement.style.height = height + "px";
    }

    dragMoveG(evt: MouseEvent) {
        if (!this.dragging) {
            return;
        }
        const newHeight = Math.max(this.resizableMinHeight, (evt.clientY - this.el.nativeElement.offsetTop)) + "px";
        const height = (evt.clientY - this.el.nativeElement.offsetTop)
        evt.stopPropagation();
    };


    mouseMoveG(evt: MouseEvent) {
        if (!this.dragging) {
            return;
        }
        this.newHeight(this.el.nativeElement.offsetTop - evt.clientY)
        evt.stopPropagation();
    };

    mouseUpG(evt: MouseEvent) {
        if (!this.dragging) {
            return;
        }
        this.restoreGlobalMouseEvents();
        this.dragging = false;
        evt.stopPropagation();
    };

    mouseDown(evt: MouseEvent) {
        if (this.inDragRegion(evt)) {
            this.dragging = true;
            this.preventGlobalMouseEvents();
            evt.stopPropagation();
        }
    };


    mouseMove(evt: MouseEvent) {
        if (this.inDragRegion(evt) || this.dragging) {
            this.el.nativeElement.style.cursor = "row-resize";
        } else {
            this.el.nativeElement.style.cursor = "default";
        }
    }

    inDragRegion(evt) {
        let el = this.el.nativeElement as HTMLElement;

        let delta = (evt.clientY - el.offsetTop)
        return delta > 0 && delta < this.resizableGrabHeight;
    }

}
