import { Component, Input, OnInit } from '@angular/core';

@Component({
    selector: 'icon',
    template: `{{ucode}}`
})

export class IconComponent implements OnInit {
    @Input() ucode: string = ''
    constructor() { }

    ngOnInit() { }

}