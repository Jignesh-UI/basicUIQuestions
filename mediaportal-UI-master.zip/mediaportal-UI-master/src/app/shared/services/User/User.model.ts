export class User {
    public domainName;
    public email;
    public firstName;
    public lastName;
    public notifications;
    public loginName;
    public otmmTicket;
    public participatingBusinessUnit;
    public roleName;
    public sessionId;
    public systemAdministrator;
    public userId;
    public userRoleId;
    public businessUnits: string[] = [];
    constructor(user: any) {
        this.domainName = user?.domainName;
        this.email = user?.email;
        this.firstName = user?.firstName;
        this.lastName = user?.lastName;
        this.notifications = user?.notifications;
        this.loginName = user?.loginName;
        this.otmmTicket = user?.otmmTicket;
        this.participatingBusinessUnit = user?.participatingBusinessUnit;
        this.roleName = user?.roleName;
        this.sessionId = user?.sessionId;
        this.systemAdministrator = user?.systemAdministrator;
        this.userId = user?.userId;
        this.userRoleId = user?.userRoleId;
        this.businessUnits = user?.businessUnits;
    }
}