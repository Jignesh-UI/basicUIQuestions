import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpService } from '../http/http.service';
import * as _ from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class BusinessUnitService {
  private businessUnits: string[] = [];

  constructor(private http: HttpService) { }

  public errorGettingBusinessUnits(res) {
    //app does not work at this point, should do more...
    throw new Error("Cannot fetch user's business unit");

  }

  resetBusinessUnit() {
    this.businessUnits = [];
  }

  public getBusinessUnits() {
    if (this.businessUnits.length > 0) {
      return new Observable(observer => observer.next(this.businessUnits))
    } else {
      return this.http.get('portalconfig').pipe(map((res: any) => {
        this.businessUnits = res.data.businessUnits;
        return this.businessUnits;
      }));
    }
  }

  public getIndex(bu): number {
    var businessUnit = bu.toLowerCase();
    var theReturn = -1;
    _.each(this.businessUnits, (value, index) => {
      if (businessUnit === value.toLowerCase()) {
        theReturn = index;
        return false;
      }
    });

    return theReturn;
  }
}
