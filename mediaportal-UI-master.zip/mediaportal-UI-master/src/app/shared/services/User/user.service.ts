import { Injectable } from '@angular/core';
import { HttpService } from '../http/http.service';
import { User } from './User.model';
import { StorageService } from '../storage.service';
import { Router } from '@angular/router';
import { Broadcast } from '../broadcast.service';
import { ACTIONS } from '../consts/actions.consts';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class UserService {

    constructor(private httpClient: HttpService, private storage: StorageService,
        private router: Router, private event: Broadcast) {
        let userData = this.storage.sessionStorage.getItem('userDetails');
        if (userData) {
            this.user = new User(userData);
        }
        this.event.on(ACTIONS.logout).subscribe(this.expire.bind(this))
    }
    
    private _user: User;

    get userIsLoggedIn() {
        return this.user ? true : false;
    }

    set user(user) {
        this._user = user;
    }

    get user() {
        return this._user;
    }

    get userDetails() {
        return this._user;
    }

    reset() {
        this._user = null;
    }

    public getParticipatingBusinessUnit() {
        return this.user.participatingBusinessUnit;
    }

    getUserData(name) {
        return this.user[name];
    }


    login(user) {
        return this.httpClient.post('login', user);
    }

    selectBU(participantBU, loginName, userId) {
        var putData = {
            loginName,
            userId,
            participantBU
        };

        return this.httpClient.put('participantbu', putData)
    }

    authSuccess(data) {
        this.storage.sessionStorage.setItem('userDetails', data);
        this.user = data;
        this.router.navigate(['home']);
    }

    expire(data = null) {
        this.reset();
        this.storage.sessionStorage.removeItem('userDetails');
        this.router.navigate(['login']);
    }

    logout(): Observable<any> {
        return this.httpClient.post('logout', {});
    }
}