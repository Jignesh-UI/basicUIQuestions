import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpService } from '../http/http.service';

@Injectable({ providedIn: 'root' })
export class AssetService {

    private freeTextUrl = 'freeTextSearch';
    private filterFreeTextUrl = 'filterFreeTextSearch';

    constructor(private http: HttpService) { }

    search(query): Observable<any> {
        return this.http.post('freeTextSearch', query);
    }

    filter(query): Observable<any> {
        return this.http.post('filterFreeTextSearch', query);
    }

    details(assetId) {

        let payload = { "assetIds": [assetId], "metadataFields": [] };
        return this.http.post('getAssetsDetails', payload).pipe(map((res: any) => {
            return res.data[0];
        }));
    }

}