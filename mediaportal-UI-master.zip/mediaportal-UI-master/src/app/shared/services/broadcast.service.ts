import { Inject, Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { filter, map } from 'rxjs/operators';

interface BroadcastEvent {
    key: any;
    data?: any;
}

@Injectable({ providedIn: 'root' })

export class Broadcast {
    private _eventQue: Subject<BroadcastEvent>;

    constructor() {
        this._eventQue = new Subject<BroadcastEvent>();
    }

    broadcast(key: any, data?: any) {
        this._eventQue.next({ key, data });
    }

    on<T>(key: any): Observable<T> {
        key = Array.isArray(key) ? key : [key];
        return this._eventQue.asObservable()
            .pipe(filter(event => key.indexOf(event.key) >= 0),
                map(event => <T>event.data));
    }
}