import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpService } from './http/http.service';

export abstract class Unsubscriber {
    add(a: Subscription) { }
    reset() { }
}

export const unsubscribe = (list: Subscription[]) => {
    list.forEach(sb => {
        sb.unsubscribe();
    });
    return [];
}

export const unsubscribable = (existing: Subscription[] = []): Unsubscriber => {
    return (() => {
        let list: Subscription[] = []
        list = list.concat(existing)
        return {
            add: (subscriber) => list.push(subscriber),
            reset: () => {
                for (let subscription of list) {
                    console.log('unsubs')
                    subscription.unsubscribe()
                }
            }
        }
    })();
}
@Injectable({ providedIn: 'root' })
export class CommonService {
    constructor(private httpClient: HttpService) { }

    private portalConfig: any = null;

    sbs(existing: Subscription[] = []): Unsubscriber {
        return (() => {
            let list: Subscription[] = []
            list = list.concat(existing)
            return {
                add: (subscriber) => list.push(subscriber),
                reset: () => {
                    for (let subscription of list) {
                        subscription.unsubscribe()
                    }
                }
            }
        })();
    }

    getCarousel() {
        return this.httpClient.get('getCarouselAssets');
    }

    getPortalConfig(name = '') {
        if (this.portalConfig) {
            return new Observable(observer => {
                observer.next(this.getConfig(name));
            })
        } else {
            return this.httpClient.get('portalconfig').pipe(map((res: any) => {
                this.portalConfig = res.data;
                return this.getConfig(name);
            }));
        }

    }

    getConfig(name) {
        if (this.portalConfig && name) {
            return this.portalConfig[name]
        }
        return null
    }
}