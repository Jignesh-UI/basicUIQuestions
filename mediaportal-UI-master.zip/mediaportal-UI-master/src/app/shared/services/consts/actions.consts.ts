export const ACTIONS = {
    login: 'login',
    load: 'loading',
    unload: 'unloading',
    logout: 'logout',
    search: 'search',
    support: 'support'
}