import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, Observer, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { Broadcast } from '../broadcast.service';
import { ACTIONS } from '../consts/actions.consts';
import { NgxSpinnerService } from 'ngx-spinner';

@Injectable({ providedIn: 'root' })
export class HttpService {

    constructor(private httpClient: HttpClient, private event: Broadcast, private spinner: NgxSpinnerService) { }

    generateUrl(uri) {
        return environment.baseUrl + uri;
    }

    beforeCall() {
        this.spinner.show();
    }

    afterCall() {
        this.spinner.hide();
    }

    post(uri, data): Observable<any> {
        let ob = this.httpClient.post(uri, data);
        this.beforeCall();
        return ob.pipe.apply(ob, this.pipe());
    }

    put(uri, data): Observable<any> {
        let ob = this.httpClient.put(uri, data);
        this.beforeCall();
        return ob.pipe.apply(ob, this.pipe());
    }

    get(uri, data = {}): Observable<any> {
        let ob = this.httpClient.get(uri, {
            params: data
        });
        this.beforeCall();
        return ob.pipe.apply(ob, this.pipe());
    }

    pipe() {
        return [map(this.map.bind(this)), catchError(this.catch.bind(this))]
    }

    map(data) {
        this.afterCall();
        if (data.succeeded === false && data.message === 'REQUEST_NOT_AUTHORIZED') {
            this.event.broadcast(ACTIONS.logout)
        }
        return data;
    }

    catch(err: HttpErrorResponse) {
        this.afterCall();
        return of(err);
    }

    mock(url, data, t = 2000): Observable<any> {
        this.beforeCall();
        return new Observable((observer: Observer<any>) => {
            setTimeout(() => {
                this.afterCall();
                observer.next({
                    url,
                    data
                });
            })
        })
    }
}