import { Injectable, Renderer2, RendererFactory2 } from '@angular/core';
import { ElementRef } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class ElementService {
    private render: Renderer2;
    constructor(private renderFactory: RendererFactory2) {
        this.render = this.renderFactory.createRenderer(null, null)
    }

    element(el: HTMLElement) {
        return new JQlite(el, this.render);
    }

}



export class JQlite {

    private el: HTMLElement;
    private render;
    constructor(el, render: Renderer2) {
        this.el = el;

        this.render = render
    }

    get width() {
        return this.el.clientWidth;
    }

    css(styles) {
        if (this.el instanceof NodeList) {
            this.el.forEach(el => {
                this.applyCss(el, styles);
            })
        } else {
            this.applyCss(this.el, styles);
        }
    }

    applyCss(el, styles) {
        for (let style in styles) {
            if (el) this.render.setStyle(el, style, styles[style]);
        }
    }

}
