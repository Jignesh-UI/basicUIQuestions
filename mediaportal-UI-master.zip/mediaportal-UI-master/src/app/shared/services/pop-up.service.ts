import { Injectable } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import * as _ from 'lodash';
import { SupportComponent } from 'src/app/modules/layout/components/support/support.component';
import { CollaboratorComponent } from 'src/app/modules/lightbox/collaborator/collaborator.component';
import { LightboxFulfillApprovalComponent } from 'src/app/modules/lightbox/lightbox-fulfill-approval/lightbox-fulfill-approval.component';
import { LightboxFulfillComponent } from 'src/app/modules/lightbox/lightbox-fulfill/lightbox-fulfill.component';
import { ConfirmComponent } from '../components/popoups/confirm/confirm.component';
import { PopupComponent } from '../components/popoups/success/popup.component';
import { ElementService } from './jQlite';

@Injectable({
  providedIn: 'root'
})

export class PopUpService {

  private currentShownDialog;
  private dialogsToShow = [];
  private popped: MatDialogRef<any>[] = []

  constructor(private $mdDialog: MatDialog, private angular: ElementService) {
  }

  private hide(dialog) {
  }

  public showConfirmDialog(message, successCb, failureCb, confirmText = '', cancelText = '') {
    if (!confirmText) confirmText = "Yes";
    if (!cancelText) cancelText = "Cancel";

    let ref: MatDialogRef<ConfirmComponent> = this.$mdDialog.open(ConfirmComponent, {
      data: {
        message,
        success: (e) => {
          ref.close()
          successCb(e)
        },
        cancel: (e) => {
          ref.close()
          failureCb(e)
        },
        cancelText,
        confirmText
      }
    })

    return ref;
  }

  public showSuccessDialog(message, time = 2000) {
    if (typeof message !== 'string') {
      message = 'Success :)';
    }

    return this.showFeedbackDialog(true, message, time);
  }

  public showFailureDialog(message) {
    if (typeof message !== 'string') {
      message = 'Error :(';
    }

    return this.showFeedbackDialog(false, message);
  }

  public showFeedbackDialog(success, message, timeout = 2000) {
    let ref: MatDialogRef<PopupComponent> = this.$mdDialog.open(PopupComponent, {
      data: {
        success, message
      }
    });
    /**This is kept for future refference */
    // this.popped.push(ref);

    return () => {
      ref.close()
      // this.popped.pop();
    };
  }

  public showEditLightboxDialog(component) {
    this.popped.push(this.$mdDialog.open(component, {
      data: {
        edit: true,
      }
    }));
  }

  public showCloneLightboxDialog(component) {
    this.popped.push(this.$mdDialog.open(component, {
      data: {
        clone: true,
      }
    }));
  }

  public hideDialog() {
    let ref = this.popped.pop();
    ref?.close();
  }

  public placePopup(config) {
    var e = config.event;

    var container = config.container || this.angular.element(document.body)[0];
    var containerOffset = this.getOffset(container);

    var popup = config.popup;
    var popupWidth = popup.offsetWidth;

    var eventTarget = config.targetOverride || e.target;
    var eventTargetOffset = this.getOffset(eventTarget);

    var offsetMiddleX = eventTargetOffset.left + eventTarget.offsetWidth / 2;
    var itemStartX = offsetMiddleX - popupWidth / 2;

    var itemDoesNotFitXRight = itemStartX + popupWidth > document.documentElement.clientWidth;
    var itemDoesNotFitXLeft = itemStartX < containerOffset.left;

    var itemDoesNotFitYBottom = itemStartX < containerOffset.left;

    var itemTooBigX = popupWidth > container.offsetWidth;

    var itemDoesNotYBottom = eventTargetOffset.top + popup.offsetHeight > document.documentElement.clientHeight;
    this.resetPosition(popup);

    if (itemTooBigX || itemDoesNotFitXLeft) {
      popup.style.left = containerOffset.left + 'px';
    } else if (itemDoesNotFitXRight) {
      popup.style.right = '0px';
    } else {
      popup.style.left = itemStartX + 'px';
    }

    if (itemDoesNotYBottom) {
      popup.style.bottom = '0px';
    } else {
      popup.style.top = eventTargetOffset.top + 'px';
    }
  }

  private getOffset(el) {
    var rect = el.getBoundingClientRect()

    return {
      top: rect.top + document.body.scrollTop,
      left: rect.left + document.body.scrollLeft
    }
  }

  private resetPosition(el) {
    el.style.left = null;
    el.style.right = null;
    el.style.top = null;
    el.style.bottom = null;
  }

  public showCollaboratorsSearchDialog(lightbox, isRemoveCollaboratorPopupOpen) {
    let ref = this.$mdDialog.open(CollaboratorComponent, {
      data: {
        lightbox,
        isRemoveCollaboratorPopupOpen,
        popupService: this
      }
    });
    this.popped.push(ref);
    return ref;
  }

  public showRequestFulfillmentDialog(lightbox) {
    let ref = this.$mdDialog.open(LightboxFulfillComponent, {
      data: {
        lightbox
      }
    });
    this.popped.push(ref);
    return ref;
  }

  public showFulfillmentApprovalDialog(lightbox) {
    let ref = this.$mdDialog.open(LightboxFulfillApprovalComponent, {
      data: {
        lightbox
      }
    });
    this.popped.push(ref);
    return ref;
  }

  showSupportDialog() {
    let ref = this.$mdDialog.open(SupportComponent, {
      data: {}
    });
    this.popped.push(ref);
    return ref;
  }
}
