import { Injectable } from '@angular/core';
import * as _ from "lodash";
import { Subscription } from 'rxjs/internal/Subscription';
import { filter } from 'rxjs/operators';
import { DATE_IMPORTED } from 'src/app/app-defaults';
import { FilterItemComponent } from 'src/app/modules/asset/filter/filter-item/filter-item.component';
import { HttpService } from '../http/http.service';

const META_DATA_FIELD_NAMES = {
  ADAPTATION_RIGHTS: "DAL.FIELD.ADAPTATION RIGHTS",
  BUSINESS_UNIT_RIGHTS: "DAL.FIELD.BUSINESS UNIT RIGHTS",
  USAGE_RESTRICTIONS: "DAL.FIELD.USAGE RESTRICTIONS"
};


@Injectable({
  providedIn: 'root'
})

export class SearchHelperService {

  public rightFilters: any[] = [];
  public nonRightFilters: any[] = [];
  public rightFilterItems = ['']
  public basicsearchJsonRequest: any;
  public keyword: string = '';
  public searchRequestObject = {
    requestOut: false,
    lastRequestHasErrors: false,
    hasNoAssetsFound: false
  }
  public searchRequestCanceler: Subscription;
  public isSideNavHidden = false;
  public assets: Array<any> = new Array<any>();
  public facets: Array<any> = new Array<any>();
  public isFreeTextSearch = false;
  public combinedFiltersSelection = [];
  public allRestrictionFiltersPerUser = [];
  public userSelectedFilters: any = [];
  public usageRestrictionFilters: any = [];
  public ffuFilterStatus = "enabled";
  public totalAssets: number = 0;
  public pendingSearchRequest = false;
  public toggleSearchHeaderClass = false;
  public searchUrl = '';
  public sortImageSrc = "24x24-descending.png";
  public facetsSortedReference: Array<string> = ['DAL.FIELD.ADAPTATION RIGHTS', 'DAL.FIELD.BUSINESS UNIT RIGHTS', 'DAL.FIELD.USAGE RESTRICTIONS',
    'ARTESIA.FIELD.MODEL', 'DAL.FIELD.ASSET TYPE', 'DAL.FIELD.RIGHTS CATEGORY', 'DAL.FIELD.MARKETING USE', 'DAL.FIELD.ASSET SOURCE',
    'DAL.FIELD.LICENSING_LIMITATIONS', 'DAL.FIELD.GENDER', 'DAL.FIELD.AGE GROUP', 'DAL.FIELD.NUMBER OF PEOPLE', 'DAL.FIELD.ETHNICITY', 
    'DAL.FIELD.SPECIAL NEEDS', 'DAL.FIELD.GENRE', 'DAL.FIELD.CHARACTERISTICS', 'DAL.FIELD.COLORBW FACET', 'DAL.FIELD.ORIENTATION', 
    'DAL.FIELD.VIDEO SOUND', 'DAL.FIELD.VIDEO DIMENSION', 'DAL.FIELD.LANGUAGE', 'DAL.FIELD.ASSET STATUS', 'DAL.FIELD.FINALIZED FLAG', 
    'DAL.FIELD.PROVIDER BU', 'DAL.FIELD.RETAIL COLLECTION', 'DAL.FIELD.DISTRIBUTION RIGHTS', 'DAL.FIELD.ASSET FORMAT'
];

  public finalSortedFacets: Array<any> = new Array<any>();

  private freeTextUrl = 'freeTextSearch';
  private filterFreeTextUrl = 'filterFreeTextSearch';
  public countPerPage: number = 50;

  public rightFiltersUnits = ['Adaptation Rights', 'Business Unit Rights', 'Usage Restrictions']
  public rightFiltersUnitsIDS = [ 'DAL.FIELD.ADAPTATION RIGHTS', 'DAL.FIELD.BUSINESS UNIT RIGHTS', 'DAL.FIELD.USAGE RESTRICTIONS']
  public metadataFieldName = {
    Model: "Model",
    Color: "Color B&W"
  };

  SearchHelper_chkDAR: boolean = false;
  SearchHelper_chkDBUR: boolean = false;
  SearchHelper_chkDUR: boolean = false;

  constructor(private http: HttpService) {
    this.reset();
  }

  private getFilterLabel(fieldPrompt) {
    if (fieldPrompt === this.metadataFieldName.Model) {
      return "Media Type";
    }

    if (fieldPrompt === this.metadataFieldName.Color) {
      return "Color/BW";
    }

    return fieldPrompt;
  }

  reset() {
    this.assets = [];
    this.searchUrl = '';
    this.basicsearchJsonRequest = {
      keyword: "",
      pageNumber: 0,
      countPerPage: this.countPerPage,
      metadataFields: [],
      facetRestrictionFields: [],
      sortFields: [{
        sortFieldId: "ARTESIA.FIELD.DATE IMPORTED",
        sortOrder: "desc"
      }],
      modeFFU: true
    };
  }

  public search() {
    if (this.basicsearchJsonRequest.keyword.length > 0) {
      this.basicsearchJsonRequest.facetRestrictionFields = this.getExistingFilters();
      this.searchRequestObject.requestOut = true;
      this.searchRequestObject.lastRequestHasErrors = false;
      this.searchRequestObject.hasNoAssetsFound = false;
      this.assets = [];
      this.pendingSearchRequest = true;

      return this.http.post(this.searchUrl, this.basicsearchJsonRequest);
    }
  }

  public fetchResponseData(res) {
    if (res?.succeeded) {
      this.searchSuccess(res);
    } else {
      this.searchFailure();
    }
  }

  public searchHasNoAssets() {
    this.totalAssets = 0;
    this.assets = [];
    this.facets = [];
    this.searchRequestObject.hasNoAssetsFound = true;
    //Make selected filters = []
    this.filters = []
    //Make Filter Updated value = false
    this.filterUpdated = false;
    //Store the initial value of right filters
    if (this.searchUrl === this.freeTextUrl) {
      this.rightFilters = this.selectedFilters.filter(item => (this.rightFiltersUnitsIDS.indexOf(item.fieldId) >= 0));
    }
  }

  public searchSuccess(res) {
    //Set the filters that is checked by user or by default for right filtering
    if (res.succeeded) {
      this.selectedFilters = res.data.originalSearchReq.facetRestrictionFields;
      if (this.selectedFilters.length > 0 && !this.rightFilterEnabled) {
        this.filterUpdated = true;
      }
    }

    if (res.data.assets.length == 0) {
      this.searchHasNoAssets();
    } else {
      this.useResponseData(res);
    }
  }

  public searchFailure() {
    this.searchRequestObject.lastRequestHasErrors = true;
  }

  private createFacetRestrictionsObjectForNewRequest(res) {
    if (this.isFreeTextSearch) {
      this.fetchUserSpecificFacetRestrictions(res.data.originalSearchReq.facetRestrictionFields);
    }
    if (!this.isFfuFilterDisabled) {
      this.updateUsageRestrictionFilters(res.data.facets);
    }
    this.combineAllFiltersForNewRequest();
  }

  private useResponseData(res) {
    this.assets = res.data.assets;
    this.totalAssets = res.data.totalCount;
    this.facets = res.data.facets;

    this.sortFacetsResponse(this.facets);


    //Store the initial value of right filters
    if (this.searchUrl == this.freeTextUrl) {
      this.rightFilters = this.selectedFilters.filter(item => (this.rightFiltersUnitsIDS.indexOf(item.fieldId) >= 0));
    }


    //NEW : Set the filter object for the filter list
    this.setFilters();
  }

  private sortFacetsResponse(facetsArrayofObjects) {
    this.finalSortedFacets = [];
    for (let i = 0; i < this.facetsSortedReference.length; i++) {
      for (let j = 0; j < facetsArrayofObjects.length; j++) {
        if (this.facetsSortedReference[i] === facetsArrayofObjects[j].fieldId) {
          this.finalSortedFacets.push(facetsArrayofObjects[j]);
        }
        this.facets = this.finalSortedFacets;
      }
    }
  }

  private fetchUserSpecificFacetRestrictions(jsonOriginalReqObject) {
    this.allRestrictionFiltersPerUser = [];
    this.allRestrictionFiltersPerUser = this.jsonObjectToArrayFacetsResponse(jsonOriginalReqObject);
  }

  private updateUsageRestrictionFilters(jsonFacets) {
    this.usageRestrictionFilters = [];

    if (jsonFacets.length > 0) {
      this.usageRestrictionFilters = this.combineFiltersFromFacetsAndFacetsRestrictions(jsonFacets)
    } else {
      this.usageRestrictionFilters = this.allRestrictionFiltersPerUser;
    }
  }

  private combineFiltersFromFacetsAndFacetsRestrictions(jsonFacets) {
    let jsonFacetsObject = this.jsonObjectToArrayFacetsResponse(jsonFacets);
    return _.intersection(this.allRestrictionFiltersPerUser, jsonFacetsObject);
  }

  public combineAllFiltersForNewRequest() {
    this.combinedFiltersSelection = this.usageRestrictionFilters.concat(this.userSelectedFilters).sort();
    this.basicsearchJsonRequest.facetRestrictionFields = this.constructFacetRestrictionsJSON(this.combinedFiltersSelection);
  }

  public sortAllFiltersForNewRequest() {
    return this.userSelectedFilters.concat(this.allRestrictionFiltersPerUser).sort()
  }

  public jsonObjectToArrayFacetsResponse(jfr): any {
    let list = [];

    for (let fri in jfr) {
      for (let i in jfr[fri].valueList) {
        list.push(jfr[fri].fieldId + "," + jfr[fri].valueList[i].value);
      }
    }
    return list;
  }

  public constructFacetRestrictionsJSON(allFiltersArray): any {
    let selectedFacetsRestrictrionFields = [];
    let valueList = [];
    let prevFieldId = "";
    let fieldRestrictionObject;
    let fieldRestrictionData;

    for (let i = allFiltersArray.length; i--;) {
      fieldRestrictionData = allFiltersArray[i].split(',');
      let fieldName = fieldRestrictionData.shift();
      let fieldValue = fieldRestrictionData.join();
      let fieldObject = {
        value: fieldValue,
        count: 0
      };

      if (fieldName === prevFieldId) {
        valueList.push(fieldObject);
        prevFieldId = fieldName;
      } else {
        prevFieldId = fieldName;
        valueList = [fieldObject];
        fieldRestrictionObject = {
          fieldId: prevFieldId,
          fieldPrompt: null,
          valueList: valueList
        };
        selectedFacetsRestrictrionFields.push(fieldRestrictionObject);
      }
    }
    return selectedFacetsRestrictrionFields;
  }

  public updateRequestOnSingleFilterClick(fieldRestrictionID, fieldRestrictionValue) {
    if (fieldRestrictionID === META_DATA_FIELD_NAMES.BUSINESS_UNIT_RIGHTS || fieldRestrictionID === META_DATA_FIELD_NAMES.ADAPTATION_RIGHTS
      || fieldRestrictionID === META_DATA_FIELD_NAMES.USAGE_RESTRICTIONS) {
      this.usageRestrictionFilters.push(fieldRestrictionID + "," + fieldRestrictionValue);
      this.usageRestrictionFilters = _.uniq(this.usageRestrictionFilters);
    }
    else {
      this.userSelectedFilters.push(fieldRestrictionID + "," + fieldRestrictionValue);
      this.userSelectedFilters = _.uniq(this.userSelectedFilters);
    }
  }

  public updateRequestOnMetaDataRemoval(fieldRestrictionID) {
    let fieldRestrictionData;

    for (let i = this.userSelectedFilters.length; i--;) {
      fieldRestrictionData = this.userSelectedFilters[i].split(',');
      if (fieldRestrictionData[0] === fieldRestrictionID) {
        this.userSelectedFilters.splice(i, 1);
      }
    }
    this.removeFieldIdfromCombinedFilters(fieldRestrictionID);
    this.removeFieldIdFiltersfromRestrictionFilters(fieldRestrictionID);
  }

  private removeFieldIdfromCombinedFilters(fieldRestrictionID) {
    let fieldRestrictionData;

    for (let i = this.combinedFiltersSelection.length; i--;) {
      fieldRestrictionData = this.combinedFiltersSelection[i].split(',');
      if (fieldRestrictionData[0] === fieldRestrictionID) {
        this.combinedFiltersSelection.splice(i, 1);
      }
    }
  }

  private removeFieldIdFiltersfromRestrictionFilters(fieldRestrictionID) {
    let fieldRestrictionData;

    for (let i = this.usageRestrictionFilters.length; i--;) {
      fieldRestrictionData = this.usageRestrictionFilters[i].split(',');
      if (fieldRestrictionData[0] === fieldRestrictionID) {
        this.usageRestrictionFilters.splice(i, 1);
      }
    }
  }

  public sendUpdatedSearchRequest(url) {
    this.searchUrl = url;
    return this;
  }

  public sendUpdatedSearchPaginationRequest(url) {
    if (url.indexOf('filter') === 0) {
      this.searchUrl = this.filterFreeTextUrl;
    } else {
      this.searchUrl = this.freeTextUrl;
    }

    return this.search();
  }

  public searchFinally() {
    this.searchRequestObject.requestOut = false;
    this.pendingSearchRequest = false;
    this.toggleSearchHeaderClass = false;
    this.isFreeTextSearch = false;
  }

  public getSortImageSrc() {
    return this.sortImageSrc;
  }

  public getCurrentSortOrder() {
    return this.basicsearchJsonRequest.sortFields[0].sortOrder;
  }

  public setSortField(sortField) {
    this.basicsearchJsonRequest.sortFields[0].sortFieldId = sortField;
  }

  public setSortOrder(sortOrder) {
    if (sortOrder === 'asc') {
      this.basicsearchJsonRequest.sortFields[0].sortOrder = "asc";
      this.sortImageSrc = "24x24-ascending.png";
    } else {
      this.basicsearchJsonRequest.sortFields[0].sortOrder = "desc";
      this.sortImageSrc = "24x24-descending.png";
    }
  }

  public getSearchRequestObject() {
    return this.searchRequestObject;
  }

  public setBasicsearchJsonRequest(updatedRequestObject) {
    _.extend(this.basicsearchJsonRequest, updatedRequestObject);
  }

  public setUserSelectedFilters(userSelectedFilters) {
    this.selectedFilters = userSelectedFilters;
  }

  public setUsageRestrictionFilters(usageRestrictionFilters) {
    this.rightFilters = usageRestrictionFilters;
  }

  public setAllRestrictionFiltersPerUser(allRestrictionFiltersPerUser) {
    this.filters = allRestrictionFiltersPerUser;
  }

  public setAssets(assets) {
    this.assets = assets;
  }

  public setFacets(facets) {
    this.facets = facets;
  }

  public setTotalAssets(totalAssets) {
    this.totalAssets = totalAssets;
  }

  public setToggleSearchHeaderClass(toggleSearchHeaderClass) {
    this.toggleSearchHeaderClass = toggleSearchHeaderClass;
  }

  public setIsFreeTextSearch(isFreeTextSearch) {
    this.isFreeTextSearch = isFreeTextSearch;
  }


  get isFfuFilterDisabled() {
    return this.ffuFilterStatus === 'disabled';
  }

  public setFfuFilterStatus(ffuFilterStatus) {
    this.ffuFilterStatus = ffuFilterStatus;
  }

  public setPageNumber(pageNumber) {
    this.basicsearchJsonRequest.pageNumber = pageNumber;
  }

  public setPageNumberToOne() {
    this.setPageNumber(0);
    return this;
  }


  public getAllRestrictionFiltersPerUser() {
    return this.allRestrictionFiltersPerUser;
  }

  public getPendingSearchRequest(pendingSearchRequest) {
    return this.pendingSearchRequest;
  }

  public getFacets() {
    return this.facets;
  }

  public getUserSelectedFilters() {
    return this.userSelectedFilters;
  }

  public getToggleSearchHeaderClass() {
    return this.toggleSearchHeaderClass;
  }

  public getUsageRestrictionsFilters() {
    return this.usageRestrictionFilters;
  }

  public getIsFfuFilterDisabled() {
    //the variable checking with the ffufilterStatus, as this variable checked with the "enabled" value so making this 
    // attribute negetive attribute using !
    return !this.rightFilterEnabled;
  }

  public getAssets() {
    return this.assets;
  }

  public getTotalCountOfAssets() {
    return this.totalAssets;
  }

  public getIsSideNavHidden() {
    return this.isSideNavHidden;
  }

  public cancelPendingSearch() {
    this.searchRequestCanceler.unsubscribe();
  }

  public getPageNumber() {
    return this.basicsearchJsonRequest.pageNumber;
  }

  public getCountPerPage() {
    return this.basicsearchJsonRequest.countPerPage;
  }

  public clearAllFilters() {

    this.selectedFilters = [];
    /**This is kept for future refference */
    // this.filters = []
    // this.clearAssetAttributeFilters();
    // this.clearUsageRestrictionFilters();
  }

  public clearAssetAttributeFilters() {
    this.setUserSelectedFilters([]);
  }

  public clearUsageRestrictionFilters() {
    if (!this.rightFilterEnabled) {
      this.setUsageRestrictionFilters([]);
    }
  }

  public toggleFfuFilter(enabled: any = null) {
    let emptyArray = [];
    let shouldBeEnabled;

    if (typeof enabled === 'boolean') {
      shouldBeEnabled = enabled;
    } else {
      shouldBeEnabled = this.rightFilterEnabled;
    }

    this.setBasicsearchJsonRequest({
      'modeFFU': shouldBeEnabled || !this.SearchHelper_chkDUR
    });

    if (shouldBeEnabled) {
    } else {
      this.filters.forEach(item => {
        if (this.rightFiltersUnitsIDS.indexOf(item.fieldId) >= 0) {
          item.valueList = item.valueList.map(_i => {
            return {
              ..._i,
              checked: false
            }
          })
        }
      })
    }
  }

  getExistingFilters() { // this function adding the filters
    let filters = this.filters;
    let updatedRightsFilter = this.rightFilters;

    /* //Commented for VDALRU-5892
    if (this.rightFilterEnabled) {
      filters = this.filters.filter(item => !item.isRightsFilter)
    }
    */

    filters = this.filters.filter(item => !item.isRightsFilter);
    if(this.SearchHelper_chkDUR){//Added for VDALRU-5892
      filters = filters.concat(this.filters.filter(item => item.fieldId==META_DATA_FIELD_NAMES.USAGE_RESTRICTIONS))
    }
    if(this.SearchHelper_chkDAR){//Added for VDALRU-5892
      updatedRightsFilter = updatedRightsFilter.filter(item => item.fieldId!=META_DATA_FIELD_NAMES.ADAPTATION_RIGHTS)
      filters = filters.concat(this.filters.filter(item => item.fieldId==META_DATA_FIELD_NAMES.ADAPTATION_RIGHTS))
    }
    if(this.SearchHelper_chkDBUR){//Added for VDALRU-5892
      updatedRightsFilter = updatedRightsFilter.filter(item => item.fieldId!=META_DATA_FIELD_NAMES.BUSINESS_UNIT_RIGHTS)
      filters = filters.concat(this.filters.filter(item => item.fieldId==META_DATA_FIELD_NAMES.BUSINESS_UNIT_RIGHTS))
    }
    
    //Added for VDALRU-5892
    if (!this.rightFilterEnabled && !this.filterUpdated && !this.SearchHelper_chkDUR && !this.SearchHelper_chkDAR && !this.SearchHelper_chkDBUR) {
      this.filterUpdated = false;
      return [];
    }

    filters = filters.filter(_i => (_i.valueList.length > 0 && _i.valueList.some(_ia => _ia.checked === true)))
      .map(r => {
        let { fieldId, valueList, fieldPrompt } = r
        valueList = valueList.filter(item => item.checked).map(({ value, count }) => {
          return {
            value,
            count: 0
          };
        })
        return {
          fieldId,
          fieldPrompt: null,
          valueList
        }
      })

    /* //Commented for VDALRU-5892
    if (this.rightFilterEnabled && this.searchUrl === this.filterFreeTextUrl) {
      filters = filters.concat(this.rightFilters)
    }
    */

    filters = filters.concat(updatedRightsFilter);

    return filters;
  }

  public pushRightsFiltersInRequest() {
    let combinedAllRestrictionsandUserSelectedFilterRequest = [];

    combinedAllRestrictionsandUserSelectedFilterRequest = this.sortAllFiltersForNewRequest();
    this.basicsearchJsonRequest.facetRestrictionFields = this.constructFacetRestrictionsJSON(combinedAllRestrictionsandUserSelectedFilterRequest);
  }

  public isUserUsageRestrictionsLoaded() {
    return this.getAllRestrictionFiltersPerUser().length !== 0;
  }

  resetFieldFilters(fieldName) {
    let right = this.filters.find(item => item.fieldId === fieldName)
    if (right) {
      right.valueList.forEach(element => {
        element.checked = false;
      });
    }
    return this;
  }

  setFilters(filters: any = null) {

    if (filters != null) {
      this.filters = filters;
    } else {
      let filedPropts = ['Adaptation Rights', 'Business Unit Rights', 'Usage Restrictions']
      let filters = this.facets.map(item => {
        let fieldPrompt = this.getFilterLabel(item.fieldPrompt)
        let valueList = item.valueList.map(vi => {
          return {
            ...vi,
            checked: false
          }
        });
        return { ...item, valueList, fieldPrompt, expand: false, isRightsFilter: (filedPropts.indexOf(item.fieldPrompt) >= 0) }
      })

      filters = this.setTheCheckState(filters)

      if (this.filters.length === 0) {
        this.filters = filters;
      } else {
        filters.forEach(item => {
          let fi = this.filters.find(_i => _i.fieldId === item.fieldId)
          if (fi) {
            item.expand = fi.expand
          }
        })
        this.filters = filters;
      }

    }
  }

  setTheCheckState(filters) {
    filters.forEach(item => {
      let oi = this.selectedFilters.find(_i => _i.fieldId === item.fieldId)
      if (oi) {
        let vl = oi.valueList.map(i => i.value)
        item.valueList.forEach(element => {
          element.checked = vl.indexOf(element.value) >= 0
        });
      }
    })

    return filters;
  }

  filters: any[] = [];

  resetFilters(filters) {
    this.filters = filters;
  }

  resetFilterStates() {

    this.filters.forEach(item => {
      if (this.rightFiltersUnits.indexOf(item.fieldPrompt) >= 0 && this.rightFilterEnabled) {
        return;
      }
      item.valueList = item.valueList.map(_i => {
        return {
          ..._i,
          checked: false
        }
      })
    })

  }

  getRightFilters() {
    return this.rightFilters;
  }

  getFilters() {
    return this.filters;
  }

  getNonRightFilters() {
    return this.nonRightFilters;
  }

  mappedFacets() {
    return this.facets.map(item => {
      let valueList = item.valueList;
      return {
        ...item,
        expand: false
      }
    })
  }

  expandFilters(state, isRight: boolean = false) {
    if (isRight) this.filters.filter(item => item.isRightsFilter).forEach(item => item.expand = state)
    else this.filters.forEach(item => item.expand = state)
  }

  getFilterOptions() {
    return {
      filters: this.getFilters(),
      rightFilters: this.getRightFilters(),
      nonRightFilters: this.getNonRightFilters()
    }
  }

  isKeyWordNull() {
    return this.keyword.length === 0
  }

  private __selected_filters = []
  set selectedFilters(filters) {
    this.__selected_filters = filters;
  }

  get selectedFilters() {
    return this.__selected_filters;
  }

  get rightFilterEnabled(): boolean {
    return this.ffuFilterStatus === 'enabled';
  }

  private _filter_updated: boolean = false;
  set filterUpdated(status: boolean) {
    this._filter_updated = status;
  }
  get filterUpdated(): boolean {
    return this._filter_updated;
  }


  manageUsageRestriction(){
    if(this.SearchHelper_chkDUR){
      this.setFfuFilterStatus('disabled');
      this.toggleFfuFilter(!this.SearchHelper_chkDUR);
    }else{
      this.setFfuFilterStatus('enabled');
      this.toggleFfuFilter(!this.SearchHelper_chkDUR);
    }
  }

  manageAdaptationRights(){
    if(this.SearchHelper_chkDAR){
      this.setFfuFilterStatus('disabled');
      this.toggleFfuFilter(!this.SearchHelper_chkDAR);
    }else{
      this.setFfuFilterStatus('enabled');
      this.toggleFfuFilter(!this.SearchHelper_chkDAR);
    }
}

  manageBusinessUnitRights(){
    if(this.SearchHelper_chkDBUR){
      this.setFfuFilterStatus('disabled');
      this.toggleFfuFilter(!this.SearchHelper_chkDBUR);
    }else{
      this.setFfuFilterStatus('enabled');
      this.toggleFfuFilter(!this.SearchHelper_chkDBUR);
    }
  }

  manageRights(){
    if(this.SearchHelper_chkDBUR || this.SearchHelper_chkDAR || this.SearchHelper_chkDUR){
      this.setFfuFilterStatus('disabled');
      this.toggleFfuFilter(!(this.SearchHelper_chkDBUR || this.SearchHelper_chkDAR || this.SearchHelper_chkDUR));
    }else{
      this.setFfuFilterStatus('enabled');
      this.toggleFfuFilter(!(this.SearchHelper_chkDBUR || this.SearchHelper_chkDAR || this.SearchHelper_chkDUR));
    }
  }


}