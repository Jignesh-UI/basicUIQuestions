import { NgModule } from '@angular/core';
import { HttpInterceptorServiceProvider } from './http/http.interceptor';
import { HttpService } from './http/http.service';
import { ElementService } from './jQlite';
import { StorageService } from './storage.service';
import { UserService } from './User/user.service';
import { CommonService } from './common.service';
import { Broadcast } from './broadcast.service';
import { AssetService } from './assets/assets.service';
import { HttpClientModule } from '@angular/common/http';
import { SearchHelperService } from './search/search-helper.service';

@NgModule({
    imports: [
        HttpClientModule
    ],
    declarations: [],
    providers: [UserService, HttpInterceptorServiceProvider, HttpService, StorageService,
        ElementService,
        CommonService,
        Broadcast,
        AssetService,
        SearchHelperService
    ],
    exports: [],
})
export class ServiceModule { }
