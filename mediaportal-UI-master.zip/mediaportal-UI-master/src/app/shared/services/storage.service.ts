import { Injectable } from '@angular/core';
import { StorageDataTypes } from './storage.model';

@Injectable({ providedIn: 'root' })
export class StorageService {
    private type: string = 'localStorage';

    _storage: any;

    constructor() { }

    public use(type) {
        return new StorageService().setType(type);
    }

    get sessionStorage() {
        return this.use('sessionStorage')
    }

    get localStorage() {
        return this.use('localStorage')
    }

    setType(type) {
        this.type = type;
        return this;
    }

    setItem(name, data, dataType = '') {
        let type = typeof data;
        dataType = dataType || type;
        this.setStorage();
        data = this.transform(data, dataType);
        this._storage.setItem(name, data);
    }

    removeItem(name) {
        this.setStorage();
        this._storage.removeItem(name);
    }

    getItem(name) {
        this.setStorage();
        let data = this._storage.getItem(name);
        if (data === null) return '';
        return this.parse(JSON.parse(data))
    }

    private setStorage() {
        if (this.type === 'localStorage') return this._storage = localStorage;
        if (this.type === 'sessionStorage') return this._storage = sessionStorage;
        this._storage = localStorage;
        return this._storage;
    }

    parse({ type, value }) {
        switch (type) {
            case StorageDataTypes.string: return String(value); break;
            case StorageDataTypes.boolean: return Boolean(value); break;
            case StorageDataTypes.number: return Number(value); break;
            case StorageDataTypes.object: return value; break;
            default: return JSON.parse(value); break;
        }
    }

    transform(data, dataType, reverse = false) {
        if (typeof data === dataType && dataType === 'object') {
            return JSON.stringify({ type: dataType, value: data })
        }
        return JSON.stringify({ type: dataType, value: data });
    }
}