import { NgModule } from '@angular/core';
import { FlexDirective, Layout, LayoutAlign, OffsetDirective, RightClickDisabled } from './directive/general.directive';
import { IconComponent } from './icon/icon.component';
import { CommonModule } from '@angular/common';
import { ErrorMessageComponent } from './components/errors/error-message/error-message.component';
import { MdContentComponent } from './components/legacy/md-content/md-content.component';
import { MdDialogComponent } from './components/legacy/md-dialog/md-dialog.component';
import { OrderbyPipe } from './pipes/orderby.pipe';
import { AngularResizeDirective } from './directive/angular-resize.directive';
import { MdDialogContentComponent } from './components/legacy/md-dialog-content/md-dialog-content.component';
import { PopupComponent } from './components/popoups/success/popup.component';
import { ResizableDirective } from './directive/resizable';
import { MdToolbarComponent } from './components/legacy/md-toolbar/md-toolbar.component';
import { ConfirmComponent } from './components/popoups/confirm/confirm.component';
import { MdInputContainerComponent } from './components/legacy/md-input-container/md-input-container.component';
import { MdButtonComponent } from './components/legacy/md-button/md-button.component';
import { MatButtonModule } from '@angular/material/button';
import { MdSidenavComponent } from './components/legacy/md-sidenav/md-sidenav.component';
import { SystemNotifcationComponent } from '../modules/login/components/system-notifcation/system-notifcation.component';

@NgModule({
    imports: [
        CommonModule,
        MatButtonModule
    ],
    declarations: [
        FlexDirective,
        LayoutAlign,
        OffsetDirective,
        RightClickDisabled,
        IconComponent,
        Layout,
        ErrorMessageComponent,
        MdContentComponent,
        MdDialogComponent,
        OrderbyPipe,
        AngularResizeDirective,
        ResizableDirective,
        MdDialogContentComponent,
        PopupComponent,
        MdToolbarComponent,
        ConfirmComponent,
        MdInputContainerComponent,
        MdButtonComponent,
        MdSidenavComponent,
        SystemNotifcationComponent
    ],
    providers: [],
    exports: [
        FlexDirective,
        LayoutAlign,
        OffsetDirective,
        RightClickDisabled,
        IconComponent,
        MdButtonComponent,
        Layout,
        ErrorMessageComponent,
        MdContentComponent,
        MdDialogComponent,
        OrderbyPipe,
        AngularResizeDirective,
        ResizableDirective,
        MdDialogContentComponent,
        PopupComponent,
        MdInputContainerComponent,
        MdSidenavComponent, 
        SystemNotifcationComponent
    ],
})
export class SharedModule { }
