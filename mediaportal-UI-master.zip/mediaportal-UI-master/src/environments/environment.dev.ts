export const environment = {
  production: true,
  baseUrl: '/mediaportal/services/api/'
};
