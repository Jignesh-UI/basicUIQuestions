"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
var home_component_1 = require("./home/home.component");
var asset_component_1 = require("./assets/asset.component");
var adv_search_component_1 = require("./assets/search/adv.search.component");
var inventory_component_1 = require("./inventory/inventory.component");
var maintenance_component_1 = require("./maintenance/maintenance.component");
var fuel_component_1 = require("./fuel/fuel.component");
var accounting_component_1 = require("./accounting/accounting.component");
var vendor_component_1 = require("./vendor/vendor.component");
var setup_component_1 = require("./setup/setup.component");
var reports_component_1 = require("./reports/reports.component");
exports.router = [
    { path: 'home', component: home_component_1.homeComponent },
    { path: 'assets', component: asset_component_1.assetComponent },
    { path: 'assetsAdvSearch', component: adv_search_component_1.assetsAdvSearchComponent },
    { path: 'inventory', component: inventory_component_1.inventoryComponent },
    { path: 'maintenance', component: maintenance_component_1.maintComponent },
    { path: 'fuel', component: fuel_component_1.fuelComponent },
    { path: 'accounting', component: accounting_component_1.accountComponent },
    { path: 'vendor', component: vendor_component_1.vendorComponent },
    { path: 'setup', component: setup_component_1.setupComponent },
    { path: 'reports', component: reports_component_1.reportComponent },
    { path: '', redirectTo: 'assets', pathMatch: 'full' },
    { path: '**', redirectTo: 'assets' }
];
exports.routes = router_1.RouterModule.forRoot(exports.router);
//# sourceMappingURL=app.routes.js.map