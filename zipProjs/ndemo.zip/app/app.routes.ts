import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { appComponent } from './app.component';
import { homeComponent } from './home/home.component';
import { assetComponent } from './assets/asset.component';
import { assetsAdvSearchComponent } from './assets/search/adv.search.component';
import { inventoryComponent } from './inventory/inventory.component';
import { maintComponent } from './maintenance/maintenance.component'
import { fuelComponent } from './fuel/fuel.component';
import { accountComponent } from './accounting/accounting.component';
import { vendorComponent } from './vendor/vendor.component';
import { setupComponent } from './setup/setup.component';
import { reportComponent } from './reports/reports.component';

export const router: Routes = [

    { path: 'home', component: homeComponent },
    { path: 'assets', component: assetComponent },
    { path: 'assetsAdvSearch', component: assetsAdvSearchComponent },
    { path: 'inventory', component: inventoryComponent },
    { path: 'maintenance', component: maintComponent },
    { path: 'fuel', component: fuelComponent },
    { path: 'accounting', component: accountComponent },
    { path: 'vendor', component: vendorComponent },
    { path: 'setup', component: setupComponent },
    { path: 'reports', component: reportComponent },
    { path: '', redirectTo: 'assets', pathMatch: 'full' },
    { path: '**', redirectTo: 'assets' }
];


export const routes: ModuleWithProviders = RouterModule.forRoot(router);