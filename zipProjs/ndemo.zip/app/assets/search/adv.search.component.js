"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
var assets_adv_service_1 = require("../../services/assets/assets.adv.service");
require("rxjs/add/observable/throw");
require("rxjs/add/operator/map");
require("rxjs/add/operator/catch");
var assetsAdvSearchComponent = (function () {
    function assetsAdvSearchComponent(_assetService, http) {
        this._assetService = _assetService;
        this.http = http;
        this.assetData = [];
    }
    assetsAdvSearchComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.pageSize = 10;
        this._assetService.get().subscribe(function (resAssetData) { return _this.assetData = resAssetData; }, function (error) { return _this.error = error; });
    };
    return assetsAdvSearchComponent;
}());
assetsAdvSearchComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'assetAdvSearch',
        templateUrl: 'assetsAdvSearchComponent.html'
    }),
    __metadata("design:paramtypes", [assets_adv_service_1.AdvanceSearchAssetsService, http_1.Http])
], assetsAdvSearchComponent);
exports.assetsAdvSearchComponent = assetsAdvSearchComponent;
//# sourceMappingURL=adv.search.component.js.map