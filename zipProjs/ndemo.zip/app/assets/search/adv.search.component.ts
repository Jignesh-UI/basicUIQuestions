import { Component, OnInit } from '@angular/core';
import { HttpModule, Http } from '@angular/http';

import { AdvanceSearchAssetsService } from '../../services/assets/assets.adv.service';

import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Component({
    moduleId: module.id,
    selector: 'assetAdvSearch',
    templateUrl: 'assetsAdvSearchComponent.html'
})
export class assetsAdvSearchComponent {
    assetData = [];
    error;
    pageSize;

    constructor(private _assetService: AdvanceSearchAssetsService, private http: Http) { }
    ngOnInit() {
        this.pageSize=10;
        this._assetService.get().subscribe(resAssetData => this.assetData = resAssetData,
            (error) => this.error = error);
    }
}