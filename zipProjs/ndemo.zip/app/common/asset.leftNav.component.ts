import { Component, OnInit } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'assetLeftNav',
    templateUrl: '../../templates/leftNavigation.html',
})
export class assetLeftnavComponent implements OnInit {
    constructor() {
    }

    ngOnInit() { }
}