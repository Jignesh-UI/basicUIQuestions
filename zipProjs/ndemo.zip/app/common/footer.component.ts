import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'footerTemplate',
    templateUrl: '../../templates/footer.html',
})
export class footerComponent {
    componentName: footerComponent
    constructor() {

    }
}