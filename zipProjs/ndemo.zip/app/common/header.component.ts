import {Component,OnInit} from '@angular/core';

@Component({
    moduleId:module.id,
    selector:'headerTemplate',
    templateUrl:'../../templates/header.html'
})

export class headerComponent{
    componentName:headerComponent
}