"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var fuelComponent = (function () {
    function fuelComponent() {
        this.employeeList = [
            { "name": "Jignesh", "role": "Self", "bDate": "28-11-1984", "occupation": "Service" },
            { "name": "Hasmukh", "role": "Father", "bDate": "01-03-1961", "occupation": "Service" },
            { "name": "Hetal", "role": "Wife", "bDate": "17-06-1983", "occupation": "House Hold" },
            { "name": "Janya", "role": "Son", "bDate": "22-10-2012", "occupation": "Study" },
            { "name": "Jignesh HUF", "role": "Owner of Family", "bDate": "22-10-2016", "occupation": "Business" }
        ];
    }
    return fuelComponent;
}());
fuelComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'fuel',
        template: '<h1>Fuel Component</h1>'
    })
], fuelComponent);
exports.fuelComponent = fuelComponent;
//# sourceMappingURL=fuel.component.js.map