import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';



@Component({
  moduleId: module.id,
  selector: 'fuel',
  template: '<h1>Fuel Component</h1>'
})


export class fuelComponent {
  componentName: 'fuelComponent'
  employeeList = [
    { "name": "Jignesh", "role": "Self", "bDate": "28-11-1984", "occupation": "Service" },
    { "name": "Hasmukh", "role": "Father", "bDate": "01-03-1961", "occupation": "Service" },
    { "name": "Hetal", "role": "Wife", "bDate": "17-06-1983", "occupation": "House Hold" },
    { "name": "Janya", "role": "Son", "bDate": "22-10-2012", "occupation": "Study" },
    { "name": "Jignesh HUF", "role": "Owner of Family", "bDate": "22-10-2016", "occupation": "Business" }
  ];
}



