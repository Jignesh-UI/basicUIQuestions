import { Component } from '@angular/core';
import {ActivatedRoute} from '@angular/router';


@Component({
    moduleId: module.id,
    selector: 'inventoryComponent',
    //templateUrl: 'app.component.html',
    template: '<h1>Inventory Component</h1>'
})
export class inventoryComponent {
    componentName:inventoryComponent
    constructor() {

    }
}