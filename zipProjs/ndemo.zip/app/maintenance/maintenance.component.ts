import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';


@Component({
    moduleId: module.id,
    selector: 'sd-app',
    //templateUrl: 'app.component.html',
    template: '<h1> Maintenance Component </h1>'
})
export class maintComponent {
    constructor() {

    }
}