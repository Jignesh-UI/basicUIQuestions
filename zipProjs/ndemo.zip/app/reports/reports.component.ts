import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';


@Component({
    moduleId: module.id,
    selector: 'reports',
    //templateUrl: 'app.component.html',
    template: '<h1>Reports Component</h1>'
})
export class reportComponent {
    componentName: reportComponent
    constructor() {

    }
}