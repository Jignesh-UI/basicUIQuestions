import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';


@Component({
    moduleId: module.id,
    selector: 'setup',
    //templateUrl: 'app.component.html',
    template: '<h1>Setup Component </h1>'
})
export class setupComponent {
    componentName: setupComponent
    constructor() {

    }
}