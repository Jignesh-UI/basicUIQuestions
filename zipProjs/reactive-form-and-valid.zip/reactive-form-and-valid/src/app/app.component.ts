import { Component, OnInit } from '@angular/core';
import { FormGroup, ValidationErrors, FormControl, FormArray, Validators, FormBuilder, NgForm } from '@angular/forms';
import { CustomValidators } from '../validators/custom-validators';
import { ServerValidation } from '../validators/server-validation';
import { ServerError } from '../validators/server-error.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  private myForm: FormGroup; 
  constructor(private fb: FormBuilder) {
  }

  ngOnInit() {
    this.myForm = this.fb.group({
      'name': ['', Validators.compose([Validators.required, Validators.maxLength(10)]), CustomValidators.uniqueName],
      'birthYear': ['', [Validators.required, CustomValidators.birthYear]],
      'location': this.fb.group({
        'country': ['', Validators.compose([Validators.required, Validators.maxLength(5)])],
        'city': ''
      }),
      'phoneNumbers': this.fb.array([this.buildPhoneNumberComponent()])
    },
      {
        validator: Validators.compose([CustomValidators.countryCity, CustomValidators.telephoneNumbers])
      }
    );
  }

  remove(i: number) {
    (<FormArray>this.myForm.controls.phoneNumbers).removeAt(i);
  }

  add() {
    (<FormArray>this.myForm.controls.phoneNumbers).push(this.buildPhoneNumberComponent());
  }

  buildPhoneNumberComponent() {
    return new FormControl('', [Validators.required, CustomValidators.telephoneNumber]);
  }

  register() {
 // call the following method when service through some error from the server ....
const serverErrors: ServerError[] = [
  {  'validationKey' : 'required', 'controlName': 'name', 'message' : 'I am required' },
  {  'validationKey' : 'required', 'controlName': 'birthYear', 'message' : 'I am required-11' },
  {  'validationKey' : 'uniqueName', 'controlName': 'name', 'message' : 'I am unique' },
  {  'validationKey' : 'uniqueName', 'controlName': 'birthYear', 'message' : 'I am unique--33' }

];
    ServerValidation.doServerValidate(serverErrors, this.myForm);
 }

}
