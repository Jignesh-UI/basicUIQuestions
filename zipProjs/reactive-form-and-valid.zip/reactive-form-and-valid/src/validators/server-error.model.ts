
export interface ServerError {
    validationKey: string;
    controlName: string;
    message: string;
}
