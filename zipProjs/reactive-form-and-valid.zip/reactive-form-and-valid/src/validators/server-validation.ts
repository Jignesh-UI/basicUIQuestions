import { ServerError } from './server-error.model';
import { FormGroup } from '@angular/forms';
export class ServerValidation {

  static doServerValidate(serverErrors: ServerError[], form: FormGroup) {
        const distinctCtrls: any[] = serverErrors.map(item => item.controlName)
        .filter((value, index, self) => self.indexOf(value) === index);

         let  objString = '';

         for (const cName of distinctCtrls){

          for (const se of serverErrors)
          {
            if (se.controlName === cName) {
              objString += `"${se.validationKey}":{"message":"${se.message}"},`;
            }
          }
          objString = objString.replace(/,\s*$/, '');
          if (form.controls.hasOwnProperty(cName)) {
            form.get(cName).setErrors(JSON.parse(`{${objString}}`.trim()));
          objString = '';
          }
      }
      }
}
